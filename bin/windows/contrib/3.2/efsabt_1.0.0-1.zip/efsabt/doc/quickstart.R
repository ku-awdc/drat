## ---- echo = FALSE, include=FALSE----------------------------------------
set.seed(2015-04-05)
library('efsabt')

## ------------------------------------------------------------------------
fixed_parameters <- DefaultFixed(N=100, novel=FALSE)
variable_parameters <- DefaultVariable(novel=FALSE)

head(fixed_parameters)
variable_parameters

## ------------------------------------------------------------------------
temp_data <- matrix(runif(24 * 150 * 5, 10, 30), ncol = 5)
dem <- CreateGubbinsDemography(N=100, FixedParameters = fixed_parameters, 
	VariableParameters = variable_parameters, TemperatureData = temp_data)

## ------------------------------------------------------------------------
results <- FarmModel(dem, 150)
results$State[1:10,1:10]
results$Vectors[1:10,,10]

## ------------------------------------------------------------------------
simulations <- SimContainer(dem)

## ------------------------------------------------------------------------
sheep <- fixed_parameters$NumberSheep
cattle <- fixed_parameters$NumberCattle
ft <- as.integer(sheep > 0)  +  2* as.integer(cattle > 0)

simulations$AddGubbinsNetwork(FarmTypes = ft, xLocations = runif(100, 0, 50), yLocations = runif(100, 0, 50))

## ------------------------------------------------------------------------
simulations$AddSimulation(150)

## ------------------------------------------------------------------------
simulations$Infect(3)
simulations$Update(10)

## ------------------------------------------------------------------------
prevs <- simulations$GetPrevalences(Observed = FALSE, Cumulative = TRUE)
prevs
states <- simulations$GetStates()
states

## ------------------------------------------------------------------------
simulation_number <- simulations$AddSimulation(150)
simulations$RemoveSimulation(1)
simulation_number

## ------------------------------------------------------------------------
dem$SetInitialisationStates('Exposed', 3)

## ------------------------------------------------------------------------
results_1 <- RunSimulations(simulations, iterations = 50, replication = FALSE)

## ------------------------------------------------------------------------
rm(simulations)  # Remove the C++ objects
gc()  # Force R to release the memory associated with the C++ objects (optional)
simulations <- SimContainer(dem)

## ------------------------------------------------------------------------
source_farms <- sample(1:100, 2000, replace=TRUE)
dest_farms <- sample(1:100, 2000, replace=TRUE)
strengths <- runif(2000, 0.01, 0.10)

sparse_matrix <- data.frame(Source = source_farms, Destination = dest_farms, Probability = strengths)
sparse_matrix <- sparse_matrix[order(sparse_matrix[,1]),]

simulations$AddSparseMatrixNetwork(NumberOfAgents=100, SparseMatrix=sparse_matrix, InfectiousAgentProb=0.5)


## ------------------------------------------------------------------------
dem$GetInitialisationStates()[1:5]

## ------------------------------------------------------------------------
results_2 <- RunSimulations(simulations, iterations = 50, replication = FALSE)

## ------------------------------------------------------------------------
PlotSimulationComparison(results_1, results_2)

## ------------------------------------------------------------------------
sessionInfo()

