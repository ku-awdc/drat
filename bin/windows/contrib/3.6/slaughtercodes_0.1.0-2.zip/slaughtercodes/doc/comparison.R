## ------------------------------------------------------------------------

# Some data:
counts <- c(18,17,15,20,10,20,25,13,12)
outcome <- factor(c(1,2,3,1,2,3,1,2,3))

# A null model:
null <- glm(counts ~ 1, family = poisson)

# An alternative model:
alt <- glm(counts ~ outcome, family = poisson)

# Calculate a thousand bootstrapped likelihood ratio statistics:
ll <- matrix(nrow=10^3, ncol=2)
for(i in 1:nrow(ll)){
	# Data simulated under the null model:
	counts.sim <- simulate(null, 1)[[1]]

	# The likelihood of this data under the null model:
	null.sim <- glm(counts.sim ~ 1, family=poisson)
	ll[i,1] <- logLik(null.sim)

	# The likelihood of this data under the alternative model:
	alt.sim <- glm(counts.sim ~ outcome, family=poisson)
	ll[i,2] <- logLik(alt.sim)
}

# The observed likelihood of the null model:
logLik(null)

# The observed likelihood of the alternative model:
logLik(alt)

# What proportion of the bootstrapped likelihood ratios are more extreme than the one we observe:
sum(-2*ll[,1] + 2*ll[,2] >= -2*-26.11 + 2*-23.38) / nrow(ll)

# How does this compare to a standard LRT under a Chi-square distribution:
1 - pchisq(-2*-26.11 + 2*-23.38, 2)

# The same thing shown graphically:
hist(-2*ll[,1] + 2*ll[,2], breaks='fd', freq=FALSE, col='pink', border='pink')
abline(v = -2*-26.11 + 2*-23.38, col='blue', lwd=2)
curve(dchisq(x, 2), col='red', add=TRUE, lwd=2)


## ------------------------------------------------------------------------

library('lme4')
alt <- glmer(cbind(incidence, size - incidence) ~ period + (1 | herd), data = cbpp, family = binomial)
null <- glmer(cbind(incidence, size - incidence) ~ (1 | herd), data = cbpp, family = binomial)

library('slaughtercodes')
LRbootstrap(null, alt, mc.cores=2)


## ------------------------------------------------------------------------
citation('slaughtercodes')

## ------------------------------------------------------------------------
sessionInfo()

