## ---- echo = FALSE, include=FALSE---------------------------------------------
unlink("CowsExample", recursive=TRUE)
unlink("Example", recursive=TRUE)
newfiles <- list.files()
unlink(newfiles[!newfiles %in% currentfiles], recursive=TRUE)

