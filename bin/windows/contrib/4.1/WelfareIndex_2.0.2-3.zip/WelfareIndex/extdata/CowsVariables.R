vMortThreshold0 <- 2.25
vMortThreshold1 <- 4.5

