vMortThreshold0 <- 2
vMortThreshold1 <- 3.5

vTroughLengthPerPig <- 0.2

vWaterThreshold <- 20
