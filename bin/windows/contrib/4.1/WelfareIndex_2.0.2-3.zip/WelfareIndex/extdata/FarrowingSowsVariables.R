vMortThreshold0 <- 6
vMortThreshold1 <- 11
vMortThreshold2 <- 15
