#' @importFrom rJava .jinit .jcall .jnew
## Internal functions, not exported

find_table <- function(table, schema=NULL, sql=TRUE){

  if(!is.null(schema)) return(list(Table=table, Schema=schema))

  if(is.data.frame(table)){
    stopifnot(nrow(table)==1L)
    if("Schema" %in% names(table)) schema <- table[["Schema"]]
    stopifnot("Table" %in% names(table))
    table <- table[["Table"]]
    return(list(Table=table, Schema=schema))
  }

  if(sql){
    vs_list_tables() |>
      filter(.data$Table == table) ->
      matches
  }else{
    vs_directory() |>
      filter(.data$Table == table) ->
      matches
  }

  if(nrow(matches)==0L) stop("Specified table '", table, "' does not exist")
  if(nrow(matches)>1L) stop("Specified table '", table, "' has multiple matches: please specify schema")

  return(matches)
}

get_conn <- function(username = vs_username(), reset=FALSE, min_ram=8, type="JDBC"){

  if(type=="JDBC"){
    conn <- get_conn_jdbc(username=username, reset=reset, min_ram=min_ram)
  }else if(type=="DatabaseConnector"){
    stop("Not currently available")
    conn <- get_conn_dc(username=username, reset=reset, min_ram=min_ram)
  }else{
    stop("Unrecognised SQL connection type")
  }

  if(conn$new){
    expdt <- dbGetQuery(conn$conn, "select * from USER_USERS") |> pull("EXPIRY_DATE")
    cat("New SQL connection established via ", type, "\n** Remember to change your password before ", as.character(as.Date(expdt)), "!!! **\n", sep="")
  }

  return(conn$conn)
}

get_conn_jdbc <- function(username = vs_username(), reset=FALSE, min_ram=8){

  newconn <- FALSE
  if(isTRUE(reset) || is.null(vs_env$active) || !isTRUE(vs_env$active)){

    jpar <- getOption("java.parameters")
    if(is.null(jpar) || (length(jpar)==1L && jpar=="-Xmx512m")){
      options(java.parameters = "-Xmx8g")
    }

    if(isTRUE(vs_env$active)){
      warning("Resetting active database connection: you should re-extract any tables you wish to join on the server")
      dbDisconnect(vs_env$jdbcConnection)
      vs_env$jdbcConnection <- NULL
    }else{
      .jinit()
      jram <- .jcall(.jnew("java/lang/Runtime"), "J", "maxMemory") / 1e9
      if(jram < min_ram){
        warning('You only have ', round(jram, 2), 'GB of RAM available to JAVA - restart R and then run e.g. options(java.parameters = "-Xmx8g") BEFORE loading the vetstat (or rJava) package')
      }
    }

    cstr_obfs |>
      unserialize() |>
      data_decrypt("vetstat" |> charToRaw() |> sha256()) |>
      unserialize() ->
      cstr

    vs_env$jdbcDriver <- JDBC("oracle.jdbc.OracleDriver", classPath = system.file("thin_driver","ojdbc8.jar",package="vetstat"))
    vs_env$jdbcConnection <- dbConnect(vs_env$jdbcDriver, cstr, username, key_get("Oracle_VetStat", username=vs_username()))
    vs_env$active <- TRUE
    newconn <- TRUE
  }

  ss <- try({
    ## List obtained from the bottom of the backend-Oracle file:
    dbplyr_edition.JDBCConnection <<- dbplyr:::dbplyr_edition.Oracle
    sql_query_select.JDBCConnection <<- dbplyr:::sql_query_select.Oracle
    sql_query_upsert.JDBCConnection <<- dbplyr:::sql_query_upsert.Oracle
    sql_translation.JDBCConnection <<- dbplyr:::sql_translation.Oracle
    sql_query_explain.JDBCConnection <<- dbplyr:::sql_query_explain.Oracle
    sql_table_analyze.JDBCConnection <<- dbplyr:::sql_table_analyze.Oracle
    sql_query_save.JDBCConnection <<- dbplyr:::sql_query_save.Oracle
    sql_values_subquery.JDBCConnection <<- dbplyr:::sql_values_subquery.Oracle
    setdiff.JDBCConnection <<- dbplyr:::setdiff.tbl_Oracle
    sql_expr_matches.JDBCConnection <<- dbplyr:::sql_expr_matches.Oracle
    db_supports_table_alias_with_as.JDBCConnection <<- dbplyr:::db_supports_table_alias_with_as.Oracle
  })
  if(inherits(ss, "try-error")) warning("Unable to set one or more SQL translation method - please report this to Matt")

  #sql_translation.JDBCConnection <<- dbplyr:::sql_translation.Oracle
  #sql_select.JDBCConnection <<- dbplyr:::sql_query_select.Oracle
  #sql_subquery.JDBCConnection <<- dbplyr:::sql_query_wrap.Oracle

  return(list(conn=vs_env$jdbcConnection, new=newconn))

}

get_conn_dc <- function(username = vs_username(), reset=FALSE, min_ram=8){

  newconn <- FALSE
  if(isTRUE(reset) || is.null(vs_env$active) || !isTRUE(vs_env$active)){

    jpar <- getOption("java.parameters")
    if(is.null(jpar) || (length(jpar)==1L && jpar=="-Xmx512m")){
      options(java.parameters = "-Xmx8g")
    }

    if(isTRUE(vs_env$active)){
      warning("Resetting active database connection: you should re-extract any tables you wish to join on the server")
      dbDisconnect(vs_env$jdbcConnection)
      vs_env$jdbcConnection <- NULL
    }else{
      .jinit()
      jram <- .jcall(.jnew("java/lang/Runtime"), "J", "maxMemory") / 1e9
      if(jram < min_ram){
        warning('You only have ', round(jram, 2), 'GB of RAM available to JAVA - restart R and then run e.g. options(java.parameters = "-Xmx8g") BEFORE loading the vetstat (or rJava) package')
      }
    }

    cstr_obfs |>
      unserialize() |>
      data_decrypt("vetstat" |> charToRaw() |> sha256()) |>
      unserialize() ->
      cstr

    vs_env$jdbcDriver <- JDBC("oracle.jdbc.OracleDriver", classPath = system.file("DatabaseConnector","ojdbc8.jar",package="vetstat"))
    vs_env$jdbcConnection <- dbConnect(vs_env$jdbcDriver, cstr, username, key_get("Oracle_VetStat", username=vs_username()))
    vs_env$active <- TRUE
    newconn <- TRUE
  }

  return(list(conn=vs_env$jdbcConnection, new=newconn))

}


vs_env <- new.env()

cstr_obfs <- as.raw(c(0x58, 0x0a, 0x00, 0x00, 0x00, 0x03, 0x00, 0x04, 0x03,
  0x02, 0x00, 0x03, 0x05, 0x00, 0x00, 0x00, 0x00, 0x05, 0x55, 0x54,
  0x46, 0x2d, 0x38, 0x00, 0x00, 0x02, 0x18, 0x00, 0x00, 0x00, 0xbb,
  0xad, 0xb7, 0xe7, 0x0a, 0xc8, 0x91, 0x36, 0x86, 0x5f, 0xd9, 0x19,
  0xc3, 0xc2, 0x2c, 0x51, 0x08, 0x4f, 0xef, 0xac, 0x65, 0xe8, 0x2a,
  0xad, 0xa4, 0xc2, 0xa1, 0x01, 0x2b, 0x37, 0x7a, 0x15, 0x99, 0x16,
  0x86, 0xdf, 0x34, 0xe6, 0x4d, 0xad, 0x4e, 0x82, 0x5e, 0x6f, 0x6d,
  0x44, 0x96, 0x91, 0x7c, 0x77, 0xc6, 0x41, 0x45, 0xb3, 0xb6, 0x84,
  0x3a, 0x9e, 0xdf, 0x4d, 0xa7, 0x78, 0xcd, 0xb9, 0x79, 0x81, 0xab,
  0x66, 0x60, 0x31, 0xb8, 0x68, 0xfc, 0xa0, 0x8f, 0xcf, 0x14, 0x85,
  0x62, 0x99, 0x03, 0x4c, 0x27, 0xd1, 0xfc, 0xcf, 0x51, 0x45, 0x61,
  0xca, 0x6c, 0x0a, 0x08, 0xa3, 0xda, 0x59, 0x70, 0xbe, 0x25, 0xd5,
  0xdc, 0x8d, 0x27, 0x79, 0x62, 0x0b, 0x7c, 0x2c, 0x87, 0x45, 0x97,
  0x21, 0x11, 0xb7, 0xb4, 0x42, 0xbc, 0xce, 0x4b, 0xd7, 0x8a, 0x1e,
  0xeb, 0xc2, 0x02, 0xdc, 0x02, 0x5c, 0xd6, 0x64, 0x8e, 0xbb, 0x24,
  0xea, 0x47, 0xee, 0xa1, 0xf9, 0x21, 0x1a, 0x8b, 0xf9, 0xf7, 0xa1,
  0xed, 0xf7, 0x41, 0x80, 0x1c, 0x9a, 0xb0, 0x57, 0x7d, 0x83, 0xb4,
  0xf7, 0x3e, 0x98, 0x6a, 0x6e, 0xf9, 0x6c, 0xab, 0x14, 0xda, 0xfa,
  0x69, 0xb6, 0x04, 0x3e, 0xe6, 0xc2, 0xdd, 0xe8, 0x0b, 0x80, 0x8d,
  0x5a, 0xe6, 0x9a, 0xa3, 0x36, 0xdb, 0xef, 0xf0, 0xc5, 0xcf, 0x5e,
  0x00, 0x00, 0x04, 0x02, 0x00, 0x00, 0x00, 0x01, 0x00, 0x04, 0x00,
  0x09, 0x00, 0x00, 0x00, 0x05, 0x6e, 0x6f, 0x6e, 0x63, 0x65, 0x00,
  0x00, 0x00, 0x18, 0x00, 0x00, 0x00, 0x18, 0x54, 0xea, 0x92, 0xae,
  0x20, 0x66, 0x06, 0xd6, 0xc2, 0xa7, 0x13, 0x4a, 0xa1, 0x91, 0x5a,
  0x8f, 0x4f, 0xf6, 0xfb, 0x5f, 0x4f, 0x9e, 0xc8, 0x0e, 0x00, 0x00,
  0x00, 0xfe))
