library("vetstat")
library("tidyverse")
library("DBI")
library("keyring")

## Load and process datasets to use:
(load("/Volumes/Groups/IVH/Common/VETMYNdata/VetStat/Data/VetStat_raw/2022/vetstat_CHR_BESAETNING.Rdata"))
vetstat_CHR_BESAETNING |>
  select(BESAETNING_ID = ID, BESNR, DYREART_ID, CHR_ID) ->
  CHR_lookup

(load("/Volumes/Groups/IVH/Common/VETMYNdata/VetStat/Data/VetStat_raw/2022/vetstat_KONVERTERING_CHR_SRA_svin.Rdata"))
(load("/Volumes/Groups/IVH/Common/VETMYNdata/VetStat/Data/VetStat_raw/2022/vetstat_KONVERTERING_CHR_SRA_kvæg.Rdata"))
bind_rows(
  vetstat_KONVERTERING_CHR_SRA_svin |> select(-DW_ID),
  vetstat_KONVERTERING_CHR_SRA_kvæg |> select(-DW_ID)
) |>
  select(CHR_NR, DYRLAEGE_ID, DYREART, PRAKSIS_ID, GYLDIG_FRA, GYLDIG_TIL, AFTALETYPE) ->
  KONV_CHR_SRA

(load("/Volumes/Groups/IVH/Common/VETMYNdata/VetStat/Data/Data_suppl/2022/chr_herd_key.RData"))
chr_herd_key |>
  select(CHR_ID = CHR_VS, CHR_NR=CHR, DYREARTKODE=ID_species_VS, BESAETNING_ID=herd_nr_VS, BESNR=herd_nr, BESNR_TIDLIGERE = herd_nr_reg) ->
  CHR_BES_LOOKUP


## Change login to IVH owner and add tables:
conn <- vetstat:::get_conn(username=vs_username() |> str_c("[IVH]"), reset=TRUE)

# dbRemoveTable(conn, Id(schema = "IVH", table = "TEST2"))
dbWriteTable(conn, Id(schema = "IVH", table = "CHR_LOOKUP"), CHR_lookup, temporary=FALSE)
dbWriteTable(conn, Id(schema = "IVH", table = "KONV_CHR_SRA"), KONV_CHR_SRA, temporary=FALSE)
dbWriteTable(conn, Id(schema = "IVH", table = "CHR_BES_LOOKUP"), CHR_BES_LOOKUP, temporary=FALSE)


## Change user status back and check:
conn <- vetstat:::get_conn(username=vs_username(), reset=TRUE)
vs_list_tables() |> View()

CHR_LOOKUP2 <- vs_table("CHR_LOOKUP", "IVH")
nrow(CHR_lookup) == CHR_LOOKUP2 |> count() |> pull(n)

KONV_CHR_SRA2 <- vs_table("KONV_CHR_SRA", "IVH")
nrow(KONV_CHR_SRA) == KONV_CHR_SRA2 |> count() |> pull(n)

CHR_BES_LOOKUP2 <- vs_table("CHR_BES_LOOKUP", "IVH")
nrow(CHR_BES_LOOKUP) == CHR_BES_LOOKUP2 |> count() |> pull(n)


## Test joins across schema:
t1 <- vs_table("CHR_BES_LOOKUP", "IVH")
t2 <- vs_table("KONV_CHR_SRA", "IVH")
t3 <- vs_table("VT_VETSTAT_INDBERETNING_MV", "EKSTERN_KU")
left_join(t1, t2, by="CHR_NR") |> show_query()
left_join(t1, t3, by="CHR_ID") |> show_query()


## Example joins:
vs_table("CHR_BES_LOOKUP", "IVH") |>
  filter(CHR_NR %in% c("56871","52228","92425")) |>
  left_join(
    vs_table("VT_VETSTAT_INDBERETNING_MV", "EKSTERN_KU"),
    by="CHR_ID"
  ) |>
  show_query()


