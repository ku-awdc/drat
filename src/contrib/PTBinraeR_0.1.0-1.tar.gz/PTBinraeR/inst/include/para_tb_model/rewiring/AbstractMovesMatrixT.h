
// PTB-rewiring (bovine paratuberculosis and movements rewiring)
// =============================================================
// 
// Contributors and contact:
// -------------------------
// 
//     - Sandie Arnoux (sandie.arnoux@inrae.fr)
//     - Pauline Ezanno (pauline.ezanno@inrae.fr)
// 
//     INRAE, Oniris, BIOEPAR, 44300, Nantes, France
// 
// 
// How to cite:
// ------------
// 
//     P. Ezanno, S. Arnoux, A. Joly, R. Vermesse (2021). "Risk-based trade
//     movements to control bovine paratuberculosis at a regional scale",
//     submitted in Preventive Veterinary Medicine.
// 
// 
// License:
// --------
// 
//    Copyright 2018 INRAE
// 
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
// 
//        http://www.apache.org/licenses/LICENSE-2.0
// 
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

#ifndef PTBM_ABSTRACTMOVESMATRIX_H
#define PTBM_ABSTRACTMOVESMATRIX_H

#include <map>
#include <vector>
#include <string>
#include <memory>

#include "../Settings.h"

#include "../ParametersT.h"
#include "../MovementUnitT.h"
#include "../herd/HerdT.h"

namespace para_tb_model{

template<auto s_ctset>
class AbstractMovesMatrixT {
    using Parameters = ParametersT<s_ctset>;
    using AbstractMovesMatrix = AbstractMovesMatrixT<s_ctset>;

protected:
    std::map<int, std::map<int, std::vector<std::shared_ptr<MovementForMatrixT<s_ctset>>>>> mmvMovements;

public:
    AbstractMovesMatrixT();
    std::map<int, std::vector<std::shared_ptr<MovementForMatrixT<s_ctset>>>>& operator[] (int status);
    virtual void rewire(std::map<std::string, std::vector<MovementUnitT<s_ctset>>>& mvOutPendingMoves) = 0;
};

}

#include "AbstractMovesMatrixT.ipp"

#endif
