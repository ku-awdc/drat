
// PTB-rewiring (bovine paratuberculosis and movements rewiring)
// =============================================================
// 
// Contributors and contact:
// -------------------------
// 
//     - Sandie Arnoux (sandie.arnoux@inrae.fr)
//     - Pauline Ezanno (pauline.ezanno@inrae.fr)
// 
//     INRAE, Oniris, BIOEPAR, 44300, Nantes, France
// 
// 
// How to cite:
// ------------
// 
//     P. Ezanno, S. Arnoux, A. Joly, R. Vermesse (2021). "Risk-based trade
//     movements to control bovine paratuberculosis at a regional scale",
//     submitted in Preventive Veterinary Medicine.
// 
// 
// License:
// --------
// 
//    Copyright 2018 INRAE
// 
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
// 
//        http://www.apache.org/licenses/LICENSE-2.0
// 
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

#ifndef PTBM_ABSTRACTMOVESMATRIX_IPP
#define PTBM_ABSTRACTMOVESMATRIX_IPP

#include "AbstractMovesMatrixT.h"

namespace para_tb_model{

template<auto s_ctset>
AbstractMovesMatrixT<s_ctset>::AbstractMovesMatrixT(){
	Parameters& iParams = Parameters::getInstance();
    for (auto i = 0; i < iParams.herdStatusNb; ++i){
        for (auto j = 0; j < iParams.herdStatusNb; ++j){
            if (i != j){
                std::vector<std::shared_ptr<MovementForMatrixT<s_ctset>>> v;
                mmvMovements[i].emplace(j, v);
            }
        }
    }
}

template<auto s_ctset>
std::map<int, std::vector<std::shared_ptr<MovementForMatrixT<s_ctset>>>>& AbstractMovesMatrixT<s_ctset>::operator[] (int status){
    return mmvMovements[status];
}

}
#endif
