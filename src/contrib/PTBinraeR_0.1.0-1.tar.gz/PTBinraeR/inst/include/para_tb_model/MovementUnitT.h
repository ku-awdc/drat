
// PTB-rewiring (bovine paratuberculosis and movements rewiring)
// =============================================================
// 
// Contributors and contact:
// -------------------------
// 
//     - Sandie Arnoux (sandie.arnoux@inrae.fr)
//     - Pauline Ezanno (pauline.ezanno@inrae.fr)
// 
//     INRAE, Oniris, BIOEPAR, 44300, Nantes, France
// 
// 
// How to cite:
// ------------
// 
//     P. Ezanno, S. Arnoux, A. Joly, R. Vermesse (2021). "Risk-based trade
//     movements to control bovine paratuberculosis at a regional scale",
//     submitted in Preventive Veterinary Medicine.
// 
// 
// License:
// --------
// 
//    Copyright 2018 INRAE
// 
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
// 
//        http://www.apache.org/licenses/LICENSE-2.0
// 
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

#ifndef PTBM_MOVEMENTUNIT_H
#define PTBM_MOVEMENTUNIT_H

#include <string>
#include <memory>

#include "herd/AnimalT.h"

namespace para_tb_model{

template<auto s_ctset>
class MovementUnitFromDataT {
public:
    std::string destinationId;
    int age;
    int breed;
    MovementUnitFromDataT(std::string destId, int ageAtMove, int breedOfMove){
        destinationId = destId;
        age = ageAtMove;
        breed = breedOfMove;
    }
};

template<auto s_ctset>
class MovementUnitT {
    using Animal = AnimalT<s_ctset>;

public:
    std::string sourceId;
    int sourceStatus;
    int breed;
    std::shared_ptr<Animal> pAnimal;
    int rewiringType;
    MovementUnitT(std::string id, int status, int breedOfMove, std::shared_ptr<Animal> pAni, int rewType){
        sourceId = id;
        sourceStatus = status;
        breed = breedOfMove;
        pAnimal = pAni;
        rewiringType = rewType;
    }
    bool operator==(const MovementUnitT& iMovementUnit) const { //for tests
        return (sourceId == iMovementUnit.sourceId
                and sourceStatus == iMovementUnit.sourceStatus
                and breed == iMovementUnit.breed
                and pAnimal == iMovementUnit.pAnimal
                and rewiringType == iMovementUnit.rewiringType);
    }
};

template<auto s_ctset>
class MovementForMatrixT {
    using Animal = AnimalT<s_ctset>;

public:
    std::string sourceId;
    std::string destinationId;
    std::shared_ptr<Animal> pAnimal;
    MovementForMatrixT(std::string source, std::string dest, std::shared_ptr<Animal> pAni){
        sourceId = source;
        destinationId = dest;
        pAnimal = pAni;
    }
    bool operator!=(const MovementForMatrixT& iMovementForMatrix) const { //for tests
        return (sourceId != iMovementForMatrix.sourceId
                or destinationId != iMovementForMatrix.destinationId
                or pAnimal != iMovementForMatrix.pAnimal);
    }
};

}
#endif
