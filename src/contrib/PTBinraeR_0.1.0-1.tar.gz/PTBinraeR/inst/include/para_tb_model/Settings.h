/*
  Compile-time settings to facilitate use of the model in different contexts (command line vs R)
  
  Copyright Matt Denwood, Sandie Arnoux and Pauline Ezanno, 2025
  Distributed as part of para_tb_model with Apache License (version 2.0)
*/

#ifndef PTBM_SETTINGS_H
#define PTBM_SETTINGS_H

#include <vector>

namespace para_tb_model
{

  // Class for settings containing e.g. compile-time constants, including different return 
  // types that can be queried using decltype()
  // (MD will define this elsewhere for R so that Rcpp headers are not needed here) 
  struct Settings
  {
    int debug_level = 0;
    std::vector<double> container_type;
    //std::vector<std::string> container_type; //will it be necessary?
  };
  
  
} // para_tb_model

#endif // PTBM_SETTINGS_H
