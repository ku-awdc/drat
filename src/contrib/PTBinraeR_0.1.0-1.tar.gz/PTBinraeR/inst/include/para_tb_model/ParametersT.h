
// PTB-rewiring (bovine paratuberculosis and movements rewiring)
// =============================================================
// 
// Contributors and contact:
// -------------------------
// 
//     - Sandie Arnoux (sandie.arnoux@inrae.fr)
//     - Pauline Ezanno (pauline.ezanno@inrae.fr)
// 
//     INRAE, Oniris, BIOEPAR, 44300, Nantes, France
// 
// 
//     - Matt Denwood (md@sund.ku.dk)
// 
//     University of Copenhagen, Denmark
// 
// 
// How to cite:
// ------------
// 
//     P. Ezanno, S. Arnoux, A. Joly, R. Vermesse (2021). "Risk-based trade
//     movements to control bovine paratuberculosis at a regional scale",
//     submitted in Preventive Veterinary Medicine.
// 
// 
// License:
// --------
// 
//    Copyright 2018 INRAE
// 
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
// 
//        http://www.apache.org/licenses/LICENSE-2.0
// 
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

// MD: This is widely supported but technically not in the standard, so I would rather use header guards
// #pragma once

#ifndef PTBM_PARAMETERS_H
#define PTBM_PARAMETERS_H

#include <string>
#include <iostream>
#include <vector>
#include <random>

// MD: it is best to have the whole model within its own namespace:
namespace para_tb_model
{

// MD: can we change these enums to enum class to follow best practice?

namespace enumAnimal {
    enum AgeGroup {newBorn, unweanedCalf, weanedInCalf, weanedOutCalf, youngHeifer, heifer, cow};
    // S : susceptible
    // It : infected transiently infectious
    // Il : infected latent (non infectious)
    // Im : infected moderately infectious
    // Ih : infected highly infectious (possibly clinical)
    enum HealthStatus {S, It, Il, Im, Ih};
    enum AnimalExitReason{noExit, death, culling};
    enum HerdStatus{clean, A, B, C, Cp};
}

enum HerdHealthState { //only 5 are defined, so vShedPropThres size have to be <= 5
    //WARNING: if useHerdHistory, then eA is a AAA herd and eB is all others, but still keep records of both types of herd statuses in outputs : eAAA is herd "status" and eA is herd "state"...
    eA, eB, eC, eD, eE
};

enum RewiringTypes {
    //0: not rewired, 1: rewired in metapopulation, 2: rewired with "outside of metapopulation", 3: animal health state changed to S
    //4: equivalent animal not available in source herd so source will be from "outside" ("NA move"), 5: forbidden move (can't be rewired in metatpopulation) so source will be from "outside" ("broken move"),
    //6: "NA move" will come from an "outside" herd of the same or better status, 7: "broken move" will come from an "outside" herd of the same or better status
    eNotRewired, eRewiredInMetapop, eRewiredOutside, eHealthyAnimal, eNA, eBroken, eRewiredNA, eRewiredBroken
};

// MD: this is the template pattern we will use - note the change of name of the class to append T:
template<auto s_ctset>
class ParametersT {
  
  // MD: for convenience:
  using Parameters = ParametersT<s_ctset>;
  
protected:
    static Parameters *instance;
    ParametersT();

public:
    std::mt19937 gen;
    int runsNb;
    int yearsNb;
    int weeksNbPerYear;
    int daysNbPerYear;
    bool dontInfect;
    std::vector<std::string> vDataFiles;
    std::string dataPath;
    std::string resultsPath;
    std::string initCondFile;
    std::string herdsToRewireFile;
    std::string selectedHerdsFile;
    std::string initOutFile;
    std::string initInFile;
    std::string initPrevFile;
    std::string newMovesOutFile;
    bool isRewiringAllowed;
    bool doRewiring;
    bool doRewiringForOutside;
    bool doRewiringForbiddenMoves;
    bool doRewiringForBuyers;
    bool doRewiringForSellers;
    bool useSelectedHerdsToRewire;
    float propOfHerdsToRewire;
    float defaultCalfExpo;
    bool useCalfExpoForSelectedHerds;
    float calfExpoForSelectedHerds;
    bool useCalfExpoForSpecHerds;
    int specHerdForCalfExpo;
    float calfExpoForSpecHerds;
    bool useSelectedHerds;
    bool doSavingOfInitialInfection;
    bool doLoadingOfInitialInfection;
    bool doLoadingOfInitialPrev;
    bool useBreed;
    int breedToRewire;
    bool useHerdHistory;
    int herdStatusNb;
    bool useAnnualPrev;
    bool useSameSensitivity;
    bool usePurchaseProba;
    float probaToPurchaseS;
    bool areDetectedIhCulledEarlier;
    float cullingProbaOfDetectedIh;
    float propOfHerdsToInfect;
    int maxInitPrev;
    std::vector<float> vShedPropThres; //thresholds of shedders proportion to classify herds
    std::vector<float> vHerdPropPerStatus; //herd proportion per status defined by vShedPropThres
    std::vector<int> vAgeThresForMoves; //thresholds of age to classify movements
    std::vector<int> vAgeThres; //thresholds of age to classify per age groups
    std::vector<int> vWeeksNbPerDeathRate;
    int categoriesNbForCows;
    std::string outsideMetapop;
    int minWeekToUpdateHerdState;
    int maxWeekToUpdateHerdState;
    void printAll();
    
    int _totalTimeSteps;
    int _weekNumber;
    int _currentTime;

    double stderrGaussian;
    double meanGaussian;

    int _startGrazing;
    int _endGrazing;

    int _ageWeaning;
    int _ageGrazing;
    int _ageYoungHeifer;
    int _ageHeifer;
    int _ageFirstCalving;
    int _nbStagesOfLactation;

    int _durSusceptible;
    int _durShedding;
    int _durIl;
    int _durIm;

    double _deathRateIm;
    double _deathRateIh;
    double _cullingRateIm;
    double _cullingRateIh;
    double _cullingProbaIh;
    double _deathRateBactInside;
    double _deathRateBactOutside;
    double _cleaningCP;
    double _adultsTogether;

    bool _colostrumTR;
    bool _milkTR;
    bool _localTR;
    double _susceptibilityCoeff;
    double _infectiousDose;
    double _infGeneralEnv;
    double _infLocalEnv;
    double _infGrazing;
    double _infIngestion;

    double _infinuteroIt;
    double _infinuteroIl;
    double _infinuteroIm;
    double _infinuteroIh;

    double _qtyFaecesCnw;
    double _qtyFaecesCw;
    double _qtyFaecesHf;
    double _qtyFaecesAd;
    double _qtyMilkDrunk;
    double _qtyColoDrunk;
    double _qtyMilkProd;
    double _qtyColoProd;
    double _propLactatingCows;
    double _qtyMilkProdIl;
    double _qtyMilkProdIm;
    double _qtyMilkProdIh;
    double _alphaFaecesIt;
    double _betaFaecesIt;
    double _alphaFaecesIm;
    double _betaFaecesIm;
    double _alphaFaecesIh;
    double _betaFaecesIh;

    double _alphaMilkDirIm;
    double _betaMilkDirIm;
    double _alphaMilkDirIh;
    double _betaMilkDirIh;
    double _alphaMilkIndirIm;
    double _betaMilkIndirIm;
    double _alphaMilkIndirIh;
    double _betaMilkIndirIh;
    double _alphaColoDirIm;
    double _betaColoDirIm;
    double _alphaColoDirIh;
    double _betaColoDirIh;
    double _alphaColoIndirIm;
    double _betaColoIndirIm;
    double _alphaColoIndirIh;
    double _betaColoIndirIh;
    double _propExcreMilkIm;
    double _propExcreMilkIh;
    double _propExcreColoIm;
    double _propExcreColoIh;

    double _testSensitivityIt;
    double _testSensitivityIl;
    double _testSensitivityIm;
    double _testSensitivityIh;
    double _testSpecificity;

    // MD: this had to be moved to an inline definition:
    static Parameters& getInstance()
    {
      // MD: naked new here will leak memory - can we change the singleton pattern for something else?
      // or at least add a destructor (and then obey the rule of 5)?
      if (instance == NULL)
          instance = new Parameters();
      return *instance;      
    }
    
    static void kill();

    void updateAfterSetting();
    void initTime();
    void updateWeekNum();
};

// MD: moved from implementation to the header file to silence compiler warnings:
template<auto s_ctset>
ParametersT<s_ctset> *ParametersT<s_ctset>::instance = nullptr;

} // para_tb_model

#endif // PTBM_PARAMETERS_H
