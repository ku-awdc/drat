/*
  Import statements for header-only-library
  
  Copyright Matt Denwood, Sandie Arnoux and Pauline Ezanno, 2025
  Distributed as part of para_tb_model with Apache License (version 2.0)
*/

#ifndef PARA_TB_MODEL_H
#define PARA_TB_MODEL_H

#include "para_tb_model/Settings.h"
#include "para_tb_model/ParametersT.h"
#include "para_tb_model/ParametersT.ipp"
#include "para_tb_model/Utils.h"
#include "para_tb_model/BetaDistribution.h"
#include "para_tb_model/herd/map/MapSheddingT.h"
#include "para_tb_model/herd/map/MapSheddingT.ipp"
#include "para_tb_model/herd/map/MapInEnvironmentsT.h"
#include "para_tb_model/herd/map/MapInEnvironmentsT.ipp"
#include "para_tb_model/herd/RepetitionHerdStateT.h"
#include "para_tb_model/herd/RepetitionHerdStateT.ipp"
#include "para_tb_model/herd/AgeGroup/AnimalAgeGroupT.h"
#include "para_tb_model/herd/AgeGroup/AnimalAgeGroupT.ipp"
#include "para_tb_model/herd/AgeGroup/NewBornT.h"
#include "para_tb_model/herd/AgeGroup/NewBornT.ipp"
#include "para_tb_model/herd/AgeGroup/UnweanedCalfT.h"
#include "para_tb_model/herd/AgeGroup/UnweanedCalfT.ipp"
#include "para_tb_model/herd/AgeGroup/WeanedInCalfT.h"
#include "para_tb_model/herd/AgeGroup/WeanedInCalfT.ipp"
#include "para_tb_model/herd/AgeGroup/WeanedOutCalfT.h"
#include "para_tb_model/herd/AgeGroup/WeanedOutCalfT.ipp"
#include "para_tb_model/herd/AgeGroup/YoungHeiferT.h"
#include "para_tb_model/herd/AgeGroup/YoungHeiferT.ipp"
#include "para_tb_model/herd/AgeGroup/HeiferT.h"
#include "para_tb_model/herd/AgeGroup/HeiferT.ipp"
#include "para_tb_model/herd/AgeGroup/CowT.h"
#include "para_tb_model/herd/AgeGroup/CowT.ipp"
#include "para_tb_model/herd/AnimalT.h"
#include "para_tb_model/herd/AnimalT.ipp"
#include "para_tb_model/herd/HerdT.h"
#include "para_tb_model/herd/HerdT.ipp"
#include "para_tb_model/MetapopT.h"
#include "para_tb_model/MetapopT.ipp"
#include "para_tb_model/MovementUnitT.h"
#include "para_tb_model/rewiring/AbstractMovesMatrixT.h"
#include "para_tb_model/rewiring/AbstractMovesMatrixT.ipp"
#include "para_tb_model/rewiring/MovesMatrixT.h"
#include "para_tb_model/rewiring/MovesMatrixT.ipp"
#include "para_tb_model/rewiring/MovesRewiringT.h"
#include "para_tb_model/rewiring/MovesRewiringT.ipp"
#include "para_tb_model/ModelT.h"
#include "para_tb_model/ModelT.ipp"

#endif // PARA_TB_MODEL_H
