#' @name PTBinraeR-package
#' @aliases PTBinraeR
#' @title Risk-based trade movements to control bovine paratuberculosis at a regional scale
#'
#' @details
#' An R package wrapper containing header files for the above-named PTB model. Note that this package does not provide any mechanism to run the model - that functionality is provided by a different R package, linking to this one.
#'
#' ## To cite this package in publications use:
#' citation("PTBinraeR")
#'
#' @references
#' P. Ezanno, S. Arnoux, A. Joly, R. Vermesse (2021). "Risk-based trade movements to control bovine paratuberculosis at a regional scale", submitted to Preventive Veterinary Medicine.
#'
#' @keywords internal
"_PACKAGE"

## usethis namespace: start
## usethis namespace: end
NULL
