#' @title Examples of running the welfare index model
#' @name index_example

#' @description
#' This function retrieves an example dataset (for Cows), and automatically generates an R script to run the index model.  The script will also contain example code for retrieving the full distribution of measure/criteria/farm scores in R, and also (optionally) example code for customising weights, variables, measures, functions and the data key.

#' @seealso
#' \code{\link{WelfareIndex}}

#' @param folder a path specifying a folder to save results to (this folder will be created and must not already exist)

#' @param data_format the format of the data to retrieve; either 'excel' which creates an excel file, or 'list' which creates an Rsave file containing a named list of data frames (representing data that could be obtained within R from e.g. an SQL database)

#' @param write_script option to generate an example R script to run the model using this data

#' @param advanced option to give code that would be needed for modifying weights/measures/functions/keys in the R script

#' @param overwrite option to overwrite a folder/file with the same name as specified (if one already exists)


#' @rdname index_example
index_example <- function(folder=paste0(type, 'Example'), data_format='excel', write_script=FALSE, advanced=FALSE, overwrite=FALSE){
	
  type <- "Cows"
	type <- checktype(type)
	if(type=='Custom')
		stop('The Custom type is not available with this function')
	
	# posstypes <- c('excel','csv','list')
	posstypes <- c('excel','list')
	choice <- pmatch(tolower(data_format), tolower(posstypes))
	if(is.na(choice))
		stop(paste0('The specified data_format "', data_format, '" was not recognised, use one of the following:  ', paste(posstypes, collapse=', ')), call.=FALSE)
	
	data_format <- posstypes[choice]	
	
	# Disable option for now:
	run_script <- FALSE
	
	stopifnot(length(write_script)==1 && !is.na(write_script) && is.logical(write_script))
	stopifnot(length(run_script)==1 && !is.na(run_script) && is.logical(run_script))
	stopifnot(length(advanced)==1 && !is.na(advanced) && is.logical(advanced))
	if(!write_script && (run_script || advanced)){
		write_script <- TRUE
		warning('The write_script argument was set to TRUE because either run_script or advanced were set as TRUE')
	}
	
	if(file.exists(folder)){
		if(overwrite){
			unlink(folder, recursive=TRUE)
		}else{
			stop(paste0('The working directory "', folder, '" already exists'))
		}
	}
	wo <- dir.create(folder)
	if(!wo){
		stop('Unable to create a folder at the specified path')
	}
	
	swd <- getwd()

	# Needed for getting data relations and other things:
	out <- capture.output(model <- WelfareIndex(type))
	drs <- unique(model$GetKey()$DataRelation)
	
	## Example data is now only provided in Excel format:
	if(data_format=='excel'){
	  ## for(fn in paste0(type, c('','Mortality','Slaughter'), c('.xlsx','.csv','.csv'))){
	  for(fn in paste0(type, '.xlsx')){
	    fp <- system.file("extdata", "example_data", fn, package = "WelfareIndex")
			if(fp==""){
				stop(paste0('Unable to locate the "', fn, '" file inside the R package'))
			}
			if(grepl('\\.xlsx$',fn)){
			  sv <- 'Data.xlsx'
			}else{
			  sv <- gsub(type,'',fn)
			}
			file.copy(fp, file.path(folder, sv))
		}
	}else if(data_format=='csv'){
		for(fn in paste0(type,'_',drs,'.csv')){
			fp <- system.file("extdata", "example_data", fn, package = "WelfareIndex")
			if(fp==""){
				stop(paste0('Unable to locate the "', fn, '" file inside the R package'))
			}
			file.copy(fp, file.path(folder, gsub(paste0('^', type),'Data',fn)))
		}
	}else if(data_format=='list'){
	  for(fn in paste0(type, '.xlsx')){
	    fp <- system.file("extdata", "example_data", fn, package = "WelfareIndex")
	    if(fp==""){
	      stop(paste0('Unable to locate the "', fn, '" file inside the R package'))
	    }
	  }
		out <- capture.output(model$ReadData(fp, excel_names=TRUE, show_warnings=FALSE))
		data <- model$GetData(excel_names=FALSE)
		save(data, file=file.path(folder, 'data.Rsave'))
	}else{
		stop('Unrecognised data_format')
	}
	

	if(write_script){
		
		scriptpath <- file.path(folder, 'rscript.R')
		
		string <- paste0('### An example R script produced for animal type ', type, ' on ', as.character(Sys.time()), ' using WelfareIndex version ', packageDescription('WelfareIndex')$Version, '###')
		hashs <- gsub('.','#',string)
	
		cat(hashs, '\n', string, '\n', hashs, '\n\n', sep='', file=scriptpath, append=FALSE)
		
		cat('# Load the package:\nlibrary("WelfareIndex")\n\n', sep='', file=scriptpath, append=TRUE)

		cat('# Create the IndexModel with a "year 0" baseline score:\nmodel <- WelfareIndex("', type, '", baseline=75)\n\n', sep='', file=scriptpath, append=TRUE)
		
		if(advanced){
			
		  cat('# Write the weights to file for editing:\nmodel$WriteWeights("Weights.csv")\n# You can open and edit this file in OpenOffice as necessary\n', sep='', file=scriptpath, append=TRUE)
		  cat('# Then re-load the weights from the file:\nmodel$ReadWeights("Weights.csv")\n', sep='', file=scriptpath, append=TRUE)
		  cat('# Alternatively you can edit the weights in R:\nweights <- model$GetWeights()\n# Edit weights as required:\nhead(weights)\nmodel$SetWeights(weights)\n\n', sep='', file=scriptpath, append=TRUE)
		  
		  cat('# Write the variables to file for editing:\nmodel$WriteVariables("Variables.R")\n# You can open and edit this file in a text editor or RStudio as necessary\n', sep='', file=scriptpath, append=TRUE)
		  cat('# Then re-load the variables from the file:\nmodel$ReadVariables("Variables.R")\n', sep='', file=scriptpath, append=TRUE)
		  cat('# Alternatively you can set individual variables in R:\nmodel$ResetVariables(vMortThreshold1 = 5.0)\n\n', sep='', file=scriptpath, append=TRUE)
		  
			cat('# The measures, functions and data key all need to be written before modifying any of them:\n# Write the measures to file for editing:\nmodel$WriteMeasures("Measures.csv")\n# Write the functions to file for editing:\nmodel$WriteFunctions("Functions.R")\n# Finally, write the data key to file for editing:\nmodel$WriteKey("Key.csv")\n# You can open and edit the measures and data key files in OpenOffice, and the functions file in a text editor, as necessary\n\n', sep='', file=scriptpath, append=TRUE)

			cat('# Then re-load the measures from the file:\nmodel$ReadMeasures("Measures.csv")\n', sep='', file=scriptpath, append=TRUE)
			cat('# Then re-load the functions from the file:\nmodel$ReadFunctions("Functions.R")\n', sep='', file=scriptpath, append=TRUE)
			cat('# Then re-load the key from the file:\nmodel$ReadKey("Key.csv")\n\n', sep='', file=scriptpath, append=TRUE)
			
		}else{
			
			cat('# Write the data key to file for inspection:\nmodel$WriteKey("Key.csv")\n# You can open and examine this file in OpenOffice\n\n', sep='', file=scriptpath, append=TRUE)
		
		}
		
		if(data_format=='excel'){
			
			cat('# Load the Excel file(s) of data:\nmodel$ReadData("Data.xlsx", output="data_problems.txt")\n\n', sep='', file=scriptpath, append=TRUE)
			
			# cat('# Extract the CHR and VistDate information:\nwhichfarms <- model$GetCHRdates()\nwhichfarms\n', sep='', file=scriptpath, append=TRUE)
			
			if(FALSE && type %in% c('Cows', 'Calves')){

				cat('# Read the mortality data file (this could also be using haven::read_sas etc):\n', sep='', file=scriptpath, append=TRUE)
				cat('mortality <- read.csv("Mortality.csv", sep=",", dec=".", stringsAsFactors=FALSE)\n\n', sep='', file=scriptpath, append=TRUE)
				
				cat('# Extract and convert the relevant data for these farms:\n', sep='', file=scriptpath, append=TRUE)
				cat('mortality <- extract_mortality(mortality, whichfarms, "BESAETNING_NR", "MAANED", "AAR", "ANTAL_DOEDE_KOEER", "ANTAL_AARSKOEER", Months=12)\n\n', sep='', file=scriptpath, append=TRUE)
				
				cat('# Load the data into the model:\n', sep='', file=scriptpath, append=TRUE)
				cat('model$SetData(list(Mortality=mortality))\n\n', sep='', file=scriptpath, append=TRUE)
				
				if(type=='Cows'){
					cat('# Read the slaughter data file (this could also be using haven::read_sas etc):\n', sep='', file=scriptpath, append=TRUE)
					cat('slaughter <- read.csv("Slaughter.csv", sep=",", dec=".", stringsAsFactors=FALSE)\n\n', sep='', file=scriptpath, append=TRUE)
				
					cat('# Filter the data to only the relevant animal group:\n', sep='', file=scriptpath, append=TRUE)
					cat('slaughter$SLAGTEDATO <- as.Date(slaughter$SLAGTEDATO)\nslaughter$FOEDSESLDATO <- as.Date(slaughter$FOEDSESLDATO)\nslaughter <- slaughter[as.numeric(difftime(slaughter$SLAGTEDATO, slaughter$FOEDSESLDATO, units="days")) > 180,]\n\n', sep='', file=scriptpath, append=TRUE)
				
					cat('# Extract and convert the relevant data for these farms:\n', sep='', file=scriptpath, append=TRUE)
					cat('slaughter <- extract_slaughter(codes=list(Pyemia=141, LiverDisease=c(375,381), HealedFracture=c(505,507)), slaughter, whichfarms, "BESNR", "SLAGTEDATO", paste0("S",1:10), Days=365)\n\n', sep='', file=scriptpath, append=TRUE)

					cat('# Load the data into the model:\n', sep='', file=scriptpath, append=TRUE)
					cat('model$SetData(list(Slaughter=slaughter))\n\n', sep='', file=scriptpath, append=TRUE)
				}

			}else if(FALSE && type %in% c("FarrowingSows","SowsAndGilts","Weaners")){

				cat('# Read the mortality data file (this could also be using haven::read_sas etc):\n', sep='', file=scriptpath, append=TRUE)
				cat('mortality <- read.csv("Mortality.csv", sep=",", dec=".", stringsAsFactors=FALSE)\n\n', sep='', file=scriptpath, append=TRUE)
				
				cat('# Extract and convert the relevant data for these farms:\n', sep='', file=scriptpath, append=TRUE)
				cat('mortality <- extract_mortality(mortality, whichfarms, "CHR_NR", "MAANED", "AAR", "ANTAL_DOEDE_SOEER", "ANTAL_SOEER", Months=12)\n\n', sep='', file=scriptpath, append=TRUE)
				
				cat('# Load the data into the model:\n', sep='', file=scriptpath, append=TRUE)
				cat('model$SetData(list(Mortality=mortality))\n\n', sep='', file=scriptpath, append=TRUE)
				
				cat('# Read the slaughter data file (this could also be using haven::read_sas etc):\n', sep='', file=scriptpath, append=TRUE)
				cat('slaughter <- read.csv("Slaughter.csv", sep=",", dec=".", stringsAsFactors=FALSE)\n\n', sep='', file=scriptpath, append=TRUE)
			
				cat('# Filter the data to only the relevant animal group:\n', sep='', file=scriptpath, append=TRUE)
				if(type=='Weaners'){
					cat('slaughter[slaughter$SAVAEGT <= 120,]\n\n', sep='', file=scriptpath, append=TRUE)
				}else{
					cat('slaughter[slaughter$SAVAEGT > 120,]\n\n', sep='', file=scriptpath, append=TRUE)						
				}
			
				cat('# Extract and convert the relevant data for these farms:\n', sep='', file=scriptpath, append=TRUE)
				if(type=='Weaners'){
					cat('slaughter <- extract_slaughter(codes=list(LiverDisease=381, Pyemia=141, Endocarditis=230, Fracture=c(505,507), Osteomyelitis=511, TailBite=601, ShoulderWounds=615), slaughter, whichfarms, "SCHRNR", "SSLDATO", c(paste0("SKKBE0",1:9), "SKKBE10"), Days=365)\n\n', sep='', file=scriptpath, append=TRUE)
				}else{
					cat('slaughter <- extract_slaughter(codes=list(LiverDisease=381), slaughter, whichfarms, "SCHRNR", "SSLDATO", c(paste0("SKKBE0",1:9), "SKKBE10"), Days=365)\n\n', sep='', file=scriptpath, append=TRUE)
				}

				cat('# Load the data into the model:\n', sep='', file=scriptpath, append=TRUE)
				cat('model$SetData(list(Slaughter=slaughter))\n\n', sep='', file=scriptpath, append=TRUE)

			}
			
		}else if(data_format=='csv'){
			
			cat('# Load the CSV file(s) of data (including all DataRelations):\nmodel$ReadData("Data.csv", excel_names=FALSE, output="data_problems.txt")\n\n', sep='', file=scriptpath, append=TRUE)
			
			# cat('# Extract the CHR and VistDate information:\nwhichfarms <- model$GetCHRdates()\nwhichfarms\n\n', sep='', file=scriptpath, append=TRUE)
			
		}else if(data_format=='list'){

			cat('# Load the data into R from the Rsave file:\nload("Data.Rsave")\nnames(data)\nhead(data$Farm)\n# This would be the format of data that could come from e.g. an SQL database\n', sep='', file=scriptpath, append=TRUE)
			
			cat('# Load the data into the model:\nmodel$SetData(data)\n\n', sep='', file=scriptpath, append=TRUE)
			
			# cat('# Extract the CHR and VistDate information:\nwhichfarms <- model$GetCHRdates()\nwhichfarms\n\n', sep='', file=scriptpath, append=TRUE)
			
		}
		
		cat('# Run the model:\nmodel$RunModel()\n\n', sep='', file=scriptpath, append=TRUE)
		
		cat('# Extract all farm scores:\nfarmscores <- model$GetFarmScores()\nhead(farmscores)\n\n', sep='', file=scriptpath, append=TRUE)
		cat('# Set random anonymisation for CHR:\nmodel$SetAnonymisation()\n\n', sep='', file=scriptpath, append=TRUE)
		
		cat('# Extract the animal scores corresponding to the overall farm score, without identifying information:\nanimalscores <- model$GetAnimalScores(anonymise=TRUE)\nhead(animalscores)\n\n', sep='', file=scriptpath, append=TRUE)
		
		cat('# Get the index result:\nmodel$GetIndex()\n\n', sep='', file=scriptpath, append=TRUE)
		
		cat('# Write the index report to a file:\nmodel$WriteIndex("report.html")\n\n', sep='', file=scriptpath, append=TRUE)
		
		cat('\n', hashs, '\n\n', sep='', file=scriptpath, append=TRUE)
		
	}else{
		cat('Data was written to the "', folder, '" folder in your current working directory\n', sep='')
	}
	
}