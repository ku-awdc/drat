# Just in case I want to bring back the lower casing:
fakelower <- function(x) return(x)

verify_key <- function(inputkey, simple, relational, recnote){
	
	stopifnot(inherits(simple, 'character'))
	stopifnot(inherits(relational, 'list'))
	
	stopifnot(inherits(inputkey, 'data.frame'))
	
	if(!'ExcelColumn' %in% names(inputkey))
		inputkey$ExcelColumn <- inputkey$DataName
	
	if(!'ExcelSheet' %in% names(inputkey))
		inputkey$ExcelSheet <- inputkey$DataRelation
	
	if(!'Notes' %in% names(inputkey))
		inputkey$Notes <- ""
	
	if(!'NumUnits' %in% names(inputkey))
		inputkey$NumUnits <- ""
	

	reqcols <- c('DataName','DataRelation','MissingOK','Type','NumUnits','NumMin','NumMax','CategoriesValid','ExcelColumn','ExcelSheet','Notes')

	presentlower <- tolower(names(inputkey))
	if(any(table(presentlower)>1)){
		dupes <- names(table(presentlower))[table(presentlower)>1]
		wd <- which(presentlower %in% dupes)
		stop(paste('Duplicated column names (ignoring case) in the data key: ', paste(names(inputkey)[wd], collapse=', ')), call.=FALSE)
	}
	if(any(sapply(reqcols, function(x) return(sum(x==fakelower(names(inputkey)))))==0)){
		stop(paste('The following required columns are missing from the variable key: ', paste(reqcols[sapply(reqcols, function(x) return(sum(x==fakelower(names(inputkey)))))==0], collapse=', ')), call.=FALSE)
	}
		
	notallowed <- c('.', ',', '+','-','*','/','&','|','%','#','$','@','^',':',';','<','>','"',"'",'!','?',' ')
	
	datanamecol <- which(fakelower(gsub('[[:space:]]','',names(inputkey)))=='DataName')
	stopifnot(length(datanamecol)==1)
	orignames <- inputkey[[datanamecol]]
	present <- vapply(notallowed, function(x) return(grepl(x, orignames, fixed=TRUE)), FUN.VALUE=logical(length(orignames)))
	rows <- which(apply(present,1,any)) | is.na(orignames) | orignames==''
	if(length(rows)>0){
		stop(paste('Illegal characters found in DataName(s): ', paste(orignames[rows], ' (row ', rows, ')', sep='', collapse=', '), ' - you cannot use any of the following characters:  ', paste(notallowed, collapse=' '), ' (or spaces, including at the end of the text, or blank/missing entries)'), call.=FALSE)
	}

	datarelationcol <- which(fakelower(gsub('[[:space:]]','',names(inputkey)))=='DataRelation')
	stopifnot(length(datarelationcol)==1)
	origrelations <- inputkey[[datarelationcol]]
	present <- vapply(notallowed, function(x) return(grepl(x, origrelations, fixed=TRUE)), FUN.VALUE=logical(length(origrelations)))
	rows <- which(apply(present,1,any)) | is.na(orignames) | orignames==''
	if(length(rows)>0){
		stop(paste('Illegal characters found in DataRelation(s): ', paste(origrelations[rows], ' (row ', rows, ')', sep='', collapse=', '), ' - you cannot use any of the following characters:  ', paste(notallowed, collapse=' '), ' (or spaces, including at the end of the text, or blank/missing entries)'), call.=FALSE)
	}
	
	repfun <- function(rows, plusone=FALSE){  #TODO# plusone argument not used anywhere
		if(length(rows) > 5){
			return(paste(paste(orignames[rows[1:5]], ' (row ', rows[1:5]+as.numeric(plusone), ')', sep='', collapse=', '), '[and others]'))
		}else{
			return(paste(orignames[rows], ' (row ', rows+as.numeric(plusone), ')', sep='', collapse=', '))
		}
	}
	
	
	notallowed <- c('|','#','$','@','^',':',';','<','>','"',"'")

	datanamecol <- which(fakelower(gsub('[[:space:]]','',names(inputkey)))=='ExcelSheet')
	stopifnot(length(datanamecol)==1)
	origsheets <- inputkey[[datanamecol]]
	present <- vapply(notallowed, function(x) return(grepl(x, origsheets, fixed=TRUE)), FUN.VALUE=logical(length(origsheets)))
	rows <- which(apply(present,1,any)) | is.na(orignames) | orignames==''
	if(length(rows)>0){
		stop(paste('Illegal characters found in ExcelSheet name(s): ', paste(origsheets[rows], ' (row ', rows, ')', sep='', collapse=', '), ' - you cannot use any of the following characters:  ', paste(notallowed, collapse=' '), ' (or spaces, including at the end of the text, or blank/missing entries)'), call.=FALSE)
	}

	datanamecol <- which(fakelower(gsub('[[:space:]]','',names(inputkey)))=='ExcelColumn')
	stopifnot(length(datanamecol)==1)
	origcols <- inputkey[[datanamecol]]
	present <- vapply(notallowed, function(x) return(grepl(x, origcols, fixed=TRUE)), FUN.VALUE=logical(length(origcols)))
	rows <- which(apply(present,1,any)) | is.na(orignames) | orignames==''
	if(length(rows)>0){
		stop(paste('Illegal characters found in ExcelColumn name(s): ', paste(origcols[rows], ' (row ', rows, ')', sep='', collapse=', '), ' - you cannot use any of the following characters:  ', paste(notallowed, collapse=' '), ' (or spaces, including at the end of the text, or blank/missing entries)'), call.=FALSE)
	}
	
	# Preserve spaces and capitals etc for Notes and NumUnits columns:
	notes <- inputkey$Notes
	nu <- inputkey$NumUnits
	inputkey <- sanitise(inputkey, lowerise=FALSE)
	inputkey$Notes <- notes
	inputkey$NumUnits <- nu

	stopifnot(all(reqcols %in% names(inputkey)))
	inputkey <- inputkey[,reqcols]
		
	# Numeric min and max can be defined in another column within the same sheet:
	# numcols <- c('num_min', 'num_max')
	# for(i in 1:length(numcols)){
	#	s <- try(inputkey[,numcols[i]] <- makenumbers(inputkey[,numcols[i]]), silent=TRUE)
	#	if(inherits(s, 'try-error')){
	#		stop(paste('There was an error processing the ', numcols[i], ' column: ', gsub('\n','',as.character(s),fixed=TRUE), sep=''))
	#	}
	# }
	
	origtypes <- inputkey$Type
	inputkey$Type <- factor(tolower(gsub(' ','',inputkey$Type)), levels=c('date','time','numeric','integer','categorical','group'))
	if(any(is.na(inputkey$Type))){
		stop(paste('Unrecognised type(s) ', paste(unique(origtypes[is.na(inputkey$Type)]), collapse=', '), ' - type must be one of date, time, numeric, integer, categorical, or group', sep=''), call.=FALSE)
	}
	
	dns <- inputkey$DataName
	counts <- table(tolower(dns))
	counts <- counts[!names(counts)%in%c('visitdate','observer','chr')]
	rows <- which(dns %in% names(counts)[counts>1])
	if(length(rows)>0){
		stop(paste('Repeated DataName(s) (ignoring case): ', repfun(rows)), call.=FALSE)
	}
	
	# Backup check - can all names be parsed?
	temp <- as.environment(list())
	for(i in dns){
		success <- try({
			eval(parse(text = paste(i, '<- TRUE')))
		}, silent=TRUE)		
		if(inherits(success, 'try-error'))
			stop(paste('Unexpected illegal character in DataName ', i, '(did you start the variable name with a number?)'), call.=FALSE)
	}
	
	

	required <- !is.na(inputkey$ExcelSheet) & inputkey$ExcelSheet!=''
	if(!all(required)){
		rows <- which(!required)
		stop(paste('DataName(s)', repfun(rows), 'have missing ExcelSheet information', sep=' '), call.=FALSE)
	}
	required <- inputkey$ExcelSheet == '__external__'  | (!is.na(inputkey$ExcelColumn) & inputkey$ExcelColumn!='')
	if(!all(required)){
		rows <- which(!required)
		stop(paste('DataName(s)', repfun(rows), 'have missing ExcelColumn information', sep=' '), call.=FALSE)
	}
	stopifnot(is.character(inputkey$ExcelColumn))
	stopifnot(is.character(inputkey$ExcelSheet))
	
	inputkey$MissingOK <- factor(tolower(gsub(' ','',inputkey$MissingOK)), levels=c('no','yes'))
	if(any(is.na(inputkey$MissingOK))){
		rows <- which(is.na(inputkey$MissingOK))
		stop(paste('DataName(s)', repfun(rows), 'have missing values in the MissingOK column', sep=' '), call.=FALSE)
	}

	isnum <- inputkey$Type %in% c('numeric','integer')
	isna <- is.na(inputkey)
	
	problems <- is.na(inputkey$NumMin) & inputkey$Type %in% c('numeric','integer')
	if(any(problems)){
		rows <- which(problems)
		stop(paste('DataName(s)', repfun(rows), 'are registered as numeric/integer so require valid numbers (or Inf, or a valid column name) in the NumMin column', sep=' '), call.=FALSE)
	}
	problems <- !is.na(inputkey$NumMin) & !inputkey$Type %in% c('numeric','integer')
	if(any(problems)){
		rows <- which(problems)
		stop(paste('DataName(s)', repfun(rows), 'are not registered as numeric/integer so cannot have anything in the NumMin column', sep=' '), call.=FALSE)
	}
	problems <- is.na(inputkey$NumMax) & inputkey$Type %in% c('numeric','integer')
	if(any(problems)){
		rows <- which(problems)
		stop(paste('DataName(s)', repfun(rows), 'are registered as numeric/integer so require valid numbers (or Inf, or a valid column name) in the NumMax column', sep=' '), call.=FALSE)
	}
	problems <- !is.na(inputkey$NumMax) & !inputkey$Type %in% c('numeric','integer')
	if(any(problems)){
		rows <- which(problems)
		stop(paste('DataName(s)', repfun(rows), 'are not registered as numeric/integer so cannot have anything in the NumMax column', sep=' '), call.=FALSE)
	}
	
	stopifnot(is.character(inputkey$CategoriesValid))
	problems <- is.na(inputkey$CategoriesValid) & inputkey$Type %in% c('categorical')
	if(any(problems)){
		rows <- which(problems)
		stop(paste('DataName(s)', repfun(rows), 'are registered as categorical so must have a valid entry in the CategoriesValid column', sep=' '), call.=FALSE)
	}
	problems <- inputkey$Type %in% c('categorical') & (sapply(strsplit(inputkey$CategoriesValid,'-',fixed=TRUE),length) < 2)
	if(any(problems)){
		rows <- which(problems)
		stop(paste('DataName(s)', repfun(rows), 'have only a single viable category - a minimum of 2 categories must be possible', sep=' '), call.=FALSE)
	}
	problems <- inputkey$Type %in% c('categorical') & (inputkey$CategoriesValid != tolower(inputkey$CategoriesValid))
	if(any(problems)){
		rows <- which(problems)
		stop(paste('DataName(s)', repfun(rows), 'have categories with uppercase letters - all categories must be specified as lowercase', sep=' '), call.=FALSE)
	}
	problems <- sapply(inputkey$CategoriesValid, function(x){
		x <- sepdash(x, oneok=TRUE)
		suppressWarnings(nums <- as.numeric(x))
		return(any(!is.na(nums)))
	})
	if(recnote && any(problems)){
		rows <- which(problems)
		cat(paste('NOTE: DataName(s)', repfun(rows), 'have categories that can be interpreted as numbers - this is not recommended', endl, sep=' '))
	}
	
	
	problems <- !is.na(inputkey$CategoriesValid) & !inputkey$Type %in% c('categorical')
	if(any(problems)){
		rows <- which(problems)
		stop(paste('DataName(s)', repfun(rows), 'are not registered as categorical so must have an empty CategoriesValid column', sep=' '), call.=FALSE)
	}
		
	
	# DataName -> observer, chr, visitdate, totalanimals (relation Farm) are required:
	#ok <- any(inputkey$DataRelation=='Farm' & inputkey$DataName=='Observer')
	#if(!ok){
	#	stop("Missing mandatory variable key entry for DataName 'Observer' with DataRelation Farm", call.=FALSE)
	#}
	#ok <- any(inputkey$DataRelation=='Farm' & inputkey$DataName =='Observer' & inputkey$Type=='categorical' & inputkey$MissingOK=='no')
	#if(!ok){
	#	stop("Observer (in sheet Farm) must be type categorical and not allow missing values", call.=FALSE)
	#}

	ok <- any(inputkey$DataRelation=='Farm' & inputkey$DataName =='CHR')
	if(!ok){
		stop("Missing mandatory variable key entry for DataName 'CHR' with DataRelation Farm", call.=FALSE)
	}
	ok <- any(inputkey$DataRelation=='Farm' & inputkey$DataName =='CHR' & inputkey$Type=='group' & inputkey$MissingOK=='no')
	if(!ok){
		stop("CHR (in sheet Farm) must be type group and not allow missing values", call.=FALSE)
	}

	#ok <- any(inputkey$DataRelation=='Farm' & inputkey$DataName =='VisitDate')
	#if(!ok){
	#	stop("Missing mandatory variable key entry for DataName 'VisitDate' with DataRelation Farm", call.=FALSE)
	#}
	#ok <- any(inputkey$DataRelation=='Farm' & inputkey$DataName =='VisitDate' & inputkey$Type=='date' & inputkey$MissingOK=='no')
	#if(!ok){
	#	stop("VisitDate (in sheet Farm) must be type date and not allow missing values", call.=FALSE)
	#}
	
	
	valid_data <- inputkey$DataName
	data_required <- unique(c(simple, unlist(relational)))
	
	# Check that all arguments specified in the functions are available in the data:
	if(!all(fakelower(data_required) %in% valid_data)){
		stop(paste('The following data is required by the functions but not stated in the key:', paste(data_required[! fakelower(data_required) %in% valid_data], collapse=', ')), call.=FALSE)
	}
	
	# Check that all relational data structures have the same relation:
	for(i in 1:length(relational)){
		dnames <- relational[[i]]
		fname <- gsub(' .*$', '', names(relational)[i])
		relations <- sapply(dnames, function(x) return(inputkey$DataRelation[inputkey$DataName==x]))
		stopifnot(is.character(relations) && length(relations)==length(dnames))
		if(!all(relations==relations[1])){
			stop(paste0('The ', fname,' function requires the specified data sources (', paste(dnames, collapse=', '), ') to have the same DataRelation, but the data key gives differing DataRelation (', paste(relations, collapse=', ')))
		}
	}
	# Check that all data with the same relation comes from the same sheet:
	allrelations <- unique(inputkey$DataRelation)
	if(any(is.na(allrelations))) stop("One or more 'DataRelation' are missing", call.=FALSE)
	for(i in 1:length(allrelations)){
		rel <- allrelations[i]
		sheets <- inputkey$ExcelSheet[inputkey$DataRelation==rel]
		if(!all(sheets==sheets[1])){
			stop(paste0('The ', sum(inputkey$DataRelation==rel), ' DataNames specified with DataRelation "', rel, '" are listed as coming from different ExcelSheets in Excel (', paste(unique(sheets), collapse=', '), ')'), call.=FALSE)
		}
	}
	
	# Find non-numeric Min/Max and check the variable is also specified as data in the same relation:
	minmaxdata <- character(0)
	for(i in 1:length(data_required)){
		dat <- data_required[i]
		whichrow <- which(inputkey$DataName == dat)
		stopifnot(length(whichrow)==1)
		rel <- inputkey$DataRelation[whichrow]
		
		min <- inputkey$NumMin[whichrow]
		max <- inputkey$NumMax[whichrow]
		suppressWarnings(nmin <- as.numeric(min))
		suppressWarnings(nmax <- as.numeric(max))
		
		if(!is.na(min) && is.na(nmin)){
			minmaxdata <- c(minmaxdata, min)
			if(!any(inputkey$DataName == min)){
				stop(paste('DataName', dat, 'has a non-numeric Min column', min, 'which does not match any DataName provided', sep=' '), call.=FALSE)
			}			
			if(inputkey$DataRelation[inputkey$DataName == min] != rel){
				stop(paste('DataName', dat, 'has a Min column given by DataName', min, 'which does not have a DataRelation of', rel, sep=' '), call.=FALSE)
			}
		}
		
		if(!is.na(max) && is.na(nmax)){
			minmaxdata <- c(minmaxdata, max)
			if(!any(inputkey$DataName == max)){
				stop(paste('DataName', dat, 'has a non-numeric Max column', max, 'which does not match any DataName provided', sep=' '), call.=FALSE)
			}
			if(inputkey$DataRelation[inputkey$DataName == max] != rel){
				stop(paste('DataName', dat, 'has a Max column given by DataName', max, 'which does not have a DataRelation of', rel, sep=' '), call.=FALSE)
			}
		}
	}
	
	# Find any data not needed by the functions and warn:
	allneeded <- c(data_required, minmaxdata, 'Farm', 'CHR', 'TotalAnimals')
	if(!all(valid_data %in% allneeded)){
		extra <- valid_data[! valid_data %in% allneeded]
		cat(paste('NOTE: The following data names are specified in the key but not required by the functions and will be ignored: ', paste(extra, collapse=', '), endl))
		inputkey <- inputkey[!inputkey$DataName %in% extra, ]
	}
	
	key <- as.data.frame(inputkey)
	
	# Sort alphabeticaly by relation then data:
	key <- key[order(key$DataRelation, key$DataName),]
	
	## Final check that CHR and VisitDate are actually called that:
	#if(!all(c("VisitDate", "CHR") %in% key$ExcelColumn)) stop("CHR and VisitDate must actually be ExcelColumn names, not just DataNames - sorry")

	return(key)
}

