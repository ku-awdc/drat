dfun_Piglets <-
list(RectalProlaps = function(NoPiglets, RectalProlaps){

	CheckNumeric( NoPiglets )
	CheckCategories( RectalProlaps , c("0", "1"))
	
	score0 <- WeightedNumber( RectalProlaps=="0" , NoPiglets) * wRectalProlaps0 
	score1 <- WeightedNumber( RectalProlaps=="1" , NoPiglets) * wRectalProlaps1

	score <- (score0 + score1) / sum(NoPiglets)

	return(score)
}, WaterClean = function(WaterPresent, WaterCleanliness, NoPiglets){
	
	CheckCategories( WaterPresent , c("present", "not_present"))
	CheckCategories( WaterCleanliness, c("clean", "dirty"))
	CheckNumeric( NoPiglets )
	
	# Creates a logical (TRUE, FALSE) vector, which is inverted (FALSE, TRUE) using ! :
	anycleanwater <- (WaterPresent=="present") & (WaterCleanliness=="clean")

	score0 <- WeightedNumber(anycleanwater, NoPiglets) * wWaterClean0
	score1 <- WeightedNumber(!anycleanwater, NoPiglets) * wWaterClean1
	
	score <- (score0 + score1) / sum(NoPiglets)
	
	return(score)
}, RestingArea = function(RestingArea, NoPiglets){

	CheckNumeric( RestingArea )
	CheckNumeric( NoPiglets )
	
	# 0.17 per piglet is optimal:
	nbatches <- length(RestingArea)
	scores <- numeric(nbatches)

	for(i in 1:nbatches){
		## NOTE: this was 0.169 but was changed to 0.17 at some point between Feb 2018 - March 2019:
		if(RestingArea[i] >= ( NoPiglets[i] * 0.17 )){
			scores[i] <- wRestingArea0
		# 0.169 changed to 0.17 here as well
		}else if(RestingArea[i] >= ( NoPiglets[i] * 0.17/2)){
			scores[i] <- wRestingArea1
		# Else score 2:
		}else{
			scores[i] <- wRestingArea2
		}
	}
	
	score <- WeightedAverage(scores, NoPiglets)
	return(score)
}, StockingDensity = function(AvailableArea, NoPiglets){

	CheckNumeric( AvailableArea )
	CheckNumeric( NoPiglets )

	# Logical - 0.2 per piglet is optimal requirement:
	optimumspace <- (AvailableArea > ( NoPiglets * 0.2 ))
	# Between 0.15 and 0.2 is OK
	okspace <- (AvailableArea <= ( NoPiglets * 0.2 )) & (AvailableArea >= ( NoPiglets * 0.15))
	# Less than 0.15 is bad:
	badspace <- (AvailableArea < ( NoPiglets * 0.15 ))
	
	# Check that only one of these is true for each group:
	stopifnot(all((optimumspace + okspace + badspace) == 1))
	
	# Weight these by the number of piglets:
	score0 <- WeightedNumber(optimumspace, NoPiglets) * wStockingDensity0
	score1 <- WeightedNumber(okspace, NoPiglets) * wStockingDensity1
	score2 <- WeightedNumber(badspace, NoPiglets) * wStockingDensity2
	
	score <- (score0 + score1 + score2) / sum(NoPiglets)
	
	return(score)
}, TeatAccess = function(NoPiglets, Hut_Width, Wall_Width){
	
	CheckNumeric( NoPiglets )
	CheckNumeric( Hut_Width )
	CheckNumeric( Wall_Width )
	
	nbatches <- length(NoPiglets)
	scores <- numeric(nbatches)
	for(i in 1:nbatches){
		if((Hut_Width[i] >= 0.56) & (Wall_Width[i] >= 0.56)){
			scores[i] <- wAccessTeats0
		}else{	
			scores[i] <- wAccessTeats1
		}
	}

	score <- WeightedAverage(scores, NoPiglets)

	return(score)
}, Lameness = function( NoPiglets, Lameness ){
	
	CheckNumeric( NoPiglets )
	CheckCategories( Lameness , c("0", "1"))
	
	score0 <- WeightedNumber( Lameness=="0" , NoPiglets) * wLameness0 
	score1 <- WeightedNumber( Lameness=="1" , NoPiglets) * wLameness1

	score <- (score0 + score1) / sum(NoPiglets)

	return(score)

}, Carpal = function( NoPiglets, NewCarpalLesions ){

	CheckCategories( NewCarpalLesions, c('0', '1','2') )
	CheckNumeric( NoPiglets )

	# This is observed at pen level, so score 0 is no piglets, score 1 is below 50% etc
	score0 <- WeightedNumberEqual( NewCarpalLesions, '0', NoPiglets) * wCarpal0
	score1 <- WeightedNumberEqual( NewCarpalLesions, '1', NoPiglets) * wCarpal1
	score2 <- WeightedNumberEqual( NewCarpalLesions, '2', NoPiglets) * wCarpal2
	
	score <- (score0 + score1 + score2) / sum(NoPiglets)	
	return(score)
}, Diarrhea = function( NoPiglets, DiarrheaPen){

	CheckNumeric( NoPiglets )
	CheckCategories( DiarrheaPen , c("0", "1"))
	
	score0 <- WeightedNumber( DiarrheaPen=="0" , NoPiglets) * wDiarrhea0 
	score1 <- WeightedNumber( DiarrheaPen=="1" , NoPiglets) * wDiarrhea1

	score <- (score0 + score1) / sum(NoPiglets)

	return(score)
}, SplayLeg = function( NoPiglets, SplayLeg ){

	CheckNumeric( NoPiglets )
	CheckCategories( SplayLeg , c("0", "1"))
	
	score0 <- WeightedNumber( SplayLeg=="0" , NoPiglets) * wSplayLeg0 
	score1 <- WeightedNumber( SplayLeg=="1" , NoPiglets) * wSplayLeg1

	score <- (score0 + score1) / sum(NoPiglets)

	return(score)
}, Castration = function(Castration_None, Castration_NoDrugs, Castration_WithDrugs){
		
	CheckPercent(Castration_None)
	CheckPercent(Castration_NoDrugs)
	CheckPercent(Castration_WithDrugs)
	
	## Sanity check:
	TotalPercent <- Castration_None + Castration_WithDrugs + Castration_NoDrugs
	if(abs(TotalPercent-100) > 2.5) stop("Total % castrated adds up to ", TotalPercent)
	
	# Weighted score according to the herd percentages:
	score <- WeightedAverage(c(wMethodCast0, wMethodCast1, wMethodCast2), c(Castration_None, Castration_WithDrugs, Castration_NoDrugs))
		
	return(score)
}, LesionsBody = function( NoPiglets, Lesions ){

	CheckNumeric( NoPiglets )
	CheckCategories( Lesions , c("0", "1"))
	
	score0 <- WeightedNumber( Lesions=="0" , NoPiglets) * wLesions0 
	score1 <- WeightedNumber( Lesions=="1" , NoPiglets) * wLesions1

	score <- (score0 + score1) / sum(NoPiglets)

	return(score)
}, Manure = function( NoPiglets, Dirty ){

	CheckNumeric( NoPiglets )
	CheckCategories( Dirty , c("0", "1", "2"))
	
	score0 <- WeightedNumber( Dirty=="0" , NoPiglets) * wManure0 
	score1 <- WeightedNumber( Dirty=="1" , NoPiglets) * wManure1
	score2 <- WeightedNumber( Dirty=="2" , NoPiglets) * wManure2

	score <- (score0 + score1 + score2) / sum(NoPiglets)

	return(score)
}, WaterSupply = function(WaterPresent, WaterFunctional, NoPiglets){

	CheckCategories( WaterPresent , c("present", "not_present"))
	CheckCategories( WaterFunctional, c("functional", "not_functional") )
	CheckNumeric( NoPiglets )
	
	# Doesn't matter if water is dirty or clean - but it must be present and functional:
	# Creates a logical (TRUE, FALSE) vector, which is inverted (FALSE, TRUE) using ! :
	anywater <- (WaterPresent=="present") & (WaterFunctional=="functional")
	  
	score0 <- WeightedNumber(anywater, NoPiglets) * wWaterSupply0
	score1 <- WeightedNumber(!anywater, NoPiglets) * wWaterSupply1
	  
	score <- (score0 + score1) / sum(NoPiglets)
	  
	return(score)  
}, HamperedResp = function( NoPiglets, HamperedResp ){

	CheckNumeric( NoPiglets )
	CheckCategories( HamperedResp , c("0", "1"))
	
	score0 <- WeightedNumber( HamperedResp=="0" , NoPiglets) * wHamperedResp0 
	score1 <- WeightedNumber( HamperedResp=="1" , NoPiglets) * wHamperedResp1

	score <- (score0 + score1) / sum(NoPiglets)

	return(score)

}, WeaningAge = function(WeanAgeMedian){

	CheckNumeric(WeanAgeMedian)
	CheckLength1(WeanAgeMedian)
	
	if(WeanAgeMedian>=28){
		score <- wWeanAgeMedian0
	}else if(WeanAgeMedian>=21){
		score <- wWeanAgeMedian1
	}else{
		score <- wWeanAgeMedian2
	}
	
	return(score)
}, EarNotching = function(EarNotch_None, EarNotch_Performed){
	
	CheckPercent(EarNotch_None)
	CheckPercent(EarNotch_Performed)

	## Sanity check:
	TotalPercent <- EarNotch_None + EarNotch_Performed
	if(abs(TotalPercent-100) > 2.5) stop("Total % ear notched adds up to ", TotalPercent)

	# Weighted score according to the herd percentages:
	score <- WeightedAverage(c(wEarNotch0, wEarNotch1), c(EarNotch_None, EarNotch_Performed))
	
	return(score)

}, RestingFloorType = function(RestType, NoPiglets){
	
	CheckCategories(RestType, c('bedding','solid','slatted','hardmat'))
	CheckNumeric(NoPiglets)

	# It is possible that more than 1 category are observed for each resting area type so a loop is required:
	scores <- numeric(length(NoPiglets))

	for(i in 1:length(scores)){
		# If bedding is present get the best score:
		if(RestType[i] %in% 'bedding'){
			scores[i] <- wRestType0
		# Otherwise, if either solid or hardmat (or both) are present get score 1:
		}else if(RestType[i] %in% c('solid','hardmat')){
			scores[i] <- wRestType1
		# Otherwise score 2:
		}else{
			scores[i] <- wRestType2	
		}
	}
	
	score <- WeightedAverage(scores, NoPiglets)
	
	return(score)
}, TeatsPerPiglet = function(NoPiglets, NumberOfTeats){

	CheckNumeric( NumberOfTeats )
	CheckNumeric( NoPiglets )
	
	# Creates a logical (TRUE, FALSE) vector, which is inverted (FALSE, TRUE) using ! :
	sufficient_teats <- (NumberOfTeats >= NoPiglets)
	
	score0 <- WeightedNumber(sufficient_teats, NoPiglets) * wTeatsPerPiglets0
	score1 <- WeightedNumber(!sufficient_teats, NoPiglets) * wTeatsPerPiglets1
	
	score <- (score0 + score1) / sum(NoPiglets)
	
	return(score)
}, ValidationCheck = function(TotalAnimals){
	
	CheckNumeric(TotalAnimals)
	
	return(TotalAnimals)

}, Neurological = function( NoPiglets, NeurSymptoms ){

	CheckNumeric( NoPiglets )
	CheckCategories( NeurSymptoms , c("0", "1"))
	
	score0 <- WeightedNumber( NeurSymptoms=="0" , NoPiglets) * wNeurological0 
	score1 <- WeightedNumber( NeurSymptoms=="1" , NoPiglets) * wNeurological1

	score <- (score0 + score1) / sum(NoPiglets)

	return(score)
}, TailDocking = function(TailDocking_None, TailDocking_NoDrugs, TailDocking_WithDrugs){
	
	CheckPercent(TailDocking_None)
	CheckPercent(TailDocking_NoDrugs)
	CheckPercent(TailDocking_WithDrugs)

	## Sanity check:
	TotalPercent <- TailDocking_None + TailDocking_WithDrugs + TailDocking_NoDrugs
	if(abs(TotalPercent-100) > 2.5) stop("Total % tail docked adds up to ", TotalPercent)

	# Weighted score according to the herd percentages:
	score <- WeightedAverage(c(wMethodTD0, wMethodTD1, wMethodTD2), c(TailDocking_None, TailDocking_WithDrugs, TailDocking_NoDrugs))
		
	return(score)

}, Runts = function( NoPiglets, Runts ){

	CheckCategories( Runts, c("0","1") )
	CheckNumeric( NoPiglets )

	score0 <- WeightedNumber(Runts=="0", NoPiglets) * wRunts0
	score1 <- WeightedNumber(Runts=="1", NoPiglets) * wRunts1

	score <- (score0 + score1) / sum(NoPiglets)
	return(score)
})
