
connect <- function(df, warn=TRUE){
	if(nrow(df)==0){
		if(warn)
			log$Warning('Attempting to load a data frame (', substitute(df), ') with 0 rows:  if relevant, you can avoid this error by first checking the number of rows of the data frame using nrow(', substitute(df), ')==0')
		
		invisible(FALSE)
	}
	
	rv <- lapply(1:ncol(df), function(x) assign(names(df)[x], df[[x]], envir=parent.frame(3)))
	invisible(TRUE)
}
Connect <- connect

disconnect <- function(df){
	
	currwarn <- getOption('warn')
	options(warn=2)
	tv <- try(rv <- lapply(1:ncol(df), function(x) rm(list=names(df)[x], envir=parent.frame(3))))
	options(warn=currwarn)
	
	if(inherits(tv, 'try-error')){
		stop(paste0('Failed to disconnect dataframe "', substitute(df), '" - maybe it has not yet been connected?'), call.=FALSE)
	}
	invisible(TRUE)	
}
Disconnect <- disconnect

CheckSampleSize <- function(x, ideal, min){
	
	xl <- NumberObs(x)
	if(!is.numeric(ideal) || length(ideal)!=1)
		stop('Second argument to CheckSampleSize is not a length 1 number')
	if(!is.numeric(min) || length(min)!=1)
		stop('Third argument to CheckSampleSize is not a length 1 number')
	if(min > ideal)
		stop('The third argument to CheckSampleSize must be less than the second argument')
	
	if(xl < min){
		log$Error('Sample size of', substitute(x), paste0('(',xl,')'), '< the minimum of', min)
	}else if(xl < ideal){
		log$Warning('Sample size of', substitute(x), paste0('(',xl,')'), '< the preferred value of', ideal)
	}
	invisible(TRUE)
}

CheckQBA <- function(x){
	stopifnot(is.numeric(x))
	if(length(x)>1){
		if(!all(x==x[1])){
			log$Error('More than 1 (non-identical observation)')
			return(NA)
		}
		log$Warning('More than 1 (identical) observation')
		x <- x[1]
	}	
	return(x)
}

GetLabel <- function(x){
	stopifnot(is.factor(x))
	stopifnot(length(x)==1)
	labs <- levels(x)
	stopifnot(all(as.numeric(labs)==labs))
	return(as.numeric(labs[as.numeric(x)]))
}
	
Total <- function(x){
	stopifnot(is.numeric(x))
	return(sum(x,na.rm=TRUE))
}

NumberObs <- function(x){
	
	# Probably a bad idea to let this be allowed for numeric and factor with different behaviour?
	if(FALSE){
		if(!is.factor(x))
			stop(paste(substitute(x), 'is not numeric or factor so cannot be used with NumberObs'))
	
		if(is.factor(x)){
			rv <- length(x)
		}else if(is.numeric(x)){
			if(any(abs(round(x)-x) > 10^-6))
				stop(paste(substitute(x), 'is not an integer so cannot be used with NumberObs'))
		
			rv <- sum(x)
		}else{
			stop(paste(substitute(x), 'is not numeric or factor so cannot be used with NumberObs'))
		}
		
	}
	
	if(inherits(x, 'data.frame')){
		rv <- nrow(x)
	}else{
		rv <- length(x)
	}
	
	return(rv)
}
NumberObservations <- NumberObs


Percent <- function(x){
	if(!is.logical(x))
		log$Error('Tried to use function Percent with a non-logical input')
	
	percent <- sum(x, na.rm=TRUE) / sum(!is.na(x)) *100
	
	if(!(length(percent)==1 && !is.na(percent) && percent >= 0 && percent <= 100))
		log$Error('The percentage of', substitute(x), 'was calculated outside the range 0-100')
	
	return(percent)
}

CheckPercent <- function(x){
	if(length(x)!=1)
		stop('Vector of length != 1 supplied to CheckPercent')
	
	if(!is.na(x) && (x < 0 || x > 100))
		log$Error('Value outside the range 0-100 supplied to CheckPercent')
}

PercentEqual <- function(x, comp){

	stopifnot(class(x)=='factor')
	stopifnot(all(comp %in% levels(x)))
	
	eq <- sum(x %in% comp, na.rm=TRUE)
	percent <- eq / sum(!is.na(x)) * 100
	if(!(length(percent)==1 && !is.na(percent) && percent >= 0 && percent <= 100))
		log$Error('The percentage of', substitute(comp), 'within', substitute(x), 'was calculated outside the range 0-100')
	
	return(percent)
}

NumberEqual <- function(x, comp){

	if(!is.factor(x))
		log$Error(substitute(x), 'is not a factor')
	
	if(!all(comp %in% levels(x)))
		log$Error(substitute(x), 'does not contain all of the levels specified')
		
	eq <- sum(x %in% comp, na.rm=TRUE)

	return(eq)
}

WeightedNumberEqual <- function(x, comp, number){

	if(!is.factor(x) && !is.numeric(x))
		log$Error(substitute(x), 'is not a factor/numeric')
	
	if(is.factor(x) && !all(comp %in% levels(x)))
		log$Error(substitute(x), 'does not contain all of the levels specified')
	
	if(!is.numeric(number))
		log$Error(substitute(number), 'is not a number')
		
	if(length(number)!=length(x))
		log$Error(substitute(x), 'and', substitute(number), 'do not have the same length')

	number <- number * as.logical(x %in% comp)
	
	return(sum(number, na.rm=TRUE))
}

WeightedNumber <- function(x, number){

	if(!is.logical(x))
		log$Error(substitute(x), 'is not a logical comparison')
	
	if(!is.numeric(number))
		log$Error(substitute(number), 'is not a number')
		
	if(length(number)!=length(x))
		log$Error(substitute(x), 'and', substitute(number), 'do not have the same length')

	number <- number * as.numeric(x)
	
	return(sum(number, na.rm=TRUE))
}

WeightedAverage <- function(x, number){

	if(!is.numeric(x))
		log$Error(substitute(x), 'is not a number')
	if(!is.numeric(number))
		log$Error(substitute(number), 'is not a number')
		
	newx <- x[!is.na(x) & !is.na(number) & x!=Inf & x!=-Inf]
	newnum <- number[!is.na(x) & !is.na(number) & x!=Inf & x!=-Inf]
	
	stopifnot(length(newx)==length(newnum))
	if(length(newx)==0){
		log$Error('One of', substitute(x), 'or', substitute(number), 'is always missing (or infinite)')
		return(NA)
	}
	
	# If all weights are 0 just use a simple mean:
	if(sum(newnum)==0)
		return(mean(x))
	
	# Apply weights:
	newx <- newx * newnum
	return(sum(newx) / sum(newnum))
	
}

NumberBetween <- function(x, lower, upper){

	if(!is.numeric(x))
		log$Error(substitute(x), 'is not numeric')
	if(!is.numeric(lower) || is.na(lower) || length(lower)!=1)
		log$Error(substitute(lower), 'is not numeric of length 1')
	if(!is.numeric(upper) || is.na(upper) || length(upper)!=1)
		log$Error(substitute(upper), 'is not numeric of length 1')
	
	if(! lower < upper)
		log$Error('The value provided for upper (', substitute(upper), ') is not greater than the value provided for lower (', substitute(lower), '). Note that the lower bound of the interval is closed and the upper is open (i.e. the same as cut(..., include.lowest=FALSE) ).')
	
	eq <- sum(x > lower & x <= upper, na.rm=TRUE)

	return(eq)
}

CheckLength1 <- function(x){

	if(length(x)!=1)
		log$Error(substitute(x), 'has length', length(x), '- should be length 1!')
	
}
CheckLengthOne <- CheckLength1


MostObserved <- function(x){
	
	stopifnot(any(is.na(x)))
	tabs <- table(na.omit(x))
	maxobs <- max(tabs)
	wh <- names(tabs)[which(tabs==maxobs)]
	return(paste(wh,collapse='/'))
}

CheckCategories <- function(x, categories=character(0)){
	
	if(!all(categories==tolower(categories)))
		log$Error('Uppercase characters provided in the categories for', substitute(x), '- all levels should be lowercase')
	
	if(!is.factor(x) && !is.multifactor(x))
		log$Error(substitute(x), 'is not a factor')
	
	if(!all(categories %in% levels(x)))
		log$Error(substitute(x), 'does not contain all of the levels specified: ', paste(levels(x), collapse=', '))

	if(!all(levels(x) %in% categories))
		log$Error(substitute(x), 'contains additional levels to those specified')
	
}

CheckNumeric <- function(x){
	
	if(!is.numeric(x) && !is.logical(x) && !inherits(x, 'POSIXct'))
		log$Error(substitute(x), 'is not numeric')

}

CheckRange <- function(x, lower, upper){
	
	if(length(lower)!=1 || is.na(lower) || !is.numeric(lower))
		log$Error('Lower range not valid for', substitute(x))
	if(length(upper)!=1 || is.na(upper) || !is.numeric(upper))
		log$Error('Upper range not valid for', substitute(x))
	
	if(!is.numeric(x))
		log$Error(substitute(x), 'is not numeric')
	
	if(length(x)!=1)
		log$Error(substitute(x), 'has length > 1')
	
	if(x < lower || x > upper)
		log$Error(substitute(x), 'is outside the given range (observed', x, 'but should be', paste0(lower, '-', upper,')'))
	
}

utility_functions <- list(
	connect = connect, 
	Connect = Connect, 
	disconnect = disconnect, 
	Disconnect = Disconnect, 
	CheckSampleSize = CheckSampleSize, 
	CheckQBA = CheckQBA, 
	GetLabel = GetLabel, 
	Total = Total, 
	NumberObs = NumberObs, 
	NumberObservations = NumberObservations, 
	Percent = Percent, 
	CheckPercent = CheckPercent, 
	PercentEqual = PercentEqual, 
	NumberEqual = NumberEqual, 
	WeightedNumberEqual = WeightedNumberEqual, 
	WeightedNumber = WeightedNumber, 
	WeightedAverage = WeightedAverage, 
	NumberBetween = NumberBetween, 
	CheckLength1 = CheckLength1, 
	CheckLengthOne = CheckLengthOne, 
	MostObserved = MostObserved, 
	CheckCategories = CheckCategories, 
	CheckNumeric = CheckNumeric, 
	CheckRange = CheckRange
)
