# Functions used by interface - not exported

parse_functions <- function(filename){
	
	stopifnot(length(filename)==1)
	if(!file.exists(filename)){
		stop('The file specified does not exist in the current working directory')
	}
	
	funenv <- list()
	funenv <- list2env(funenv, parent=as.environment('package:WelfareIndex'))
	
	tp <- try(eval(parse(filename), envir=funenv), silent=TRUE)
	if(inherits(tp, 'try-error')){
		stop(paste('An error occured while parsing the function file provided:\n', tp))
	}
	
	funs <- as.list(funenv)
	classes <- sapply(funs, class)
	if(any(classes != 'function')){
		stop(paste('The following object(s) did not parse to a function: ', paste(names(classes)[classes!='function'])))
	}
	
	if(length(funs)==0){
		stop('No valid functions were found in the file specified')
	}
	
	return(funs)
	
}

verify_functions <- function(funs, measuresdf, strict=FALSE){
	
	if(!inherits(funs, 'list')){
		stop('A list must be provided', call.=FALSE)
	}
	
	providedfuns <- names(funs)
	if(is.null(providedfuns) || any(is.na(providedfuns)) || any(providedfuns=="")){
		stop('Each function in the list must be named', call.=FALSE)
	}
	
	if(!all(sapply(funs, class)=='function')){
		stop('One or more items in the list is not a function', call.=FALSE)
	}
	
	# The list of known measures that the file should give:
	measurenames <- c('ValidationCheck', measuresdf$Measure)
	
	if(any(! measurenames %in% providedfuns)){
		whichnot <- measurenames[! measurenames %in% providedfuns]
		stop(paste('The following functions are required but not specified: ', paste(whichnot, collapse=', ')), call.=FALSE)
	}
	
	if(any(! providedfuns %in% measurenames)){
		whichnot <- providedfuns[! providedfuns %in% measurenames]
		if(strict){
			stop(paste('The following functions are specified but not required: ', paste(whichnot, collapse=', '), endl), call.=FALSE)
		}else{
			cat(paste('NOTE:  The following functions are specified but not required and will be ignored: ', paste(whichnot, collapse=', '), endl))
		}
		funs <- funs[providedfuns %in% measurenames]
		providedfuns <- names(funs)
	}
	
	# Check all functions have arguments:
	gotargs <- sapply(funs, function(x) return(length(formals(x))))
	if(!all(gotargs > 0)){
		stop(paste('The following function(s) are missing any arguments:', paste(names(gotargs)[!(gotargs > 0)], collapse=', ')), call.=FALSE)
	}
	
	# Get function arguments:
	funcheck <- lapply(1:length(funs), getdatanames, funs=funs, retdf=TRUE, persistent=FALSE)
	data_required <- unlist(lapply(funcheck, function(x) return(x$allvars)))
	dfnames <- unlist(lapply(funcheck, function(x) return(x$alldfvars)))		
	
	# Check the names of the data frames don't overlap with data that is being used:
	df_overlap <- unique(dfnames[tolower(dfnames) %in% data_required])

	if(length(df_overlap)>0)
		stop(paste('The following data.frame names overlap with the data names in the key and must be changed: ', paste(df_overlap, collapse=', ')), call.=FALSE)


	# Check that ValidationCheck uses only normal arguments:
	if(any(sapply(formals(funs$ValidationCheck), class)!='name')){
		stop('It is not possible (or necessary) to use data.frame or complex argument types with the ValidationCheck function - missing data are not removed and argument lengths may differ', call.=FALSE)
	}
	
	# Check that all functions use CheckXXX on each of the data needed and get the full set of (relational) data required:
	relationals <- vector('list', length=0)
	for(i in 1:length(funs)){
		funbod <- body(funs[[i]])
		alldata <- getdatanames(i, funs, retdf=FALSE, persistent=TRUE)
		for(j in alldata){
			cqba <- any(grepl(paste0('CheckQBA(', j, ')'), gsub(' ', '', funbod), fixed=TRUE))
			cnum <- any(grepl(paste0('CheckNumeric(', j, ')'), gsub(' ', '', funbod), fixed=TRUE))
			cper <- any(grepl(paste0('CheckPercent(', j, ')'), gsub(' ', '', funbod), fixed=TRUE))
			ccat <- any(grepl(paste0('CheckCategories(', j, ','), gsub(' ', '', funbod), fixed=TRUE))
			if(!any(cqba, cnum, cper, ccat)){
				stop(paste('Error in the function specifications provided:  \nThe data source', j, 'is not checked in the', names(funs)[i], 'function - ensure that all data sources have a call to CheckNumeric(), CheckPercent(), CheckCategories() or CheckQBA() before they are used'), call.=FALSE)
			}
		}
		
		# Check that all data frames are connected and disconnected:
		for(j in getdatanames(i, funs, retdf=TRUE)$alldfvars){
			fb <- paste(gsub(' ', '', funbod), collapse='\n')
			d1 <- sum(gregexpr(paste0('disconnect(', j, ')'), fb, fixed=TRUE)[[1]] >= 0)
			d2 <- sum(gregexpr(paste0('Disconnect(', j, ')'), fb, fixed=TRUE)[[1]] >= 0)
			c1 <- sum(gregexpr(paste0('connect(', j, ')'), fb, fixed=TRUE)[[1]] >= 0) - (d1+d2)  # Need to remove D/disconnect as a subset of this string
			c2 <- sum(gregexpr(paste0('Connect(', j, ')'), fb, fixed=TRUE)[[1]] >= 0)
			
			if(!(c1+c2) >0){
				stop(paste('Error in the function specifications provided:  \nThe data relation', j, 'is not connected in the', names(funs)[i], 'function - ensure that all data relations have a call to connect() before their variables are used'), call.=FALSE)
			}
			if(strict && !(d1+d2) >0){
				stop(paste('Error in the function specifications provided:  \nThe data relation', j, 'is not disconnected in the', names(funs)[i], 'function - ensure that all data relations have a call to disconnect() after their variables are used'), call.=FALSE)
			}
			if(strict && ! (c1+c2)==(d1+d2)){
				stop(paste('Error in the function specifications provided:  \nThe data relation', j, 'is connected', (c1+c2), 'times and disconnected', (d1+d2), 'times in the', names(funs)[i], 'function - ensure that each connect is matched by exactly 1 disconnect'), call.=FALSE)
			}
		}
		
		if(names(funs)[i]=='ValidationCheck'){
			# Within validation check these are all individually relational:
			for(j in 1:length(alldata)){
				newrel <- list(alldata[j])
				names(newrel) <- paste(names(funs)[i], j, sep=' ')
				relationals <- c(relationals, newrel)
			}
		}else{
			# Otherwise each data frame is its own relational database with the data grouped by this:
			newrel <- getdatanames(i, funs, retdf=FALSE, persistent=FALSE, retrel=TRUE)
			names(newrel) <- paste(names(funs)[i], 1:length(newrel), sep=' ')
			relationals <- c(relationals, newrel)
		}
	}
	
	# Separate relationals with a single data:
	lengths <- sapply(relationals, length)
	stopifnot(all(lengths > 0))
	simpledata <- relationals[lengths==1]
	relationaldata <- relationals[lengths>1]
	stopifnot((length(simpledata)+length(relationaldata))==length(relationals))
	# Don't make them unique so that the key checker can report all functions that need data that is missing!
	
	# Return the functions and their relational data requirements:
	return(list(funs=funs, simpledata=unlist(simpledata), relationaldata=relationaldata))
}

