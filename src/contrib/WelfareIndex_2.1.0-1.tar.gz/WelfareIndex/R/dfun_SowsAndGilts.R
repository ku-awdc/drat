dfun_SowsAndGilts <-
list(HamperedResp = function(HampResp_Individ){
	
	CheckCategories(HampResp_Individ, c('0','1'))
	
	w0 <- NumberEqual(HampResp_Individ, '0') * wHampResp0
	w1 <- NumberEqual(HampResp_Individ, '1') * wHampResp1
	
	score <- (w0 + w1) / NumberObs(HampResp_Individ)
	
	return(score)
}, ValidationCheck = function(TotalAnimals){  
	
	CheckNumeric(TotalAnimals)
	
	return(TotalAnimals)
}, Slipperiness = function(Slipperiness_Individ){
	
	CheckCategories(Slipperiness_Individ, c('0','1'))
	
	w0 <- NumberEqual(Slipperiness_Individ, '0') * wSlipperiness0
	w1 <- NumberEqual(Slipperiness_Individ, '1') * wSlipperiness1
	
	score <- (w0 + w1) / NumberObs(Slipperiness_Individ)
	
	return(score)
}, FeedingSystem = function(NoSows_Group, Feeding_system_Group, No_feeders_Group){
	
	CheckNumeric(NoSows_Group)
	CheckNumeric(No_feeders_Group)
	CheckCategories(Feeding_system_Group, c('adlibitum','closedautomat','openautomat','closedfeedingstall','openfeedingstall','trough','floorfeeding')) 
 	
	N <- length(NoSows_Group)
	scores <- numeric(N)
 	
	# Loop through each observation separately:
 	for(i in 1:N){
		# If there are 0 sows in the group then set the score to missing
		# (otherwise No_feeders_Group[i]/NoSows_Group[i] is undefined)
		if(NoSows_Group[i] <= 0){
			scores[i] <- NA
			next
		}
		
		# Three different options for getting the best score:
		if(Feeding_system_Group[i] %in% c('adlibitum')){
			scores[i] <- wFeeding_system0
		}else if(Feeding_system_Group[i]%in% c('closedautomat') & ((No_feeders_Group[i]/NoSows_Group[i]) >= (1/55))){
			scores[i] <- wFeeding_system0
		}else if(Feeding_system_Group[i]%in% c('closedfeedingstall') & ((No_feeders_Group[i]/NoSows_Group[i]) >= 1)){
			scores[i] <- wFeeding_system0
			# Otherwise get the worse score:
		}else if(Feeding_system_Group[i]%in% c('openfeedingstall', 'trough', 'floorfeeding', 'openautomat', 'closedautomat', 'closedfeedingstall')){
			# Note that the closedautomat and closedfeedingstall are only relevant if the above condition with feeders per sow is not met
			scores[i] <- wFeeding_system1
		}else{
			stop('Non-match found')
		}
	}	 
	
	return( WeightedAverage(scores, NoSows_Group) )	
}, RootingMaterial = function(Rooting_type_Group, NoSows_Group){

	CheckNumeric(NoSows_Group)
	CheckCategories(Rooting_type_Group, c('none', 'straw', 'rope', 'chain', 'softwood', 'hardwood', 'pellets/shavings/sawdust', 'hay', 'other'))
	
	N <- length(Rooting_type_Group)
	scores_group <- numeric(N)

	for(i in 1:N){
		if(Rooting_type_Group[i] %in% c('straw','hay')){
			scores_group[i] <- wRooting0
		}else if(Rooting_type_Group[i] %in% c('rope','pellets/shavings/sawdust')){
			scores_group[i] <- wRooting1
		}else if(Rooting_type_Group[i] %in% c('softwood','hardwood')){
			scores_group[i] <- wRooting2
		}else if(Rooting_type_Group[i] %in% c('chain','other')){
			scores_group[i] <- wRooting3
		}else if(Rooting_type_Group[i] %in% c('none')){
			scores_group[i] <- wRooting4
		}else{
			stop('Unrecognised category')				
		}
	}
	
	score <- WeightedAverage(scores_group, NoSows_Group)
	
	return(score)
	
}, Stereotypy = function(Individual=data.frame(Stereo_Individ), Group=data.frame(Stereo_Group, PantingStereo_NoSows)){
	
	# Calculate the mean individual score, if any animals are housed individually:
	if(nrow(Individual)==0){
		number_ind <- 0
		meanscore_ind <- NA
	}else{
		connect(Individual)
	
		CheckCategories(Stereo_Individ, c('0','1'))

		N <- length(Stereo_Individ)
		scores_ind <- numeric(N)
	
		for(i in 1:N){
			if(Stereo_Individ[i] %in% c('0')){
				scores_ind[i] <- wStereo0
			}else if(Stereo_Individ[i] %in% c('1')){
				scores_ind[i] <- wStereo1
			}else{
				stop('Unrecognised category')
			}
			
		}
		
		meanscore_ind <- mean(scores_ind)
		number_ind <- N

		disconnect(Individual)
	}
		
	
	# Calculate the mean group score, if any animals are housed in groups:
	if(nrow(Group)==0){
		number_group <- 0
		meanscore_group <- NA
	}else{
		connect(Group)
	
		CheckNumeric(PantingStereo_NoSows)
		CheckNumeric(Stereo_Group)
		
		N <- length(Stereo_Group)
		scores_group <- numeric(N)
	
		for(i in 1:N){
			
			if(Stereo_Group[i] > PantingStereo_NoSows[i]){
				stop("Stereo_Group[i] > PantingStereo_NoSows[i]")
			}
			
			# If there are 0 observed animals then the score is missing:
			if(PantingStereo_NoSows[i] == 0){
				scores_group[i] <- NA
			}else{
				proportion_with <- Stereo_Group[i] / PantingStereo_NoSows[i]
				proportion_without <- (PantingStereo_NoSows[i] - Stereo_Group[i]) / PantingStereo_NoSows[i]
				scores_group[i] <- (wStereo0 * proportion_without) + (wStereo1 * proportion_with)
			}
		}
		
		# If there are a total of 0 observed animals then the score is missing:
		if(sum(PantingStereo_NoSows[i]) == 0){
			meanscore_group <- NA
		}else{
			meanscore_group <- WeightedAverage(scores_group, PantingStereo_NoSows)
		}
		number_group <- sum(PantingStereo_NoSows)

		disconnect(Group)
	}
	
	# Check to see if a total of 0 animals were assessed:
	if((number_ind+number_group) == 0){
		return("A total of 0 animals were assessed")
	}
	
	# Calculate the weighted average from the two sets of animals:
	score <- WeightedAverage(c(meanscore_ind, meanscore_group), c(number_ind, number_group))
	
	return(score)
}, Bursitis = function(Bursitis_Individ){
	
	CheckCategories(Bursitis_Individ, c('0','1'))
	
	w0 <- NumberEqual(Bursitis_Individ, '0') * wBursitis0
	w1 <- NumberEqual(Bursitis_Individ, '1') * wBursitis1
	
	score <- (w0 + w1) / NumberObs(Bursitis_Individ)
	
	return(score)
}, RestingAreaFloortype = function(Resting_type_Group, NoSows_Group){
	
	CheckCategories(Resting_type_Group, c('deep','softmat','hardmat','solid','slatted/drained'))
	
	CheckNumeric(NoSows_Group)

	N <- length(NoSows_Group)
	scores <- numeric(N)

	for(i in 1:N){
		if(Resting_type_Group[i] %in% c('deep','softmat')) {
			scores[i] <- wResting_area_floortype_Group0
		}else if(Resting_type_Group[i] %in% c('hardmat')) {
			scores[i] <- wResting_area_floortype_Group1
		}else if(Resting_type_Group[i] %in% c('solid')) {
			scores[i] <- wResting_area_floortype_Group2
		}else if(Resting_type_Group[i] %in% c('slatted/drained')) {
			scores[i] <- wResting_area_floortype_Group3
		}else {
			stop("Resting type not recognised")
		}
	}
		
	return(WeightedAverage(scores, NoSows_Group))
}, Prolapse = function(Prolapse_Individ){
	
	CheckCategories(Prolapse_Individ, c('0','1'))
	
	N <- length(Prolapse_Individ)
	scores <- numeric(N)
	for(i in 1:N){
		# Either rectal or uterine prolapse (or both) gets the worse score:
		if(Prolapse_Individ[i]=='1'){
			scores[i] <- wProlapse1
		}else{
			scores[i] <- wProlapse0
		}
	}
	return(mean(scores))
}, HousingSystemService = function(Housing_unit_Individ, Housing_system){
	
	CheckCategories(Housing_unit_Individ, c('service','gestation'))
	CheckCategories(Housing_system, c('group','crated'))
	
	N <- length(Housing_unit_Individ)
 	scores <- numeric(N)
	
	for(i in 1:N){
		# We ignore all of the Housing_unit_Individ=='g' sows for this function:
		if(Housing_unit_Individ[i]=='gestation'){
			scores[i] <- NA
		}else if(Housing_unit_Individ[i]=='service' & Housing_system[i]=='group'){
			scores[i] <- wHousing_system_service0
		}else if(Housing_unit_Individ[i]=='service' & Housing_system[i]=='crated'){
			scores[i] <- wHousing_system_service1
		}else{
			stop('Unmatched condition')
		}
	}
	
 	# Note that if all Housing_unit_Individ=='gestation' then score will be missing:
	if(all(Housing_unit_Individ == 'gestation')){
		return("All sows are category gestation")
	}
 	
	# Otherwise we still need to remove missing here before calculating the mean:
 	score <- mean(scores, na.rm=TRUE)	

 	return(score)
}, TimeCratedService = function(TimeCrated_Service_median){
	
	CheckNumeric(TimeCrated_Service_median)
	CheckLength1(TimeCrated_Service_median)
	
	# NB this is recorded in time intervals!
	
	if(TimeCrated_Service_median < 0.001){
		score <- wTimeCrated_service0
	}else if(TimeCrated_Service_median >0 & TimeCrated_Service_median <=2) {
		score <- wTimeCrated_service1
	}else if(TimeCrated_Service_median >2 & TimeCrated_Service_median <=4) {
		score <- wTimeCrated_service2
	} else {
		score <- wTimeCrated_service3
	}
	return(score)
}, StockingDensity = function(Pen_area_Group, NoSows_Group, Animalgrp_Group){
	
	N <- length(Pen_area_Group)
	scores <- numeric(N)
	
	CheckCategories(Animalgrp_Group, c('sows','gilts','sowsandgilts'))
	CheckNumeric(Pen_area_Group)
	CheckNumeric(NoSows_Group)

	for(i in 1:N){

		# Work out how many sows and gilts are present:
		if(Animalgrp_Group[i]=='sows'){
			sows <- NoSows_Group[i]
			gilts <- 0
		}else if(Animalgrp_Group[i]=='gilts'){
			sows <- 0
			gilts <- NoSows_Group[i]
		}else if(Animalgrp_Group[i]=='sowsandgilts'){
			gilts <- NoSows_Group[i] / 2
			sows <- NoSows_Group[i] / 2
		}else{
			stop('Unrecognised code')
		}
		
		# Numbers below taken from the legislation:
		
		# For sows:
		if(sows <= 17){
			first4 <- min(4, sows)
			next6 <- max(0, min(6, sows-first4))
			other7 <- max(0, sows - (first4+next6))
			req_space <- first4 * 2.8 + next6 * 2.2 + other7 * 2
		}else if(sows <= 39){
			req_space <- sows * 2.25
		}else{
			req_space <- sows * 2.025
		}
		
		# For gilts:
		first10 <- min(10, gilts)
		next10 <- max(0, min(10, gilts-first10))
		rest <- max(0, gilts - (first10+next10))
		req_space <- req_space + first10 * 1.9 + next10 * 1.7 + rest * 1.5
		
		# Compare to what is available:
		if(Pen_area_Group[i] < req_space){
			scores[i] <- wStocking_density2
		}else if(Pen_area_Group[i] < (req_space * 1.2)){
			scores[i] <- wStocking_density1
		}else{
			scores[i] <- wStocking_density0
		}
	}
	
	score <- WeightedAverage(scores, NoSows_Group)
	return(score)
}, ShoulderWounds = function(Shoulder_Individ){
	
	CheckCategories(Shoulder_Individ, c('0','1','2'))
	
	w0 <- NumberEqual(Shoulder_Individ, '0') * wShoulder0
	w1 <- NumberEqual(Shoulder_Individ, '1') * wShoulder1
	w2 <- NumberEqual(Shoulder_Individ, '2') * wShoulder2
	
	score <- (w0 + w1 + w2) / NumberObs(Shoulder_Individ)
	
	return(score)
}, HousingSystemGestation = function(Housing_unit_Individ, Housing_system){
	
	CheckCategories(Housing_unit_Individ, c('service','gestation'))
	CheckCategories(Housing_system, c('group','crated'))

	N <- length(Housing_unit_Individ)
 	scores <- numeric(N)
	
	# We ignore all of the Housing_unit_Individ=='s' sows for this function:
	for(i in 1:N){
		if(Housing_unit_Individ[i]=='service'){
			scores[i] <- NA
		}else if(Housing_unit_Individ[i]=='gestation' & Housing_system[i]=='group'){
			scores[i] <- wHousing_system_gestation0
		}else if(Housing_unit_Individ[i]=='gestation' & Housing_system[i]=='crated'){
			scores[i] <- wHousing_system_gestation1
		}else{
			stop('Unmatched condition')
		}
	}

 	# Note that if all Housing_unit_Individ=='service' then score will be missing:
	if(all(Housing_unit_Individ == 'service')){
		return("All sows are category service")
	}
 	
	# Otherwise we still need to remove missing here before calculating the mean:
 	score <- mean(scores, na.rm=TRUE)	
 	
 	return(score)
}, Panting = function(Individual=data.frame(Panting_Individ), Group=data.frame(Panting_Group, PantingStereo_NoSows)){
	
	# Calculate the mean individual score, if any animals are housed individually:
	if(nrow(Individual)==0){
		number_ind <- 0
		meanscore_ind <- NA
	}else{
		connect(Individual)
	
		CheckCategories(Panting_Individ, c('0','1'))

		N <- length(Panting_Individ)
		scores_ind <- numeric(N)
	
		for(i in 1:N){
			if(Panting_Individ[i] %in% c('0')){
				scores_ind[i] <- wPanting0
			}else if(Panting_Individ[i] %in% c('1')){
				scores_ind[i] <- wPanting1
			}else{
				stop('Unrecognised category')
			}
			
		}
		
		meanscore_ind <- mean(scores_ind)
		number_ind <- N

		disconnect(Individual)
	}
		
	
	# Calculate the mean group score, if any animals are housed in groups:
	if(nrow(Group)==0){
		number_group <- 0
		meanscore_group <- NA
	}else{
		connect(Group)
	
		CheckNumeric(PantingStereo_NoSows)
		CheckNumeric(Panting_Group)
		
		N <- length(Panting_Group)
		scores_group <- numeric(N)
	
		for(i in 1:N){
			
			if(Panting_Group[i] > PantingStereo_NoSows[i]){
				stop("Panting_Group[i] > PantingStereo_NoSows[i]")
			}
			
			# If there are 0 observed animals then the score is missing:
			if(PantingStereo_NoSows[i] == 0){
				scores_group[i] <- NA
			}else{
				proportion_with <- Panting_Group[i] / PantingStereo_NoSows[i]
				proportion_without <- (PantingStereo_NoSows[i] - Panting_Group[i]) / PantingStereo_NoSows[i]
				scores_group[i] <- (wPanting0 * proportion_without) + (wPanting1 * proportion_with)
			}
		}
		
		# If there are a total of 0 observed animals then the score is missing:
		if(sum(PantingStereo_NoSows[i]) == 0){
			meanscore_group <- NA
		}else{
			meanscore_group <- WeightedAverage(scores_group, PantingStereo_NoSows)
		}
		number_group <- sum(PantingStereo_NoSows)

		disconnect(Group)
	}
	
	# Check to see if a total of 0 animals were assessed:
	if((number_ind+number_group) == 0){
		return("A total of 0 animals were assessed")
	}
	
	# Calculate the weighted average from the two sets of animals:
	score <- WeightedAverage(c(meanscore_ind, meanscore_group), c(number_ind, number_group))
	
	return(score)
	
}, RestingAreaFloorage = function(Resting_area_Group, NoSows_Group, Med_av_weight_Group){
	
	CheckNumeric(Med_av_weight_Group)
	CheckNumeric(NoSows_Group)
	CheckNumeric(Resting_area_Group)
	
	N <- length(NoSows_Group)
	scores <- numeric(N)
	
	for(i in 1:N){
		if(Resting_area_Group[i] >= (0.033 * (Med_av_weight_Group[i]^0.66) * NoSows_Group[i])){
			scores[i]<- wResting_area_floorage0
		}else{
			scores[i] <- wResting_area_floorage1
		}
	}

	return(WeightedAverage(scores, NoSows_Group))
}, Lameness = function(Lameness_Individ){
	
	CheckCategories(Lameness_Individ, c('0','1','2'))
	
	w0 <- NumberEqual(Lameness_Individ, '0') * wLameness0
	w1 <- NumberEqual(Lameness_Individ, '1') * wLameness1
	w2 <- NumberEqual(Lameness_Individ, '2') * wLameness2
	
	score <- (w0 + w1 + w2) / NumberObs(Lameness_Individ)
	
	return(score)
}, Hernia = function(Hernia_Individ){
	
	CheckCategories(Hernia_Individ, c('0','1','2'))
	
	w0 <- NumberEqual(Hernia_Individ, '0') * wHernia0
	w1 <- NumberEqual(Hernia_Individ, '1') * wHernia1
	w2 <- NumberEqual(Hernia_Individ, '2') * wHernia2
	
	score <- (w0 + w1 + w2) / NumberObs(Hernia_Individ)
	
	return(score)
}, WaterSupply = function(NippleClean_Group, NippleDirty_Group, TroughClean_Group, TroughDirty_Group, BowlClean_Group, BowlDirty_Group, NoSows_Group){
	
	
	CheckNumeric(NippleClean_Group)
	CheckNumeric(NippleDirty_Group)
	CheckNumeric(TroughClean_Group)
	CheckNumeric(TroughDirty_Group)
	CheckNumeric(BowlClean_Group)
	CheckNumeric(BowlDirty_Group)
	CheckNumeric(NoSows_Group)

	N <- length(NoSows_Group)
	scores <- numeric(N)

	totalnipples <- NippleClean_Group + NippleDirty_Group + BowlClean_Group*2 + BowlDirty_Group*2
	totaltrough <- TroughClean_Group/vTroughLengthPerPig + TroughDirty_Group/vTroughLengthPerPig 

	for(i in 1:N){
		
		# If there are no sows then give a missing score:
		if(NoSows_Group[i]==0){
			scores[i] <- NA

		# Otherwise we need to have at least 2 water sources otherwise always bad score:
		}else if((totalnipples[i]+totaltrough[i]) < 2){
			scores[i] <- wWatersupply_func1
		}else{
			
			# Must have 1 nipple per 10 or 1 bowl/trough/other per 15, or a combination of each, to get a good score:
			if((totalnipples[i]/NoSows_Group[i]) >= (1/vWaterThreshold0)){
				scores[i] <- wWatersupply_func0
			}else if((totaltrough[i]/NoSows_Group[i]) >= (1/vWaterThreshold1)){
				scores[i] <- wWatersupply_func0
			}else if((totalnipples[i]/NoSows_Group[i]) >= (1/vWaterThreshold2) && (totaltrough[i]/NoSows_Group[i]) >= (1/vWaterThreshold3)){
				scores[i] <- wWatersupply_func0
			}else{
				scores[i] <- wWatersupply_func1
			}
		}		
	}
	
	score <- WeightedAverage(scores, NoSows_Group)

	return(score)
}, IntegumentAlterations = function(IntAltlnX_Individ){
	
	CheckCategories(IntAltlnX_Individ, c('0','1'))
	
	w0 <- NumberEqual(IntAltlnX_Individ, '0') * wIntAltlnX0
	w1 <- NumberEqual(IntAltlnX_Individ, '1') * wIntAltlnX1
	
	score <- (w0 + w1) / NumberObs(IntAltlnX_Individ)
	
	return(score)
}, Cratespace = function(Sow_depth_Crated, Sow_length_Crated, Crate_width_Crated, Crate_length_Crated){
	
	CheckNumeric(Sow_depth_Crated)
	CheckNumeric(Sow_length_Crated)
	CheckNumeric(Crate_width_Crated)
	CheckNumeric(Crate_length_Crated)
	
	N <- length(Crate_length_Crated)
	scores <- numeric(N)
	# NB: if there is a sow who is partially recorded (e.g. missing crate width) then it is ignored
	for(i in 1:N){
		if((Crate_width_Crated[i] >= Sow_depth_Crated[i]) & (Crate_length_Crated[i] >= (Sow_length_Crated[i]+0.5))){
			scores[i] <- wCratespace0
		}else {
			scores[i] <- wCratespace1
		}
	}

	return(mean(scores))
}, ManureOnTheBody = function(Hygiene_Individ){
	
	CheckCategories(Hygiene_Individ, c('0','1','2'))
	
	w0 <- NumberEqual(Hygiene_Individ, '0') * wHygiene0
	w1 <- NumberEqual(Hygiene_Individ, '1') * wHygiene1
	w2 <- NumberEqual(Hygiene_Individ, '2') * wHygiene2
	
	score <- (w0 + w1 + w2) / NumberObs(Hygiene_Individ)
	
	return(score)
}, OverGrownClaws = function(OverGrownClaws_Individ){
	
	CheckCategories(OverGrownClaws_Individ, c('0','1'))
	
	w0 <- NumberEqual(OverGrownClaws_Individ, '0') * wOverGrownClaws0
	w1 <- NumberEqual(OverGrownClaws_Individ, '1') * wOverGrownClaws1
	
	score <- (w0 + w1) / NumberObs(OverGrownClaws_Individ)
	
	return(score)
}, VulvaLesions = function(VulvaLesions_Individ){
	
	CheckCategories(VulvaLesions_Individ, c('0','1'))
	
	w0 <- NumberEqual(VulvaLesions_Individ, '0') * wVulvaLesions0
	w1 <- NumberEqual(VulvaLesions_Individ, '1') * wVulvaLesions1
	
	score <- (w0 + w1) / NumberObs(VulvaLesions_Individ)
	
	return(score)
}, BodyConditionScore = function(BCS_Individ){
	
	CheckCategories(BCS_Individ, c('0','1'))
	
	w0 <- NumberEqual(BCS_Individ, '0') * wBCS0
	w1 <- NumberEqual(BCS_Individ, '1') * wBCS1
	
	score <- (w0 + w1) / NumberObs(BCS_Individ)
	
	return(score)
}, Cooling = function(Cooling_system_Group, NoSows_Group){
	
	CheckCategories(Cooling_system_Group, c('yes','no'))
	CheckNumeric(NoSows_Group)
	
	# NB: not taking cooling type into account! 
	
	scores <- ifelse(Cooling_system_Group=='yes', wCooling0, wCooling1)
	score <- WeightedAverage(scores, NoSows_Group)
	            
	return( score )
}, Roughage = function(Roughage_Group, NoSows_Group){
	
	
	CheckNumeric(NoSows_Group)
	CheckCategories(Roughage_Group, c('hay','straw','other','none'))

	scores_group <- numeric(length(Roughage_Group))
	
	for(i in 1:length(scores_group)){
		if(Roughage_Group[i] %in% c("hay","straw","other")){
			scores_group[i] <- wRoughage0
		}else if(Roughage_Group[i] == 'none'){
			scores_group[i] <- wRoughage1
		}else{
			stop('Unrecognised code')
		}		
	}
	
	score <- WeightedAverage(scores_group, NoSows_Group)
	
	return(score)
}, CleanWater = function(NippleClean_Group, TroughClean_Group, BowlClean_Group, NoSows_Group){

	CheckNumeric(NippleClean_Group)
	CheckNumeric(TroughClean_Group)
	CheckNumeric(BowlClean_Group)
	CheckNumeric(NoSows_Group)
	
	N <- length(NoSows_Group)
	scores <- numeric(N)

	totalclean <- NippleClean_Group + BowlClean_Group + TroughClean_Group

	for(i in 1:N){
		
		# A single clean water source is sufficient:
		if(totalclean[i] > 0){
			scores[i] <- wWatersupply_clean0
		}else{
			scores[i] <- wWatersupply_clean1
		}		
	}
	
	score <- WeightedAverage(scores, NoSows_Group)

	return(score)
}, Mortality = function(Mortality){
	
	CheckPercent(Mortality)
	CheckLength1(Mortality)
	
	# Score is based on % mortality as follows:
	if(Mortality <= vMortThreshold0){
		score <- wMortality0
	}else if(Mortality <= vMortThreshold1){
		score <- wMortality1
	}else if(Mortality <= vMortThreshold2){
		score <- wMortality2
	}else{
		score <- wMortality3
	}
	
	return(score)
}, NoseRing = function(NoseRing_Individ){
	
	CheckCategories(NoseRing_Individ, c('0','1'))
	
	w0 <- NumberEqual(NoseRing_Individ, '0') * wNoseRing0
	w1 <- NumberEqual(NoseRing_Individ, '1') * wNoseRing1
	
	score <- (w0 + w1) / NumberObs(NoseRing_Individ)
	
	return(score)
})
