#' @title The multifactor and charmultifactor classes
#' @name multifactor

#' @description
#' The multifactor class supports factors with each individual observation itself having multiple factor level memberships.  Where each observation has only 1 factor level membership, the multifactor is the same as a factor with the equivalent levels.  The charmultifactor class exists primarily to allow a multifactor to be included in a data frame.

#' @seealso
#' \code{\link[base]{factor}} for a standard factor object

#' @param x the object to be converted to/from a (char)multifactor

#' @param levels the levels to be used, as for \code{\link[base]{factor}}

#' @param labels the levels to be used, as for \code{\link[base]{factor}}

#' @param ordered are the levels ordered, as for \code{\link[base]{factor}}

#' @param simplify2factor if possible (each observation has only 1 factor level membersip) should the multifactor be reduced to a simple factor object?



#' @rdname multifactor
multifactor <- function(x, levels, labels=levels, ordered=FALSE, simplify2factor=FALSE){

	levels <- as.character(levels)
	if(any(grepl('-', levels,fixed=TRUE)))
		stop('Levels cannot contain a dash (-)')
	
	startl <- length(x)
	if(!is.list(x)){
		x <- lapply(x, sepdash, oneok=TRUE)
	}
	
	toret <- lapply(x, factor, levels=levels, labels=labels, ordered=ordered)
	stopifnot(all(sapply(toret,length) >= 1))
	
	attr(toret, 'levels') <- labels
	class(toret) <- 'multifactor'
	if(ordered)
		class(toret) <- c(class(toret), 'ordered')
	
	# Finally try to reduce to a simple (ordered) factor:
	if(simplify2factor)
		toret <- as.factor(toret)
	
	return(toret)
}

#' @rdname multifactor
#' @method is multifactor
is.multifactor <- function(x) inherits(x, c('multifactor','charmultifactor'))

#' @rdname multifactor
#' @method is charmultifactor
is.charmultifactor <- function(x) inherits(x, c('charmultifactor'))

#' @rdname multifactor
#' @method as multifactor
as.multifactor <- function(x, simplify2factor=FALSE){
	UseMethod('as.multifactor', x)
}


# Should this go all the way to character in one go???
as.character.multifactor <- function(x, ...){
	stopifnot(inherits(x, 'multifactor'))
	newx <- sapply(lapply(x, as.character.factor), function(y){
		if(length(y)>1 && any(is.na(y))){
			warning('Removing unnecessary missing (NA) elements from multifactor on conversion to character')
			y <- y[!is.na(y)]
		}
		newy <- paste(y, collapse='-')
		if(all(is.na(y)))
			newy <- NA
		return(newy)
	})
	stopifnot(all(is.na(newx)) || is.character(newx))
	attr(newx, 'levels') <- attr(x, 'levels')
	class(newx) <- c('charmultifactor', 'multifactor')
	if(is.ordered(x))
		class(newx) <- c(class(newx), 'ordered')
	class(newx) <- c(class(newx), 'character')
	return(newx)
}

as.character.charmultifactor <- function(x, ...){
	class(x) <- 'character'
	return(as.character(x))
}


as.data.frame.multifactor <- function(x, ...){
  dots <- list(...)
  dots$x <- as.character(x)
  dots$stringsAsFactors <- FALSE
  do.call('as.data.frame.character', dots)
}


as.multifactor.default <- function(x, simplify2factor=FALSE, ...){
	stop('There is no default as.multifactor method')
}
as.multifactor.charmultifactor <- function(x, simplify2factor=FALSE, ...){
	newx <- multifactor(x, levels=attr(x, 'levels'), ordered=is.ordered(x), simplify2factor=simplify2factor)
	return(newx)
}
as.multifactor.factor <- function(x, simplify2factor=FALSE, ...){
	mf <- as.list(x)
	attr(mf, 'levels') <- levels(x)
	class(mf) <- 'multifactor'
	if(is.ordered(x))
		class(mf) <- c(class(mf), 'ordered')
	
	if(simplify2factor)
		mf <- as.factor(mf, force=FALSE)
	
	return(mf)
}
as.multifactor.multifactor <- function(x, simplify2factor=FALSE, ...){
	if(simplify2factor)
		return(as.factor(x, force=FALSE))
	else
		return(x)
}

levels.multifactor <- function(x) attr(x, 'levels')

as.factor.multifactor <- function(x, force=FALSE, ...){
	
	if(inherits(x, 'charmultifactor'))
		x <- as.multifactor(x, simplify2factor=FALSE)
	
	if(force){
		x$x[sapply(x, length) > 1] <- NA
	}
	
	if(all(sapply(x, length)==1)){
		x <- unlist(factor(x, levels=attr(x, 'levels'), ordered=is.ordered(x)))
	}else{
		stopifnot(!force)
	}
	return(x)   # Will be a factor if possible
}

c.multifactor <- function(..., recursive = FALSE){
	dots <- list(...)
	
	stopifnot(all(sapply(dots,is.factor) || sapply(dots, is.multifactor)))  # Can also be charmultifactor
	stopifnot(all(sapply(dots,function(x) return(is.multifactor(x) || is.factor(x)))))
	levels_equal <- sapply(dots, function(x) return(length(levels(x))==length(levels(dots[[1]])) && all(levels(x)== levels(dots[[1]])) && is.ordered(x)==is.ordered(dots[[1]])))
	stopifnot(all(levels_equal))
	
	facts <- lapply(dots, function(x) return(as.multifactor(x, simplify2factor=FALSE)))
	newfacts <- unlist(facts, recursive=FALSE)
	
	toret <- newfacts
	attr(toret, 'levels') <- levels(dots[[1]])
	class(toret) <- 'multifactor'
	if(is.ordered(dots[[1]]))
		class(toret) <- c(class(toret), 'ordered')
		
	return(toret)
}

'[.multifactor' <- function(x, i){
	y <- as.list(as.multifactor(x, simplify2factor=FALSE))[i]
	return(multifactor(y, levels=attr(x, 'levels'), ordered=is.ordered(x), simplify2factor=TRUE))
}
'[[.multifactor' <- function(x, i){
	y <- as.list(as.multifactor(x, simplify2factor=FALSE))[i]
	return(multifactor(y, levels=attr(x, 'levels'), ordered=is.ordered(x), simplify2factor=TRUE))
}
'[.charmultifactor' <- function(x, i){
	y <- x
	class(y) <- 'character'
	y <- y[i]
	attr(y, 'levels') <- attr(x, 'levels')
	class(y) <- c('charmultifactor', 'multifactor')
	if(is.ordered(x))
		class(y) <- c(class(y), 'ordered')
	class(y) <- c(class(y), 'character')
	return(y)
}
'[[.charmultifactor' <- function(x, i){
	y <- x
	class(y) <- 'character'
	y <- y[i]
	attr(y, 'levels') <- attr(x, 'levels')
	class(y) <- c('charmultifactor', 'multifactor')
	if(is.ordered(x))
		class(y) <- c(class(y), 'ordered')
	class(y) <- c(class(y), 'character')
	return(y)
}
'==.multifactor' <- function(x, y){
	x <- as.multifactor(x, simplify2factor=TRUE)
	y <- as.multifactor(y, simplify2factor=TRUE)
	
	if(is.multifactor(x) && is.multifactor(y)){
		x <- as.character(x)
		class(x) <- 'character'
		y <- as.character(y)
		class(y) <- 'character'
		return(all(x==y))
	}
	
	if(is.multifactor(x) || is.multifactor(y))
		stop('The == method is not valid for a multifactor - use the %in% function instead (which will return TRUE if any x matches any y)', call.=FALSE)

	return(x==y)
}
as.list.multifactor <- function(x, ...){
	class(x) <- 'list'
	return(x)
}
as.numeric.multifactor <- function(x, ...){
	return(unlist(lapply(as.multifactor(x), as.numeric, ...)))
}
print.multifactor <- function(x, ...){
	print.default(x, ...)
}



sepdash <- function(x, oneok=FALSE){
	stopifnot(length(x)==1)

	if(is.na(x))
		return(x)

	newx <- strsplit(gsub(' ', '', x,fixed=TRUE), '-',fixed=TRUE)[[1]]
	stopifnot(is.character(newx))
	stopifnot(all(!is.na(newx)))
	stopifnot(all(newx!=''))
	if(oneok)
		stopifnot(length(newx)>=1)
	else
		stopifnot(length(newx)>1)
	
	return(newx)
}


#' @title A wrapper for factor and \%in\%
#' @name as.factor

#' @description
#' These wrappers only exist to support as.factor and %in% with multifactor objects.  For all other objects, the default base functions are used.

#' @seealso
#' The base functions \code{\link[base]{as.factor}} and \code{\link[base]{match}}

#' @param x the object to be converted to/from a (char)multifactor

#' @param table a vector of values to be matched against

#' @param ... additional arguments to be passed to base functions


#' @rdname as.factor
as.factor <- function(x, ...){
	UseMethod('as.factor',x)
}

as.factor.default <- function(x, ...){
	return(base::as.factor(x))
}

#' @rdname as.factor
"%in%" <- function(x, table){
	if(inherits(x, 'multifactor')){
		# Don't bother to try and reduce this to a simple factor - will only take more time:
		x <- as.multifactor(x, simplify2factor=FALSE)
		anyin <- sapply(x, function(d) return(any(match(d, table=table, nomatch=0) > 0)))
		return(anyin)
	}else{
		return(base::'%in%'(x, table))
	}
}
