#' @title Utility functions for converting mortality and slaughter data
#' @name extract_mortality
#' @aliases extract_mortality extract_slaughter

#' @description
#' These functions convert data frames representing mortality/slaughter data (in a format used by FVST) to a format that would be required for use with the welfare index model.  The results of these functions could be provided to the SetData method of a WelfareIndex model, if the data were required by functions/measures to be calculated.  Note that as of the 2021 version of the WelfareIndex model, these sources are not required by default for any animal group.

#' @seealso
#' \code{\link{WelfareIndex}}

#' @param mortality_data a data frame representing the mortality data in a format matching that used by FVST

#' @param visit_data a data frame with columns CHR and VisitDate detailing the extent of the data to extract

#' @param CHR_col the name of the column within the data frame specifying the CHR

#' @param month_col the name of the column within the data frame specifying the month

#' @param year_col the name of the column within the data frame specifying the year

#' @param num_col the name of the column within the data frame specifying the numerator (number of dead animals per month)

#' @param denom_col the name of the column within the data frame specifying the denominator (total number of animals per month)

#' @param Months the number of months up to the corresponding VisitDate for which to extract data

#' @param codes a named list of vectors representing the slaughter codes corresponding to the DataName given by the name of that element of the list

#' @param slaughter_data a data frame representing the slaughter data in a format matching that used by FVST

#' @param date_col the name of the column within the data frame specifying the date

#' @param code_cols a vector of names of the columns within the data frame specifying the slaughter code(s) registered for that animal

#' @param Days the number of days up to the corresponding VisitDate for which to extract data



#' @rdname extract_mortality
extract_mortality <- function(mortality_data, visit_data, CHR_col, month_col, year_col, num_col, denom_col, Months=12){
	
	mortality_data <- as.data.frame(mortality_data)
	visit_data <- as.data.frame(visit_data)
		
	stopifnot(is.data.frame(mortality_data))
	data <- mortality_data
	
	stopifnot(is.data.frame(visit_data) && all(c('CHR','VisitDate') %in% names(visit_data)))
	chr <- visit_data$CHR
	visit_date <- visit_data$VisitDate
	
	stopifnot(length(chr)==length(visit_date))
	stopifnot(length(file)==1)
	
	stopifnot(length(CHR_col)==1)
	stopifnot(length(month_col)==1)
	stopifnot(length(year_col)==1)
	stopifnot(length(num_col)==1)
	stopifnot(length(denom_col)==1)
	
	if(length(Months)==1)
		Months <- rep(Months, length(chr))
	stopifnot(length(Months)==length(chr))
	
	stopifnot(CHR_col %in% names(data))
	stopifnot(month_col %in% names(data))
	stopifnot(year_col %in% names(data))
	stopifnot(num_col %in% names(data))
	stopifnot(denom_col %in% names(data))
	
	# Drop unneeded CHR:
	data <- data[data[,CHR_col] %in% chr, c(CHR_col, month_col, year_col, num_col, denom_col),drop=FALSE]
	if(nrow(data)==0){
	  stop('No matching CHR found in the data provided')
	}
	names(data) <- c('CHR', 'Month', 'Year', 'Num', 'Denom')
	
	data$Month <- gsub(' ', '0', format(data$Month, width=2))
	data$Date <- as.Date(paste(data$Year, data$Month, '01',sep='-'))
	
	res <- t(sapply(1:length(chr), function(i){
		
		maxdate <- visit_date[i]
		mindate <- maxdate - (Months[i]*365.25/12) +15  # Add 15 days so we get exactly Months obs
		
		# Can be a compound CHR number
		allchr <- as.numeric(gsub(' ', '', strsplit(chr[i], '-', fixed=TRUE)[[1]]))
		
		sub <- data[data$CHR%in%allchr & data$Date >= mindate & data$Date <= maxdate,]
		
		# Sometimes a denominator of 0 is recorded - if so assume it is spurious and remove that month (sometimes it is all observations, so the farm becomes missing):
		sub <- sub[sub$Denom > 0,]
		
		if(nrow(sub)==0){
			return(c(CHR=chr[i], VisitDate=strftime(visit_date[i]), num=NA, denom=0, n_obs=0))
		}else{
			return(c(CHR=chr[i], VisitDate=strftime(visit_date[i]), num=sum(sub$Num), denom=mean(sub$Denom), n_obs=nrow(sub)))
		}
		
	}))
	
	res <- as.data.frame(res, stringsAsFactors=FALSE)
	res$VisitDate <- as.Date(res$VisitDate)
	res$MortalityNumber <- as.numeric(res$num)
	res$MortalityTotal <- as.numeric(res$denom)
	res$MortalityMonths <- as.numeric(res$n_obs)
	
	allres <- res[,c('CHR','VisitDate','MortalityNumber','MortalityTotal','MortalityMonths'),drop=FALSE]
	
	return(allres)
}

#' @rdname extract_mortality
extract_slaughter <- function(codes=list(), slaughter_data, visit_data, CHR_col, date_col, code_cols, Days=365){
	
	slaughter_data <- as.data.frame(slaughter_data)
	visit_data <- as.data.frame(visit_data)
	
	stopifnot(is.list(codes))
	if(is.null(names(codes)) || any(is.na(names(codes))) || any(names(codes)=="")){
		stop('The codes must be provided as a named list')
	}
	if(any(!sapply(codes, is.numeric)) || any(sapply(codes, length)==0)){
		stop('The codes must be provided as a named list of numbers')
	}
	
	stopifnot(is.data.frame(slaughter_data))
	
	stopifnot(is.data.frame(visit_data) && all(c('CHR','VisitDate') %in% names(visit_data)))
	chr <- visit_data$CHR
	visit_date <- visit_data$VisitDate
	
	codenames <- names(codes)
	allres <- lapply(1:length(codes), function(i) return(process_slaughter(slaughter_data, codenames[i], codes[[i]], chr, visit_date, CHR_col, date_col, code_cols, Days)))
	dfres <- cbind(visit_data[,c('CHR','VisitDate'),drop=FALSE], do.call('cbind', args=lapply(allres, cbind)))
	
	stopifnot(ncol(dfres)==(2+length(codes)*2))
	
	return(dfres)
}


process_slaughter <- function(data, codename, codes, chr, visit_date, CHR_col, date_col, code_cols, Days=365){
	
	stopifnot(length(chr)==length(visit_date))
	stopifnot(length(file)==1)
	
	stopifnot(length(CHR_col)==1)
	stopifnot(length(date_col)==1)
	stopifnot(length(codename)==1)
	stopifnot(length(code_cols)>=1)
	stopifnot(length(codes)>=1)
	
	if(length(Days)==1)
		Days <- rep(Days, length(chr))
	stopifnot(length(Days)==length(chr))
	
	stopifnot(CHR_col %in% names(data))
	stopifnot(date_col %in% names(data))
	stopifnot(all(code_cols %in% names(data)))
	
	# Drop unneeded CHR:
	data <- data[data[,CHR_col] %in% chr, c(CHR_col, date_col, code_cols),drop=FALSE]
	if(nrow(data)==0){
	  stop('No matching CHR found in the data provided')
	}
	names(data) <- c('CHR', 'Date', paste0('Code',1:length(code_cols)))
	data$Date <- as.Date(data$Date)
	stopifnot(!any(is.na(data$Date)))
	
	data$CodesPresent <- apply(data[,3:ncol(data)],1,function(x) return(any(codes %in% x)))
	
	res <- t(sapply(1:length(chr), function(i){
		
		maxdate <- visit_date[i]
		mindate <- maxdate - Days[i]
		
		# Can be a compound CHR number
		allchr <- as.numeric(gsub(' ', '', strsplit(chr[i], '-', fixed=TRUE)[[1]]))
		
		sub <- data[data$CHR%in%allchr & data$Date >= mindate & data$Date <= maxdate,]
		return(c(CHR=chr[i], VisitDate=strftime(visit_date[i]), num=sum(sub$CodesPresent), denom=nrow(sub)))
		
	}))
	
	res <- as.data.frame(res, stringsAsFactors=FALSE)
	res$VisitDate <- as.Date(res$VisitDate)
	res$Number <- as.numeric(res$num)
	res$Total <- as.numeric(res$denom)
	
	stopifnot(all(res$CHR==chr))
	stopifnot(all(res$VisitDate==visit_date))
	
	allres <- res[,c('Number','Total'),drop=FALSE]
	names(allres) <- paste0(codename, c('Number','Total'))

	return(as.data.frame(allres))
}