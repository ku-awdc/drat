# Index improvements function - to be exported and documented eventually
# TODO:  tidy up checks
	

improvements <- function(scores, measure, select_method=c('minimum_score', 'bottom_percentile'), select_value=50, set_method=c('remaining_mean','remaining_percentile','fixed_score'), set_value=90, exclude_perfect=FALSE, chr='all', anonymise=FALSE){
	
	if(inherits(scores, 'WelfareIndex')){
		scores <- scores$GetFarmScores('Measures', chr=chr, anonymise=anonymise, impute=FALSE)
	}
	
	stopifnot(inherits(scores, 'data.frame'))
	stopifnot("TotalAnimals" %in% names(scores))
	stopifnot(ncol(scores) > 1)
	
	totalanimals <- scores$TotalAnimals
	
	additionals <- c('TotalAnimals', 'CHR', 'Observer', 'VisitDate')
	prefixes <- scores[,names(scores) %in% additionals]
	modified <- scores[, ! names(scores) %in% additionals]
			
	stopifnot(is.character(measure))
	stopifnot(length(measure) >=1 && all(!is.na(measure)))
	stopifnot(all(measure %in% names(scores)))
	stopifnot(! "TotalAnimals" %in% measure)
	
	stopifnot(all(select_method %in% c('minimum_score', 'bottom_percentile')))
	stopifnot(all(set_method %in% c('remaining_mean','remaining_percentile','fixed_score')))
	
	if(length(measure) > 1 && length(select_method)==1)
		select_method <- rep(select_method, length(measure))
	if(length(measure) > 1 && length(select_value)==1)
		select_value <- rep(select_value, length(measure))
	if(length(measure) > 1 && length(set_method)==1)
		set_method <- rep(set_method, length(measure))
	if(length(measure) > 1 && length(set_value)==1)
		set_value <- rep(set_value, length(measure))
	
	stopifnot(length(measure)==length(select_method))
	stopifnot(length(measure)==length(select_value))
	stopifnot(length(measure)==length(set_method))
	stopifnot(length(measure)==length(set_value))
	
	# Stop if any measures all missing:
	allmissing <- apply(is.na(modified),2,all)
	if(any(allmissing))
		stop(paste0('All scores are missing for the following measure(s): ', paste(names(allmissing)[allmissing], collapse=', ')))
	
	numchanged <- numeric(length(measure))
	names(numchanged) <- measure
	
	# Loop over possibly cumulative measure improvements:
	for(i in 1:length(measure)){
		
		m <- measure[i]
		ms <- modified[,m]
		
		# Catch possibly all 100 measures:
		if(all(is.na(ms) | ms >= 99.99999)){
			modified[,m] <- ms
			next
		}
		
		if(select_method[i] == 'minimum_score'){
			tochange <- !is.na(ms) & ms < select_value[i]			
		}else if(select_method[i] == 'bottom_percentile'){
			score_rank <- rank(ms, na.last=TRUE, ties.method='first')
			if(exclude_perfect){
				numbertochange <- (select_value[i]/100) * sum(!is.na(ms) & ms < 100)
			}else{
				numbertochange <- (select_value[i]/100) * sum(!is.na(ms))
			}			
			tochange <- !is.na(ms) & score_rank <= numbertochange
		}else{
			stop('Unregocnised select method')
		}
		
		# Values to draw from to calculate reset value:
		set_dist <- ms[!is.na(ms) & !tochange]

		if(set_method[i] == 'remaining_mean'){
			numchanged[m] <- sum(tochange)
			ms[tochange] <- mean(set_dist)
		}else if(set_method[i] == 'remaining_percentile'){
			numchanged[m] <- sum(tochange & ms < quantile(set_dist, prob=set_value[i]/100))
			ms[tochange] <- quantile(set_dist, prob=set_value[i]/100)
		}else if(set_method[i] == 'fixed_score'){
			numchanged[m] <- sum(tochange & ms < set_value[i])
			ms[tochange] <- set_value[i]
		}else{
			stop('Unregocnised set method')
		}
		
		modified[,m] <- ms
	}
	
	imputed <- modified
	for(i in 1:ncol(imputed)){
		newmu <- mean(imputed[,i], na.rm=TRUE)
		imputed[is.na(imputed[,i]),i] <- newmu
	}
	
	# Calculate overall score:
	farmscores <- apply(imputed,1,mean)
	tobind <- lapply(1:length(farmscores), function(x){
		score <- farmscores[x]
		if(totalanimals[x] < 1){
			scores <- numeric(0)
		}else{
			scores <- rep(score, totalanimals[x])
		}
		stopifnot(length(scores)==totalanimals[x])
		return(scores)
	})
	toret <- do.call('c', args=tobind)
	stopifnot(length(toret)==sum(totalanimals))
	overall <- mean(toret)
	
	average_farm <- apply(modified,2,mean,na.rm=TRUE)
	tobind <- lapply(1:nrow(modified), function(x){
		slice <- modified[x,,drop=FALSE]
		rownames(slice) <- NULL
		if(totalanimals[x] < 1){
			slices <- slice[-1,]
		}else{
			slices <- cbind(Animal=1:totalanimals[x], slice)[,-1]
		}
		stopifnot(nrow(slices)==totalanimals[x])
		return(slices)
	})
	toret <- do.call('rbind', args=tobind)
	stopifnot(nrow(toret)==sum(totalanimals))
	average_animal <- apply(toret,2,mean,na.rm=TRUE)
	
	newscores <- cbind(prefixes, modified)
	farmscores <- cbind(prefixes, data.frame(FarmScore=farmscores))
	
	

	return(list(overall=overall, farms=farmscores, measures=newscores, average_farm=average_farm, average_animal=average_animal, number_changed=numchanged))
	
}
