dfun_Weaners <-
list(Hernia = function(HerniaS1, HerniaS2, PigsScored_Clinical, PigsPen_Clinical){
	
	CheckNumeric(HerniaS1)
	CheckNumeric(HerniaS2)
	CheckNumeric(PigsScored_Clinical)
	CheckNumeric(PigsPen_Clinical)
	
	## Calculate implied number with score 0:
	HerniaS0 <- PigsScored_Clinical - (HerniaS1+HerniaS2)

	npens <- length(PigsPen_Clinical)
	scores <- numeric(npens)
	
	for(i in 1:npens){
		
		# Check pigs scored is not more than pigs in the pen:
		if(PigsScored_Clinical[i] > PigsPen_Clinical[i]){
			log$Error("The number of scored pigs (", PigsScored_Clinical[i], ") is greater than the total number in the pen (", PigsPen_Clinical[i], ")")
		}
		
		# Check pigs scored equals sum of manure categories:
		if(HerniaS0[i] < 0){
			log$Error("The number of scored pigs (", PigsScored_Clinical[i], ") is less than the total number from the Hernia S1 and S2 categories in that pen (", (HerniaS1[i]+HerniaS2[i]), ")")
		}
	
		# Calculate average score for the pen:
		w0 <- HerniaS0[i] * wHernia0
		w1 <- HerniaS1[i] * wHernia1
		w2 <- HerniaS2[i] * wHernia2
		
		scores[i] <- (w0 + w1 + w2) / PigsScored_Clinical[i]
	}
	
	return( WeightedAverage(scores, PigsPen_Clinical) )
}, TailBite = function(TailBite, PigsScored_Clinical, PigsPen_Clinical){
	
	CheckNumeric(TailBite)
	CheckNumeric(PigsScored_Clinical)
	CheckNumeric(PigsPen_Clinical)
	
	# Check all numbers are less than or equal to pigs scored:
	stopifnot(all(PigsScored_Clinical >= TailBite))
	
	w0 <- (PigsScored_Clinical-TailBite) * wTailBite0
	w1 <- TailBite * wTailBite1
		
	scores <- (w0 + w1) / PigsScored_Clinical
	
	return( WeightedAverage(scores, PigsPen_Clinical) )
}, RestingArea = function(AverageWeight, Rest_area, PigsPen_Resources){
	
	CheckNumeric(AverageWeight)
	CheckNumeric(Rest_area)
	CheckNumeric(PigsPen_Resources)
	
	npens <- length(AverageWeight)
	scores <- numeric(npens)
	for(i in 1:npens){
		
		# Space requirement calcualtion for half recumbency (see netlist):
		require <- (0.033 * AverageWeight[i])^0.66

		if(Rest_area[i] >= (require * PigsPen_Resources[i])){
			scores[i] <- wResting_area_floorage0
		}else{
			scores[i] <- wResting_area_floorage1
		}
	}

	return( WeightedAverage(scores, PigsPen_Resources) )
}, BodyConditionScore = function(BCSLeanNr, PigsScored_Clinical, PigsPen_Clinical){
	
	CheckNumeric(BCSLeanNr)
	CheckNumeric(PigsScored_Clinical)
	CheckNumeric(PigsPen_Clinical)

	if(sum(PigsScored_Clinical) == 0)
		return('A total of 0 pigs were recorded for clinical observations')
	
	ratio <- BCSLeanNr/PigsScored_Clinical
	scores <- ratio * wBCS1 + (1-ratio) * wBCS0
	
	return( WeightedAverage( scores, PigsPen_Clinical ))
	
}, StockingDensity = function(AverageWeight, Pen_area, PigsPen_Resources){
	
	CheckNumeric(AverageWeight)
	CheckNumeric(Pen_area)
	CheckNumeric(PigsPen_Resources)
	
	npens <- length(AverageWeight)
	scores <- numeric(npens)
	for(i in 1:npens){
		
		# Space requirement calcualtion for fully recumbency (see netlist):
		fr_require <- (0.047 * AverageWeight[i])^0.66
		
		# If they meet fully recumbency requirements score 0:
		if(Pen_area[i] >= (fr_require * PigsPen_Resources[i])){
			scores[i] <- wStocking_density0
		}else{
			
			# Requirements according to legislation:
			if(AverageWeight[i] <= 10){
				require <- 0.15
			}else if(AverageWeight[i] <= 20){
				require <- 0.2
			}else if(AverageWeight[i] <= 30){
				require <- 0.3
			}else if(AverageWeight[i] <= 50){
				require <- 0.4
			}else if(AverageWeight[i] <= 85){
				require <- 0.55
			}else if(AverageWeight[i] <= 110){
				require <- 0.65
			}else{
				require <- 1
			}
			
			# If they meet legal requirements but not fully recumbency requirements score 1:
			if(Pen_area[i] >= (require * PigsPen_Resources[i])){
				scores[i] <- wStocking_density1
			}else{
				scores[i] <- wStocking_density2
			}
		}
	}
		
	return( WeightedAverage(scores, PigsPen_Resources) )
}, FeedingSystem = function(FeedSys, PigsPen_Resources, AverageWeight, FeedLength){
	
	CheckCategories(FeedSys, c('al','nal'))
	CheckNumeric(PigsPen_Resources)
	CheckNumeric(AverageWeight)
	CheckNumeric(FeedLength)
	
	scores <- numeric(length(FeedSys))
	for(i in 1:length(scores)){
		
		# First work out space requirement based on pig size:
		if(AverageWeight[i] <= 15){
			require <- 0.16
		}else if(AverageWeight[i] <= 30){
			require <- 0.21
		}else if(AverageWeight[i] <= 50){
			require <- 0.25
		}else if(AverageWeight[i] <= 70){
			require <- 0.28
		}else if(AverageWeight[i] <= 90){
			require <- 0.32
		}else{
			require <- 0.35
		}

		# If feeding system is al then score 0 regardless of pig size/space
		if(FeedSys[i] == 'al'){
			scores[i] <- wFeeding_system0
		# Otherwise must meet requirements for relevant pig size
		}else if(FeedLength[i] >= require){
			scores[i] <- wFeeding_system0
		}else{
			scores[i] <- wFeeding_system1
		}
	}
		
	score <- WeightedAverage(scores, PigsPen_Resources)
		
	return(score)
}, Integument = function(IntegAlter, PigsScored_Clinical, PigsPen_Clinical){
	
	CheckNumeric(IntegAlter)
	CheckNumeric(PigsScored_Clinical)
	CheckNumeric(PigsPen_Clinical)
	
	# Check all numbers are less than or equal to pigs scored:
	stopifnot(all(PigsScored_Clinical >= IntegAlter))
	
	w0 <- (PigsScored_Clinical-IntegAlter) * wIntegAlter0
	w1 <- IntegAlter * wIntegAlter1
		
	scores <- (w0 + w1) / PigsScored_Clinical
	
	return( WeightedAverage(scores, PigsPen_Clinical) )
}, Lameness = function(LameS1, LameS2, PigsScored_Clinical, PigsPen_Clinical){
	
	CheckNumeric(LameS1)
	CheckNumeric(LameS2)
	CheckNumeric(PigsScored_Clinical)
	CheckNumeric(PigsPen_Clinical)
	
	## Calculate implied number with score 0:
	LameS0 <- PigsScored_Clinical - (LameS1+LameS2)

	npens <- length(PigsPen_Clinical)
	scores <- numeric(npens)
	
	for(i in 1:npens){
		
		# Check pigs scored is not more than pigs in the pen:
		if(PigsScored_Clinical[i] > PigsPen_Clinical[i]){
			log$Error("The number of scored pigs (", PigsScored_Clinical[i], ") is greater than the total number in the pen (", PigsPen_Clinical[i], ")")
		}
		
		# Check pigs scored equals sum of manure categories:
		if(LameS0[i] < 0){
			log$Error("The number of scored pigs (", PigsScored_Clinical[i], ") is less than the total number from the lame S1 and S2 categories in that pen (", (LameS1[i]+LameS2[i]), ")")
		}
	
		# Calculate average score for the pen:
		w0 <- LameS0[i] * wLameness0
		w1 <- LameS1[i] * wLameness1
		w2 <- LameS2[i] * wLameness2
		
		scores[i] <- (w0 + w1 + w2) / PigsScored_Clinical[i]
	}
	
	return( WeightedAverage(scores, PigsPen_Clinical) )
}, Panting = function(Panting, PigsScored_Clinical, PigsPen_Clinical){
	
	CheckCategories(Panting, c("n","y"))
	CheckNumeric(PigsPen_Clinical)
	CheckNumeric(PigsScored_Clinical)
	
	npens <- length(PigsPen_Clinical)
	scores <- numeric(npens)

	for(i in 1:npens){
		
		# Check pigs scored is not more than pigs in the pen:
		if(PigsScored_Clinical[i] > PigsPen_Clinical[i]){
			log$Error("The number of scored pigs (", PigsScored_Clinical[i], ") is greater than the total number in the pen (", PigsPen_Clinical[i], ")")
		}
		
		# Panting is observed at pen level:
		if(Panting[i]=="n"){
			scores[i] <- wPanting0
		}else if(Panting[i]=="y"){
			scores[i] <- wPanting1
		}else{
			stop("Category unrecognised")
		}
	}

	# Then weight by total number of pigs in the pen:	
	return( WeightedAverage(scores, PigsPen_Clinical) )
}, RectalProlapse = function(RectalProlNr, PigsScored_Clinical, PigsPen_Clinical){
	
	CheckNumeric(RectalProlNr)
	CheckNumeric(PigsScored_Clinical)
	CheckNumeric(PigsPen_Clinical)
	
	# Check all rectal prolapse numbers are less than or equal to pigs scored:
	stopifnot(all(PigsScored_Clinical >= RectalProlNr))
	
	w0 <- (PigsScored_Clinical - RectalProlNr) * wProlapse0
	w1 <- RectalProlNr * wProlapse1		

	scores <- (w0 + w1) / PigsScored_Clinical
	
	return( WeightedAverage(scores, PigsPen_Clinical) )
}, CoolingAccess = function(CoolingAccess, PigsPen_Resources, AverageWeight){
	
	CheckCategories(CoolingAccess, c('y','n'))
	CheckNumeric(PigsPen_Resources)
	CheckNumeric(AverageWeight)
	
	npens <- length(PigsPen_Resources)
	scores <- numeric(npens)
	
	for(i in 1:npens){
		# If the pigs are small then cooling is not needed:
		if(AverageWeight[i] < 20){
			scores[i] <- NA
		# Otherwise do they have access to cooling?
		}else if(CoolingAccess[i] %in% c('y')){
			scores[i] <- wCooling0
		}else{
			scores[i] <- wCooling1
		}		
	}
	
	# If all pens have small pigs return a message and NA:
	if(all(AverageWeight < 20)){
		return("All available pens have an average weight under 20kg")
	}
	
	return( WeightedAverage(scores, PigsPen_Resources) )

}, Manure = function(ManureS1, ManureS2, PigsScored_Clinical, PigsPen_Clinical){
	
	CheckNumeric(ManureS1)
	CheckNumeric(ManureS2)
	CheckNumeric(PigsScored_Clinical)
	CheckNumeric(PigsPen_Clinical)
	
	## Calculate implied number with score 0:
	ManureS0 <- PigsScored_Clinical - (ManureS1+ManureS2)

	npens <- length(PigsPen_Clinical)
	scores <- numeric(npens)
	
	for(i in 1:npens){
		
		# Check pigs scored is not more than pigs in the pen:
		if(PigsScored_Clinical[i] > PigsPen_Clinical[i]){
			log$Error("The number of scored pigs (", PigsScored_Clinical[i], ") is greater than the total number in the pen (", PigsPen_Clinical[i], ")")
		}
		
		# Check pigs scored equals sum of manure categories:
		if(ManureS0[i] < 0){
			log$Error("The number of scored pigs (", PigsScored_Clinical[i], ") is less than the total number from the manure S1 and S2 categories in that pen (", (ManureS1[i]+ManureS2[i]), ")")
		}
	
		# Calculate average score for the pen:
		w0 <- ManureS0[i] * wManure0
		w1 <- ManureS1[i] * wManure1
		w2 <- ManureS2[i] * wManure2
		
		scores[i] <- (w0 + w1 + w2) / PigsScored_Clinical[i]
	}

	# Then weight by total number of pigs in the pen:	
	return( WeightedAverage(scores, PigsPen_Clinical) )
}, FloorType = function(Rest_FloorType, PigsPen_Resources){
	
	CheckCategories(Rest_FloorType, c('db','s','sl','hm','hm<c'))
	CheckNumeric(PigsPen_Resources)
	
	npens <- length(Rest_FloorType)
	scores <- numeric(npens)
	
	for(i in 1:npens){
		
		if(Rest_FloorType[i] %in% c('db')){
			scores[i] <- wResting_area_floortype_0
		}else if(Rest_FloorType[i] %in% c('s','hm')){
			scores[i] <- wResting_area_floortype_1
		}else{
			scores[i] <- wResting_area_floortype_2
		}
		
	}

	return( WeightedAverage(scores, PigsPen_Resources) )
}, EarDamage = function(EarDamage, PigsScored_Clinical, PigsPen_Clinical){
	
	CheckNumeric(EarDamage)
	CheckNumeric(PigsScored_Clinical)
	CheckNumeric(PigsPen_Clinical)
	
	# Check all numbers are less than or equal to pigs scored:
	stopifnot(all(PigsScored_Clinical >= EarDamage))
	
	w0 <- (PigsScored_Clinical-EarDamage) * wEarDamage0
	w1 <- EarDamage * wEarDamage1
		
	scores <- (w0 + w1) / PigsScored_Clinical
	
	return( WeightedAverage(scores, PigsPen_Clinical) )
}, WaterSupply = function(NippleClean, NippleDirty, TroughClean, TroughDirty, BowlClean, BowlDirty, PigsPen_Resources){
	
	CheckNumeric(NippleClean)
	CheckNumeric(NippleDirty)
	CheckNumeric(TroughClean)
	CheckNumeric(TroughDirty)
	CheckNumeric(BowlClean)
	CheckNumeric(BowlDirty)
	CheckNumeric(PigsPen_Resources)

	totalwater <- NippleClean + NippleDirty + TroughClean/vTroughLengthPerPig + TroughDirty/vTroughLengthPerPig + BowlClean + BowlDirty
	totalnipples <- NippleClean + NippleDirty + BowlClean*2 + BowlDirty*2
	
	npens <- length(NippleClean)
	scores <- numeric(npens)
	for(i in 1:npens){
		if(totalwater[i] > 2 & ((PigsPen_Resources[i] / totalnipples[i]) <= vWaterThreshold)){
			scores[i] <- wWatersupply_func0
		}else{
			scores[i] <- wWatersupply_func1
		}
	}
	
	score <- WeightedAverage(scores, PigsPen_Resources)
	return(score)
}, Rooting = function(RootingType, PigsPen_Resources){
	
	CheckCategories(RootingType, c('none', 'straw', 'rope', 'metal', 'softwood', 'hardwood', 'sawdust', 'hay', 'rubber', 'other'))
	CheckNumeric(PigsPen_Resources)
	
	npens <- length(PigsPen_Resources)
	scores <- numeric(npens)
	
	for(i in 1:npens){
		if(RootingType[i] %in% c('straw','hay')){
			scores[i] <- wRooting0
		}else if(RootingType[i] %in% c('rope','sawdust')){
			scores[i] <- wRooting1
		}else if(RootingType[i] %in% c('softwood','hardwood','rubber')){
			scores[i] <- wRooting2
		}else if(RootingType[i] %in% c('metal','other')){
			scores[i] <- wRooting3
		}else if(RootingType[i] %in% c('none')){
			scores[i] <- wRooting4
		}else{
			stop('Unrecognised category')				
		}
	}

	return( WeightedAverage(scores, PigsPen_Resources) )
}, HamperedResp = function(HampRespNr, PigsScored_Clinical, PigsPen_Clinical){
	
	CheckNumeric(HampRespNr)
	CheckNumeric(PigsScored_Clinical)
	CheckNumeric(PigsPen_Clinical)
	
	# Check all hampered respiration numbers are less than or equal to pigs scored:
	stopifnot(all(PigsScored_Clinical >= HampRespNr))
	
	w0 <- (PigsScored_Clinical-HampRespNr) * wHampResp0
	w1 <- HampRespNr * wHampResp1
		
	scores <- (w0 + w1) / PigsScored_Clinical
	
	return( WeightedAverage(scores, PigsPen_Clinical) )
}, Slipping = function(TotalSlipping, PigsScored_Clinical, PigsPen_Clinical){
	
	CheckNumeric(TotalSlipping)
	CheckNumeric(PigsScored_Clinical)
	CheckNumeric(PigsPen_Clinical)
	
	npens <- length(PigsPen_Clinical)
	scores <- numeric(npens)
	
	for(i in 1:npens){
		# Calculate average score for the pen:
		w0 <- (PigsScored_Clinical[i]-TotalSlipping[i]) * wSlipping0
		w1 <- TotalSlipping[i] * wSlipping1
		scores[i] <- (w0 + w1) / PigsScored_Clinical[i]
	}

	# Then weight by total number of pigs in the pen:	
	return( WeightedAverage(scores, PigsPen_Clinical) )
}, CleanWater = function(NippleClean, TroughClean, BowlClean, PigsPen_Resources){
	
	CheckNumeric(NippleClean)
	CheckNumeric(TroughClean)
	CheckNumeric(BowlClean)
	CheckNumeric(PigsPen_Resources)

	totalclean <- NippleClean + TroughClean + BowlClean
	
	npens <- length(totalclean)
	scores <- numeric(npens)
	for(i in 1:npens){
		if(totalclean[i] > 0){
			scores[i] <- wWaterClean0
		}else{
			scores[i] <- wWaterClean1
		}
	}
	
	score <- WeightedAverage(scores, PigsPen_Resources)
	return(score)
}, TwistedSnout = function(TwSnoutNr, PigsScored_Clinical, PigsPen_Clinical){
	
	CheckNumeric(TwSnoutNr)
	CheckNumeric(PigsScored_Clinical)
	CheckNumeric(PigsPen_Clinical)
	
	stopifnot(all(PigsScored_Clinical >= TwSnoutNr))
	
	w0 <- (PigsScored_Clinical-TwSnoutNr) * wTwistedSnout0
	w1 <- TwSnoutNr * wTwistedSnout1
		
	scores <- (w0 + w1) / PigsScored_Clinical
	
	return( WeightedAverage(scores, PigsPen_Clinical) )
}, Mortality = function(Mortality){
	
	CheckPercent(Mortality)
	CheckLength1(Mortality)
	
	# Score is based on % mortality as follows:
	if(Mortality <= vMortThreshold0){
		score <- wMortality0
	}else if(Mortality <= vMortThreshold1){
		score <- wMortality1
	}else{
		score <- wMortality2
	}
	
	return(score)
}, ValidationCheck = function(TotalAnimals, PigsScored_Clinical){
	
	CheckNumeric(TotalAnimals)
	CheckNumeric(PigsScored_Clinical)
	
	CheckLength1(TotalAnimals)
	
	if(sum(PigsScored_Clinical, na.rm=TRUE) == 0)
		log$Warning('No pigs have been clinically scored for this CHR')	
	
	if(TotalAnimals == 0)
		log$Warning('The number of animals on this farm is recorded as 0 - the farm will be ignored when building the index')
	
	return(TotalAnimals)	
}, Neurological = function(NeuroSymptNr, PigsScored_Clinical, PigsPen_Clinical){
	
	CheckNumeric(NeuroSymptNr)
	CheckNumeric(PigsScored_Clinical)
	CheckNumeric(PigsPen_Clinical)
	
	stopifnot(all(PigsScored_Clinical >= NeuroSymptNr))
 
	w0 <- (PigsScored_Clinical-NeuroSymptNr) * wNeuroSymptoms0
	w1 <- NeuroSymptNr * wNeuroSymptoms1
		
	scores <- (w0 + w1)  / PigsScored_Clinical
	
	return( WeightedAverage(scores, PigsPen_Clinical) )
})
