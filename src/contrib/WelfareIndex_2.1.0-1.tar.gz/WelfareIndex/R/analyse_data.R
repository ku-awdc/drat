analyse_data <- function(torun, datalist, fun_objects, type, measuresdf, key, errorfile='errorfile.txt', show_warnings=TRUE){
	
	# Set up the environment:
	funenv <- list2env(fun_objects, parent=as.environment('package:WelfareIndex'))
	
	# Set up a log file:
	if(show_warnings){
		warnfile <- errorfile
	}else{
		warnfile <- '/dev/null'
	}
	assign('log',new('logger', errorfile, warnfile, type),envir=funenv)
	log <- funenv$log
	
	# Assign the calling environment of the functions:
	for(i in 1:length(funenv$funs)){
		environment(funenv$funs[[i]]) <- funenv
	}

	# Assign the calling environment of the utilities:
	for(i in 1:length(utility_functions)){
		environment(utility_functions[[i]]) <- funenv
		assign(names(utility_functions)[i], utility_functions[[i]], envir=funenv)
	}
	
	get_this <- function(x, envir){
    	x <- eval(parse(text=x), envir=envir)
		return(x)
	}
	
	# Ensures ValidationCheck is first - so we can define things there using <<- that persist
	measures <- measuresdf$Measure
	stopifnot(measures[1]=='ValidationCheck')
	funenv$funs <- funenv$funs[measures]
	stopifnot(all(measures == names(funenv$funs)))
	
	#mins <- c(0, as.numeric(measuresdf$Min))
	#maxs <- c(Inf, as.numeric(measuresdf$Max))
	mins <- as.numeric(measuresdf$Min)
	maxs <- as.numeric(measuresdf$Max)
	stopifnot(all(!is.na(as.numeric(mins))))
	stopifnot(all(!is.na(as.numeric(maxs))))
	
	# A dataframe to hold all results - measure_index first so all measures are done for a single CHR before moving to the next:
	all_results <- expand.grid(measure_index=1:length(measures), CHR=NA, Observer=NA, VisitDate=NA, Measure=NA, entry_index=1:nrow(torun), Nobs=NA, Value=NA, NumberOfErrors=0, NumberOfWarnings=0, AllErrors='', AllWarnings='', stringsAsFactors=FALSE)
	all_results$Measure <- measures[all_results$measure_index]
	all_results$CHR <- torun$CHR[all_results$entry_index]
	all_results$Observer <- "fake"
	all_results$VisitDate <- as.Date("1970-01-01")
	
	all_datanames <- lapply(1:length(measures), getdatanames, funs=funenv$funs)
	all_dataexpressions <- lapply(1:length(measures), getdataexpressions, funs=funenv$funs)
	all_argnames <- lapply(1:length(measures), function(i) return(names(formals(funenv$funs[[i]]))))
  
	lastchr <- 0
	totalwarns <- 0
	totalerrors <- 0
	
	for(i in 1:nrow(all_results)){
		
		this_measure_index <- all_results$measure_index[i]
		this_chr <- torun$CHR[all_results$entry_index[i]]
		this_observer <- torun$Observer[all_results$entry_index[i]]
		this_date <- torun$VisitDate[all_results$entry_index[i]]
		
		# Set up a new environment for farm specific data if needed:
		if(lastchr!=this_chr){
			newenv <- new.env()
			# First extract all DataRelations and cut down to the correct farm:
			farmdata <- list()
			for(r in unique(key$DataRelation)){
				x <- get(r, pos=datalist)
				stopifnot(names(x)[1]==c('CHR'))
				newx <- as.list(x[x$CHR==this_chr, -(1), drop=FALSE])
				farmdata <- c(farmdata, newx)
			}
			stopifnot(all(unlist(all_datanames) %in% c('CHR', names(farmdata))))
			
			# Needed to stop charmultifactor being stripped of attributes by data frame:			
			for(v in 1:length(farmdata)){
				if(inherits(farmdata[[v]], 'charmultifactor')){
					farmdata[[v]] <- as.multifactor(farmdata[[v]], simplify2factor=TRUE)
				}
				assign(names(farmdata)[v], farmdata[[v]], envir=newenv)
			}
		}
		lastchr <- this_chr
		
		funenv$log$SetDataset(this_chr, as.character(this_observer), this_date, measures[this_measure_index])
		datain <- all_dataexpressions[[this_measure_index]]
		datanames <- all_datanames[[this_measure_index]]
		argnames <- all_argnames[[this_measure_index]]
    
		retval <- NA
		s <- try({
			
			reqdata <- lapply(datain, get_this, envir=newenv)
			names(reqdata) <- argnames

			# If one argument is a data frame then they all are:
			if(inherits(reqdata[[1]], 'data.frame')){
				stopifnot(all(sapply(reqdata, inherits, 'data.frame')))
				stopifnot(all_results$Measure[i]!='ValidationCheck')
				
				if(all(sapply(reqdata, nrow)==0)){
					stop(paste0('All of the required data frame(s) have 0 rows: ', argnames))
				}
				tocheck <- reqdata
			}else{
				tocheck <- list(Complete=reqdata)
			}
			
			arglengths <- numeric(length(tocheck)+sum(sapply(tocheck,length)))
			names(arglengths) <- c(names(tocheck), unlist(lapply(tocheck,names)))
			tl <- numeric(length(tocheck))
			names(tl) <- names(tocheck)
			# Lengths of data is name of data frame followed by elements within it:
			
			length0 <- logical(length(tocheck))
			length0[] <- FALSE
			for(a in 1:length(tocheck)){
				
				al <- sapply(tocheck[[a]], function(x){
					suppressWarnings(obsok <- !is.na(x))
					return(sum(obsok))
				})
				arglengths[names(tocheck[[a]])] <- al
				
				# Remove missing from within data frame rows and check argument lengths:
				if(all_results$Measure[i]!='ValidationCheck'){
					
					whichmin <- which.min(sapply(tocheck[[a]], length))
					whichmax <- which.max(sapply(tocheck[[a]], length))

					# Check argument lengths:
					if(any(sapply(tocheck[[a]], length)!=length(tocheck[[a]][[1]]))){
						stop(paste0('Argument lengths differ (range: ', min(sapply(tocheck[[a]], length)), ' for ', names(tocheck[[a]])[whichmin], ' - ', max(sapply(tocheck[[a]], length)), ' for ', names(tocheck[[a]])[whichmax], ') - use a data.frame argument for data from different sources'), call.=FALSE)
					}
					if(any(sapply(tocheck[[a]], length)!=length(tocheck[[a]][[1]]))){
						stop(paste0('Argument lengths differ after removing missing (range: ', min(sapply(tocheck[[a]], length)), ' for ', names(tocheck[[a]])[whichmin], ' - ', max(sapply(tocheck[[a]], length)), ' for ', names(tocheck[[a]])[whichmax], ') - this is probably a bug!'), call.=FALSE)
					}
					
					# Remove missing:
					nas <- vapply(tocheck[[a]], is.na, logical(length(tocheck[[a]][[1]])))
					dim(nas) <- c(length(tocheck[[a]][[1]]), length(tocheck[[a]]))
					anyna <- apply(nas,1,any)
					tocheck[[a]] <- lapply(tocheck[[a]], function(x) return(x[!anyna]))
					cl <- sum(!anyna)
					stopifnot(cl==length(tocheck[[a]][[1]]))

					arglengths[names(tocheck)[a]] <- cl
					tl[names(tocheck)[a]] <- cl
					if(cl==0){
						stopifnot(nrow(tocheck[[a]])==0)
						length0[a] <- TRUE
					}else{
						stopifnot(nrow(tocheck[[a]])>0)
					}
					
					# Needed to stop charmultifactor being stripped of attributes by data frame:
					for(v in 1:length(tocheck[[a]])){
					  if(inherits(tocheck[[a]][[v]], 'charmultifactor')){
							tocheck[[a]][[v]] <- as.multifactor(tocheck[[a]][[v]], simplify2factor=TRUE)
						}
					}
					
					# Make it a data frame:
					t1 <- try({
					  	temp <- tocheck[[a]]
						tocheck[[a]] <- as.data.frame(tocheck[[a]])
					})
					if(inherits(t1,'try-error'))
						stop(paste0('There was an error coercing the arguments for ', names(tocheck)[a], ' into a data frame - this is probably a bug!'), call.=FALSE)
					
				}else{
					# Scrub the complete sum for ValidationCheck:
					arglengths <- arglengths[-1]
					tl[names(tocheck)[a]] <- max(al)
				}
				
			}
			all_results$Nobs[i] <- paste(paste0(names(arglengths), ': ', arglengths), collapse=' -:- ')

			# ValidationCheck will always run (length0 never TRUE):
			if(all(length0)){
				funenv$log$Warning('No complete set of non-missing observations available for this CHR')
				all_results$Value[i] <- NA
				
			}else{
			
				# If this isn't really a dataframe function we need to strip the single data frame back to a list of arguments:
				if(!inherits(reqdata[[1]], 'data.frame')){
					stopifnot(length(tocheck)==1)
					tocheck <- as.list(tocheck[[1]])
				}
			
				wo <- options()$warn
				options(warn=1)
				warns <- capture.output(retval <- do.call(funenv$funs[[this_measure_index]], tocheck), type='message')
				# Debugging option:
				# warns <- character(0); retval <- do.call(funenv$funs[[this_measure_index]], tocheck)
				options(warn=wo)
			
				if(length(warns)>0){
					funenv$log$Warning(paste(warns, collapse=' '))
				}
			
				if(length(retval)!=1)
					stop('Return value was the wrong length (should be length 1)', call.=FALSE)
				
				# It is possible to return a character string in which case it is an explanation for a missing value:
				if(is.character(retval)){

					funenv$log$Warning(paste0('Score missing due to: "', retval, '"'))
					retval <- as.numeric(NA)
					
				}else{
				
					if(is.na(retval)){
						retval <- as.numeric(NA)
						funenv$log$Warning('Missing value returned from the function')
					}else{
				
						if(!is.numeric(retval))
							stop('Return value was not numeric', call.=FALSE)

						if(retval > maxs[this_measure_index]){
							stop(paste0('Return value of ', round(retval,2), ' is above the maximum specified (', maxs[this_measure_index], ')'), call.=FALSE)
						}
						if(retval < mins[this_measure_index])
							stop(paste0('Return value of ', round(retval,2), ' is below the minimum specified (', mins[this_measure_index], ')'), call.=FALSE)
					
					}
					
				}
			
				all_results$Value[i] <- retval
			}
			
		}, silent=TRUE)
		
		if(inherits(s, 'try-error')){
#			if(grepl('subsettable', as.character(s)))
#				browser()
      
			err <- gsub('^ *', '', gsub('\n','', strsplit(as.character(s),'Error : ',TRUE)[[1]][2]))
			if(is.na(err)){
				err <- gsub('^ *', '', gsub('\n','', as.character(s)))
			}
			funenv$log$Error(err)
		}
	
		errors <- funenv$log$RetrieveErrors()
		warnings <- funenv$log$RetrieveWarnings()
		
		totalwarns <- totalwarns + length(warnings)
		totalerrors <- totalerrors + length(errors)
		
		all_results$NumberOfErrors[i] <- length(errors)
		all_results$NumberOfWarnings[i] <- length(warnings)
		all_results$AllErrors[i] <- paste(errors, collapse='  -:-  ')
		all_results$AllWarnings[i] <- paste(warnings, collapse='  -:-  ')
		
		# Move lengthy Nobs to last element:
		Nobs <- all_results$Nobs
		all_results$Nobs <- NULL
		all_results$Nobs <- Nobs
		
		funenv$log$UnsetDataset()
		
		
	}

	funenv$log$CloseFiles()

	# Have to be aware of when using these results that we might still get a return value when errors thrown - leave ValidationCheck though so we always have TotalAnimals:
	all_results$Value[all_results$NumberOfErrors > 0 & all_results$Measure!='ValidationCheck'] <- NA
	
	cat('A total of ', nrow(all_results), ' functions (from ', length(unique(all_results$CHR)), ' farms) were analysed ', sep='')
	if((totalerrors + totalwarns)==0){
		cat('with no errors or warnings\n', sep='')
	}else{
		if(totalerrors > 0){
			cat('with ', totalerrors, ' errors ', sep='')
			if(totalwarns > 0){
				cat('and ', totalwarns, ' warnings', sep='')
			}
			cat('\nThe following errors were obtained:\n', sep='')
			
			msgs <- all_results$AllErrors
			tabs <- table(msgs)
			singles <- tabs[tabs==1]
			
			tabs <- sort(tabs[tabs > 1 & names(tabs)!=""], decreasing=TRUE)
			tabs <- tabs[names(tabs)!=""]
			stopifnot((length(tabs) + length(singles)) >0)
			
			if(length(tabs) > 0) for(m in 1:length(tabs)){
				cat('\t', names(tabs)[m], '\n\t\t[for ', tabs[m], ' CHR / Measure combinations]\n', sep='')
			}
			if(length(singles) > 0) for(m in 1:length(singles)){
				combo <- which(msgs == names(singles)[m])
				stopifnot(length(combo)==1)				
				#cat('\t', names(singles)[m], '\n\t\t[for CHR: ', all_results$CHR[combo], ' on ', as.character(all_results$VisitDate[combo]), ']\n', sep='')
				cat('\t', names(singles)[m], '\n\t\t[for CHR: ', all_results$CHR[combo], ']\n', sep='')
			}
			
			if(totalwarns > 0){
				cat('\nThe following warnings were obtained:\n', sep='')
			}
					
		}else{
			cat('with no errors but ', totalwarns, ' warnings:\n', sep='')
		}
		if(totalwarns > 0){
			
			msgs <- all_results$AllWarnings
			tabs <- table(msgs)
			singles <- tabs[tabs==1]
			
			tabs <- sort(tabs[tabs > 1 & names(tabs)!=""], decreasing=TRUE)
			tabs <- tabs[names(tabs)!=""]
			stopifnot((length(tabs) + length(singles)) >0)
			
			if(length(tabs) > 0) for(m in 1:length(tabs)){
				cat('\t', names(tabs)[m], '\n\t\t[for ', tabs[m], ' CHR / Measure combinations]\n', sep='')
			}
			if(length(singles) > 0) for(m in 1:length(singles)){
				combo <- which(msgs == names(singles)[m])
				stopifnot(length(combo)==1)				
				#cat('\t', names(singles)[m], '\n\t\t[for CHR: ', all_results$CHR[combo], ' on ', as.character(all_results$VisitDate[combo]), ']\n', sep='')
				cat('\t', names(singles)[m], '\n\t\t[for CHR: ', all_results$CHR[combo], ']\n', sep='')
			}
		}
		cat('[You can use either GetResults or SaveResults to inspect the individual function errors and warnings in detail]', sep='')
	} 
	cat('\n')
	
	return(all_results)
}


