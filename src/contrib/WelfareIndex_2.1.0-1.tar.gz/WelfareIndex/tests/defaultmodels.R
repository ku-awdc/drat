library('WelfareIndex')

owd <- getwd()

folders <- c('Cows')#,'Calves','FarrowingSows','Piglets','SowsAndGilts','Weaners')
problem <- logical(length(folders))
names(problem) <- folders
probtext <- ''
for(folder in folders){
  
  setwd(owd)
  
  ss <- try({
    
    model <- WelfareIndex(folder)
    
    setwd(owd)
    index_example(folder=paste0('Testing', folder), data_format='excel', write_script=TRUE, advanced=FALSE, overwrite=TRUE)
    setwd(paste0(owd, '/', paste0('Testing', folder)))
    source('rscript.R')
    model1 <- model
	rm(model)

    setwd(owd)
    index_example(folder=paste0('Testing', folder), data_format='excel', write_script=TRUE, advanced=TRUE, overwrite=TRUE)
    setwd(paste0(owd, '/', paste0('Testing', folder)))
    source('rscript.R')
    model2 <- model
	rm(model)
    
    setwd(owd)
    index_example(folder=paste0('Testing', folder), data_format='excel', write_script=TRUE, advanced=FALSE, overwrite=TRUE)
    setwd(paste0(owd, '/', paste0('Testing', folder)))
    source('rscript.R')
    model3 <- model
	rm(model)
    
    setwd(owd)
    index_example(folder=paste0('Testing', folder), data_format='excel', write_script=TRUE, advanced=TRUE, overwrite=TRUE)
    setwd(paste0(owd, '/', paste0('Testing', folder)))
    source('rscript.R')
    model4 <- model
	rm(model)
    
    setwd(owd)
    index_example(folder=paste0('Testing', folder), data_format='list', write_script=TRUE, advanced=FALSE, overwrite=TRUE)
    setwd(paste0(owd, '/', paste0('Testing', folder)))
    source('rscript.R')
    model5 <- model
	rm(model)
    
    setwd(owd)
    index_example(folder=paste0('Testing', folder), data_format='list', write_script=TRUE, advanced=TRUE, overwrite=TRUE)
    setwd(paste0(owd, '/', paste0('Testing', folder)))
    source('rscript.R')
    model6 <- model
	rm(model)
    
	m1res <- model1$GetResults()
	stopifnot(all(m1res$NumberOfErrors == 0))
	stopifnot(all(m1res$NumberOfWarnings == 0))
	
    stopifnot(all(model1$GetWeights()==model2$GetWeights()))
    stopifnot(all(model1$GetWeights()==model3$GetWeights()))
    stopifnot(all(model1$GetWeights()==model4$GetWeights()))
    stopifnot(all(model1$GetWeights()==model5$GetWeights()))
    stopifnot(all(model1$GetWeights()==model6$GetWeights()))
    
    stopifnot(all(model1$GetMeasures()==model2$GetMeasures()))
    stopifnot(all(model1$GetMeasures()==model3$GetMeasures()))
    stopifnot(all(model1$GetMeasures()==model4$GetMeasures()))
    stopifnot(all(model1$GetMeasures()==model5$GetMeasures()))
    stopifnot(all(model1$GetMeasures()==model6$GetMeasures()))

    stopifnot(all(model1$GetKey()==model2$GetKey(), na.rm=TRUE))
    stopifnot(all(model1$GetKey()==model3$GetKey(), na.rm=TRUE))
    stopifnot(all(model1$GetKey()==model4$GetKey(), na.rm=TRUE))
    stopifnot(all(model1$GetKey()==model5$GetKey(), na.rm=TRUE))
    stopifnot(all(model1$GetKey()==model6$GetKey(), na.rm=TRUE))
    
    m1r <- model1$GetResults()
    
    mtr <- model2$GetResults()
    stopifnot(all(dim(m1r)==dim(mtr)))
    stopifnot(all(sapply(1:length(m1r), function(i) return((all(is.na(m1r[[i]])==is.na(m1r[[i]])) && all(m1r[[i]]==mtr[[i]], na.rm=TRUE))))))
    
    mtr <- model3$GetResults()
    stopifnot(all(dim(m1r)==dim(mtr)))
    stopifnot(all(sapply(1:length(m1r), function(i) return((all(is.na(m1r[[i]])==is.na(m1r[[i]])) && all(m1r[[i]]==mtr[[i]], na.rm=TRUE))))))
    
    mtr <- model4$GetResults()
    stopifnot(all(dim(m1r)==dim(mtr)))
    stopifnot(all(sapply(1:length(m1r), function(i) return((all(is.na(m1r[[i]])==is.na(m1r[[i]])) && all(m1r[[i]]==mtr[[i]], na.rm=TRUE))))))
    
    mtr <- model5$GetResults()
    stopifnot(all(dim(m1r)==dim(mtr)))
    stopifnot(all(sapply(1:length(m1r), function(i) return((all(is.na(m1r[[i]])==is.na(m1r[[i]])) && all(m1r[[i]]==mtr[[i]], na.rm=TRUE))))))
    
    mtr <- model6$GetResults()
    stopifnot(all(dim(m1r)==dim(mtr)))
    stopifnot(all(sapply(1:length(m1r), function(i) return((all(is.na(m1r[[i]])==is.na(m1r[[i]])) && all(m1r[[i]]==mtr[[i]], na.rm=TRUE))))))
    
  
  })
  
  if(inherits(ss, 'try-error')){
    problem[folder] <- TRUE
    probtext <- paste(probtext, as.character(ss), sep='\n')
  }
}

cat(probtext, '\n')
if(any(problem))
  stop(paste0('Problem with the default models for: ', paste(folders[which(problem)], collapse=', ')))

setwd(owd)

folders <- c('Cows','Calves','FarrowingSows','Piglets','SowsAndGilts','Weaners')
problem <- logical(length(folders))
names(problem) <- folders
probtext <- ''
for(folder in folders){
  
  setwd(owd)
  
  ss <- try({
    
    model <- WelfareIndex(folder)
      
  })
  
  if(inherits(ss, 'try-error')){
    problem[folder] <- TRUE
    probtext <- paste(probtext, as.character(ss), sep='\n')
  }
}

cat(probtext, '\n')
if(any(problem))
  stop(paste0('Problem with the default models for: ', paste(folders[which(problem)], collapse=', ')))

setwd(owd)
