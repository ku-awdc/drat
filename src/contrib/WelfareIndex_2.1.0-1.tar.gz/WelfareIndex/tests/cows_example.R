## Test cows example code

library("WelfareIndex")
cwd <- getwd()
setwd(cwd)

unlink("CowsExample", recursive=TRUE)
index_example()
stopifnot(file.exists("CowsExample/Data.xlsx"))

unlink("CowsExample", recursive=TRUE)
index_example(data_format="list")
stopifnot(file.exists("CowsExample/data.Rsave"))

unlink("CowsExample", recursive=TRUE)
index_example(data_format="excel", write_script=TRUE)
stopifnot(file.exists("CowsExample/Data.xlsx"))
stopifnot(file.exists("CowsExample/rscript.R"))
setwd("CowsExample")
source("rscript.R")
setwd(cwd)

unlink("CowsExample", recursive=TRUE)
index_example(data_format="list", write_script=TRUE)
stopifnot(file.exists("CowsExample/data.Rsave"))
stopifnot(file.exists("CowsExample/rscript.R"))
setwd("CowsExample")
source("rscript.R")
setwd(cwd)

unlink("CowsExample", recursive=TRUE)
index_example(data_format="excel", write_script=TRUE, advanced=TRUE)
stopifnot(file.exists("CowsExample/Data.xlsx"))
stopifnot(file.exists("CowsExample/rscript.R"))
setwd("CowsExample")
source("rscript.R")
setwd(cwd)

unlink("CowsExample", recursive=TRUE)
index_example(data_format="list", write_script=TRUE, advanced=TRUE)
stopifnot(file.exists("CowsExample/data.Rsave"))
stopifnot(file.exists("CowsExample/rscript.R"))
setwd("CowsExample")
source("rscript.R")
setwd(cwd)

unlink("CowsExample", recursive=TRUE)
