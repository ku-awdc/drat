options(java.parameters = "-Xmx8g")

library("vetstat")
library("pbapply")
library("qs")

tb <- vs_list_tables()
table_name <- tibble(Table="VT_VETSTAT_HIS_INDBERETNING_MV", Schema="EKSTERN_KU")

oprd <- "OPRETTET_DATO" %in% (vs_table(x) |> names())
oprd


vs_list_tables() |>
  group_split(Table) |>
  pblapply(function(x){
    nrow <- vs_table(x) |> count() |> pull(n)
    x |> mutate(N = nrow)
  }) |>
  bind_rows() ->
  tt

tt |>
  filter(N > 1e6) |>
  group_split(Table) |>
  pblapply(function(x){
    x |>
      bind_cols(
        tibble(Names = vs_table(x) |> names())
      )
  }) |>
  bind_rows() ->
  tn

tn |>
  group_by(Names) |>
  filter(n() == 4L)

table_name <- tibble(Table="VT_VETSTAT_HIS_INDBERETNING_MV", Schema="EKSTERN_KU")
schema=NULL; path=getwd(); max_rows=1e6



# Most have OPRETTET_DATO and it seems to be never missing:
vs_list_tables() |>
  group_split(Table, Schema) |>
  pblapply(function(x){
    oprd <- "OPRETTET_DATO" %in% (vs_table(x$Table, x$Schema) |> names())
    ntot <- vs_table(x$Table, x$Schema) |> count() |> pull(n)
    if(oprd){
      nmiss <- vs_table(x$Table, x$Schema) |> filter(is.null(OPRETTET_DATO)) |> count() |> pull(n)
    }else{
      nmiss <- NA_real_
    }
    x |> mutate(HAS_OPRETTET_DATO = oprd, NTOT = ntot, NMISS = nmiss)
  }) |>
  bind_rows() ->
  tabs
