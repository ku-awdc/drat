library("vetstat")
library("tidyverse")
library("DBI")
library("keyring")

## Load and process datasets to use:
(load("/Volumes/Groups/IVH/Common/VETMYNdata/VetStat/Data/VetStat_raw/2022/vetstat_CHR_BESAETNING.Rdata"))
vetstat_CHR_BESAETNING |>
  select(BESAETNING_ID = ID, BESNR, DYREART_ID, CHR_ID) ->
  CHR_lookup

(load("/Volumes/Groups/IVH/Common/VETMYNdata/VetStat/Data/VetStat_raw/2022/vetstat_KONVERTERING_CHR_SRA_svin.Rdata"))
(load("/Volumes/Groups/IVH/Common/VETMYNdata/VetStat/Data/VetStat_raw/2022/vetstat_KONVERTERING_CHR_SRA_kvæg.Rdata"))
bind_rows(
  vetstat_KONVERTERING_CHR_SRA_svin |> select(-DW_ID),
  vetstat_KONVERTERING_CHR_SRA_kvæg |> select(-DW_ID)
) |>
  select(CHR_NR, DYRLAEGE_ID, DYREART, PRAKSIS_ID, GYLDIG_FRA, GYLDIG_TIL, AFTALETYPE) ->
  KONV_CHR_SRA

(load("/Volumes/Groups/IVH/Common/VETMYNdata/VetStat/Data/Data_suppl/2022/chr_herd_key.RData"))
chr_herd_key |>
  select(CHR_ID = CHR_VS, CHR_NR=CHR, DYREARTKODE=ID_species_VS, BESAETNING_ID=herd_nr_VS, BESNR=herd_nr, BESNR_TIDLIGERE = herd_nr_reg) ->
  CHR_BES_LOOKUP


## Change login to IVH owner and add tables:
conn <- vetstat:::get_conn(username=vs_username() |> str_c("[IVH]"), reset=TRUE)

# dbRemoveTable(conn, Id(schema = "IVH", table = "TEST2"))
# Note: dbplyr::copy_to does this as well
dbWriteTable(conn, Id(schema = "IVH", table = "CHR_LOOKUP"), CHR_lookup, temporary=FALSE)
dbWriteTable(conn, Id(schema = "IVH", table = "KONV_CHR_SRA"), KONV_CHR_SRA, temporary=FALSE)
dbWriteTable(conn, Id(schema = "IVH", table = "CHR_BES_LOOKUP"), CHR_BES_LOOKUP, temporary=FALSE)

data(mtcars)
dbWriteTable(conn, Id(schema = "QJV610", table = "MTCARS"), mtcars, temporary=FALSE)

## Change user status back and check:
conn <- vetstat:::get_conn(username=vs_username(), reset=TRUE)
vs_list_tables() |> View()

CHR_LOOKUP2 <- vs_table("CHR_LOOKUP", "IVH")
nrow(CHR_lookup) == CHR_LOOKUP2 |> count() |> pull(n)

KONV_CHR_SRA2 <- vs_table("KONV_CHR_SRA", "IVH")
nrow(KONV_CHR_SRA) == KONV_CHR_SRA2 |> count() |> pull(n)

CHR_BES_LOOKUP2 <- vs_table("CHR_BES_LOOKUP", "IVH")
nrow(CHR_BES_LOOKUP) == CHR_BES_LOOKUP2 |> count() |> pull(n)


## Test joins across schema:
t1 <- vs_table("CHR_BES_LOOKUP", "IVH")
t2 <- vs_table("KONV_CHR_SRA", "IVH")
t3 <- vs_table("VT_VETSTAT_INDBERETNING_MV", "EKSTERN_KU")
left_join(t1, t2, by="CHR_NR") |> show_query()
left_join(t1, t3, by="CHR_ID") |> show_query()


## Example joins:
stopifnot(packageVersion("vetstat")>="0.1.1-3")
vs_table("CHR_BES_LOOKUP", "IVH") |>
  filter(CHR_NR %in% c("56871","52228","92425")) |>
  left_join(
    vs_table("VT_VETSTAT_INDBERETNING_MV", "EKSTERN_KU"),
    by="CHR_ID"
  ) |>
  collect() ->
  data


## Creating tables:
conn <- vetstat:::get_conn()

#dbRemoveTable(conn, Id(schema = vs_username(), table = "MTCARS"))
#dbCreateTable(conn, Id(schema = vs_username(), table = "MTCARS"), mtcars, temporary=FALSE)

dbRemoveTable(conn, Id(schema = vs_username(), table = "MTCARS"))
dbWriteTable(conn, Id(schema = vs_username(), table = "MTCARS"), mtcars, temporary=FALSE)
vs_table("MTCARS", vs_username())

# For some reason copy_to doesn't work:
dbRemoveTable(conn, Id(schema = vs_username(), table = "MTCARS"))
copy_to(conn, mtcars, in_schema(vs_username(), "MTCARS"), overwrite = TRUE, temporary = FALSE)
vs_table("MTCARS", vs_username())
# NB: overwrite is ignored?



### Attempt to chunk up large tables for saving, but gave up...

library("vetstat")
library("pbapply")

tb <- vs_list_tables()
x <- tibble(Table="VT_VETSTAT_HIS_VARE_MV", Schema="EKSTERN_KU")

vs_list_tables() |>  group_split(Table, Schema) |>  pblapply(function(x){    ntot <- vs_table(x$Table, x$Schema) |> count() |> pull(n)
    tibble(Table=x$Table, N=ntot)
    }) |>
    bind_rows() |>
    arrange(desc(N))
    
    
# Most have OPRETTET_DATO and it seems to be almost never missing:
vs_list_tables() |>
	group_split(Table, Schema) |>
	pblapply(function(x){
		oprd <- "OPRETTET_DATO" %in% (vs_table(x$Table, x$Schema) |> names())
		ntot <- vs_table(x$Table, x$Schema) |> count() |> pull(n)
	    if(oprd){
      		nmiss <- vs_table(x$Table, x$Schema) |> filter(is.null(OPRETTET_DATO)) |> count() |> pull(n)
      	}else{
      		nmiss <- NA_real_
      	}
      	x |> mutate(HAS_OPRETTET_DATO = oprd, NTOT = ntot, NMISS = nmiss)
	}) |>
	bind_rows() ->
	tabs



dumpfun <- function(x, max_rows=1e5){

  stopifnot(nrow(x)==1L)
  df <- vs_table(x$Table, x$Schema)
  nrows <- df |> count() |> pull(n)

  if(nrows > max_rows){
    datecol <- df |> names() |> str_subset("DATO") |> _[1L]
  }

  tibble(chunk = seq(1, nrows %/% (max_rows+1) + 1)) |>
    mutate(start = (chunk-1)*max_rows + 1, end = pmin(chunk*max_rows, nrows)) |>
    mutate(name = case_when(
      max(chunk) == 1L ~ str_c(x$Table, ".rqs"),
      TRUE ~ str_c(x$Table, "_ck", format(chunk) |> str_replace(" ", "0"), ".rqs")
    )) |>
    group_split(name) |>
    lapply(function(y){
      df |> mutate(row = 1:nrows) |> filter(row >= y$start, row <= y$end) -> temp
      qsave(temp, y$name)
      invisible(y$name)
    }) |>
    unlist() ->
    nn

  invisible(nn)

}
