## Script to save all tables

library("vetstat")

vs_list_tables(schema=c("IVH","EKSTERN_KU")) |>
  group_split(Table, Schema) |>
  lapply(function(x){
    tt <- vs_table(x$Table, x$Schema)
    x |> mutate(Rows = tt |> count() |> pull(n), Cols = tt |> names() |> length())
  }) |>
  bind_rows() |>
  arrange(Rows*Cols) ->
  tables

write_csv(tables, "~/Desktop/VetStatSave/tables.csv")

tables |>
  mutate(Index = row_number()) |>
  group_split(Index) |>
  lapply(function(x){
    vs_save(x, path="~/Desktop/VetStatSave")
  }) |>
  bind_rows() ->
  allinfo

vs_read("~/Desktop/VetStatSave/EKSTERN_KU.VT_VETSTAT_HIS_VARE_MV") |> system.time()
vs_read("/Volumes/Groups/IVH/Common/VETMYNdata/VetStat/Data/VetStatSQL/EKSTERN_KU.VT_VETSTAT_HIS_VARE_MV") |> system.time()

df <- vs_read("/Volumes/Groups/IVH/Common/VETMYNdata/VetStat/Data/VetStatSQL/EKSTERN_KU.VT_VETSTAT_HIS_VARE_MV")
