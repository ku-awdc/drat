#' Save SQL tables to a file, and subsequently read from that file
#'
#' @param table_name Name of table to extract (or data frame with 1 row giving Table and Schema)
#' @param schema Schema of table to extract
#' @param path folder to save output to
#' @param max_rows maximum number of rows to read via SQL in one chunk
#' @param chunkswhich chunk(s) should be read back in
#' @param min_dato not currently implemented
#' @param max_dato not currently implemented
#'
#'
#' @importFrom qs qsave qread
#' @importFrom stats quantile
#' @importFrom readr write_csv
#' @importFrom pbapply pblapply
#' @importFrom lubridate tz format_ISO8601
#'
#' @export
vs_save <- function(table_name, schema=NULL, path=getwd(), max_rows=1e6){

  tab <- vs_table(table_name, schema)

  if(!dir.exists(path)){
    stop("Specified path (", path, ") does not exist")
  }
  if(dir.exists(file.path(path, attr(tab, "name")))){
    stop("Save folder (", file.path(path, attr(tab, "name")), ") already exists")
  }
  dir.create(file.path(path, attr(tab, "name")))

  cat("Saving ", attr(tab, "name"), " to ", path, "...\n", sep="")
  st <- Sys.time()

  rows <- tab |> count() |> pull(n)

  if(rows > max_rows){

    stopifnot("OPRETTET_DATO" %in% (tab |> names()))
    oprd <- tab |> pull(OPRETTET_DATO)
    breaks <- quantile(oprd, probs=seq(0,1,length.out=(rows %/% max_rows)+2L))
    breaks[1L] <- breaks[1L]-60

    tibble(Chunk = seq(1,length(breaks)-1L,by=1L), Min=breaks[-length(breaks)], Max=breaks[-1L]) |>
      mutate(Extracted = as.Date(NA_character_), Rows = NA_integer_, Name = case_when(
        max(Chunk) == 1L ~ str_c(attr(tab, "name"), ".rqs"),
        TRUE ~ str_c(attr(tab, "name"), ".", format(Chunk) |> str_replace(" ", "0"), ".rqs")
      )) |>
      group_split(Name) |>
      pblapply(function(x){
        minoprd <- as.character(strftime(x[["Min"]], format="%Y-%m-%d %H:%M:%S"))
        maxoprd <- as.character(strftime(x[["Max"]], format="%Y-%m-%d %H:%M:%S"))

        ## https://www.sqlines.com/oracle-to-sql-server/to_date
        tab |>
          filter(OPRETTET_DATO > to_date(minoprd, "YYYY-MM-DD HH24:MI:SS"),
                 OPRETTET_DATO <= to_date(maxoprd, "YYYY-MM-DD HH24:MI:SS")) |>
          collect() ->
          tdat

        qsave(tdat, file=file.path(path, attr(tab, "name"), x[["Name"]]))

        x[["Rows"]] <- nrow(tdat)
        x[["Extracted"]] <- Sys.time()

        return(x)
      }) |>
      bind_rows() ->
      info

    tz(info[["Min"]]) <- Sys.timezone()
    tz(info[["Max"]]) <- Sys.timezone()
    qsave(info, file=file.path(path, attr(tab, "name"), "info.rqs"))

    info[["Min"]] <- format_ISO8601(info[["Min"]], usetz=TRUE)
    info[["Max"]] <- format_ISO8601(info[["Max"]], usetz=TRUE)

  }else{

    tibble(Chunk = 1L, Extracted = as.Date(NA_character_), Rows = NA_integer_, Name = case_when(
      max(Chunk) == 1L ~ str_c(attr(tab, "name"), ".rqs"),
      TRUE ~ str_c(attr(tab, "name"), ".", format(Chunk) |> str_replace(" ", "0"), ".rqs")
    )) |>
      group_split(Name) |>
      pblapply(function(x){
        tab |>
          collect() ->
          tdat

        qsave(tdat, file=file.path(path, attr(tab, "name"), x[["Name"]]))

        x[["Rows"]] <- nrow(tdat)
        x[["Extracted"]] <- Sys.time()

        return(x)
      }) |>
      bind_rows() ->
      info

    qsave(info, file=file.path(path, attr(tab, "name"), "info.rqs"))
  }

  write_csv(info, file=file.path(path, attr(tab, "name"), "info.csv"))
  if(sum(info[["Rows"]])!=rows){
    warning("Mismatch between total rows saved (", sum(info[["Rows"]]), ") and total rows in database (", rows, ")")
  }

  cat("Done (total time: ", round(as.numeric(Sys.time()-st, units="secs")/60, 1), " minutes)\n", sep="")

  invisible(info)
}


#' @rdname vs_save
#' @export
vs_read <- function(path, chunks=NULL, min_dato=NULL, max_dato=NULL){

  if(!dir.exists(path)) stop("No folder at specified directory")
  if(!file.exists(file.path(path, "info.rqs"))) stop("No info.rqs at specified directory")

  info <- qread(file.path(path, "info.rqs"))

  #info <- read_csv(file.path(path, "info.csv"), col_types=cols(
  #  Chunk = col_double(),
  #  Min = col_datetime(format = ""),
  #  Max = col_datetime(format = ""),
  #  Extracted = col_datetime(format = ""),
  #  Rows = col_double(),
  #  Name = col_character()
  # ))
  ## Note:  tz will be UTC not Europe/Copenhagen

  ## TODO: implement min_dato and max_dato
  if(!is.null(min_dato)) stop("min_dato is not yet supported")
  if(!is.null(max_dato)) stop("max_dato is not yet supported")

  if(is.null(chunks)) chunks <- info[["Chunk"]]

  if(!all(chunks %in% info[["Chunk"]])) stop("Invalid chunk(s) specified")

  rv <- pblapply(chunks, function(c) qread(file.path(path, info[["Name"]][c]))) |> bind_rows()
  attr(rv, "extracted") <- info[["Extracted"]][chunks] |> max()

  return(rv)
}
