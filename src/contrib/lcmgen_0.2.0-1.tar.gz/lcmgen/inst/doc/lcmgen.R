## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library("lcmgen")
library("mirai")

mirai::daemons(2)

## -----------------------------------------------------------------------------
lcm_sim(
  N = c(200,200),
  prevalence = c(0.5,0.1),
  sensitivity = c(0.9,0.8),
  specificity = c(0.95,0.99),
  iterations = 10L
)

## -----------------------------------------------------------------------------
lcm_sim(
  N = c(200,200),
  prevalence = c(0.5,0.1),
  sensitivity = c(0.9,0.8),
  specificity = c(0.95,0.99),
  target_se = 0.8,
  target_sp = 0.9,
  iterations = 10L
)

## -----------------------------------------------------------------------------
library("tibble")
roc <- tribble(
    ~Se, ~Sp,
    0, 1,
    0.6, 0.99,
    0.7, 0.95,
    0.8, 0.92,
    0.9, 0.9,
    0.99, 0.8,
    1, 0
  )
with(roc, plot(Se, Sp, type="both", xlim=c(0.5,1), ylim=c(0.5,1)))

## -----------------------------------------------------------------------------
lcm_sim(
  N = c(200,200),
  prevalence = c(0.5,0.1),
  sensitivity = c(0.9,0.8),
  specificity = c(0.95,0.99),
  target_roc = roc,
  target_se = 0.8,
  target_sp = 0.9,
  iterations = 10L
)

