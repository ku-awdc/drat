# lcmgen
framework for generating, testing and comparing Bayesian latent class models for diagnostic test evaluation
