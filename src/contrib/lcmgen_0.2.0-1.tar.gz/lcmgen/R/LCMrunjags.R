#' @importFrom stats approxfun

LCMrunjags <- R6::R6Class(
  "LCMrunjags",

  public = list(

    set_target_se = function(se){
      qassert(se, "R1(0,1)")
      private$se_target <- se

      invisible(self)
    },

    set_target_sp = function(sp){
      qassert(sp, "R1(0,1)")
      private$sp_target <- sp

      invisible(self)
    },

    set_target_roc = function(roc){
      # roc should be a data frame with se and sp cols, where one is decreasing as the other increases, both with range 0-1
      qassert(roc, "D2")

      names(roc) <- tolower(names(roc))
      stopifnot(names(roc)==c("se","sp"), roc$se==sort(roc$se), roc$sp==sort(roc$sp, decreasing=TRUE), range(roc$se)==c(0.0,1.0), range(roc$sp)==c(0.0,1.0))

      private$roc_target <- approxfun(roc$se, roc$sp)

      invisible(self)
    },

    # To be run when moved to a mirai demon
    setup = function(){

      stopifnot(require("checkmate"))
      stopifnot(require("dplyr"))
      stopifnot(require("tidyr"))
      stopifnot(require("tibble"))
      stopifnot(require("runjags"))
      stopifnot(require("rjags"))
      runjags.options(silent.jags=TRUE, silent.runjags=TRUE)

      invisible(self)
    },

    # Set initial values
    set_inits = function(initlist){

      private$inits <- list(initlist, initlist)

      invisible(self)
    },

    # Do everything
    get_pvals = function(datalist){

      private$compile_model(datalist)
      private$extend_model()

      rv <- tibble(
        Median_Se = median(private$trace_se),
        Median_Sp = median(private$trace_sp)
      )

      pv <- private$extract_se_pval()
      if(!is.null(pv)){
        rv <- mutate(rv, Pval_Se=pv)
      }
      pv <- private$extract_sp_pval()
      if(!is.null(pv)){
        rv <- mutate(rv, Pval_Sp=pv)
      }
      pv <- private$extract_roc_pval()
      if(!is.null(pv)){
        rv <- mutate(rv, Pval_ROC=pv)
      }

      rv
    },

    # Get the fitted model object
    get_model = function(){
      return(private$model)
    }

  ),

  private = list(

    inits = list(),

    se_target = NULL,
    sp_target = NULL,
    roc_target = NULL,

    model = NULL,
    trace_se = NULL,
    trace_sp = NULL,

    # Compile model with burnin
    compile_model = function(datalist){
      mm <- "model{
    for(p in 1:Populations){
        Tally[1:4,p] ~ dmulti(prob[1:4,p], N[p])
        prob[1,p] <- prev[p] * ((1-se[1])*(1-se[2]))  +  (1-prev[p]) * (sp[1])*(sp[2])
        prob[2,p] <- prev[p] * (se[1]*(1-se[2]))  +  (1-prev[p]) * (1-sp[1])*sp[2]
        prob[3,p] <- prev[p] * ((1-se[1])*(se[2]))  +  (1-prev[p]) * (sp[1])*(1-sp[2])
        prob[4,p] <- prev[p] * (se[1]*se[2])  +  (1-prev[p]) * (1-sp[1])*(1-sp[2])
    }
    for(p in 1:Populations){
      prev[p] ~ dbeta(1,1)
    }
    se[1] ~ dbeta(2,1)
    se[2] ~ dbeta(2,1)
    sp[1] ~ dbeta(2,1)
    sp[2] ~ dbeta(2,1)
  	for(t in 1:2){
  		AcceptTest[t] ~ dbern(ifelse((se[t]+sp[t]) >= 1.0, 1, 0))
  	}
}"
      private$model <- run.jags(mm, adapt=1000L, burnin=1000L, sample=0L, monitor=c("se[1]","sp[1]"), data=datalist, n.chains=2, inits=private$inits, method="rjags", summarise=FALSE)

    },

    # Extend model
    extend_model = function(){

      private$model <- extend.jags(private$model, sample=10000L, combine=TRUE)
      private$trace_se <- combine.mcmc(private$model, vars="se[1]") |> as.numeric()
      private$trace_sp <- combine.mcmc(private$model, vars="sp[1]") |> as.numeric()

    },

    # Extract se pval
    extract_se_pval = function(){
      if(is.null(private$se_target)) return(NULL)
      return(sum(private$trace_se < private$se_target) / length(private$trace_se))
    },

    # Extract sp pval
    extract_sp_pval = function(){
      if(is.null(private$sp_target)) return(NULL)
      return(sum(private$trace_sp < private$sp_target) / length(private$trace_sp))
    },

    # Extract roc pval
    extract_roc_pval = function(){
      if(is.null(private$roc_target)) return(NULL)

      sp_min <- private$roc_target(private$trace_se)
      stopifnot(length(sp_min)==length(private$trace_sp), sp_min >= 0, sp_min <= 1)
      return(sum(private$trace_sp < sp_min) / length(private$trace_sp))
    }

  ),

  active = list(

  ),

  lock_class = TRUE

)

if(FALSE){
  library(checkmate)
  library(tidyverse)
  data <- list(
    "Tally" = structure(c(9, 4, 3, 4, 8, 1, 1, 0), .Dim = c(4, 2)),
    "N" = c(20, 10),
    "AcceptTest" = c(1, 1),
    "Populations" = 2
  )
  inits <- list(
    "se" = c(0.9, 0.8),
    "sp" = c(0.9, 0.95),
    "prev" = c(0.5, 0.1)
  )
  mm <- LCMrunjags$new()
  mm$set_target_se(0.8)
  mm$set_target_sp(0.5)
  mm$set_target_roc(tribble(
    ~Se, ~Sp,
    0, 1,
    0.8, 0.99,
    0.9, 0.95,
    0.99, 0.9,
    1, 0
  ))
  mm$setup()
  mm$set_inits(inits)
  mm$get_pvals(data)
}
