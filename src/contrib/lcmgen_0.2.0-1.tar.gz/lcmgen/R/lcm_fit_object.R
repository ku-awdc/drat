#' Construct an LCM fit object
#'
#' @param type currently only "runjags" is supported
#'
#' @returns an R6 class object
#'
#' @import R6
#' @import rjags
#' @import runjags
#'
#' @export
lcm_fit_object <- function(type = c("runjags")){

  type <- match.arg(type)
  LCMrunjags$new()

}
