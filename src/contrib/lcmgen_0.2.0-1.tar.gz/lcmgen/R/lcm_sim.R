#' Simulate a diagnostic test evaluation (latent class) model for the purposes of sample size / power calculation
#'
#' @param N a vector of sample sizes in different populations
#' @param prevalence a vector of prevalences in different populations (between 0-1)
#' @param sensitivity a vector of sensitivity values (between 0-1) where the first element is the new test to be evaluated
#' @param specificity a vector of specificity values (between 0-1) where the first element is the new test to be evaluated
#' @param target_roc a data frame with two columns named Se and Sp, giving paired points along a ROC curve representing the target profile for the new test to be evaluated - Se should be ascending (from 0-1) and Sp should be descending (from 1-0), so that the first and last rows must be 0,1 and 1,0 respectively. This parameter is optional - if provided, then Bayesian p-values will be calculated representing the posterior probability that the new test performs at least as well as the provided target ROC.
#' @param target_se a scalar value (between 0-1) giving a target sensitivity value for the new test to be evaluated. This parameter is optional - if provided, then Bayesian p-values will be calculated representing the posterior probability that the new test has a sensitivity at least as good as the provided target.
#' @param target_sp a scalar value (between 0-1) giving a target specificity value for the new test to be evaluated. This parameter is optional - if provided, then Bayesian p-values will be calculated representing the posterior probability that the new test has a specificity at least as good as the provided target.
#' @param iterations the number of iterations to run
#' @param return_type the function can produce either a summary data frame of bias/precision/power values, raw results of Bayesian p-value(s) and median estimates for se/sp from each iteration, or a mirai promise for a list of single-row data frames with the raw results.
#' @param fitting_object an R6 class (or similar) object used for the fitting and extracting posterior estimates - see the \code{\link{lcm_fit_object}} function
#'
#' @returns see the return_type argument
#'
#' @importFrom checkmate qassert
#' @importFrom stats rmultinom qbeta var
#' @importFrom mirai require_daemons mirai_map collect_mirai everywhere
#' @import dplyr
#' @import tibble
#' @import stringr
#' @importFrom tidyr pivot_longer
#' @importFrom forcats fct
#' @importFrom purrr map
#' @importFrom rlang .data
#' @importFrom TeachingDemos hpd
#'
#' @export
lcm_sim <- function(N, prevalence, sensitivity, specificity, target_roc=NULL, target_se=NULL, target_sp=NULL, iterations=500L, return_type=c("summary", "raw", "mirai"), fitting_object=lcm_fit_object("runjags")){

  warning("This function was written quickly and has not yet undergone any substantial testing; it should therefore be used carefully as it may contain bugs...")

  ## Parameter checks
  qassert(N, "X+[0,]")
  qassert(sensitivity, "R2(0,1)")
  qassert(specificity, "R2(0,1)")
  qassert(prevalence, "R+(0,1)")
  qassert(iterations, "X1[0,]")
  stopifnot(length(N)==length(prevalence))
  return_type <- match.arg(return_type)
  # TODO: check fitting_object for required methods including pvalue member

  ## Simulate the data first:
  vapply(seq_along(prevalence), \(p){
    prev <- prevalence[p]
    c(
      prev * (1.0-sensitivity[1])*(1-sensitivity[2]),
      prev * (sensitivity[1])*(1-sensitivity[2]),
      prev * (1.0-sensitivity[1])*(sensitivity[2]),
      prev * (sensitivity[1])*(sensitivity[2])
    ) + c(
      (1-prev) * (specificity[1])*(specificity[2]),
      (1-prev) * (1.0-specificity[1])*(specificity[2]),
      (1-prev) * (specificity[1])*(1.0-specificity[2]),
      (1-prev) * (1.0-specificity[1])*(1.0-specificity[2])
    ) ->
      probs
    stopifnot(all.equal(1.0, sum(probs)))

    rmultinom(iterations, N[p], probs)
  }, matrix(NA_integer_, nrow=2^length(sensitivity), ncol=iterations)) |>
    apply(2, identity, simplify=FALSE) |>
    lapply(\(x){
      list(Tally = x, N = N, AcceptTest = c(1,1), Populations = length(N))
    }) |>
    identity() ->
    simdata

  ## Pass in targets:
  anytarget <- FALSE
  if(!is.null(target_roc)){
    fitting_object$set_target_roc(target_roc)
    anytarget <- TRUE
  }
  if(!is.null(target_se)){
    fitting_object$set_target_se(target_se)
    anytarget <- TRUE
  }
  if(!is.null(target_sp)){
    fitting_object$set_target_sp(target_sp)
    anytarget <- TRUE
  }
  if(isFALSE(anytarget) && return_type=="power") stop("No target values provided")

  ## Generate initial values:
  fitting_object$set_inits(list(
    se = sensitivity,
    sp = specificity,
    prev = prevalence
  ))

  ## Then check mirai is set up:
  require_daemons()
  everywhere({
    fitting_object$setup()
  }, fitting_object = fitting_object)

  ## Then run on the daemons:
  mm <- mirai_map(simdata, \(sd){
    fitting_object$get_pvals(sd)
  })

  if(return_type=="mirai"){
    return(mm)
  }

  rr <- collect_mirai(mm, ".progress") |> bind_rows()

  if(return_type=="raw"){
    return(rr)
  }

  stopifnot(return_type=="summary")

  ## Bias and precision
  rr |>
    select(starts_with("Median_")) |>
    rename_with(\(x) str_replace(x, "Median_", "")) |>
    pivot_longer(everything(), names_to="Parameter", values_to="Median") |>
    left_join(
      tibble(True = c(sensitivity[1], specificity[1]), Parameter=c("Se","Sp")),
      join_by("Parameter")
    ) |>
    group_by(.data$Parameter) |>
    summarise(Bias = mean(.data$Median-.data$True), Variance = var(.data$Median), .groups="drop") |>
    identity() ->
    bprec

  if(anytarget){
    bind_rows(

      ## Power for individual parameters
      rr |>
        select(starts_with("Pval_")) |>
        rename_with(\(x) str_replace(x, "Pval_", "")) |>
        pivot_longer(everything(), names_to="Parameter", values_to="Pval") |>
        group_by(.data$Parameter) |>
        summarise(Success = sum(.data$Pval <= 0.05), Total = n(), Power = .data$Success/.data$Total, .groups="drop"),

      ## Power for combined parameters
      rr |>
        select(starts_with("Pval_")) |>
        rename_with(\(x) str_replace(x, "Pval_", "")) |>
        rowid_to_column("Iteration") |>
        pivot_longer(-.data$Iteration, names_to="Parameter", values_to="Pval") |>
        group_by(.data$Iteration) |>
        summarise(Status = all(.data$Pval <= 0.05), .groups="drop") |>
        summarise(Parameter = "Combined", Success = sum(.data$Status), Total = n(), Power = .data$Success/.data$Total, .groups="drop")
    ) |>
      rowwise() |>
      group_split() |>
      map(\(x){
        ci <- hpd(qbeta, shape1=x$Success+1, shape2=(x$Total-x$Success)+1)
        x |>
          ungroup() |>
          mutate(LCI = ci[1],
                 UCI = ci[2])
      }) |>
      bind_rows() |>
      full_join(
        bprec,
        join_by("Parameter")
      ) |>
      select(.data$Parameter, .data$Bias, .data$Variance, .data$Success,
             .data$Total, .data$Power, .data$LCI, .data$UCI) |>
      identity() ->
      rv
  }else{
    rv <- bprec
  }

  rv |>
    mutate(Parameter = fct(.data$Parameter, levels=c("Se","Sp","ROC","Combined"))) |>
    arrange(.data$Parameter)

}

if(FALSE){
  mirai::daemons(2)
  lcm_sim(
    N = c(20,20),
    prevalence = c(0.5,0.1),
    sensitivity = c(0.9,0.8),
    specificity = c(0.95,0.99),
    target_roc = tibble::tribble(
      ~Se, ~Sp,
      0, 1,
      0.8, 0.99,
      0.9, 0.95,
      0.99, 0.9,
      1, 0
    ),
    target_se = 0.8,
    target_sp = 0.9,
    iterations = 4L,
    return_type = "summary"
  )
}
