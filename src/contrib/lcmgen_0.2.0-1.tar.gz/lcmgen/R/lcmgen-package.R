#' @name lcmgen-package
#' @aliases lcmgen
#' @title What the Package Does (One Line, Title Case)
#'
#' @details
#' Some description of the package
#'
#' @examples
#'
#' ## To cite this package in publications use:
#' citation("lcmgen")
#'
#'
#' @keywords internal
"_PACKAGE"

## usethis namespace: start
## usethis namespace: end
NULL
