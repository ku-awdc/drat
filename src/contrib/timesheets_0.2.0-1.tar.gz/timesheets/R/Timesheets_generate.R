#' @importFrom openxlsx loadWorkbook pageSetup cloneWorksheet writeData removeWorksheet saveWorkbook readWorkbook
#' @importFrom readxl read_excel excel_sheets
#' @importFrom pbapply pblapply
#' @importFrom rlang set_names

Timesheets_generate <- function(self, private, template="innovationsfonden"){

  if(FALSE){
    excel_sheets(input_data) |>
      set_names() |>
      pblapply(function(x) read_excel(input_data, sheet=x)) ->
      input_data

    lnames <- names(input_data)

    if(!"Metadata" %in% lnames){
      stop("Missing Metadata")
    }

    stopifnot("Hours" %in% names(input_data))
    stopifnot(all(c("Date","Time","Task") %in% names(input_data[["Hours"]])))

  }

  (private %.% holidays) |>
    mutate(End = case_when(is.na(End) ~ Start, TRUE ~ End)) |>
    mutate(Start = as.Date(Start), End = as.Date(End)) |>
    group_split(row_number()) |>
    lapply(function(x){
      seq(x$Start, x$End, by=1L)
    }) |>
    {function(x) do.call("c", x)}() ->
    all_holidays

  wbfn <- system.file("templates", str_c(template, ".xlsx"), package="timesheets")
  stopifnot(length(wbfn)==1L, !is.na(wbfn), file.exists(wbfn))

  wb <- loadWorkbook(wbfn)

  ## Check:
  tplt <- readWorkbook(wb, "Template", skipEmptyRows=FALSE, skipEmptyCols=FALSE, colNames=FALSE, rowNames=FALSE, startRow=0L)
  lastrow <- nrow(tplt)

  (private %.% metadata) |>
    group_split(Variable) |>
    pblapply(function(x){
      stopifnot(nrow(x)==1L)
      rn <- case_when(
        x[["Variable"]] == "Project" ~ 12L,
        x[["Variable"]] == "Alias" ~ 13L,
        x[["Variable"]] == "FileNo" ~ 14L,
        x[["Variable"]] == "Name" ~ 15L,
        x[["Variable"]] == "Category" ~ 16L,
        x[["Variable"]] == "Approver" ~ lastrow+1L,
        TRUE ~ NA_integer_
      )
      cn <- case_when(
        x[["Variable"]] == "Approver" ~ "E",
        TRUE ~ "F"
      )
      if(!is.na(rn)) writeData(wb, "Template", x[["Value"]], startCol = cn, startRow = rn)
    }) ->
    tt

  nm <- (private %.% metadata) |> filter(Variable=="Name") |> pull(Value)
  stopifnot(length(nm)==1L)
  writeData(wb, "Template", nm, startCol = "E", startRow = lastrow-5L)

  pageSetup(wb, "Template", "portrait", fitToWidth=TRUE, fitToHeight=TRUE, paperSize=9L)

  (private %.% timesheet) |>
    mutate(Year = year(Date), Month = month(Date), MonthLab = month(Date, label = TRUE, abbr = FALSE, locale = "en_US.UTF-8")) |>
    group_by(Year, Month, MonthLab, Task) |>
    summarise(Time = sum(Time), .groups="drop") |>
    group_split(Year, Month, MonthLab) |>
    pblapply(function(x){
      shtnm <- str_c(x[["Year"]][1], "-", x[["MonthLab"]][1])
      entries <- 1:nrow(x)
      sigdts <- as.Date(str_c(x[["Year"]][1], "-", x[["Month"]][1], "-01")) + months(1) + 0:9
      sigdts <- sigdts[wday(sigdts, week_start=1) %in% 1:5]
      sigdts <- sigdts[!sigdts %in% all_holidays]
      stopifnot(length(sigdts) > 0L)
      sigdt <- min(Sys.Date(), sample(sigdts, 1))

      cloneWorksheet(wb, shtnm, "Template")
      writeData(wb, shtnm, x[["Task"]], "C", 21)
      writeData(wb, shtnm, x[["Time"]], "K", 21)
      writeData(wb, shtnm, sum(x[["Time"]]), "K", lastrow-9L)

      writeData(wb, shtnm, x[["MonthLab"]][1], "F", 18)
      writeData(wb, shtnm, x[["Year"]][1], "I", 18)

      writeData(wb, shtnm, as.character(sigdt), "C", lastrow-5L)
      writeData(wb, shtnm, as.character(sigdt), "C", lastrow+1L)

      tibble(Month = shtnm, Hours=sum(x[["Time"]]))
    }) |>
    bind_rows() ->
    tt

  removeWorksheet(wb, "Template")

  tdir <- private$get_tdir()
  saveWorkbook(wb, file.path(tdir, "timesheets.xlsx"), overwrite=TRUE)

  tt
}
