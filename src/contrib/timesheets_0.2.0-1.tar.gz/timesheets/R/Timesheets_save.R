#' @importFrom utils browseURL

Timesheets_save <- function(self, private, filename, open){

  ff <- file.path(private$get_tdir(), "timesheets.xlsx")
  if(!file.exists(ff)) stop("You have not run generate!")

  ss <- file.copy(ff, file.path(getwd(), filename), overwrite=TRUE)
  if(!ss) stop("Error copying file")

  if(open) browseURL(file.path(getwd(), filename))

  cat("File written to ", file.path(getwd(), filename), "\n")
  invisible(self)

}

Timesheets_save_pdf <- function(self, private, filename, open, lo_path){
  ff <- file.path(private$get_tdir(), "timesheets.xlsx")
  if(!file.exists(ff)) stop("You have not run generate!")

  tdir <- private$get_tdir()
  system2(lo_path, c(paste0("-env:UserInstallation=file://", tdir), "--headless", "--convert-to pdf", "--outdir", tdir, file.path(tdir,"timesheets.xlsx")))

  ss <- file.copy(file.path(tdir, "timesheets.pdf"), file.path(getwd(), filename), overwrite=TRUE)
  if(!ss) stop("Error copying file")

  if(open) browseURL(file.path(getwd(), filename))

  cat("File written to ", file.path(getwd(), filename), "\n")
  invisible(self)

}
