#' An example R6 class
#'
#' @param value an initialisation value
#' @param new_value a new value to use
#'
#' @importFrom R6 R6Class
#'
#' @examples
#' example_instance <- Timesheets$new()
#' example_instance
#'
#' @export
Timesheets <- R6::R6Class("Timesheets",

  public = list(
    # https://github.com/mlr-org/mlr3/wiki/Roxygen-R6-Guide

    #' @description
    #' Creates a new instance of this [R6][R6::R6Class] class.
    #'
    #' Note that this object is typically constructed via derived classes,
    #' e.g., [ParamDbl].
    #'
    #' @param id (`character(1)`)\cr
    #'   Identifier of the object.
    #' @param special_vals (`list()`)\cr
    #'   Arbitrary special values this parameter is allowed to take, to make it
    #'   feasible. This allows extending the domain of the parameter. Note that
    #'   these values are only used in feasibility checks, neither in generating
    #'   designs nor sampling.
    #' @param default (`any`)\cr
    #'   Default value. Can be from the domain of the parameter or an element of
    #'   `special_vals`. Has value [NO_DEF] if no default exists. `NULL` can be a
    #'   valid default.
    #' @param tags (`character()`)\cr
    #'   Arbitrary tags to group and subset parameters. Some tags serve a special
    #'   purpose:\cr
    #'   * `"required"` implies that the parameters has to be given when setting
    #'     `values` in [ParamSet].
    initialize = function(project="", alias="", file_no="", name="", category="",
      approver="", template="innovationsfonden")
      Timesheets_initialize(self=self, private=private,
        project=project, alias=alias, file_no=file_no, name=name,
        category=category, approver=approver, template=template),

    finalize = function() if(dir.exists(private %.% tdir)) unlink(private %.% tdir, recursive=TRUE),

    import_file = function(file) Timesheets_import_file(self, private, file),
    import_metadata = function(df) Timesheets_import_metadata(self, private, df),
    import_totals = function(df) Timesheets_import_totals(self, private, df),
    import_holidays = function(df) Timesheets_import_holidays(self, private, df),
    import_timesheet = function(df) Timesheets_import_timesheet(self, private, df),

    generate = function() Timesheets_generate(self, private),

    save = function(filename="timesheets.xlsx", open=TRUE) Timesheets_save(self, private, filename=filename, open=open),

    save_pdf = function(filename="timesheets.pdf", open=TRUE, lo_path="/Applications/LibreOffice.app/Contents/MacOS/soffice") Timesheets_save_pdf(self, private, filename=filename, open=open, lo_path=lo_path)
  ),

  private = list(

    #' @field id (`tibble()`)\cr
    #' Timesheet metadata.
    metadata = tibble(Project="", Alias="", FileNo="", Name="", Category="", Approver=""),

    totals = tibble(Year=numeric(0), Hours=numeric(0)),
    holidays = tibble(Start=as.Date(character(0)), End=as.Date(character(0)), Notes=character(0)),
    timesheet = tibble(Date=as.Date(character(0)), Hours=numeric(0), Task=character(0)),

    workbook = NULL,
    tdir = NULL,

    get_tdir = function(){
      if(!dir.exists(private %.% tdir)) dir.create(private %.% tdir)
      private %.% tdir
    }

  )


)


Timesheets_initialize <- function(self, private, project, alias, file_no, name, category, approver, template){

  ## TODO: save template

  (self %.% import_metadata)(
    tibble(Project=project, Alias=alias, FileNo=file_no, Name=name, Category=category, Approver=approver) |> pivot_longer(everything(), names_to="Variable", values_to="Value")
  )

  ## Note:  this is unlinked by the finaliser if it exists
  tdir <- tempfile(pattern="timesheets")
  private$tdir <- tdir

  invisible(self)
}

Timesheets_import_metadata <- function(self, private, df){
  cat("Importing metadata...\n")
  private$metadata <- df
  invisible(self)
}


Timesheets_import_timesheet <- function(self, private, df){
  cat("Importing timesheet...\n")

  if(is.character(df) && file.exists(df)) df <- read_excel(df, 1L)

  stopifnot(all(c("Date","Time","Task") %in% names(df)))
  stopifnot(inherits(df[["Date"]], c("Date", "POSIXt")))
  stopifnot(is.numeric(df[["Time"]]))
  stopifnot(is.character(df[["Task"]]))

  private$timesheet <- df |> select(Date, Time, Task) |> mutate(Date = as.Date(Date))
  invisible(self)
}

Timesheets_import_file <- function(self, private, file){

  stopifnot(file.exists(file))
  excel_sheets(file) |>
    set_names() |>
    pblapply(function(x) read_excel(file, sheet=x)) ->
    input_data

  lnames <- names(input_data)

  if(!"Metadata" %in% lnames){
    stop("Missing Metadata")
  }else{
    self$import_metadata(input_data[["Metadata"]])
  }

  ## TODO: other sheets

  invisible(self)

}
