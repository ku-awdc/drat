## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library("timesheets")

## -----------------------------------------------------------------------------
ts <- Timesheets$new(project="Testing", alias="123456", file_no="0123-456789", name="Michael Mouse", category="VIP", approver="Donald Duck", template="innovationsfonden")

## -----------------------------------------------------------------------------
tribble(~Date, ~Time, ~Task,
  "2023-01-05", 2, "Some task",
  "2023-01-15", 2, "Some other task",
  "2023-02-05", 2, "A third task",
  "2023-02-06", 2, "A third task",
  "2023-02-15", 2, "Some task"
  ) |> mutate(Date = as.Date(Date)) ->
hours

hours

ts$import_timesheet(hours)

## -----------------------------------------------------------------------------
(totals <- ts$generate())
totals |> summarise(Hours=sum(Hours))

## -----------------------------------------------------------------------------
ts$save("timesheets.xlsx", open=FALSE)

## ----eval=FALSE---------------------------------------------------------------
#  ts$save_pdf("timesheets.pdf", open=FALSE, lo_path="path/to/libreoffice")

## ----show=FALSE---------------------------------------------------------------
rm("timesheets.xlsx")

