# Skip this on CRAN / WinBuilder:
if(is.na(Sys.getenv("NOT_CRAN", unset = NA))){
  cat('Test skipped on CRAN\n')
}else{

  cat('Check that the model can be set up and run with a very large number of farms (150,000) without causing memory issues\n')
  
  library('efsabt')
  set.seed(2016-02-12)
  st <- Sys.time()
  N <- 150000

  dem <- CreateGubbinsDemography(N=N)
  
  fixedinfo <- DefaultFixed(N)
  variableinfo <- DefaultVariable()
  
  temps <- matrix(20, ncol=5, nrow=1000*24)
  
  demography <- CreateGubbinsDemography(N = N, FixedParameters = fixedinfo, VariableParameters = variableinfo, TemperatureData=temps)
  
  sc <- SimContainer(demography)
  
  # Randomly generated spatial points:
  xl <- runif(N, min=0, max=1000)
  yl <- runif(N, min=0, max=1000)
  
  sm <- SparseMatrix(xl, yl, threshold=10^-6)
  sc$AddSparseMatrixNetwork(N, sm, 1)
  
  sc$AddSimulation(50)
  sc$Infect(1:10)
  sc$Update(50)
  
  # Should spread a reasonable amount:
  if(sc$GetPrevalences()[50] > 0.1){
	  cat('Test passed in ', difftime(Sys.time(), st, units='m'), ' minutes\n')
  }else{
	  stop(paste('Test failed - prevalence was below 0.1 at the end of the simulation\n(All time points: ', paste(round(sc$GetPrevalences(),2), collapse=', '), ')\n'))
  }
  
}