cat('Test that the farms become infectious at high temperatures\n')

library('efsabt')
tol <- 10^-6
set.seed(2015-01-05)

fixed <- DefaultFixed(N=100, novel=TRUE)
variable <- DefaultVariable(novel=TRUE)

temps <- matrix(30, ncol=5, nrow=1000*24)

dem <- CreateGubbinsDemography(N=100, fixed, variable, temps)

res <- FarmModel(dem, 20, quiet=TRUE)

# >50% inefcted animals at 10 time points
stopifnot(sum(res$Sheep[,'CumulativeInfected','Time_10']+res$Cattle[,'CumulativeInfected','Time_10'] > 0) > 50)
# >25% infectious farms at 10 time points
stopifnot(sum(res$FirstInfectious <= 10) > 25)
# >50% infectious farms at 20 time points
stopifnot(sum(res$FirstInfectious <= 20) > 50)

cat('Test passed\n')
