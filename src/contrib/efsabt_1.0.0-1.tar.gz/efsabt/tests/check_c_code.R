library('efsabt')

debugmode <- efsabt:::GetDebugSetting()
test <- efsabt:::CheckAgentTypes()

cat('Using debug setting', debugmode, '\n', sep=' ')
cat('Test passed\n')
