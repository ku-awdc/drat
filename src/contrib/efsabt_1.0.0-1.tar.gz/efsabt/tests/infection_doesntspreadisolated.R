cat('Test that infection infection seeded in an isolated farm does not spread to a network component involving all other farms\n')

library('efsabt')
tol <- 10^-6
set.seed(2015-01-05)

fixed <- DefaultFixed(N=100, novel=TRUE)
variable <- DefaultVariable(novel=TRUE)

temps <- matrix(25, ncol=5, nrow=1000*24)

dem <- CreateGubbinsDemography(N=100, fixed, variable, temps)

sim <- SimContainer(dem)

sm <- data.frame(Source=rep(1:99, each=99), Destination=rep(1:99, times=99), Probability=1)

sim$AddSparseMatrixNetwork(100, sm, 1)

# Prevalence should be 99%
sim$AddSimulation(50)
sim$Infect(1)
sim$Update(50)
stopifnot(abs(sim$GetPrevalences()[50] - 0.99) < tol)

# Prevalence should be 1%
sim$AddSimulation(50)
sim$Infect(100)
sim$Update(50)
stopifnot(abs(sim$GetPrevalences()[50] - 0.01) < tol)

cat('Test passed\n')
