cat('Check that a basic within-farm model can be run and summarised\n')

library('efsabt')

fixedinfo <- DefaultFixed()
variableinfo <- DefaultVariable()

temps <- matrix(rnorm(150*5*24, 10), ncol=5)
demography <- CreateGubbinsDemography(N = nrow(fixedinfo), FixedParameters = fixedinfo, 
                                      VariableParameters = variableinfo, TemperatureData=temps)

withinfarm_1 <- FarmModel(demography, TimePoints = 150)


temps <- matrix(rnorm(150*5*24, 20), ncol=5)
demography <- CreateGubbinsDemography(N = nrow(fixedinfo), FixedParameters = fixedinfo, 
                                      VariableParameters = variableinfo, TemperatureData=temps)

withinfarm_2 <- FarmModel(demography, TimePoints = 150)

PlotFarmComparison(withinfarm_1, withinfarm_2)

cat('Test passed\n')
