cat('Test that the number of animals reported on a farm is consistent with the input data\n')

library('efsabt')
tol <- 10^-6
set.seed(2015-01-05)

fixed <- DefaultFixed(N=100, novel=TRUE)
variable <- DefaultVariable(novel=TRUE)

temps <- matrix(25, ncol=5, nrow=1000*24)

dem <- CreateGubbinsDemography(N=100, fixed, variable, temps)

sim <- SimContainer(dem)

sm <- data.frame(Source=rep(1:75, each=75), Destination=rep(1:75, times=75), Probability=1)

sim$AddSparseMatrixNetwork(100, sm, 1)

sn <- sim$AddSimulation(50)

sim$AccessSimulation(sn)$SaveParameters(0)

nsheep <- sim$AccessDemography()$SheepNumbers
ncattle <- sim$AccessDemography()$CattleNumbers

stopifnot(all(abs(nsheep[,1] - fixed$NumberSheep) < tol))
stopifnot(all(abs(ncattle[,1] - fixed$NumberCattle) < tol))

sim$Infect(1:100)
sim$Update(50)

sim$AccessSimulation(sn)$SaveParameters(0)

nsheep <- sim$AccessDemography()$SheepNumbers
ncattle <- sim$AccessDemography()$CattleNumbers

stopifnot(all(abs(apply(nsheep[,1:5],1,sum) - fixed$NumberSheep) < tol))
stopifnot(all(abs(apply(ncattle[,1:5],1,sum) - fixed$NumberCattle) < tol))

cat('Test passed\n')
