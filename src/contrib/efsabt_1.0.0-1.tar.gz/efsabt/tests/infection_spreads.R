cat('Test that infection spreads over a full network with high connection probabilities\n')

library('efsabt')
tol <- 10^-6
set.seed(2015-01-05)

fixed <- DefaultFixed(N=100, novel=TRUE)
variable <- DefaultVariable(novel=TRUE)

temps <- matrix(20, ncol=5, nrow=150*24)

dem <- CreateGubbinsDemography(N=100, fixed, variable, temps)

sim <- SimContainer(dem)

sm <- data.frame(Source=1, Destination=1:100, Probability=0.75)

sim$AddSparseMatrixNetwork(100, sm, 0.5)

# All farms should be infected:
sim$AddSimulation(50)
sim$Infect(1)
sim$Update(50)
stopifnot(abs(sim$GetPrevalences()[50] - 1) < tol)


# Only the source farm should be infected:
sim$AddSimulation(50)
sim$Infect(2)
sim$Update(50)
stopifnot(abs(sim$GetPrevalences()[50] - 1/100) < tol)

cat('Test passed\n')
