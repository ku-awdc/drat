cat('Check that a basic between-farm model can be run and summarised\n')

library('efsabt')

fixedinfo <- DefaultFixed(100)
variableinfo <- DefaultVariable()

temps <- matrix(20, ncol=5, nrow=1000*24)

demography <- CreateGubbinsDemography(N = nrow(fixedinfo), FixedParameters = fixedinfo, 
  VariableParameters = variableinfo, TemperatureData=temps)
demography$SetInitialisationStates('Exposed',1)

sc1 <- SimContainer(demography)

sm <- data.frame(Source=c(rep(1,10), sort(sample(1:100,200,TRUE))), Destination=sample(1:100,210,TRUE), Probability=1)
sc1$AddSparseMatrixNetwork(100, sm, 1)

betweenfarm_1 <- RunSimulations(sc1, 5, max_time=50, parallel=FALSE)

sc2 <- SimContainer(demography)

sm <- data.frame(Source=c(rep(1,10), sort(sample(1:100,200,TRUE))), Destination=sample(1:100,210,TRUE), Probability=1)
sc2$AddSparseMatrixNetwork(100, sm, 1)

betweenfarm_2 <- RunSimulations(sc2, 5, max_time=50, parallel=.Platform$OS.type=='unix', mc.cores=2)

PlotSimulationComparison(betweenfarm_1, betweenfarm_2)

cat('Test passed\n')
