cat('Test that the farms do not become infectious at very low temperatures\n')

library('efsabt')
tol <- 10^-6
set.seed(2015-01-05)

fixed <- DefaultFixed(N=100, novel=TRUE)
variable <- DefaultVariable(novel=TRUE)

temps <- matrix(0, ncol=5, nrow=1000*24)

dem <- CreateGubbinsDemography(N=100, fixed, variable, temps)

res <- FarmModel(dem, 1000, quiet=TRUE)

stopifnot(all(abs(res$Sheep[,'CumulativeInfected','Time_1000'] - 0) < tol))
stopifnot(all(abs(res$Cattle[,'CumulativeInfected','Time_1000'] - 0) < tol))

stopifnot(all(res$FirstInfectious > 1000))

cat('Test passed\n')
