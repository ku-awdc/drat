cat('Test that infection spreads over a giant strong component network with high connection probabilities\n')

library('efsabt')
tol <- 10^-6
set.seed(2015-01-05)

fixed <- DefaultFixed(N=100, novel=TRUE)
variable <- DefaultVariable(novel=TRUE)

temps <- matrix(25, ncol=5, nrow=1000*24)

dem <- CreateGubbinsDemography(N=100, fixed, variable, temps)

sim <- SimContainer(dem)

sm <- data.frame(Source=rep(1:75, each=75), Destination=rep(1:75, times=75), Probability=1)

sim$AddSparseMatrixNetwork(100, sm, 1)

# Prevalence should be 75%
sim$AddSimulation(50)
sim$Infect(1)
sim$Update(50)
stopifnot(abs(sim$GetPrevalences()[50] - 0.75) < tol)
stopifnot(all(sim$GetStates(FALSE)[1:75] > 0))
stopifnot(all(sim$GetStates(FALSE)[76:100] == 0))

cat('Test passed\n')
