#' @title Default fixed parameters for the bluetongue model
#' @name DefaultFixed

#' @description
#' Utility function for generating default fixed parameters that can be used to set up a bluetongue demography

#' @return
#' A data frame of parameter values for each farm

#' @seealso
#' \code{\link{Demography}}, and \code{\link{DefaultVariable}}

#' @param N the number of farms to generate parameters for

#' @param novel option to generate default parameters for the baseline (FALSE) or modified (TRUE) model

#' @param ... parameters that can be used to override the default values within the returned data frame
NULL

#' @rdname DefaultFixed
DefaultFixed <- function(N = 10, novel = TRUE, ...){
	
	WeatherStation <- sample(1:5, N, replace=TRUE)
	NumberCattle <- sample(50:500, N, replace=TRUE) * rbinom(N, 1, 0.5)
	NumberSheep <- sample(100:1000, N, replace=TRUE) * ifelse(NumberCattle>0, rbinom(N, 1, 0.5), 1)
	MinVectorRatio <- 0
	MaxVectorRatio <- 5000
	SurveillanceChangeDay <- 0
	StagesViraemiaCattle <- 5
	StagesViraemiaSheep <- 14
	DurationViraemiaCattle <- 20.6
	DurationViraemiaSheep <- 16.4
	BloodMealFrequencyEffect <- 1
	VaccinationTime <- -1
	TimeStepsWithinHour <- 4
	
	if(novel){

		SurveillanceChangeDay <- as.numeric(as.Date('2007-09-20')-as.Date('2007-08-04'))

	}

	
	fixedpars <- data.frame(WeatherStation=WeatherStation, NumberCattle=NumberCattle, NumberSheep=NumberSheep, MinVectorRatio = MinVectorRatio, MaxVectorRatio = MaxVectorRatio, SurveillanceChangeDay = SurveillanceChangeDay, StagesViraemiaCattle = StagesViraemiaCattle, StagesViraemiaSheep = StagesViraemiaSheep, DurationViraemiaCattle = DurationViraemiaCattle, DurationViraemiaSheep = DurationViraemiaSheep, BloodMealFrequencyEffect = BloodMealFrequencyEffect, VaccinationTime = VaccinationTime, TimeStepsWithinHour = TimeStepsWithinHour)
	
	varnames <- c('WeatherStation','NumberCattle','NumberSheep','MinVectorRatio','MaxVectorRatio','SurveillanceChangeDay','StagesViraemiaCattle','StagesViraemiaSheep','DurationViraemiaCattle','DurationViraemiaSheep','BloodMealFrequencyEffect','VaccinationTime','TimeStepsWithinHour')

	specified <- list(...)
	if(length(specified)>0){
		for(i in 1:length(specified)){
			matched <- pmatch(names(specified)[i], varnames, duplicates.ok = TRUE)
			if(is.na(matched)){
				stop(paste('Unrecognised or ambiguous specified parameter "', names(specified)[i], '"', sep=''))
			}
			stopifnot(length(matched)==1)
			
			if(! length(specified[[i]] %in% c(1, N))){
				stop(paste('Incorrect length of values for specified parameter "', names(specified)[i], '"', sep=''))
			}
			fixedpars[varnames[matched]] <- specified[[i]]
		}
	}
	
	return(fixedpars)
}


#' @title Default variable parameters for the bluetongue model
#' @name DefaultVariable

#' @description
#' Utility function for generating default variable parameters that can be used to set up a bluetongue demography

#' @return
#' A data frame of lower and upper ranges from which parameter values will be generated for each farm by the C++ code

#' @seealso
#' \code{\link{Demography}}, and \code{\link{DefaultFixed}}

#' @param novel option to generate default parameters for the baseline (FALSE) or modified (TRUE) model

#' @param ... parameters that can be used to override the default values within the returned data frame
NULL

#' @rdname DefaultVariable
DefaultVariable <- function(novel = TRUE, ...){
	
	TransferVectorToHost <- c(0.8 , 1)
	TransferHostToVector <- c(0.001 , 0.15)
	MinimumVectorMortality <- 0
	MortalityCattlePre <- 0
	ClinicalCattlePre <- 0
	MortalitySheepPre <- 0
	ClinicalSheepPre <- 0
	MortalityCattlePost <- c(0 , 0.0001)
	ClinicalCattlePost <- c(0.0078 , 0.067)
	MortalitySheepPost <- c(0.001 , 0.01)
	ClinicalSheepPost <- c(0.027 , 0.080)
	VectorPreference <- c(0 , 1)
	MidgeIncubationStages <- c(2 , 100)
	VaccineEfficacyCattle <- 1
	VaccineEfficacySheep <- 1
	VaccineLagCattle <- 60
	VaccineLagSheep <- 14

	if(novel){
		MortalityCattlePre <- c(0,0.001)/10
		ClinicalCattlePre <- c(0.0078, 0.067)/10
		MortalitySheepPre <- c(0.001,0.01)/10
		ClinicalSheepPre <- c(0.027, 0.08)/10
		MinimumVectorMortality <- c(1/28, 1/21)

	}
	
	varpars <- data.frame(TransferVectorToHost = TransferVectorToHost, TransferHostToVector = TransferHostToVector, MinimumVectorMortality = MinimumVectorMortality, MortalityCattlePre = MortalityCattlePre, ClinicalCattlePre = ClinicalCattlePre, MortalitySheepPre = MortalitySheepPre, ClinicalSheepPre = ClinicalSheepPre, MortalityCattlePost = MortalityCattlePost, ClinicalCattlePost = ClinicalCattlePost, MortalitySheepPost = MortalitySheepPost, ClinicalSheepPost = ClinicalSheepPost, VectorPreference = VectorPreference, MidgeIncubationStages = MidgeIncubationStages, VaccineEfficacyCattle = VaccineEfficacyCattle, VaccineEfficacySheep = VaccineEfficacySheep, VaccineLagCattle = VaccineLagCattle, VaccineLagSheep = VaccineLagSheep)
	
	varnames <- c('TransferVectorToHost','TransferHostToVector','MinimumVectorMortality','MortalityCattlePre','ClinicalCattlePre','MortalitySheepPre','ClinicalSheepPre','MortalityCattlePost','ClinicalCattlePost','MortalitySheepPost','ClinicalSheepPost','VectorPreference','MidgeIncubationStages','VaccineEfficacyCattle','VaccineEfficacySheep','VaccineLagCattle','VaccineLagSheep')
		
	specified <- list(...)
	if(length(specified)>0){
		for(i in 1:length(specified)){
			matched <- pmatch(names(specified)[i], varnames, duplicates.ok = TRUE)
			if(is.na(matched)){
				stop(paste('Unrecognised or ambiguous specified parameter "', names(specified)[i], '"', sep=''))
			}
			stopifnot(length(matched)==1)
			
			if(! length(specified[[i]] %in% c(1, 2))){
				stop(paste('Incorrect length of values for specified parameter "', names(specified)[i], '"', sep=''))
			}
			varpars[varnames[matched]] <- specified[[i]]
		}
	}
	
	dimnames(varpars) <- list(c('LowerBound','UpperBound'),dimnames(varpars)[[2]])
	return(varpars)
}
