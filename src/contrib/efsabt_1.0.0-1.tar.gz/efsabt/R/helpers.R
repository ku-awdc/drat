#' @title Default fixed parameters for the bluetongue model
#' @name Bluetongue_Utilities
#' @aliases AvailableAgentTypes PossibleStates SparseMatrix

#' @description
#' Utility functions associated with the bluetongue models.

#' @details
#' AvailableAgentTypes can be used to return the agent types used within the C++ code, PossibleStates returns the possible agent states used within the C++ code, and SparseMatrix generates a sparse matrix based on x and y locations as for the GubbinsNetwork class.

#' @seealso
#' \code{\link{Demography}}, and \code{\link{efsabt}}

#' @param xLocations the x location (easting / 1000) of the farms

#' @param yLocations the y location (northing / 1000) of the farms

#' @param TransmissionProbs a vector with length matching xLocations & yLocations (or length 1) of transmission probabilities for each farm

#' @param threshold the minimum calculated probability for the link to be stored in the returned sparse matrix

#' @param alpha the alpha parameter of the transmission kernel.
NULL

#' @rdname Bluetongue_Utilities
AvailableAgentTypes <- function(){
	
	at <- GetAvailableAgentTypes()
	
	return(data.frame(AgentType = at, Integer = 1:length(at)))
}

#' @rdname Bluetongue_Utilities
PossibleStates <- function(){
	
	return(GetPossibleStates())
}


#' @rdname Bluetongue_Utilities
SparseMatrix <- function(xLocations, yLocations, TransmissionProbs=1, threshold = 10^-12, alpha = 0.0341){
	
	if(length(xLocations)!=length(yLocations)){
		stop("Unequal xLocations and yLocations lengths")
	}
	if(length(TransmissionProbs)==1){
		TransmissionProbs <- rep(TransmissionProbs, length(xLocations))
	}
	if(length(xLocations)!=length(TransmissionProbs)){
		stop("Unequal lengths of locations and transmission probabilities")		
	}
	
	retval <- GetSparseMatrix(xLocations, yLocations, TransmissionProbs, threshold, alpha)

	stopifnot(all(names(retval) == c("Source","Destination","Probability")))
	
	return(retval)
}
