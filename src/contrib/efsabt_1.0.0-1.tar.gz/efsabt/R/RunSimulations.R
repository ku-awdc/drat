runsimreplication <- function(RNGseed, simulations, between_simulations, maxdays, quiet, delete, clinical_conditioning){
	
	# Set the RNG seed in R as well:
	set.seed(RNGseed)
	
	incursion <- data.frame(modelday = c(0, 59, 61, 64, 64, 66, 71), agent.id= c(65645, 2670, 38587, 38778, 68453, 40095, 2095))
	
	# Update the demography etc:
	testing <- between_simulations(simulations)
	
	simno <- simulations$AddSimulation(MaxDays=maxdays, RNGseed)
	sim <- simulations$AccessSimulation(simno)
	
	done <- FALSE
	vinf <- 5
	N <- length(simulations$AccessDemography()$InitialisationStates)
	
	notake <- 0
	noclinical <- 0
	nospread <- 0
	
	possstates <- PossibleStates()
	isclinical <- grepl("Clinical",possstates$State)
	clinicalindex <- possstates$Integer[isclinical]
	stopifnot(length(clinicalindex)>=1)
	
	if(!quiet) cat('\tRunning a new simulation\n')
		
	while(!done){
		
		# Need to seed all infections and run to the end (with stopifinactive) then check that all seed farms became infectious by time point 150
			# Or change 150 or change requirement for infectious to exposed/latent??
			# Note that Gubbins checks that they all became infectious at some point - possibly after time point 150, and also checks that they become clinical
		# Also need to check that at least 1 other farm became infected
		
		# The first farm was infected on day 0:
		sim$Infect(incursion$agent.id[incursion$modelday==0], vinf)
		
		# Gubbins checks that the outbreak lasted minimum 50 days on this farm:
		sim$Update(50, StopIfInactive=TRUE)
		states <- sim$StateMatrix[incursion$agent.id[1],1:50]
		if(states[50] < 1){
			if(!quiet) cat('\t\tInitial infection did not take\n')
			notake <- notake + 1
			
			# If there was no secondary spread by this time, stop:
			cp <- sim$GetCumulativePrevalences()
			aff.farms <- round(cp * N)
		
			if(max(aff.farms) == 1){
				if(!quiet) cat('\t\tFailed to spread\n')
				nospread <- nospread + 1
			
				# Reset all the farm parameters (also triggers a re-initialise):
				sim$Reset()
				next
			}
			
			# Reset all the farm parameters (also triggers a re-initialise):
			sim$Reset()
			next
		}
		
		# Then stagger the infections of others
		# Gubbins assumes that they get infected 10 days before the clinical signs dates, and requires that they show clinical signs
		failclinical <- logical(nrow(incursion))
		failclinical[] <- FALSE
		for(i in 51:(max(incursion$modelday)+10)){
			sim$Update(1, StopIfInactive=FALSE)
			toinf <- which(incursion$modelday==i)
			for(j in toinf){
				sim$Infect(incursion$agent.id[j], vinf)
			}
			tocheck <- which((incursion$modelday+10)==i)
			for(j in tocheck){
				states <- sim$StateMatrix[incursion$agent.id[j],]
				# Check it was clinical on at least 1 day so far:
				if(!any(states%in%clinicalindex)){
					failclinical[j] <- TRUE
				}
			}
		}
		# Relax the requirements - allow 1 farm not to show clinical signs (often farm 7):
		if(sum(failclinical)>(6-clinical_conditioning)){
			if(!quiet) cat('\t\tIncursion', paste(which(failclinical),collapse=','), 'failed to become clinical\n')

			noclinical <- noclinical + 1
			
			# Reset all the farm parameters (also triggers a re-initialise):
			sim$Reset()
			next
		}
		
		# Finally run until the infection dies out, with a max of 150 days:
		sim$Update(maxdays-sim$TimePoint, StopIfInactive=FALSE)
		cp <- sim$GetCumulativePrevalences()
		op <- sim$GetCumulativeObservedPrevalences()
		
		# If there was no secondary spread by this time, stop:
		aff.farms <- round(cp * N)
		
		if(max(aff.farms) <= nrow(incursion)){
			if(!quiet) cat('\t\tFailed to spread\n')
			nospread <- nospread + 1
			
			# Reset all the farm parameters (also triggers a re-initialise):
			sim$Reset()
			next
		}
		
		
		# Get weekly new cases observed:
		TimeBin <- 7
		op <- round(op * N)
		ltr <- length(numeric(ceiling(length(op) / TimeBin)))
		startpoints <- 0:(ltr-1) * TimeBin +1
		endpoints <- pmin(startpoints+TimeBin-1, length(op))
		opout <- c(op[endpoints[1]], sapply(2:length(endpoints), function(x) return(op[endpoints[x]] - op[endpoints[x-1]])))
		names(opout) <- paste('Period_', startpoints, ':', endpoints, sep='')

		
		# Get time of first infection (including exposed/latent) for all, then save full matrix for farms that were infected with dimnames
		firstinfs <- sim$FirstStateTimes(c(1:9))
		everinf <- which(firstinfs > -1)
		retmat <- sim$StateMatrix[everinf,1:sim$TimePoint,drop=FALSE]
		dimnames(retmat) <- list(paste('Agent',everinf,sep='_'), paste('Time',1:sim$TimePoint,sep='_'))
  
		obs.farms <- opout
		done <- TRUE
			

#		if(sim$TimePoint < maxdays){
#			success <- try({
#			retmat[,sim$TimePoint:maxdays] <- NA
#			})
#			if(class(success)=='try-error'){
#				err <- paste('An error occured while resetting the return matrix beyond the final time point - dims are ', dim(retmat)[1], ' by ', dim(retmat)[2], ' and requested elements are ', sim$TimePoint, ' to ', maxdays, '\nError was:  ', success[1], sep='')
#				stop(err)
#			}
#		}		
#		retmat[] <- factor(retmat[], levels=possstates$Integer, labels=possstates$State)
		
    	# Then loop through farms ever infected and get number of affected/dead cattle and sheep
    	animals <- matrix(0, ncol=4, nrow=nrow(retmat), dimnames=list(dimnames(retmat)[[1]], c('AffectedCattle', 'DeadCattle','AffectedSheep','DeadSheep')))
    	for(i in 1:length(everinf)){
	    	sim$SaveParameters(everinf[i])
    	}
    	dem <- simulations$AccessDemography()
      
    	stopifnot(attr(dem$CattleNumbers, 'colnames')[c(6,3)] == c("CumulativeInfected", "Dead"))
		stopifnot(attr(dem$SheepNumbers, 'colnames')[c(6,3)] == c("CumulativeInfected", "Dead"))
		
   		animals[,1:2] <- dem$CattleNumbers[everinf,c(6,3)]
   		animals[,3:4] <- dem$SheepNumbers[everinf,c(6,3)]
    	
		
		if(!quiet) cat('\t\tFinished at time point', sim$TimePoint, 'with', max(aff.farms), 'affected farms\n')
	}
	
	rm(sim)
	if(delete) simulations$RemoveSimulation(simno)

	return(list(StateMatrix = retmat, Affected = aff.farms, Observed = obs.farms, NoTake = notake, NoClinical = noclinical, NoSpread = nospread, AffectedAnimals=animals))
	
}

runsimplain <- function(RNGseed, simulations, between_simulations, maxdays, quiet, delete, clinical_conditioning){
	
	# Set the RNG seed in R as well:
	set.seed(RNGseed)
	
	# Update the demography etc:
	testing <- between_simulations(simulations)
	
	simno <- simulations$AddSimulation(MaxDays=maxdays, RNGseed)
	sim <- simulations$AccessSimulation(simno)
	
	done <- FALSE
	N <- length(simulations$AccessDemography()$InitialisationStates)
	
	nospread <- 0
	
	possstates <- PossibleStates()
	
	if(!quiet) cat('\tRunning a new simulation\n')
	
	incursions <- sum(simulations$AccessDemography()$InitialisationStates!=0)
		
	while(!done){
		
		# Seeding is done by the Demography at re-initialisation time

		# Run until the infection dies out, with a max of maxdays days:
		sim$Update(maxdays, StopIfInactive=FALSE)
		cp <- sim$GetCumulativePrevalences()
		op <- sim$GetCumulativeObservedPrevalences()
		
		# If there was no secondary spread by this time, stop:
		aff.farms <- round(cp * N)
		
		if(max(aff.farms) <= incursions){
			if(!quiet) cat('\t\tFailed to spread\n')
			nospread <- nospread + 1
			
			# Reset all the farm parameters (also triggers a re-initialise):
			sim$Reset()
			next
		}
		
		
		# Get weekly new cases observed:
		TimeBin <- 7
		op <- round(op * N)
		ltr <- length(numeric(ceiling(length(op) / TimeBin)))
		startpoints <- 0:(ltr-1) * TimeBin +1
		endpoints <- pmin(startpoints+TimeBin-1, length(op))
		opout <- c(op[endpoints[1]], sapply(2:length(endpoints), function(x) return(op[endpoints[x]] - op[endpoints[x-1]])))
		names(opout) <- paste('Period_', startpoints, ':', endpoints, sep='')

		
		# Get time of first infection (including exposed/latent) for all, then save full matrix for farms that were infected with dimnames
		firstinfs <- sim$FirstStateTimes(c(1:9))
		everinf <- which(firstinfs > -1)
		retmat <- sim$StateMatrix[everinf,1:sim$TimePoint,drop=FALSE]
		dimnames(retmat) <- list(paste('Agent',everinf,sep='_'), paste('Time',1:sim$TimePoint,sep='_'))
  
		obs.farms <- opout
		done <- TRUE
			

#		retmat[] <- factor(retmat[], levels=possstates$Integer, labels=possstates$State)
		
    	# Then loop through farms ever infected and get number of affected/dead cattle and sheep
    	animals <- matrix(0, ncol=4, nrow=nrow(retmat), dimnames=list(dimnames(retmat)[[1]], c('AffectedCattle', 'DeadCattle','AffectedSheep','DeadSheep')))
    	for(i in 1:length(everinf)){
	    	sim$SaveParameters(everinf[i])
    	}
    	dem <- simulations$AccessDemography()
      
    	stopifnot(attr(dem$CattleNumbers, 'colnames')[c(6,3)] == c("CumulativeInfected", "Dead"))
		stopifnot(attr(dem$SheepNumbers, 'colnames')[c(6,3)] == c("CumulativeInfected", "Dead"))
		
   		animals[,1:2] <- dem$CattleNumbers[everinf,c(6,3)]
   		animals[,3:4] <- dem$SheepNumbers[everinf,c(6,3)]
    	
		
		if(!quiet) cat('\t\tFinished at time point', sim$TimePoint, 'with', max(aff.farms), 'affected farms\n')
	}
	
	rm(sim)
	if(delete) simulations$RemoveSimulation(simno)

	return(list(StateMatrix = retmat, Affected = aff.farms, Observed = obs.farms, NoSpread = nospread, AffectedAnimals=animals))
	
}


#' @title Run a between-farm model
#' @name RunSimulations

#' @description
#' A wrapper function for running a set of between-farm models of disease spread.  

#' @details
#' Which seed farms that are infected at the start of the simulation depends on the replication option.  For replication = TRUE, seven specific farms are seeded on the dates on which they were assumed to be infected during the 2008 UK outbreak.  For replication = FALSE, the starting states of all agents depend on the return value of the GetInitialisationStates() method of the demography.

#' @return
#' A list with the following elements:
#' \itemize{
#'	\item{FarmsAffected}{ - A matrix of the cumulative number of farms affected at each time point for each simulation}
#'	\item{NewFarmsObserved}{ - A matrix of the cumulative number of farms observed to be affected at each time point for each simulation}
#'	\item{AnimalsAffected}{ - The total number of animals affected for each simulation}
#'	\item{FailedSimulations}{ - The number of simulations which were repeated due to the acceptance criteria (e.g. spread to another farm, farms becoming clinical as required) not being met}
#'	\item{StateMatrices}{ - An array of the true state of each infected farm for each time point in each simulation}
#'	\item{TimeTaken}{ - The time taken to complete the simulation}
#' }

#' @seealso
#' \code{\link{Demography}}, \code{\link{SimContainer}} and \code{\link{PlotSimulationComparison}}

#' @param simulation_container an object produced by the \code{\link{SimContainer}} function.

#' @param iterations the number of iterations to run the simulation for.

#' @param between_simulations a function to run between simulations in order to update the demography.

#' @param replication option to replicate the 2008 UK outbreak (see details).

#' @param max_time the number of time points to run the simulation for.

#' @param parallel option to run replicate simulations on parallel processes using mclapply (requires fork clusters to be available).

#' @param RNGseeds a seed to be passed to each pseudo-random number generator in the C++ code.

#' @param delete option to remove the simulations after completion to free up system memory.  If the simulations are not deleted (and also not run in parallel), then it is possible to subsequently access the completed simulations through the simulation_container specified.

#' @param mc.cores the number of parallel processes to use (for parallel==TRUE).

#' @param quiet option to suppress printing of progress information.

#' @param clinical_conditioning the minimum number of the 6 secondary seed farms from the 2008 UK outbreak that must show clinical signs within 10 days of being infected in order for the simulation results to be used.  Ignored if replication==FALSE.
NULL

#' @rdname RunSimulations
RunSimulations <- function(simulation_container, iterations, between_simulations = function(SimContainer) return(), replication = FALSE, max_time = 150, parallel = FALSE, RNGseeds = sample(10^9, iterations), delete = parallel, mc.cores = getOption("mc.cores", 2L), quiet = parallel, clinical_conditioning = if(replication) 5 else 0){
	
	if(parallel && !delete){
		stop('Unable to preserve the simulations using forking - set delete = TRUE with parallel = TRUE')
	}
	if(parallel && .Platform$OS.type=='windows'){
		stop('The parallel method makes use of shared memory via forking so is not available on windows')
	}
	
	RNGseeds <- as.integer(RNGseeds)
	if(any(is.na(RNGseeds))){
		stop('One or more of RNGseeds became NA when coerced to integer')
	}
	if(length(RNGseeds)!=iterations){
		stop('Inconsistent number of RNG seeds supplied')
	}
	if(length(unique(RNGseeds))!=iterations){
		stop('Not all RNGseeds are unique')
	}

	# Test a simulation locally:
	simno <- simulation_container$AddSimulation(max_time, RNGseed = RNGseeds[1])
	simulation_container$RemoveSimulation(simno)
	# Test updating the demography etc:
	testing <- between_simulations(simulation_container)
	
	if(replication){
		if(clinical_conditioning > 6 || clinical_conditioning < 0)
			stop('The clinical_conditioning argument must be between 0 and 6')
		runsim <- runsimreplication
		states <- simulation_container$AccessDemography()$InitialisationStates
		if(any(states)>0){
			stop('The Demography states must all be Susceptible when using replication = TRUE')
		}
	}else{
		if(clinical_conditioning != 0)
			warning('The clinical_conditioning argument is ignored when not using the replication model')
		runsim <- runsimplain
		states <- simulation_container$AccessDemography()$InitialisationStates
		if(all(states==0)){
			stop('One or more Demography states must be non-Susceptible when using replication = FALSE (see the SetInitialisationStates method of the Demography class)')
		}
	}
	
	stopifnot(iterations > 0)
	if(iterations==1){
		cat("Running", iterations, "simulation\n")
	}else{
		cat("Running", iterations, "simulations\n")
	}
	
	start <- Sys.time()
	if(parallel){
		results <- mclapply(RNGseeds, runsim, mc.cores=mc.cores, mc.preschedule=FALSE, simulations=simulation_container, between_simulations=between_simulations, maxdays=max_time, quiet=quiet, delete = TRUE, clinical_conditioning=clinical_conditioning) 
	}else{
		results <- lapply(RNGseeds, runsim, simulations=simulation_container, between_simulations=between_simulations, maxdays=max_time, quiet=quiet, delete = delete, clinical_conditioning=clinical_conditioning) 
	}
	TimeTaken <- difftime(Sys.time(), start, units='mins')
	
	# Create a matrix of prevalence, weekly obs, total affected, number failed to take off, list of state matrices, also add time taken 
	
	cat('Finished in a total of', TimeTaken, 'minutes\n')
	
	success <- try({
		prevs <- t(sapply(results, function(x) return(x$Affected)))
		obs <- t(sapply(results, function(x) return(x$Observed)))
	
		if(replication){
			failed <- cbind(NoTake = sapply(results, function(x) return(x$NoTake)), NoClinical = sapply(results, function(x) return(x$NoClinical)), NoSpread = sapply(results, function(x) return(x$NoSpread)))
		}else{
			failed <- cbind(NoSpread = sapply(results, function(x) return(x$NoSpread)))
		}
		affected <- t(sapply(results, function(x) return(apply(x$AffectedAnimals,2,sum))))
	
		states <- lapply(results, function(x) return(x$StateMatrix))
	
		dimnames(prevs) <- list(paste('Simulation',1:iterations,sep='_'), paste('Time_point',1:max_time,sep='_'))
		dimnames(obs) <- list(paste('Simulation',1:iterations,sep='_'), dimnames(obs)[[2]])
		dimnames(failed) <- list(paste('Simulation',1:iterations,sep='_'), dimnames(failed)[[2]])
		dimnames(affected) <- list(paste('Simulation',1:iterations,sep='_'), dimnames(affected)[[2]])
		names(states) <- paste('Simulation',1:iterations,sep='_')
	
		toret <- list(FarmsAffected = prevs, NewFarmsObserved = obs, AnimalsAffected = affected, FailedSimulations = failed, StateMatrices = states, TimeTaken = TimeTaken)
	})
	
	if(class(success)=='try-error'){
		
		if(parallel){
			whichfailed <- sapply(results, class)=='try-error'
			if(any(whichfailed)){
				errors <- sapply(results[whichfailed],as.character)
				cat('Error(s) returned by mclapply were:\n\t', paste(errors, collapse='\n\t'))
			}
		}
		
		warning('Something went wrong when processing results - returning result of (mc)lapply')
		toret <- results
	}
	
	return(toret)
	
}

#' @title Graphical comparison of two between-farm models
#' @name PlotSimulationComparison

#' @description
#' Utility function for producing a graphical comparison of two sets of between-farm model simulations.

#' @return
#' A (gg)plot is produced

#' @seealso
#' \code{\link{Demography}}, \code{\link{SimContainer}} and \code{\link{RunSimulations}}

#' @param baseline a set of simulations produced by the \code{\link{RunSimulations}} function. No default. These simulations will be coloured red in the output.

#' @param modified a set of simulations produced by the \code{\link{RunSimulations}} function. No default. These simulations will be coloured blue in the output.

#' @param solid the quantiles to draw using a solid line

#' @param dashed the quantiles to draw using a dashed line

#' @param dotted the quantiles to draw using a dotted line

#' @param observed.ylim the y-axis limits for the observed number of farms plot

#' @param affected.ylim the y-axis limits for the total number of affected farms plot
NULL

#' @rdname PlotSimulationComparison
PlotSimulationComparison <- function(baseline, modified, solid='50%', dashed=c('25%','75%'), dotted=c('10%','90%'), observed.ylim=c(0,40), affected.ylim=c(0,200)){
	

	if(!identical(names(baseline), c("FarmsAffected", "NewFarmsObserved", "AnimalsAffected", "FailedSimulations", "StateMatrices", "TimeTaken"))){
		stop('The results of a call to RunSimulations must be specified (for the baseline argument)')
	}
	if(!identical(names(modified), c("FarmsAffected", "NewFarmsObserved", "AnimalsAffected", "FailedSimulations", "StateMatrices", "TimeTaken"))){
		stop('The results of a call to RunSimulations must be specified (for the modified argument)')
	}

	if(ncol(baseline$FarmsAffected)!=ncol(modified$FarmsAffected)){
		stop("The baseline and modified results have different length time periods")
	}
	
	# Just generate the summary statistics here:
	probs <- c(0.1,0.25,0.5,0.75,0.9)

	mysummary <- function(x, probs=probs, ...){
		
		mu <- mean(x)
		sig <- sqrt(var(x))
		quants <- quantile(x, probs=probs, ...)
		
		return(c(Mean=mu, StdDev=sig, Median=median(x), quants))
	}
	
	
	sumbase <- list(FarmsAffected=apply(baseline$FarmsAffected,2,mysummary,probs=probs), NewFarmsObserved=apply(baseline$NewFarmsObserved,2,mysummary,probs=probs))
	summod <- list(FarmsAffected=apply(modified$FarmsAffected,2,mysummary,probs=probs), NewFarmsObserved=apply(modified$NewFarmsObserved,2,mysummary,probs=probs))
	
	rows <- c(solid,dashed,dotted)
	linetype <- c(rep('a',length(solid)), rep('g', length(dashed)), rep('e', length(dotted)))
	
	sf <- options('stringsAsFactors')[[1]]
	on.exit(options(stringsAsFactors=sf))
	options(stringsAsFactors=FALSE)
	
	# Plot for farms affected:
	timepoints1 <- ncol(sumbase$FarmsAffected)
	totalrows1 <- timepoints1 * length(rows) * 2
	plotdata1 <- data.frame(FarmsAffected = rep(0, totalrows1), Statistic = 'mean', Simulation = 'Baseline', LineType = 'a', TimePoint = 1:timepoints1, Group=0)
	
	# Plot for farms observed:
	timepoints2 <- ncol(sumbase$NewFarmsObserved)
	totalrows2 <- timepoints2 * length(rows) * 2
	plotdata2 <- data.frame(NewFarmsObserved = rep(0, totalrows2), Statistic = 'mean', Simulation = 'Baseline', LineType = 'a', TimePoint = 1:timepoints2, Group=0)
	
	group <- 0
	for(i in 1:length(rows)){
		group <- group+1
		startat <- (i-1)*timepoints1 +1
		endat <- timepoints1*i
		index1 <- startat:endat
		startat <- (i-1)*timepoints2 +1
		endat <- timepoints2*i
		index2 <- startat:endat
		plotdata1$FarmsAffected[index1] <- sumbase$FarmsAffected[rows[i],]
		plotdata2$NewFarmsObserved[index2] <- sumbase$NewFarmsObserved[rows[i],]
		
		plotdata1$Statistic[index1]=plotdata2$Statistic[index2] <- rows[i]
		plotdata1$Simulation[index1]=plotdata2$Simulation[index2] <- 'Baseline'
		plotdata1$Group[index1]=plotdata2$Group[index2] <- group
		plotdata1$LineType[index1]=plotdata2$LineType[index2] <- linetype[i]
		stopifnot(all(plotdata1$TimePoint == 1:timepoints1))
		stopifnot(all(plotdata2$TimePoint == 1:timepoints2))
	}
	firstgroups <- c(1, group+1)
	for(i in 1:length(rows)){
	  group <- group+1
	  startat <- (timepoints1*length(rows)) + (i-1)*timepoints1 +1
	  endat <- (timepoints1*length(rows)) + timepoints1*i
	  index1 <- startat:endat
	  startat <- (timepoints2*length(rows)) + (i-1)*timepoints2 +1
	  endat <- (timepoints2*length(rows)) + timepoints2*i
	  index2 <- startat:endat
	  plotdata1$FarmsAffected[index1] <- summod$FarmsAffected[rows[i],]
	  plotdata2$NewFarmsObserved[index2] <- summod$NewFarmsObserved[rows[i],]
	  
	  plotdata1$Statistic[index1]=plotdata2$Statistic[index2] <- rows[i]
	  plotdata1$Simulation[index1]=plotdata2$Simulation[index2] <- 'Modified'
	  plotdata1$Group[index1]=plotdata2$Group[index2] <- group
	  plotdata1$LineType[index1]=plotdata2$LineType[index2] <- linetype[i]
	  stopifnot(all(plotdata1$TimePoint == 1:timepoints1))
	  stopifnot(all(plotdata2$TimePoint == 1:timepoints2))
	}
	
  # Just to suppress 'no visible binding' warnings:
	TimePoint <- 0
	FarmsAffected <- 0
	NewFarmsObserved <- 0
	Simulation <- 0
	Week <- 0
	Group <- 0
	LineType <- 0
	upper <- 0
	lower <- 0
	
	#plot1 <- ggplot(plotdata2, aes(x=TimePoint, y=NewFarmsObserved, col=Simulation, group=Group, linetype=LineType)) + geom_line() + theme(legend.position="none") + scale_colour_manual(values=c('red','blue')) + ylim(0,40) # + scale_y_log10()

	arrowplot <- plotdata2[plotdata2$Statistic=='50%',]
	arrowplot$lower <- plotdata2$NewFarmsObserved[plotdata2$Statistic=='10%']
	arrowplot$upper <- plotdata2$NewFarmsObserved[plotdata2$Statistic=='90%']
	position <- position_dodge(0.6)
	arrowplot$Week <- arrowplot$TimePoint-1
	
	plot1 <- ggplot(arrowplot, aes(x=Week, y=NewFarmsObserved, col=Simulation, group=Group, linetype=LineType, ymax=max(upper))) + geom_point(position=position) + geom_errorbar(aes(ymin=lower, ymax=upper), position=position, lty='solid') + theme(legend.position="none") + scale_colour_manual(values=c('red','blue')) + coord_cartesian(ylim = observed.ylim)
	
	plot2 <- ggplot(plotdata1, aes(x=TimePoint, y=FarmsAffected, col=Simulation, group=Group, linetype=LineType)) + geom_line() + theme(legend.position="none") + scale_colour_manual(values=c('red','blue')) + coord_cartesian(ylim = affected.ylim)
	
	
	fs1 <- apply(baseline$FailedSimulations,2,sum)
	names(fs1) <- paste('Failed_',dimnames(baseline$FailedSimulations)[[2]],sep='')
	ss1 <- c(MinutesTaken = round(baseline$TimeTaken,1), fs1)

	fs2 <- apply(modified$FailedSimulations,2,sum)
	names(fs2) <- paste('Failed_',dimnames(modified$FailedSimulations)[[2]],sep='')
	ss2 <- c(MinutesTaken = round(modified$TimeTaken,1), fs2)
	
	times <- rbind(ss1, ss2)
	dimnames(times) <- list(c('Baseline','Modified'), dimnames(times)[[2]])
  		
	allplots <- list(p1=plot1, p2=plot2, times=times)
	class(allplots) <- 'sim_multiplot'
	
	return(allplots)
}

print.sim_multiplot <- function(x, ...){
	
    grid.newpage()
    pushViewport(viewport(layout = grid.layout(2, 1)))
    rows <- c(1,2)
    cols <- c(1,1)
    for (i in 1:2){
      print(x[[i]], vp = viewport(layout.pos.row = rows[i], layout.pos.col = cols[i]))
    }
	
	linetype <- x$linetype
	linetype[linetype=='a'] <- 'solid'
	linetype[linetype=='g'] <- 'dashed'
	linetype[linetype=='e'] <- 'dotted'
	
	if(FALSE){
		cat("Producing plots:\n\tRed is the baseline model & Blue is the modified model\n")
		for(i in 1:length(x$rows))
			if(x$rows[i]=='50%')
				cat("\tThe median statistic is given by a ", linetype[i], " line\n", sep="")
			else
				cat("\tThe ", x$rows[i], if(grepl("%",x$rows[i],fixed=TRUE)) " quantile", " statistic is given by a ", linetype[i], " line\n", sep="")
	}
	
	print(x$time)
	
}
