#' @title Reference class containing the C++ demography object
#' @name Demography

#' @description
#' This is an R-wrapper for the C++ simulation object code.  Initialisation requires a valid Demography object.  Methods are provided to control the simulation itself.

#' @seealso
#' \code{\link[methods]{ReferenceClasses}} for more information on OOP programming in R

#' @param which_agent the agent number to set/get the initialisation state for (can be missing, in which case all states are set/returned)

#' @param new_state the new initialisation state for the specified agent(s)

#' @param new_state the new initialisation state for the specified agent(s)

#' @param new_fixed_parameters fixed parameters to use

#' @param new_variable_parameters variable parameters to use

NULL

#' @rdname Demography
Demography <- setRefClass('Demography',
	fields = list(demography ='list', agents='numeric'),
	methods = list(
	initialize = function(InternalDemography){
		if(!inherits(InternalDemography, "InternalDemography"))
			stop("A pre-generated C++ demography must be supplied")
		.self$demography <- list(InternalDemography)
		.self$agents <- length(InternalDemography$InitialisationStates)
	},
	
	AccessDemography = function(){
		"Access the C++ methods available to this demography directly"
		
		return(.self$demography[[1]])
	},
	
	GetInitialisationStates = function(which_agent){
		"Get the initialisation states (used to seed infection for the RunSimulations function with replication=FALSE) currently registered"
		
		states <- .self$demography[[1]]$InitialisationStates
		if(missing(which_agent)){
			which_agent <- 1:length(states)
		}
		stopifnot(all(which_agent >= 0) && all(which_agent <= length(states)))
		
		as <- GetPossibleStates()
		toret <- factor(states[which_agent], levels=as$Integer, labels=as$State)
		return(toret)
	},
	
	SetInitialisationStates = function(new_state, which_agent){
		"Set the initialisation states used to seed infection for the RunSimulations function with replication=FALSE)"

		states <- .self$demography[[1]]$InitialisationStates		
		
		as <- GetPossibleStates()
		amatch <- pmatch(new_state, as$State, duplicates.ok = TRUE)
		if(any(is.na(amatch))){
			amatch <- pmatch(unique(new_state), as$State, duplicates.ok = TRUE)
			stop(paste('Unknown or ambiguous specified agent state(s) "', paste(unique(new_state)[which(is.na(amatch))], collapse='", "'), '"', sep=''))
		}
		new_state <- as$Integer[amatch]
		
		if(missing(which_agent)){
			which_agent <- 1:length(states)
			
			if(length(new_state)==1){
				new_state <- rep(new_state, length(states))
			}
			stopifnot(length(new_state)==length(states))
		}
		
		if(length(new_state)==1){
			new_state <- rep(new_state, length(which_agent))
		}
		stopifnot(length(which_agent) == length(new_state))

		stopifnot(all(which_agent >= 0) && all(which_agent <= length(states)))
		states[which_agent] <- new_state
		.self$demography[[1]]$InitialisationStates <- states
	},
	
	GetNumberOfAgents = function(){
		"Get the number of agents registered in this demography"

		return(.self$agents)
	},
	
	SetFixedParameters = function(new_fixed_parameters){
		"Reset the fixed parameters in the demography"

		.self$demography[[1]]$FixedParameters <- as.matrix(new_fixed_parameters)
	},
	
	GetFixedParameters = function(){
		"Get the current fixed parameters in the demography"

		return(as.data.frame(.self$demography[[1]]$FixedParameters))
	},

	SetVariableParameters = function(new_variable_parameters){
		"Reset the variable parameters in the demography"

		.self$demography[[1]]$VariableParameters <- t(as.matrix(new_variable_parameters))
	},
	
	GetVariableParameters = function(){
		"Get the current variable parameters in the demography"

		return(as.data.frame(t(.self$demography[[1]]$VariableParameters)))
	},
	
	# Returns a bare interface to the C++ class:
	AccessDemography = function(){
		"Access the C++ methods available to this demography directly"

		stopifnot(length(.self$demography)==1)
		return(.self$demography[[1]])
	}	
))


# Specific demography types:

#' @title Generate demography classes
#' @name CreateDemography
#' @aliases CreateBasicDemography CreateGubbinsDemography CreateDemography

#' @description
#' Generator functions for creating new demography types.

#' @return
#' A \code{\link{Demography}} object

#' @seealso
#' \code{\link{Demography}}, \code{\link{DefaultFixed}}, \code{\link{DefaultVariable}} and \code{\link{Bluetongue_Utilities}} for details of the possible agent types and agent states

#' @param N the number of agents to set up in the demography

#' @param AgentStates a vector of agent states to use - see \code{\link{Bluetongue_Utilities}}

#' @param AgentTypes a vector of agent types to use - see \code{\link{Bluetongue_Utilities}}

#' @param FixedParameters a set of fixed parameter values to use - see \code{\link{DefaultFixed}} (the number of rows of this data frame must match N)

#' @param VariableParameters a set of variable parameter values to use - see \code{\link{DefaultVariable}}

#' @param TemperatureData a data frame or matrix of temperature values to use

#' @param DemographyType the C++ class name of the demography to be set up

#' @param ... further arguments to be passed to the C++ constructor of the demography
NULL

#' @rdname CreateDemography
CreateBasicDemography <- function(N=10, AgentStates = 'Susceptible', AgentTypes ="SIAgent"){

	if(length(AgentStates)==1)
		AgentStates <- rep(AgentStates, N)
	if(length(AgentTypes)==1)
		AgentTypes <- rep(AgentTypes, N)
	stopifnot(length(AgentStates)==length(AgentTypes))
	
	at <- AvailableAgentTypes()
	amatch <- pmatch(AgentTypes, at$AgentType, duplicates.ok = TRUE)
	if(any(is.na(amatch))){
		amatch <- pmatch(unique(AgentTypes), at$AgentType, duplicates.ok = TRUE)
		stop(paste('Unknown or ambiguous specified agent type(s) "', paste(unique(AgentTypes)[which(is.na(amatch))], collapse='", "'), '"', sep=''))
	}
	AgentTypes <- at$Integer[amatch]
	
	as <- GetPossibleStates()
	amatch <- pmatch(AgentStates, as$State, duplicates.ok = TRUE)
	if(any(is.na(amatch))){
		amatch <- pmatch(unique(AgentStates), as$State, duplicates.ok = TRUE)
		stop(paste('Unknown or ambiguous specified agent state(s) "', paste(unique(AgentStates)[which(is.na(amatch))], collapse='", "'), '"', sep=''))
	}
	AgentStates <- as$Integer[amatch]
	
	demography <- new(BasicDemography, AgentStates=AgentStates, AgentTypes = AgentTypes)
	
	class(demography) <- "InternalDemography"
	toret <- Demography(demography)
	
	return(toret)
	
}

#' @rdname CreateDemography
CreateGubbinsDemography <- function(N=10, FixedParameters = DefaultFixed(N=N), VariableParameters = DefaultVariable(), TemperatureData = matrix(runif(24*150*5,10,30),ncol=5), AgentStates = 'Susceptible', AgentTypes ="GubbinsFarm"){
	
	FixedParameters <- FixedParameters
	if(nrow(FixedParameters)!=N){
		stop("Non-matching number of agents in the FixedParameters")
	}

	if(length(AgentStates)==1){
		AgentStates <- rep(AgentStates, N)
	}
	if(length(AgentTypes)==1){
		AgentTypes <- rep(AgentTypes, N)
	}
	
	if(length(AgentStates) != N){
		stop("Non-matching number of agents in the AgentStates vector")
	}
	if(length(AgentTypes) != N){
		stop("Non-matching number of agents in the AgentTypes vector")
	}
	
	if(any(FixedParameters$WeatherStation > ncol(TemperatureData))){
		stop("One or more specified WeatherStation was out of range of the TemperatureData")
	}
	
	at <- AvailableAgentTypes()
	amatch <- pmatch(AgentTypes, at$AgentType, duplicates.ok = TRUE)
	if(any(is.na(amatch))){
		amatch <- pmatch(unique(AgentTypes), at$AgentType, duplicates.ok = TRUE)
		stop(paste('Unknown or ambiguous specified agent type(s) "', paste(AgentTypes[which(is.na(amatch))], collapse='", "'), '"', sep=''))
	}
	AgentTypes <- at$Integer[amatch]
	
	as <- GetPossibleStates()
	amatch <- pmatch(AgentStates, as$State, duplicates.ok = TRUE)
	if(any(is.na(amatch))){
		amatch <- pmatch(unique(AgentTypes), at$AgentType, duplicates.ok = TRUE)
		stop(paste('Unknown or ambiguous specified agent state(s) "', paste(AgentStates[which(is.na(amatch))], collapse='", "'), '"', sep=''))
	}
	AgentStates <- as$Integer[amatch]
	
	demography <- new(GubbinsDemography, FixedParameters=as.matrix(FixedParameters), VariableParameters=t(as.matrix(VariableParameters)), TemperatureData = as.matrix(TemperatureData), AgentStates=AgentStates, AgentTypes = AgentTypes)
	
	class(demography) <- "InternalDemography"
	toret <- Demography(demography)

	return(toret)
}


# A generic demography adder that doesn't check arguments:
#' @rdname CreateDemography
CreateDemography <- function(DemographyType, ...){

	demography <- new(DemographyType, ...)
	
	class(demography) <- "InternalDemography"
	toret <- Demography(demography)

	return(toret)
}

