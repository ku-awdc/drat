#' @title Run a within-farm model
#' @name FarmModel

#' @description
#' A wrapper function for running a set of within-farm models of disease spread (i.e. there is no spread of disease between farms).  All farms are infected on day 0 of the simulation.

#' @return
#' A list with the following elements:
#' \itemize{
#'	\item{Vectors}{ - An array of the number of vectors of each class in each farm at each time point}
#'	\item{Cattle}{ - An array of the number of cattle of each class in each farm at each time point}
#'	\item{Sheep}{ - An array of the number of sheep of each class in each farm at each time point}
#'	\item{FirstInfectious}{ - The first time point at which each farm became infectious}
#'	\item{FirstObserved}{ - The first time point at which each farm was observed to be infected (through clinically affected or dead sheep or cattle)}
#'	\item{State}{ - An array of the true infection state of each farm at each time point}
#'	\item{TimeTaken}{ - The time taken to complete the simulation}
#' }

#' @seealso
#' \code{\link{Demography}}, \code{\link{SummariseFarmModel}} and \code{\link{PlotFarmComparison}}

#' @param Demography an object produced by the \code{\link{Demography}} function. No default.

#' @param TimePoints the number of time points to run the simulation for.  Default 150.

#' @param RNGseed a seed to be passed to the pseudo-random number generator in the C++ code.

#' @param quiet option to suppress printing of progress information.  Default FALSE.
NULL


#' @rdname FarmModel
FarmModel <- function(Demography, TimePoints=150, RNGseed = sample(10^9, 1), quiet = FALSE){
	
	if(!inherits(Demography, "Demography"))
		stop("A pre-generated demography must be supplied")
	
	RNGseed <- as.integer(RNGseed)
	if(length(RNGseed)!=1){
		stop('A single RNG seed should be supplied')
	}
	if(is.na(RNGseed)){
		stop('The RNGseed became NA when coerced to integer')
	}
	
	start <- Sys.time()
	
	nfarms <- Demography$GetNumberOfAgents()
	demography <- Demography$AccessDemography()
	timepoints <- TimePoints
	
	if(!quiet) cat("Running the simulation for", nfarms, "farms and", timepoints, "time points\n")
		
	sims <- SimContainer(Demography)
	sims$AddFlatNetwork(0,0)
	sn <- sims$AddSimulation(MaxDays=TimePoints, RNGseed)
	
	for(i in 1:nfarms){
		sims$Infect(i)
	}
	
	td <- demography$VectorNumbers
	vectorout <- array(dim=c(dim(td), timepoints), dimnames=list(paste('Farm',1:nfarms,sep='_'),attr(td,'colnames'),paste('Time',1:timepoints,sep='_')))

	td <- demography$CattleNumbers
	cattleout <- array(dim=c(dim(td), timepoints), dimnames=list(paste('Farm',1:nfarms,sep='_'),attr(td,'colnames'),paste('Time',1:timepoints,sep='_')))

	td <- demography$SheepNumbers
	sheepout <- array(dim=c(dim(td), timepoints), dimnames=list(paste('Farm',1:nfarms,sep='_'),attr(td,'colnames'),paste('Time',1:timepoints,sep='_')))

	for(i in 1:timepoints){
		sims$Update(1)
		sims$AccessSimulation(sn)$SaveParameters(0)
		vectorout[,,i] <- demography$VectorNumbers
		cattleout[,,i] <- demography$CattleNumbers
		sheepout[,,i] <- demography$SheepNumbers
	}
	stateout <- sims$GetStates(all=TRUE)
	
	possstates <- PossibleStates()
	infstates <- possstates$Integer[grepl('Infective', possstates$State)]
	firstinfs <- sims$AccessSimulation(sn)$FirstStateTimes(infstates)
	firstinfs[firstinfs==-1] <- Inf

	obsstates <- possstates$Integer[grepl('Clinical', possstates$State)]
	firstobs <- sims$AccessSimulation(sn)$FirstStateTimes(obsstates)
	firstobs[firstobs==-1] <- Inf
	
	TimeTaken <- difftime(Sys.time(), start, units='mins')
	if(!quiet) cat('Finished in a total of', TimeTaken, 'minutes\n')

	return(list(Vectors=vectorout, Cattle=cattleout, Sheep=sheepout, FirstInfectious = firstinfs, FirstObserved = firstobs, State=stateout, TimeTaken = TimeTaken))
	
}


#' @title Summarise the results of a within-farm model
#' @name SummariseFarmModel

#' @description
#' A utility function for summarising the results of a FarmModel simulation, in order to save storage space compared to the full simulation results.

#' @return
#' A list with the following elements:
#' \itemize{
#'	\item{AffectedAnimals}{ - Quantiles of the cumulative number of affected animals at each time point on each farm}
#'	\item{InfectiousVectors}{ - Quantiles of the cumulative number of infectious vectors at each time point on each farm}
#'	\item{InfectiousFarms}{ - The cumulative number of farms which have become infectious by each time point}
#'	\item{ObservedFarms}{ - The cumulative number of farms which have been observed to be infected by each time point}
#' }

#' @seealso
#' \code{\link{FarmModel}} and \code{\link{PlotFarmComparison}}

#' @param farm_results an set of simulation results produced by the \code{\link{FarmModel}} function. No default.

#' @param probs the quantiles to calculate.

#' @param ... further arguments to be passed to \code{\link[stats]{quantile}}
NULL


#' @rdname SummariseFarmModel
SummariseFarmModel <- function(farm_results, probs = c(0.1,0.25,0.5,0.75,0.9), ...){
	
	if(!identical(names(farm_results), c("Vectors", "Cattle", "Sheep", "FirstInfectious", "FirstObserved", "State", "TimeTaken"))){
		stop('The results of a call to FarmModel must be specified')
	}
	
	ci <- which(dimnames(farm_results$Sheep)[[2]] == 'CumulativeInfected')
	totalsheep <- apply(farm_results$Sheep[,-ci,],c(1,3),sum)
	test <- apply(totalsheep,1,function(x) stopifnot(all(x==x[1])))

	ci <- which(dimnames(farm_results$Cattle)[[2]] == 'CumulativeInfected')
	totalcattle <- apply(farm_results$Cattle[,-ci,],c(1,3),sum)
	test <- apply(totalcattle,1,function(x) stopifnot(all(x==x[1])))

	havesheep <- which(totalsheep[,1] > 0)
	havecattle <- which(totalcattle[,1] > 0)
	
	mysummary <- function(x, probs=probs, ...){
		
		mu <- mean(x)
		sig <- sqrt(var(x))
		quants <- quantile(x, probs=probs, ...)
		
		return(c(Mean=mu, StdDev=sig, Median=median(x), quants))
	}
	
	ci <- which(dimnames(farm_results$Sheep)[[2]] == 'CumulativeInfected')
	cumulative_sheep <- apply(farm_results$Sheep[,ci,][havesheep,,drop=FALSE] / totalsheep[havesheep,,drop=FALSE], 2,mysummary, probs=probs)

	ci <- which(dimnames(farm_results$Cattle)[[2]] == 'CumulativeInfected')
	cumulative_cattle <- apply(farm_results$Cattle[,ci,][havecattle,,drop=FALSE] / totalcattle[havecattle,,drop=FALSE], 2,mysummary, probs=probs)
	
	stopifnot(which(dimnames(farm_results$Cattle)[[2]] == 'CumulativeInfected') == which(dimnames(farm_results$Sheep)[[2]] == 'CumulativeInfected'))
	cumulative_animals <- apply((farm_results$Cattle[,ci,]+farm_results$Sheep[,ci,]) / (totalcattle+totalsheep), 2, mysummary, probs=probs)
	
	cis <- which(dimnames(farm_results$Sheep)[[2]] == 'Dead')
	cic <- which(dimnames(farm_results$Cattle)[[2]] == 'Dead')
#	total_dead <- apply((farm_results$Cattle[,cic,] + farm_results$Sheep[,cis,]) / (totalcattle + totalsheep), 2,mysummary, probs=probs)
	total_dead <- apply((farm_results$Cattle[,cic,] + farm_results$Sheep[,cis,]), 2,mysummary, probs=probs)
	
	timepoints <- dim(farm_results$Sheep)[3]
	firstinf <- farm_results$FirstInfectious
	neverinf <- firstinf == Inf
	firstinf <- firstinf[!neverinf]
	
	stopifnot(all(firstinf <= timepoints))
	prop_infectious <- sapply(1:timepoints, function(x) return(sum(firstinf <= x))) / length(farm_results$FirstInfectious)
	names(prop_infectious) <- paste('TimePoint',1:timepoints,sep='_')	
	
	firstobs <- farm_results$FirstObserved
	neverobs <- firstobs == Inf
	firstobs <- firstobs[!neverobs]
	
	stopifnot(all(firstobs <= timepoints))
	prop_observed <- sapply(1:timepoints, function(x) return(sum(firstobs <= x))) / length(farm_results$FirstObserved)
	names(prop_observed) <- paste('TimePoint',1:timepoints,sep='_')	
	
	ci <- which(dimnames(farm_results$Vectors)[[2]] == 'CumulativeInfectious')
	cumulative_vectors <- apply(farm_results$Vectors[,ci,], 2, mysummary, probs=probs)
	
	return(list(AffectedAnimals = cumulative_animals, InfectiousVectors = cumulative_vectors, InfectiousFarms = prop_infectious, ObservedFarms = prop_observed))
}


#' @title Plot the comparative results of two within-farm models
#' @name PlotFarmComparison

#' @description
#' Utility function for producing a graphical comparison of two sets of within-farm model simulations.

#' @return
#' A (gg)plot is produced

#' @seealso
#' \code{\link{FarmModel}} and \code{\link{SummariseFarmModel}}

#' @param baseline a set of simulations produced by the \code{\link{FarmModel}} function. No default. These simulations will be coloured red in the output.

#' @param modified a set of simulations produced by the \code{\link{FarmModel}} function. No default. These simulations will be coloured blue in the output.

#' @param solid the quantiles to draw using a solid line

#' @param dashed the quantiles to draw using a dashed line

#' @param dotted the quantiles to draw using a dotted line
NULL


#' @rdname PlotFarmComparison
PlotFarmComparison <- function(baseline, modified, solid='50%', dashed=c('25%','75%'), dotted=c('10%','90%')){
	
	if(identical(names(baseline), c("Vectors", "Cattle", "Sheep", "FirstInfectious", "FirstObserved", "State", "TimeTaken"))){
		baseline <- SummariseFarmModel(baseline)
	}
	if(identical(names(modified), c("Vectors", "Cattle", "Sheep", "FirstInfectious", "FirstObserved", "State", "TimeTaken"))){
		modified <- SummariseFarmModel(modified)
	}
	
	if(!identical(names(baseline), c("AffectedAnimals", "InfectiousVectors", "InfectiousFarms", "ObservedFarms"))){
		stop('The results of a call to either FarmModel or SummariseFarmModel must be specified (for the baseline argument)')
	}
	if(!identical(names(modified), c("AffectedAnimals", "InfectiousVectors", "InfectiousFarms", "ObservedFarms"))){
		stop('The results of a call to either FarmModel or SummariseFarmModel must be specified (for the modified argument)')
	}
	if(ncol(baseline$AffectedAnimals)!=ncol(modified$AffectedAnimals)){
		stop("The baseline and modified results have different length time periods")
	}
	if(!all(c(solid,dashed,dotted) %in% dimnames(baseline$AffectedAnimals)[[1]])){
		stop('One or more of the rows indicated by solid, dashed and dotted was not found in the baseline data')
	}
	if(!all(c(solid,dashed,dotted) %in% dimnames(modified$AffectedAnimals)[[1]])){
		stop('One or more of the rows indicated by solid, dashed and dotted was not found in the modified data')
	}
	
	# Assume all time points are identical - i.e. the results haven't been fiddled with
	timepoints <- ncol(modified$AffectedAnimals)
	rows <- c(solid,dashed,dotted)
	linetype <- c(rep('a',length(solid)), rep('g', length(dashed)), rep('e', length(dotted)))
	
	totalrows <- timepoints * length(rows) * 2
	
	sf <- options('stringsAsFactors')[[1]]
	on.exit(options(stringsAsFactors=sf))
	options(stringsAsFactors=FALSE)
	
	plotdata <- data.frame(AffectedAnimals = rep(0, totalrows), InfectiousVectors = rep(0, totalrows), InfectiousFarms = rep(0, totalrows), ObservedFarms = rep(0, totalrows), Statistic = 'mean', Simulation = 'Baseline', LineType = 'a', TimePoint = 1:timepoints, Group=0)
	
	group <- 0
	for(i in 1:length(rows)){
		group <- group+1
		startat <- (i-1)*timepoints +1
		endat <- timepoints*i
		index <- startat:endat
		plotdata$AffectedAnimals[index] <- baseline$AffectedAnimals[rows[i],]
		plotdata$InfectiousVectors[index] <- baseline$InfectiousVectors[rows[i],]
		plotdata$InfectiousFarms[index] <- baseline$InfectiousFarms
		plotdata$ObservedFarms[index] <- baseline$ObservedFarms

		plotdata$Statistic[index] <- rows[i]
		plotdata$Simulation[index] <- 'Baseline'
		plotdata$Group[index] <- group
		plotdata$LineType[index] <- linetype[i]
		stopifnot(all(plotdata$TimePoint == 1:timepoints))
	}
	firstgroups <- c(1, group+1)
	for(i in 1:length(rows)){
		group <- group+1
		startat <- (timepoints*length(rows)) + (i-1)*timepoints +1
		endat <- (timepoints*length(rows)) + timepoints*i
		index <- startat:endat
		plotdata$AffectedAnimals[index] <- modified$AffectedAnimals[rows[i],]
		plotdata$InfectiousVectors[index] <- modified$InfectiousVectors[rows[i],]
		plotdata$InfectiousFarms[index] <- modified$InfectiousFarms
		plotdata$ObservedFarms[index] <- modified$ObservedFarms

		plotdata$Statistic[index] <- rows[i]
		plotdata$Simulation[index] <- 'Modified'
		plotdata$Group[index] <- group
		plotdata$LineType[index] <- linetype[i]
		stopifnot(all(plotdata$TimePoint == 1:timepoints))
	}
	
	# to suppress 'no visible binding' warnings:
	TimePoint <- 0
	InfectedCattle <- 0
	InfectedSheep <- 0
	DeadAnimals <- 0
	InfectiousFarms <- 0
	InfectiousVectors <- 0
	AffectedAnimals <- 0
	ObservedFarms <- 0
	Simulation <- 0
	Group <- 0
	LineType <- 0
	
		
	plot1 <- ggplot(plotdata, aes(x=TimePoint, y=AffectedAnimals, col=Simulation, group=Group, linetype=LineType)) + geom_line() + theme(legend.position="none") + scale_colour_manual(values=c('red','blue'))
	plot2 <- ggplot(plotdata, aes(x=TimePoint, y=InfectiousVectors, col=Simulation, group=Group, linetype=LineType)) + geom_line() + theme(legend.position="none") + scale_colour_manual(values=c('red','blue')) + scale_y_log10()
	
	plot3 <- ggplot(plotdata[plotdata$Group%in%firstgroups,], aes(x=TimePoint, y=InfectiousFarms, col=Simulation, group=Group, linetype=LineType)) + geom_line() + theme(legend.position="none") + scale_colour_manual(values=c('red','blue')) + ylim(c(0,1))
	plot4 <- ggplot(plotdata[plotdata$Group%in%firstgroups,], aes(x=TimePoint, y=ObservedFarms, col=Simulation, group=Group, linetype=LineType)) + geom_line() + theme(legend.position="none") + scale_colour_manual(values=c('red','blue')) + ylim(c(0,1))
	
	meanvar <- data.frame(Type=rep(c('AffectedAnimals','InfectiousVectors'), each=2), Model=rep(c('Baseline','Modified'),times=2), Mean=0, Median=0, StdDev=0)
	i <- 1
	meanvar[i,3:5] <- baseline$AffectedAnimals[c('Mean','Median','StdDev'),timepoints]; i <- i+1
	meanvar[i,3:5] <- modified$AffectedAnimals[c('Mean','Median','StdDev'),timepoints]; i <- i+1
	meanvar[i,3:5] <- baseline$InfectiousVectors[c('Mean','Median','StdDev'),timepoints]; i <- i+1
	meanvar[i,3:5] <- modified$InfectiousVectors[c('Mean','Median','StdDev'),timepoints]; i <- i+1
		
	allplots <- list(p1=plot1, p2=plot2, p3=plot3, p4=plot4, plotdata=plotdata, rows=rows, linetype=linetype, meanvar=meanvar)
	class(allplots) <- 'farm_multiplot'
	
	return(allplots)
}

print.farm_multiplot <- function(x, ...){
	
    grid.newpage()
    pushViewport(viewport(layout = grid.layout(2, 2)))
    rows <- c(1,1,2,2)
    cols <- c(1,2,1,2)
    for (i in 1:4){
      print(x[[i]], vp = viewport(layout.pos.row = rows[i], layout.pos.col = cols[i]))
    }
	
	linetype <- x$linetype
	linetype[linetype=='a'] <- 'solid'
	linetype[linetype=='g'] <- 'dashed'
	linetype[linetype=='e'] <- 'dotted'
	
	if(FALSE){
		cat("Producing plots:\n\tRed is the baseline model & Blue is the modified model\n")
		for(i in 1:length(x$rows))
			if(x$rows[i]=='50%')
				cat("\tThe median statistic is given by a ", linetype[i], " line\n", sep="")
			else
				cat("\tThe ", x$rows[i], if(grepl("%",x$rows[i],fixed=TRUE)) " quantile", " statistic is given by a ", linetype[i], " line\n", sep="")
	}
	
	for(i in 3:5) x$meanvar[,i] <- round(x$meanvar[,i], 3)
	print(x$meanvar)
}
