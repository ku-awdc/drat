loadModule("efsabt_module", TRUE)

.onAttach <- function(libname, pkgname){
	debugmode <- GetDebugSetting()
	packageStartupMessage(paste('Attaching efsabt with debug setting', debugmode, sep=' '))
	test <- CheckAgentTypes()
	test <- GetPossibleStates()
}

.onDetach <- function(libpath){
	gc()
}

