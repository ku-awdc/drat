#' @title Reference class containing the C++ simulation object
#' @name SimContainer

#' @description
#' This is an R-wrapper for the C++ simulation object code.  Initialisation requires a valid Demography object.  Methods are provided to control the simulation itself.

#' @seealso
#' \code{\link{Demography}} and \code{\link{CreateDemography}} for usage and creation of Demography classes, and \code{\link[methods]{ReferenceClasses}} for more information on OOP programming in R

#' @param Demography a pre-created Demography class object

#' @param FarmTypes a numeric vector of the types of farms (1=sheep, 2=cattle, 3=both) to set up

#' @param xLocations a numeric vector of x locations (easting / 1000)

#' @param yLocations a numeric vector of y locations (northing / 1000)

#' @param TransmissionProb a vector of transmission probabilities

#' @param RemovalProb a vector of removal probabilities

#' @param NumberOfAgents the number of agents within the network

#' @param SparseMatrix a data frame of connection probabilities

#' @param InfectiousAgentProb the binomial probability to apply to the total number of infected vectors on the source farm to determine the infection pressure on the destination farm

#' @param AquisitionProbs a vector of aquisition probabilities for the destination farms

#' @param MaxDays the maximum number of days that will be needed for the simulation

#' @param RNGseed an RNG seed to be passed to the C++ code setting up the simulation

#' @param LogName the name of a log file to use for the simulation (may be ignored depending on compilation settings)

#' @param SimulationNumber the simulation number to access/remove

#' @param AgentNumbers the agent number(s) to infect

#' @param InfectionForce the number of infected midges to introduce to the newly infected farm

#' @param Iterations the number of iterations to run

#' @param StopIfInactive option to stop running the simulation if further disease transmission becomes impossible

#' @param Observed return the observed (TRUE) or actual (FALSE) prevalence

#' @param Cumulative return the cumulative (TRUE) or current (FALSE) prevalence

#' @param TimeBin the number of time points to group together when calculating the number of new infections in the designated time periods

#' @param all option to return the state at all time periods (TRUE) or only the current time period (FALSE)

#' @param new_fixed_parameters fixed parameters to use

#' @param new_variable_parameters variable parameters to use

NULL

#' @rdname SimContainer
SimContainer <- setRefClass('SimContainer',
	fields = list(demography ='list', networks ='list', simulations='list', simulationsactive='logical', simaccessors='list', locked='logical', activesim='numeric'),
	methods = list(

	initialize = function(Demography){
		"Initialise a SimContainer with a Demography"
		
		if(!inherits(Demography, "Demography"))
			stop("A pre-generated demography must be supplied")
		
		.self$demography <- list(Demography)
		.self$networks <- list()
		.self$simulations <- list()
		.self$simulationsactive <- logical(0)
		.self$locked <- FALSE
		.self$activesim <- 0
	},
	
	# A generic network adder that doesn't check arguments:
	AddNetwork = function(NetworkType, ...){

		stopifnot(!locked)

		currentnets <- length(.self$networks)
		.self$networks[[currentnets+1]] <- new(NetworkType, ...)
		
		invisible(currentnets+1)
	},

	
	# Specific network types:
	AddGubbinsNetwork = function(FarmTypes, xLocations, yLocations){
		"Add a Gubbins Network to the SimContainer"

		stopifnot(!locked)
		
		NumberOfAgents <- length(xLocations)
		stopifnot(length(xLocations)==length(yLocations))
		
		currentnets <- length(.self$networks)
		.self$networks[[currentnets+1]] <- new(GubbinsNetwork, as.numeric(FarmTypes), xLocations, yLocations, NumberOfAgents)
		
		invisible(currentnets+1)
	},

	AddFlatNetwork = function(TransmissionProb, RemovalProb){
		"Add a Flat Network to the SimContainer"

		stopifnot(!locked)
		
		NumberOfAgents <- 0  # No limitations
		stopifnot(length(TransmissionProb)==1)
		stopifnot(length(RemovalProb)==1)
		
		currentnets <- length(.self$networks)
		.self$networks[[currentnets+1]] <- new(FlatNetwork, TransmissionProb, RemovalProb, NumberOfAgents)
		
		invisible(currentnets+1)
	},
	
	AddSparseMatrixNetwork = function(NumberOfAgents, SparseMatrix, InfectiousAgentProb, AquisitionProbs=1){
		"Add a Sparse Matrix Network to the SimContainer"

		stopifnot(!locked)
		
		if(length(AquisitionProbs)==1)
			AquisitionProbs <- rep(AquisitionProbs, NumberOfAgents)
		stopifnot(NumberOfAgents == length(AquisitionProbs))
		stopifnot(length(InfectiousAgentProb)==1)
		
		if(!inherits(SparseMatrix, 'data.frame')){
			SparseMatrix <- as.data.frame(SparseMatrix)
		}
		if(any(is.na(SparseMatrix))){
			stop("Missing values not allowed in the sparse matrix")
		}
		if(ncol(SparseMatrix) !=3){
			stop('The SparseMatrix must have exactly 3 columns')
		}
		if(is.null(names(SparseMatrix))){
			names(SparseMatrix) <- c("Source","Destination","Probability")
		}
		if(!all(names(SparseMatrix) == c("Source","Destination","Probability"))){
			stop("The names of the 3 columns must be (exactly) equal to Source, Destination, Probability")
		}
		
		if(any(SparseMatrix[,1] < 1) || any(SparseMatrix[,1] > NumberOfAgents)){
			stop('One or more source farm out of range (based on the length of AquisitionProbs)')
		}
		if(any(SparseMatrix[,2] < 1) || any(SparseMatrix[,2] > NumberOfAgents)){
			stop('One or more destination farm out of range (based on the length of AquisitionProbs)')
		}
		
		currentnets <- length(.self$networks)
		.self$networks[[currentnets+1]] <- new(SparseMatrixNetwork, SparseMatrix, AquisitionProbs, InfectiousAgentProb, NumberOfAgents)
		
		invisible(currentnets+1)
	},

	AddSimulation = function(MaxDays, RNGseed = sample(10^9, 1), LogName="Simulation.txt"){
		"Add a Simulation to the SimContainer"

		.self$locked <- TRUE
		currentsims <- length(.self$simulations)
		
		stopifnot(length(.self$networks) > 0)
		netno <- sapply(.self$networks, function(x) return(x$NetworkID))
		stopifnot(length(.self$demography) == 1)
		demno <- .self$AccessDemography()$DemographyID
		
		.self$simulations[[currentsims+1]] <- new(Simulation, DemographyNumber = demno, NetworkNumbers = netno, MaxDays, LogName, as.integer(RNGseed))
		.self$simulationsactive <- c(.self$simulationsactive, TRUE)
		
		.self$activesim <- currentsims+1
		invisible(currentsims+1)
	},

	RemoveSimulation = function(SimulationNumber){
		"Remove a Simulation from the SimContainer"

		if(!length(.self$simulationsactive) >= SimulationNumber || identical(.self$simulations[[SimulationNumber]], 'removed')){
			stop("Invalid simulation number")
		}
		
		stopifnot(length(.self$simulationsactive) == length(.self$simulations))
		
		.self$simulations[[SimulationNumber]] <- 'removed'
		.self$simulationsactive[SimulationNumber] <- FALSE
		if(.self$activesim==SimulationNumber){
			.self$activesim <- 0
		}
		gc()
		
		if(sum(.self$simulationsactive)==0){
			.self$simulations <- list()
			.self$simulationsactive <- logical(0)
			.self$locked <- FALSE
		}
	},
	
	ResetSimulation = function(SimulationNumber){
		"Reset the specified simulation"

		if(missing(SimulationNumber))
			SimulationNumber <- .self$activesim
		
		if(!length(.self$simulationsactive) >= SimulationNumber || identical(.self$simulations[[SimulationNumber]], 'removed')){
			stop("Invalid simulation number")
		}
		
		stopifnot(length(.self$simulationsactive) == length(.self$simulations))
		
		sim <- .self$AccessSimulation(.self$activesim)
		sim$Reset()
	},
	
	SetActiveSimulation = function(SimulationNumber){
		"Make the specified simulation number the active simulation"

		if(!length(.self$simulationsactive) >= SimulationNumber || identical(.self$simulations[[SimulationNumber]], 'removed')){
			stop("Invalid simulation number")
		}
		stopifnot(length(.self$simulationsactive) == length(.self$simulations))
		
		.self$activesim <- SimulationNumber
	},
	
	Infect = function(AgentNumbers, InfectionForce = 5){
		"Infect the specified agent number(s) (in the active simulation)"

		stopifnot(.self$activesim!=0)
		sim <- .self$AccessSimulation(.self$activesim)
		if(any(AgentNumbers <= 0) || any(AgentNumbers > length(sim$CurrentStates))){
			stop("One or more AgentNumber out of range")
		}
		for(i in AgentNumbers){
			sim$Infect(i, InfectionForce)
		}
	},
	
	Update = function(Iterations, StopIfInactive = TRUE){
		"Update the active simulation"

		stopifnot(.self$activesim!=0)
		sim <- .self$AccessSimulation(.self$activesim)
		sim$Update(Iterations, StopIfInactive)
	},
	
	GetPrevalences = function(Observed = FALSE, Cumulative = TRUE){
		"Get the (cumulative) (observed) prevalence (in the active simulation)"

		stopifnot(.self$activesim!=0)
		sim <- .self$AccessSimulation(.self$activesim)
		if(Observed && Cumulative){
			prevs <- sim$GetCumulativeObservedPrevalences()
		}else if(Observed && !Cumulative){
			prevs <- sim$GetObservedPrevalences()
		}
		else if(!Observed && Cumulative){
			prevs <- sim$GetCumulativePrevalences()
		}else if(!Observed && !Cumulative){
			prevs <- sim$GetPrevalences()
		}else{
			stop('An unknown error occured')
		}
		return(prevs)
	},

	GetNewInfections = function(Observed = FALSE, TimeBin = 7){
		"Get the new (observed) infected farms for each time period with specified binning (in the active simulation)"

		stopifnot(.self$activesim!=0)
		sim <- .self$AccessSimulation(.self$activesim)
		if(Observed){
			prevs <- sim$GetCumulativeObservedPrevalences()
		}else{
			prevs <- sim$GetCumulativePrevalences()
		}
		
		N <- length(.self$GetStates(all=FALSE))
		ltr <- length(numeric(ceiling(length(prevs) / TimeBin)))
		prevs <- round(prevs * N)

		startpoints <- 0:(ltr-1) * TimeBin +1
		endpoints <- pmin(startpoints+TimeBin-1, length(prevs))

		stopifnot(length(startpoints)==length(endpoints))
		stopifnot(length(startpoints)==ltr)
		stopifnot(all(startpoints > 0))
		stopifnot(all(startpoints <= endpoints))
		stopifnot(all(endpoints <= length(prevs)))
		stopifnot(sum(startpoints==1)==1)
		stopifnot(sum(endpoints==length(prevs))==1)

		toret <- c(prevs[endpoints[1]], sapply(2:length(endpoints), function(x) return(prevs[endpoints[x]] - prevs[endpoints[x-1]])))
		names(toret) <- paste('Period_', startpoints, ':', endpoints, sep='')
		
		return(toret)
	},

	GetStates = function(all = FALSE){
		"Get the state for all agents, either for all time points or only the current time point (in the active simulation)"

		stopifnot(.self$activesim!=0)
		sim <- .self$AccessSimulation(.self$activesim)
		states <- sim$StateMatrix
		if(all){
			return(states)
		}else{
			return(states[,sim$TimePoint])
		}
	},

	SetFixedParameters = function(new_fixed_parameters){
		"Reset the fixed parameters in the demography"
		
		.self$demography[[1]]$SetFixedParameters(new_fixed_parameters)
	},
	
	GetFixedParameters = function(){
		"Return the current fixed parameters in the demography"

		return(.self$demography[[1]]$GetFixedParameters())
	},

	SetVariableParameters = function(new_variable_parameters){
		"Reset the variable parameters in the demography"

		.self$demography[[1]]$SetVariableParameters(new_variable_parameters)
	},
	
	GetVariableParameters = function(){
		"Return the current variable parameters in the demography"

		return(.self$demography[[1]]$GetVariableParameters())
	},
	
	# Returns a bare interface to the C++ class:
	AccessDemography = function(){
		"Access the C++ methods available to this demography directly"
		
		stopifnot(length(.self$demography)==1)
		return(.self$demography[[1]]$AccessDemography())
	},
	
	# Returns a bare interface to the C++ class:
	AccessSimulation = function(SimulationNumber){
		"Access the C++ methods available to the specified simulation directly"

		if(!length(.self$simulationsactive) >= SimulationNumber || identical(.self$simulations[[SimulationNumber]], 'removed')){
			stop("Invalid simulation number")
		}
		stopifnot(length(.self$simulationsactive) == length(.self$simulations))
		
		return(.self$simulations[[SimulationNumber]])
	},
	
	ActiveSimulations = function(){
		"Return a numeric vector of the simulation numbers which are currently active"
		
		return(which(.self$simulationsactive))
	},
	
	finalize = function(){
		for(i in which(.self$simulationsactive)){
			.self$RemoveSimulation(i)
		}
		
		.self$demography <- list()
		.self$networks <- list()
		gc()
	}
))
