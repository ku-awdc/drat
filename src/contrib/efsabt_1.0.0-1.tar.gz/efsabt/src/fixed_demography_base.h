/*

 demography_base 
 The demography_base class
 
 A single object of this class is needed for each set of simulations.  The function of this class is to 
 provide a means of passing information between derived agent classes and R.
 This file should not need to be modified.  A base class demography can be used by an active simulation.

 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.
 
 */


#include "settings.h"
#include "fixed_metapop.h"
#include "fixed_agent_base.h"

#include <iostream>
#include <fstream>
#include <vector>
#include <Rcpp.h>

class Logger;

#ifndef DEMOG_BASE_H
#define DEMOG_BASE_H


class Demography
{
protected:
	
	Logger* logger;
	long m_agents;

	int m_MaxDays;

	int m_ID;
	// The static variable for IDGen allows each demography to know its unique ID
    static int s_IDGen;
	
	// An Rcpp::IntegerVector to hold the states of agents:
	Rcpp::IntegerVector mp_AgentStates;
	
	// A vector to hold the agent types:
	std::vector<AgentType> mp_AgentTypes;
	
public:
	
	// Public constructor, to be called by the user before setting up a simulation.
    Demography(Rcpp::IntegerVector InputAgentStates, Rcpp::IntegerVector InputAgentTypes, std::string LogName = "BasicDemography.txt");
	
	// Functions used by simulation to update and retrieve agent parameters - not intended to be overridden directly:
	void UpdateAgentsWrapper(MetaPop* p_MetaPop);
	void RetrieveAgentsWrapper(MetaPop* p_MetaPop, long AgentNumber = 0);		
	void ResetWrapper(MetaPop* p_MetaPop);
	
	// Functions that should be overridden:
	virtual void UpdateAgentParameters(long AgentNumber, long IndexNumber, MetaPop* p_MetaPop);
	virtual void RetrieveAgentParameters(long AgentNumber, long IndexNumber, MetaPop* p_MetaPop);
	virtual void Reset(MetaPop* p_MetaPop);
	
	virtual Rcpp::NumericMatrix GetFixedParameters();
	virtual void SetFixedParameters(Rcpp::NumericMatrix NewFixedParameters);
	virtual Rcpp::NumericMatrix GetVariableParameters();
	virtual void SetVariableParameters(Rcpp::NumericMatrix NewVariableParameters);
	
	// Get the ID of this demography:
	int GetDemographyID();
	// Just used in R to ensure this is the correct class:
	Rcpp::StringVector GetBaseClass();
	
	// Function used by simulation to check that the number of agents is consistent with that passed to the simulation
	virtual bool CheckNumberOfAgents(long InputNumber);
	// Function used by R and Simulation constructor:
	int GetNumberOfAgents();
	// Function used by simulation::update to check we can do the requested time points:
	int MaxDays();
	
	// Function used by MetaPop to get the agent types:
	std::vector<AgentType> GetAgentTypes();
	// Function used by MetaPop to get the current state of one or all agents (AgentNumber 0 means all agents)
	Rcpp::IntegerVector GetAgentStates(long AgentNumber = 0);
	
	Rcpp::IntegerVector GetInitialisationStates();
	void SetInitialisationStates(Rcpp::IntegerVector States);
	
	// The destructor.  Responsible for closing the log file
	virtual ~Demography();		
};

#endif  // DEMOG_BASE_H
