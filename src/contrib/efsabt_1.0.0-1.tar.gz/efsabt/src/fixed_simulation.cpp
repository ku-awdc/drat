/*
 
 Simulation class
 This file should not need to be modified
 
 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.
 
 */


#include "fixed_simulation.h"

#include "fixed_settings.h"
#include "fixed_metapop.h"
#include "fixed_logger.h"
#include "fixed_network_base.h"
#include "fixed_demography_base.h"
#include "fixed_agent_base.h"

#include <gsl/gsl_randist.h>
#include <Rcpp.h>

// ID generator using a static variable:
int Simulation::s_IDGen = 1;

// Forward declarations:
extern std::vector<Network*> global_NetworkPointers;
extern std::vector<bool> global_NetworkActive;
extern std::vector<int> global_NetworkUsed;
extern std::vector<Demography*> global_DemographyPointers;
extern std::vector<bool> global_DemographyActive;
extern std::vector<int> global_DemographyUsed;


// Constructor	
Simulation::Simulation(int DemographyNumber, Rcpp::IntegerVector NetworkNumbers, int MaxDays, std::string LogName, long RNGseed)
	: m_MaxDays(MaxDays)
{
	
	// The logger must be set up first:
	logger = new FileLogger(logDEBUG3, LogName);
//	logger->SetLevel(logDEBUG);
	
	// First check the agent classes match up:
	CheckAgentTypes();

	// Check that the demography is valid before we do anything else:
	stopifnot_msg(DemographyNumber > 0, "The Demography Number provided (" << DemographyNumber << ") must be greater than 0");
	stopifnot_msg(DemographyNumber <= ((int) global_DemographyPointers.size()), "The Demography Number provided (" << DemographyNumber << ") is greater than the number of demographys available (" << global_DemographyPointers.size() << ")");
	stopifnot_msg(global_DemographyActive[DemographyNumber], "The Demography Number provided (" << DemographyNumber << ") has been deleted");
	// Limit demography use to one per simulation:
	// stopifnot_msg(global_DemographyUsed[DemographyNumber]==0, "The Demography Number provided (" << DemographyNumber << ") is already in use by another simulation - you can delete the other solution and run gc() and then try again");
	// There probably isn't much point - the Demography can't call Simulation, MetaPop or Agent anyway as it must be declared first
	
	// Retrieve a pointer to the relevant demography:
	Demography* InputDemography = global_DemographyPointers[DemographyNumber];
	mp_Demography = InputDemography;
	
	// Check that the reported Demography Number matches:
	assert(mp_Demography->GetDemographyID() == DemographyNumber);
	LOG(logINFO) << "Using Demography number " << mp_Demography->GetDemographyID() <<std::endl;
	
	// Check that the demography is compatible with this number of time points:
	int demwmd = mp_Demography->MaxDays();
	stopifnot_msg(m_MaxDays > 0 && m_MaxDays <= 10000, "MaxDays must be greater than 0 and less than 10,001");
	if(demwmd > 0){
		stopifnot_msg(demwmd >= m_MaxDays, "The maximum time points allowable by this Demography (" << demwmd << ") is less than the maximum number requested for the simulation (" << m_MaxDays << ")");
	}
	
	
	// Retrieve pointers to the relevant networks:
	mv_Networks.resize(NetworkNumbers.length());
	for(int i=0; i<NetworkNumbers.length(); i++){

		// Check that the network is valid before we do anything else:
		stopifnot_msg(NetworkNumbers[i] > 0, "The Network Number provided (" << NetworkNumbers[i] << ") must be greater than 0");
		stopifnot_msg(NetworkNumbers[i] <= (int) global_NetworkPointers.size(), "The Network Number provided (" << NetworkNumbers[i] << ") is greater than the number of networks available (" << global_NetworkPointers.size() << ")");
		stopifnot_msg(global_NetworkActive[NetworkNumbers[i]], "The Network Number provided (" << NetworkNumbers[i] << ") has been deleted");
		// We don't check for duplicates

		// Then retrieve the network:
		Network* InputNetwork = global_NetworkPointers[NetworkNumbers[i]];
		mv_Networks[i] = InputNetwork;

		// Check that the reported Network Number matches:
		assert(mv_Networks[i]->GetNetworkID() == NetworkNumbers[i]);
		LOG(logINFO) << "Using Network number " << mv_Networks[i]->GetNetworkID() <<std::endl;

		// Check that the network is compatible with this number of agents:
		long NumberOfAgents = mp_Demography->GetNumberOfAgents();
		stopifnot_msg(mv_Networks[i]->CheckNumberOfAgents(NumberOfAgents), "The number of agents in the Demography specified (" << NumberOfAgents << ") was rejected by the Network specified (which was set up with " << mv_Networks[i]->GetNumberOfAgents() << " agents)");
		
		// Check time points:
		int netwmd = mv_Networks[i]->MaxDays();
		if(netwmd > 0){
			stopifnot_msg(netwmd >= m_MaxDays, "The maximum time points allowable by Network " << mv_Networks[i]->GetNetworkID() << " (" << netwmd << ") is less than the maximum number requested for the simulation (" << m_MaxDays << ")");
		}
		
	}

	
	// Increment the ID so that we can keep track of all the simulations started for this R session
	m_ID = s_IDGen++;
	
	// Set up the RNG:
	r = gsl_rng_alloc (gsl_rng_mt19937);
    unsigned long long seed;
	if(RNGseed){
        seed = (unsigned long long) RNGseed;
    }else{
        seed = time(0);
    }
	gsl_rng_set(r, (unsigned long long) seed);
	
	LOG(logINFO) << "Setting up an '" << gsl_rng_name(r) << "' RNG with seed:  " << seed << std::endl;
	
	
	// We set up a metapopulation (passing the relevant pointers through), and pass the pointer to our member variable:
	mp_MetaPop = new MetaPop(mp_Demography, logger, m_ID, r);
	
	LOG(logINFO) << "Registering network numbers as in use" << std::endl;

	// If everything has succeeded, register the Network and Demography numbers as in use:
	mv_NetworkID.resize(NetworkNumbers.length());
	for(int i=0; i<NetworkNumbers.length(); i++){
		mv_NetworkID[i] = mv_Networks[i]->GetNetworkID();
		global_NetworkUsed[mv_NetworkID[i]]++;		
	}

	LOG(logINFO) << "Registering demography number as in use" << std::endl;
	m_DemographyID = mp_Demography->GetDemographyID();
	global_DemographyUsed[m_DemographyID]++;
	
	LOG(logINFO) << "Setting up prevalence vectors" << std::endl;
	// And set up cumulative prevalence vector:
	mv_Prevalences.resize(m_MaxDays);
	mv_CumulativePrevalences.resize(m_MaxDays);
	mv_ObservedPrevalences.resize(m_MaxDays);
	mv_CumulativeObservedPrevalences.resize(m_MaxDays);

	mp_EverInfected.resize(GetNumberOfAgents());
	mp_EverObserved.resize(GetNumberOfAgents());
	// And state matrix:
	Rcpp::IntegerMatrix temp(GetNumberOfAgents(), m_MaxDays);
	mp_StateMatrix = temp;
	
	// Then initialise for the first time:
	Reset();
}

void Simulation::SetRNG(int RNGseed){
	// Free up memory associated with the old RNG:
	gsl_rng_free (r);
	
	// Make a new RNG:
	r = gsl_rng_alloc (gsl_rng_mt19937);
    unsigned long long seed;
	if(RNGseed){
        seed = (unsigned long long) RNGseed;
    }else{
        seed = time(0);
    }
	gsl_rng_set(r, (unsigned long long) seed);	

	LOG(logINFO) << "Setting up an '" << gsl_rng_name(r) << "' RNG with seed:  " << seed << std::endl;	
}

void Simulation::Reset(){
	
	LOG(logINFO) << "Resetting the simulation" << std::endl;
	
	// First trigger an update of the agent parameters by Demography for all agents:
	
	LOG(logINFO) << "Telling demography to update agents" << std::endl;
	mp_Demography->UpdateAgentsWrapper(mp_MetaPop);
	// Then reset the demography and network as needed:
	LOG(logINFO) << "Telling demography to reset" << std::endl;
	mp_Demography->ResetWrapper(mp_MetaPop);

	for(int i=0; i < ((int) mv_NetworkID.size()); i++){
		LOG(logINFO) << "Telling network " << i+1 << " to reset" << std::endl;
		mv_Networks[i]->ResetWrapper(mp_MetaPop);
	}
	
	// Then initialise the agents for the first time with ResetTime=true:
	Initialise(true);

}

void Simulation::Initialise(bool ResetTime){
	if(ResetTime){
		// First reset the time point to 0 if requested:
		mp_MetaPop->SetTimePoint(0);
	}
	
	// Loop through the agents calling initialise on the final class:
	for(int i=0; i<AT_Num; i++){
		for(long a=0; a<mp_MetaPop->m_AgentClassNumbersFinalClass[i]; a++){
			LOG(logINFO) << "Initialising " << ((AgentType) i) << " number " << a+1 << std::endl;
			Agent* ap = mp_MetaPop->m_AgentPointersFinalClass[i][a];
			ap->Initialise();
			// If resetting time then reset the ever infecteds:
			if(ResetTime){
				mp_EverInfected[a] = ap->IsInfected();
				mp_EverObserved[a] = ap->IsObservedInfected();
			}
			// Check that the state is gettable and conistent:
			assert(ap->GetState() == ap->GetState());
		}
	}
}

void Simulation::SaveParameters(long AgentNumber){
	
	if(AgentNumber!=0){
		stopifnot_msg(AgentNumber <= mp_MetaPop->GetNumberOfAgents(AT_Agent), "Supplied AgentNumber (" << AgentNumber << ") is out of range");
		stopifnot_msg(AgentNumber > 0, "Supplied AgentNumber (" << AgentNumber << ") is out of range");
	}
	
	mp_Demography->RetrieveAgentsWrapper(mp_MetaPop, AgentNumber);
	
}

const int Simulation::GetTimePoint(){
	return(mp_MetaPop->GetTimePoint());
}

const long Simulation::GetNumberOfAgents(AgentType UseAgentType){
	return(mp_MetaPop->GetNumberOfAgents(UseAgentType));
}


Rcpp::IntegerVector Simulation::GetStates()
{
	AgentType AT = AT_Agent;
	Rcpp::IntegerVector states(mp_MetaPop->GetNumberOfAgents(AT));
	for(long i=1; i<=mp_MetaPop->GetNumberOfAgents(AT); i++)
  {
	  // i-1 as indexing not consistent:
		states[i-1] = mp_MetaPop->GetAgentPointer(i, AT)->GetState();
	}
  return(states);
}

const Rcpp::IntegerMatrix Simulation::GetStateMatrix()
{
	// Easiest for R to copy the state matrix and subset the time points used, so just return the whole thing:	
	return(mp_StateMatrix);
}

void Simulation::Infect(long AgentNumber, int InfectionPressure)
{
	AgentType AT = AT_Agent;
	if(AgentNumber==0){
		for(long i=1; i<=mp_MetaPop->GetNumberOfAgents(AT); i++)
	  {
		  // i-1 for States[] as indexing not consistent:
			mp_MetaPop->GetAgentPointer(i, AT)->Infect(InfectionPressure);
		}
	}else{
		stopifnot_msg(AgentNumber > 0 && AgentNumber <= mp_MetaPop->GetNumberOfAgents(AT), "AgentNumber specified is out of range");
		mp_MetaPop->GetAgentPointer(AgentNumber, AT)->Infect(InfectionPressure);
	}
}

void Simulation::Remove(long AgentNumber)
{
	AgentType AT = AT_Agent;
	if(AgentNumber==0){
		for(long i=1; i<=mp_MetaPop->GetNumberOfAgents(AT); i++)
	  {
		  // i-1 for States[] as indexing not consistent:
			mp_MetaPop->GetAgentPointer(i, AT)->Remove();
		}
	}else{
		stopifnot_msg(AgentNumber > 0 && AgentNumber <= mp_MetaPop->GetNumberOfAgents(AT), "AgentNumber specified is out of range");
		mp_MetaPop->GetAgentPointer(AgentNumber, AT)->Remove();
	}
}

void Simulation::Vaccinate(long AgentNumber)
{
	AgentType AT = AT_Agent;
	if(AgentNumber==0){
		for(long i=1; i<=mp_MetaPop->GetNumberOfAgents(AT); i++)
	  {
		  // i-1 for States[] as indexing not consistent:
			mp_MetaPop->GetAgentPointer(i, AT)->Vaccinate();
		}
	}else{
		stopifnot_msg(AgentNumber > 0 && AgentNumber <= mp_MetaPop->GetNumberOfAgents(AT), "AgentNumber specified is out of range");
		mp_MetaPop->GetAgentPointer(AgentNumber, AT)->Vaccinate();
	}
}

const Rcpp::IntegerVector Simulation::GetFirstTime(Rcpp::IntegerVector TargetStates)
{
	// Find the first time that a farm is registered as one of these states in mp_StatesMatrix
	// Have a special case for TargetStates.size()==1 for speed ??
	// Check inputstates are valid first (create a new int[] and coerce them to state before going into the loop)
	// loop up to current time point max, and bail if found a state (loop agents first, then time points, then states - break second loop if found - top loop does instate = instate || state==TargetStates[k])
	
	for(int i=0; i < TargetStates.size(); i++){
		stopifnot_msg(TargetStates[i] < n_states, "Requested TargetState " << TargetStates[i] << " is not valid");
	}
	
	// Set up a vector with default times of -1:
	Rcpp::IntegerVector statetimes(GetNumberOfAgents(AT_Agent));
	for(long a=0; a < GetNumberOfAgents(AT_Agent); a++){
		statetimes[a] = -1;
		
		bool foundstate = false;
		for(int t=0; t < GetTimePoint(); t++){
			for(int s=0; s < TargetStates.size(); s++){
				foundstate = foundstate || (mp_StateMatrix(a, t) == TargetStates[s]);
			}
			if(foundstate){
				statetimes[a] = t+1;
				break;  // Break from the time point loop and go to the next agent
			}
		}
	}
	return(statetimes);
}


const int Simulation::GetAgentState(long AgentNumber){
	
	stopifnot_msg(AgentNumber <= mp_MetaPop->GetNumberOfAgents(AT_Agent), "Supplied AgentNumber (" << AgentNumber << ") is out of range");
	stopifnot_msg(AgentNumber > 0, "Supplied AgentNumber (" << AgentNumber << ") is out of range");
	
	return(mp_MetaPop->GetAgentPointer(AgentNumber, AT_Agent)->GetState());
	
}


const double Simulation::GetPrevalence(int UseAgentType){
	
	// Always -1 as indexing in R starts at 1:
	stopifnot_msg(UseAgentType > 0, "The agent type argument must be greater than or equal to 1");
	stopifnot_msg(UseAgentType <= AT_Num, "The agent type argument provided is greater than the number of agent classes available");
	AgentType ConvertedType = (AgentType) (UseAgentType-1);
	
	int numagents = mp_MetaPop->GetNumberOfAgents(ConvertedType);
	stopifnot_msg(numagents > 0, "There are no agents of (or deriving from) the specified type in the simulation");
	
	return(mp_MetaPop->GetPrevalence(ConvertedType));
	
}

void Simulation::Update(int NumberOfTimePoints, bool StopIfInactive){
	
	int startingiter = mp_MetaPop->GetTimePoint();
	stopifnot_msg(NumberOfTimePoints > 0, "Requested number of time points must be greater than 0");
	stopifnot_msg(startingiter+NumberOfTimePoints <= m_MaxDays, "Requested number of time points is beyond the maximum time set up for this simulation");	
	
	// Do this as a vector (and coerce to NumericVector at the end) so we can use resize
	LOG(logDEBUG) << "Setting up prevalences vector" << std::endl;
	std::vector<double> prevs;
	prevs.resize(NumberOfTimePoints);
	
	LOG(logDEBUG) << "Running the simulation for an additional " << NumberOfTimePoints << " iterations (starting at " << startingiter << " with a maximum of " << m_MaxDays << ")" << std::endl;
	for(int i=0; i<NumberOfTimePoints; i++){
		
		// Must set the time point first:
		mp_MetaPop->SetTimePoint(startingiter+i+1);
		int currentindex = startingiter+i;  // Not +1 as index starts at 0, but iterations start at 1 (iteration 0 is not stored)
		
		// First tell networks to do infection thing:
		for(int n=0; n<((int) mv_NetworkID.size()); n++){
			mv_Networks[n]->TransmissionWrapper(mp_MetaPop);
		}
		
		// Then loop over agents (starting index 1) and update them:
		long numinfectednow = 0;
		long numinfectedever = 0;
		long numobservednow = 0;
		long numobservedever = 0;
		for(long a=1; a<=GetNumberOfAgents(); a++){
			Agent* ap = mp_MetaPop->GetAgentPointer(a);
			ap->Update();
			mp_EverInfected[a-1] = mp_EverInfected[a-1] || ap->IsInfected();
			mp_EverObserved[a-1] = mp_EverObserved[a-1] || ap->IsObservedInfected();
			numinfectednow += (int) ap->IsInfected();
			numobservednow += (int) ap->IsObservedInfected();
			numinfectedever += (int) mp_EverInfected[a-1];
			numobservedever += (int) mp_EverObserved[a-1];
			
			mp_StateMatrix(a-1, currentindex) = (int) ap->GetState();
		}
		mv_CumulativePrevalences[startingiter+i] = ((double) numinfectedever) / ((double) GetNumberOfAgents());		
		mv_Prevalences[startingiter+i] = ((double) numinfectednow) / ((double) GetNumberOfAgents());	
		mv_CumulativeObservedPrevalences[startingiter+i] = ((double) numobservedever) / ((double) GetNumberOfAgents());		
		mv_ObservedPrevalences[startingiter+i] = ((double) numobservednow) / ((double) GetNumberOfAgents());	

		LOG(logDEBUG) << "Iteration  " << (startingiter+i+1) << " complete - number currently infected is " << numinfectednow << std::endl;
		
		// If StopIfInactive and Inactive, then stop:
		if(StopIfInactive && (numinfectednow==0)){
			break;
		}		
	}
	
}

Rcpp::NumericVector Simulation::GetCumulativePrevalences(){
	std::vector<double> prevs = mv_CumulativePrevalences;
	prevs.resize(GetTimePoint());
	Rcpp::NumericVector retprevs(prevs.begin(), prevs.end());
	return(retprevs);
}

Rcpp::NumericVector Simulation::GetPrevalences(){
	std::vector<double> prevs = mv_Prevalences;
	prevs.resize(GetTimePoint());
	Rcpp::NumericVector retprevs(prevs.begin(), prevs.end());
	return(retprevs);
}

Rcpp::NumericVector Simulation::GetCumulativeObservedPrevalences(){
	std::vector<double> prevs = mv_CumulativeObservedPrevalences;
	prevs.resize(GetTimePoint());
	Rcpp::NumericVector retprevs(prevs.begin(), prevs.end());
	return(retprevs);
}

Rcpp::NumericVector Simulation::GetObservedPrevalences(){
	std::vector<double> prevs = mv_ObservedPrevalences;
	prevs.resize(GetTimePoint());
	Rcpp::NumericVector retprevs(prevs.begin(), prevs.end());
	return(retprevs);
}

const Rcpp::StringVector Simulation::GetBaseClass(){
	Rcpp::StringVector temp("Simulation");
	return(temp);
}

// Destructor - we have allocated memory for some variables, so need to deallocate to avoid memory leaks:
Simulation::~Simulation(){
	
	LOG(logINFO) << "Removing the simulation" << std::endl;
	
	LOG(logINFO) << "Deleting the agents" << std::endl;
	// The agents (or derived class) are pointers, so we have to deallocate each element
	// This can't be done by MetaPop as we can't fully declare the Agents before MetaPop

	// First loop through all final class agent types:
	for(int i=0; i<AT_Num; i++){
		// Delete the agents themselves and final class pointers - deleting must be done on the final class to trigger the correct destructor:
		for(long a=0; a<mp_MetaPop->m_AgentClassNumbersFinalClass[((int) i)]; a++){
			LOG(logINFO) << "Deleting " << ((AgentType) i) << " number " << a+1 << std::endl;
			delete mp_MetaPop->m_AgentPointersFinalClass[i][a];
			LOG(logINFO) << "Deleting final class pointer for " << ((AgentType) i) << " number " << a+1 << std::endl;
			mp_MetaPop->m_AgentPointersFinalClass[i][a] = 0;
		}
	}
	
	// Then loop through again to delete the remaining pointers now the agents are removed:
	for(int i=0; i<AT_Num; i++){
		for(long a=0; a<mp_MetaPop->m_AgentClassNumbers[i]; a++){
			LOG(logINFO) << "Deleting pointer for " << ((AgentType) i) << " number " << a+1 << std::endl;
			mp_MetaPop->m_AgentPointers[i][a] = 0;
		}
	}
	
	LOG(logINFO) << "All agents removed" << std::endl;
	
	// Now de-register the Network and Demography as in-use:
	for(int i=0; i<((int) mv_NetworkID.size()); i++){
		global_NetworkUsed[mv_NetworkID[i]]--;		
	}
	global_DemographyUsed[m_DemographyID]--;
	
	
	// Finally delete the metapopulation itself:
	delete mp_MetaPop;
	mp_MetaPop=0;
	
	// Free up memory associated with the RNG:
	gsl_rng_free (r);

	// Because logger is allocated dynamically (so that writing to log files can be different for different 
	// simulations), we need to ensure it is deallocated (which also calls its destructor to ensure all text is written out and stamp the date/time):
	delete logger;
	logger=0;
	
}
