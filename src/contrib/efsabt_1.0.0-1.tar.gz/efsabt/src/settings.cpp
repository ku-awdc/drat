/*
 Customisable settings
 When agents are added they will need to be added to this file
  
 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.
 
 */


#include "settings.h"
#include <Rcpp.h>
#include "fixed_agent_base.h"
#include "fixed_metapop.h"

// The user derived agent class header files need to be added here:
#include "agent_gubbinsfarm.h"
#include "agent_si.h"

// Modify this function with new agent classes as in the AgentType enum:
void AddAgent(AgentType Type, int InputState, MetaPop *InputMetaPop){
	
	Agent* NewAgent;
	Logger* logger = InputMetaPop->GetLogger();
	Rcpp::StringVector types = AvailableAgentTypes();
  
	if (Type == AT_Agent){
		stopifnot_msg(false, "Can't use a base Agent class - the constructor is protected!");
		// This creates a compiler error:
		// NewAgent = new Agent(Type, InputState, InputMetaPop);
	}else if(Type == AT_SIAgent){
		NewAgent = new SIAgent(Type, InputState, InputMetaPop);	
	}else if(Type == AT_GubbinsFarm){
		NewAgent = new GubbinsFarm(Type, InputState, InputMetaPop);	
	}else{
		stopifnot_msg(((int) types.size()) > (AT_Num-1), "AgentFactory and AvailableAgentTypes (in settings.cpp) have not been told about Agent Type number:  " << ((int) Type));
		stopifnot_msg(false, "AgentFactory (in settings.cpp) is missing a constructor for Agent Type:  " << Type);
	}
	
	stopifnot_msg(((int) types.size()) > (AT_Num-1), "AvailableAgentTypes (in settings.cpp) has not been told about Agent Type number:  " << ((int) Type));
	stopifnot_msg(NewAgent->GetType() == Type, "Agent type number " << ((int) Type) << " does not return the correct type");
	
	// Nothing is returned by this function as the Agent itself is responsible for adding its pointer to MetaPop
}

// Modify this helper function so that the user-visible names of Agent classes match what is in the AgentType enum (and AgentFactory function):
Rcpp::StringVector AvailableAgentTypes(){;
	
	Rcpp::StringVector types = Rcpp::StringVector::create(
    "Agent",
	"SIAgent",
	"GubbinsFarm"
    );
	
	return(types);
}
