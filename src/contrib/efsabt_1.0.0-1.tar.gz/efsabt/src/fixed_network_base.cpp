/*

 network_base.cpp
 This file should not need to be modified

 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.

 */

#include "fixed_network_base.h"

#include "fixed_settings.h"
#include "fixed_logger.h"
#include "fixed_metapop.h"

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>

// Don't include assert directly - this needs to go through settings.h so it can be turned off
//#include <assert.h>

// network ID generator using a static variable:
int Network::s_IDGen = 1;
// To hold the network pointers:
std::vector<Network*> global_NetworkPointers;
// To check if it has been deleted:
std::vector<bool> global_NetworkActive;
// To check if it is being used:
std::vector<int> global_NetworkUsed;


// Constructor
Network::Network(long NumberOfAgents, std::string LogName)
{

	logger = new FileLogger(logDEBUG3, LogName);
	
	// Check the available agent types:
	Rcpp::StringVector types = AvailableAgentTypes();
	LOG(logINFO) << "There are a total of " << types.size() << " agent types available as follows:" << std::endl;
	for(int i=0; i<types.size(); i++){
		LOG(logINFO) << types[i] << ", ";
	}
	LOG(logINFO) << std::endl;
	
	// Check some input parameters (from R):
	stopifnot_msg(NumberOfAgents >= 0 && NumberOfAgents!=1, "Invalid NumberOfAgents (" << NumberOfAgents << ") - this must be 0 or greater than or equal to 2");
	m_agents = NumberOfAgents;
	
	m_MaxDays = 0;
	

	// From here the constructor must succeed:
	
	m_ID = s_IDGen++;
	
	// If this is the first network, set up the vectors:
	if(m_ID==1){
		global_NetworkPointers.resize(0);
		global_NetworkActive.resize(0);
		global_NetworkUsed.resize(0);
		// Remove element 0:
		global_NetworkPointers.push_back(0);
		global_NetworkActive.push_back(false);
		global_NetworkUsed.push_back(0);
	}
	global_NetworkPointers.push_back(this);
	global_NetworkActive.push_back(true);
	global_NetworkUsed.push_back(0);
	
	LOG(logINFO) << "Creating network number " << m_ID << " with " << NumberOfAgents << " agents" << std::endl;
		
}

long Network::GetNumberOfAgents() {
	return(m_agents);
}

bool Network::CheckNumberOfAgents(long InputNumber) {
	// 0 means no limitations
	bool retval;
	if(GetNumberOfAgents()==0){
		retval = true;
	}else{
		retval = (InputNumber == GetNumberOfAgents());
	}
	return(retval);
}

int Network::MaxDays() {
	// 0 means no limitations
	return(m_MaxDays);
}

int Network::GetNetworkID() {
	return(m_ID);
}
Rcpp::StringVector Network::GetBaseClass() {
	Rcpp::StringVector temp("Network");
	return(temp);
}

void Network::TransmissionWrapper(MetaPop* p_MetaPop) {
	
	// In order to be thread-safe, this function and the functions it calls must not make use of member variables
	// Functions are all therefore marked , and metapop etc must be passed explicitly:
	gsl_rng *r = p_MetaPop->GetRNG();
	int TimePoint = p_MetaPop->GetTimePoint();
	
	// The function that actually does the updating:
	Transmission(p_MetaPop, TimePoint, r);
	Removal(p_MetaPop, TimePoint, r);
	Vaccination(p_MetaPop, TimePoint, r);
	
}

void Network::ResetWrapper(MetaPop* p_MetaPop) {
	// In order to be thread-safe, this function and the functions it calls must not make use of member variables - so pass them explicitly:
	gsl_rng *r = p_MetaPop->GetRNG();
	int TimePoint = p_MetaPop->GetTimePoint();
	Reset(p_MetaPop, TimePoint, r);
}


// Functions to be overridden:
void Network::Transmission(MetaPop* p_MetaPop, int TimePoint, gsl_rng* r) {
	// The base class does nothing
}
void Network::Removal(MetaPop* p_MetaPop, int TimePoint, gsl_rng* r) {
	// The base class does nothing
}
void Network::Vaccination(MetaPop* p_MetaPop, int TimePoint, gsl_rng* r) {
	// The base class does nothing
}
void Network::Reset(MetaPop* p_MetaPop, int TimePoint, gsl_rng* r) {
	// The base class does nothing
}


// Destructor
Network :: ~Network(){
	
	// Do this first to check it is OK to delete:
	if(global_NetworkUsed[GetNetworkID()]!=0){
		std::stringstream err_msg;
		err_msg << "Removing network number " << GetNetworkID() << " while it is being used by " << global_NetworkUsed[GetNetworkID()] << " simulation(s).  This will likely cause a segfault.  You should delete all active simulations (and possibly restart your R session).";
		LOG(logERROR) << err_msg.str() << std::endl;
//		Rf_warning(err_msg.str().c_str());
	}

	
	LOG(logINFO) << "Removing network number " << GetNetworkID() << std::endl;

	// Deactivate this network:
	global_NetworkPointers[GetNetworkID()] = 0;
	global_NetworkActive[GetNetworkID()] = false;
	
	delete logger;
	logger=0;
	
}
