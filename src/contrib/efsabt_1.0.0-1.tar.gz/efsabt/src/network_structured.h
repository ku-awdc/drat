/*

 network_structured.h
 The parent class for structured-type (Gubbins/SparseMatrix) networks.  Can not be used directly.
 
 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.
 
 */


#ifndef STRUCTUREDNETWORK_H
#define STRUCTUREDNETWORK_H

#include "fixed_network_base.h"
#include <Rcpp.h>

class StructuredNetwork : public Network
{

protected:
	
	// Stubs for this class but only things that are derived for other kernals:
	virtual bool IsAgentAtRisk(long AgentID, MetaPop* p_MetaPop, int TimePoint, gsl_rng* r);
	// The number of new infection events - can index the destination farm either on AquiringID or RiskIndex - RiskIndex will match GetRiskAgents return
	virtual int GetNewInfectionEvents(long TransmittingID, long AquiringID, long RiskIndex, int InfectiousAgents, int ExistingInfections, MetaPop* p_MetaPop, int TimePoint, gsl_rng* r);
	// A vector of agents that this AgentNumber can transmit to:
	virtual Rcpp::IntegerVector GetRiskAgents(long AgentNumber);
	
	// A vector to point to all agents:
	Rcpp::IntegerVector mv_AllAgents;
			
public:
	// Public constructor, to be called by the user before setting up a simulation.
    StructuredNetwork(long NumberOfAgents, std::string LogName);
	
	// The main functions for this (and derived) classes:
	virtual void Transmission(MetaPop* p_MetaPop, int TimePoint, gsl_rng* r);
	virtual void Removal(MetaPop* p_MetaPop, int TimePoint, gsl_rng* r);
	virtual void Reset(MetaPop* p_MetaPop, int TimePoint, gsl_rng* r);
	
	// Function used within R to check that the number of agents is consistent for the simulation
	long GetNumberOfAgents(){ return(Network::GetNumberOfAgents()); }
	// Function used within R to get the network ID
	int GetNetworkID(){ return(Network::GetNetworkID()); }
	Rcpp::StringVector GetBaseClass(){ return(Network::GetBaseClass()); }
	// Both must be defined like this in all inherited classes to allow exposure in Rcpp module
	// http://lists.r-forge.r-project.org/pipermail/rcpp-devel/2013-October/006517.html
	
	// Function to check the number of agents is consistent - can be overridden:
	bool CheckNumberOfAgents(long InputNumber);
	
	~StructuredNetwork();
	
};

#endif // STRUCTUREDNETWORK_H
