/*
 Simulation class
 The main interface class for the model.
 This file should not need to be modified
 
 This interface class does the majority of the work.  It takes a network (and RNG) 
 created in R and creates a simulation, including a metapopulation of agents/farms 
 around it.  Number of time points to run for and the state of individual
 farms can be controlled through this class as well.

 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.
 
 */


#ifndef SIM_H
#define SIM_H

// Needed for AgentType and DiseaseState
#include "fixed_settings.h"

#include <gsl/gsl_rng.h>
#include <vector>
#include <Rcpp.h>
#include <gsl/gsl_randist.h>

class Network;
class Demography;
class MetaPop;
class Logger;


class Simulation
{
	
private:

	// All of the important objects (network, metapop, agents) are handeled as pointers to dynamic memory.  This is partly to allow the references to be shared
	// between objects when needed, and partly because demography and metapopulation need to be passed to the other objects so they can instantiate.
	
	// Demography is allocated before the simulation is called, and is passed to our constructor:
	Demography *mp_Demography;
	// Networks are allocated before the simulation is called, and is passed to our constructor:
	std::vector<Network*> mv_Networks;
	// MetaPop is allocated by the simulation constructor:
	MetaPop *mp_MetaPop;	
	// Logger is set up by MetaPop but we need a pointer:
	Logger *logger;
	
	// The RNG held by the simulation:
	gsl_rng *r;
	
	// The simulations ID:
    int m_ID;
	// The static variable for IDGen allows each simulation to know its unique ID
    static int s_IDGen;
	
	// The network and demography numbers we are using:
	std::vector<int> mv_NetworkID;
	int m_DemographyID;
	
	// The maximum number of days to run to:
	const int m_MaxDays;
	
	// A vector for calculating cumulative prevalence:
	std::vector<bool> mp_EverInfected;
	std::vector<double> mv_Prevalences;
	std::vector<double> mv_CumulativePrevalences;
	std::vector<bool> mp_EverObserved;
	std::vector<double> mv_ObservedPrevalences;
	std::vector<double> mv_CumulativeObservedPrevalences;
	
	// A matrix for holding all states:
	Rcpp::IntegerMatrix mp_StateMatrix;
	
public:
	// The public constructor
	/* Requires a pointer to a network class to be passed in.  This allows multiple simulations
	 to share the same network file.  Also requires arrays of agent types and states.
	 */
    Simulation(int DemographyNumber, Rcpp::IntegerVector NetworkNumbers, int MaxDays, std::string LogName = "Simulation.txt", long RNGseed = (long) NULL); 
	
	// Run the simulation and return a vector of cumulative prevalence at each time point
	void Update(int NumberOfTimePoints, bool StopIfInactive = false);
	
	// Reset (or initialise the simulation for the first time):
	void Reset();
	
	// Initialise the simulation without resetting parameters:
	void Initialise(bool ResetTime = true);
	
	// Force one specific / all agents to report their state back to the demography:
	void SaveParameters(long AgentNumber = 0);
	
	// Return the number of the specified agent type (and derived types) in the metapopulation (fixed):
	const long GetNumberOfAgents(AgentType UseAgentType = AT_Agent);
	
	// Get the prevalence in the specified agent type (and derived types)
	const double GetPrevalence(int UseAgentType = 1);
	
	// At each time point:
	Rcpp::NumericVector GetCumulativePrevalences();
	Rcpp::NumericVector GetPrevalences();
	Rcpp::NumericVector GetCumulativeObservedPrevalences();
	Rcpp::NumericVector GetObservedPrevalences();
	
	// Get/set all agent states as a vector - state is an integer to allow >1 values (latent etc)
	Rcpp::IntegerVector GetStates();
	
	// Change states of individual agents:
	void Infect(long AgentNumber, int InfectionPressure);
	void Remove(long AgentNumber);
	void Vaccinate(long AgentNumber);

	// Get all agent times of first transition to one or more desired states:
	const Rcpp::IntegerVector GetFirstTime(Rcpp::IntegerVector TargetStates);
	// Get matrix of agent states:
	const Rcpp::IntegerMatrix GetStateMatrix();

	// Get a single agent state:
	const int GetAgentState(long AgentNumber);
	
	const int GetTimePoint();
	
	// Allows us to re-set the RNG:
	void SetRNG(int RNGseed);
	
	// Just used in R to ensure this is the correct class:
	const Rcpp::StringVector GetBaseClass();
	
	//! The destructor
	/*! This destructor ensures memory allocated to agent objects is deallocated before the metapop destructor is called
	 */
	~Simulation();
	
};

#endif
