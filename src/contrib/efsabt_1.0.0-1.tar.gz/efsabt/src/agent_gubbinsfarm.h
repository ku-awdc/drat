/*

 agent_gubbinsfarm.h
 Use this file as an example of a derived agent class

 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.

 */


#ifndef GUBBINSFARM_H
#define GUBBINSFARM_H

#include "fixed_agent_base.h"

class MetaPop;

class GubbinsFarm: public Agent
{
protected:
	
	int m_WeatherStation;  // Currently ignored as demography passes the correct temperature data
	
	int m_SuspicionTimePoint;
	
	int m_SusceptibleCattle;
	std::vector<int> mp_InfectedCattle;
	int m_DeadCattle;
	int m_RecoveredCattle;
	int m_VaccinatedCattle;
	
	int m_SusceptibleSheep;
	std::vector<int> mp_InfectedSheep;
	int m_DeadSheep;
	int m_RecoveredSheep;
	int m_VaccinatedSheep;
	
	int m_SusceptibleVectors;
	std::vector<int> mp_LatentVectors;
	int m_InfectiousVectors;
	
	// Allows us to distinguish between vectors introduced to the farm (not infective) and home-grown vectors available (infective):
	int m_CumulativeInfectiousVectors;
	int m_CumulativeInfectedSheep;
	int m_CumulativeInfectedCattle;
	
	int m_TotalCattle;
	int m_TotalSheep;
	int m_TotalVectors;
	double m_ProbTransVectorHost;
	double m_ProbTransHostVector;
	double m_DurationViraemiaCattle;
	int m_StagesViraemiaCattle;
	double m_MortalityRateCattlePre;
	double m_ClinicalSignsCattlePre;
	double m_MortalityRateCattlePost;
	double m_ClinicalSignsCattlePost;
	double m_DurationViraemiaSheep;
	int m_StagesViraemiaSheep;
	double m_MortalityRateSheepPre;
	double m_ClinicalSignsSheepPre;
	double m_MortalityRateSheepPost;
	double m_ClinicalSignsSheepPost;
	double m_VectorCattleRatio;
	double m_VectorSheepRatio;
	double m_VectorPreference;
	int m_ExtrinsicIncubationStages;
	
	double m_BloodMealFrequencyEffect;
	double m_VaccinationTime;
	double m_VaccineEfficacyCattle;
	double m_VaccineEfficacySheep;
	int m_TimeToVaccineEffectCattle;
	int m_TimeToVaccineEffectSheep;
	
	
	double m_MinVectorMortality;
	
	double m_DeltaTime;
	int m_TimeStepsWithinHour;
		
	// Additional things decided by the class itself and not reported anywhere:
	double m_InfectionRate;
	double m_RecoveryRate;
	
	// Temperature data from demography:
	Rcpp::NumericVector* m_Temperatures;
	
public:
	
    GubbinsFarm(AgentType AT, int InputState, MetaPop *InputMetaPop); 
	
	// It is important for these all to be declared as virtual so that the most derived version is always found:
		
	virtual void Initialise();
	virtual void SetParameters(State InputState, Rcpp::NumericMatrix* FixedParameters, Rcpp::NumericMatrix* VariableParameters, Rcpp::NumericVector* temperatures);
	virtual void Infect(int InfectionForce = 5);
	virtual void Remove();
	virtual void Update();
	virtual const int IsInfectious();
	// We could also redefine IsInfected, IsInfectious, GetFirstInfectionTime
	virtual const bool IsInfected();
	virtual const bool IsInfectable();
	virtual const bool IsObservedInfected();
	
	// New functions required for this class:
	virtual Rcpp::IntegerVector GetCattleNumbers();
	virtual Rcpp::IntegerVector GetSheepNumbers();
	virtual Rcpp::IntegerVector GetVectorNumbers();
	
	const double GetTodaysTemp(int hour);
	
	virtual ~GubbinsFarm();
};

#endif // GUBBINSFARM_H
