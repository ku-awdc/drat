/*
 The Rcpp module definition
 This file provides the interface between R and the C++ networks, demographies and simulations
 When new derived demography and network classes are added they will need to be added to this file
  
 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.
 
 */

#include <Rcpp.h>

#include "fixed_simulation.h"
#include "fixed_settings.h"
#include "fixed_network_base.h"
#include "fixed_demography_base.h"
#include "zzz_helpers.h"

// Need to include all derived Network and Demography classes here:
#include "network_flat.h"
#include "network_gubbins.h"
#include "network_sparsematrix.h"
#include "demography_gubbins.h"

RCPP_MODULE(efsabt_module){
    using namespace Rcpp ;
	
	// New demography classes should be added like this:
    class_<GubbinsDemography>("GubbinsDemography")
		.constructor<NumericMatrix, NumericMatrix, NumericMatrix, IntegerVector, IntegerVector, std::string>()
		.constructor<NumericMatrix, NumericMatrix, NumericMatrix, IntegerVector, IntegerVector>()
		
		// As for the parent class:
		.property("NumberOfAgents", &GubbinsDemography::GetNumberOfAgents, "get the number of agents")
		// As for the parent class:
		.property("DemographyID", &GubbinsDemography::GetDemographyID, "Get the Demography Number")
		// As for the parent class:
		.property("BaseClass", &GubbinsDemography::GetBaseClass, "Get the base class (to ensure this is a type of Demography)")
		// As for the parent class:
		.property("FixedParameters", &GubbinsDemography::GetFixedParameters, &GubbinsDemography::SetFixedParameters, "Get/set the fixed parameters")
		// As for the parent class:
		.property("VariableParameters", &GubbinsDemography::GetVariableParameters, &GubbinsDemography::SetVariableParameters, "Get/set the variable parameters")

		.property("CattleNumbers", &GubbinsDemography::GetCattleNumbers, "Get (call Simulation::SaveParameters first) the total number of cattle on each farm")
		.property("SheepNumbers", &GubbinsDemography::GetSheepNumbers, "Get (call Simulation::SaveParameters first) the total number of sheep on each farm")
		.property("VectorNumbers", &GubbinsDemography::GetVectorNumbers, "Get (call Simulation::SaveParameters first) the total number of vectors on each farm")

		// Used to get info from R:
		.property("InitialisationStates", &GubbinsDemography::GetInitialisationStates, &GubbinsDemography::SetInitialisationStates, "Return/set all of the initialisation farm states")
    ;
	
	// The base demography class can be used with SIAgent:
    class_<Demography>("BasicDemography")
		.constructor<IntegerVector, IntegerVector, std::string>()
		.constructor<IntegerVector, IntegerVector>()
		
		// As for the parent class:
		.property("NumberOfAgents", &Demography::GetNumberOfAgents, "get the number of agents")
		// As for the parent class:
		.property("DemographyID", &Demography::GetDemographyID, "Get the Demography Number")
		// As for the parent class:
		.property("BaseClass", &Demography::GetBaseClass, "Get the base class (to ensure this is a type of Demography)")
		// As for the parent class:
		.property("FixedParameters", &Demography::GetFixedParameters, &Demography::SetFixedParameters, "Get/set the fixed parameters (a stub for the base demography)")
		// As for the parent class:
		.property("VariableParameters", &Demography::GetVariableParameters, &Demography::SetVariableParameters, "Get/set the variable parameters (a stub for the base demography)")
		
		// Used to get info from R:
		.property("InitialisationStates", &Demography::GetInitialisationStates, &Demography::SetInitialisationStates, "Return/set all of the initialisation agent states")
    ;


	// New network classes should be added like this:
    class_<FlatNetwork>("FlatNetwork")
	    // expose the constructors - arguments are transmission prob, removal prob, number of farms, log file name (ignored if not debug)
	    .constructor<double, double, long, std::string>()
	    .constructor<double, double, long>()
			
		// As for the parent class:
		.property("NumberOfAgents", &FlatNetwork::GetNumberOfAgents, "get the number of agents")
		// As for the parent class:
		.property("NetworkID", &FlatNetwork::GetNetworkID, "Get the Network Number")
		// As for the parent class:
		.property("BaseClass", &FlatNetwork::GetBaseClass, "Get the base class (to ensure this is a type of network)")

		// Optional - only used in R:
		.property("TransmissionProb", &FlatNetwork::GetTransmissionProb, &FlatNetwork::SetTransmissionProb, "Get/(re)set the constant between-farm transmission probability")
		.property("RemovalProb", &FlatNetwork::GetRemovalProb, &FlatNetwork::SetRemovalProb, "Get/(re)set the constant infected farm removal probability")
    ;
	

	// New network classes should be added like this:
    class_<GubbinsNetwork>("GubbinsNetwork")
	    .constructor<IntegerVector, NumericVector, NumericVector, long, std::string>()
	    .constructor<IntegerVector, NumericVector, NumericVector, long>()
			
		// As for the parent class:
		.property("NumberOfAgents", &GubbinsNetwork::GetNumberOfAgents, "get the number of agents")
		// As for the parent class:
		.property("NetworkID", &GubbinsNetwork::GetNetworkID, "Get the Network Number")
		// As for the parent class:
		.property("BaseClass", &GubbinsNetwork::GetBaseClass, "Get the base class (to ensure this is a type of network)")

    ;
	
	// New network classes should be added like this:
    class_<SparseMatrixNetwork>("SparseMatrixNetwork")
	    .constructor<DataFrame, NumericVector, double, long, std::string>()
	    .constructor<DataFrame, NumericVector, double, long>()
			
		// As for the parent class:
		.property("NumberOfAgents", &SparseMatrixNetwork::GetNumberOfAgents, "get the number of agents")
		// As for the parent class:
		.property("NetworkID", &SparseMatrixNetwork::GetNetworkID, "Get the Network Number")
		// As for the parent class:
		.property("BaseClass", &SparseMatrixNetwork::GetBaseClass, "Get the base class (to ensure this is a type of network)")

    ;
	
	
	function("GetAvailableAgentTypes", &AvailableAgentTypes, "Helper function so that the available agent types can be queried from R");
	function("GetPossibleStates", &GetPossibleStates, "Helper function so that the available agent states can be queried from R");
	function("CheckAgentTypes", &CheckAgentTypes, "Helper function to check that the enum length matches - used in .onLoad");
	function("GetDebugSetting", &GetDebugSetting, "Helper function so that the debug setting used at compilation can be queried from R");
	function("GetSparseMatrix", &GetSparseMatrix, "Helper function to calculate a sparse matrix based on the Gubbins kernal and transmission probs");
	
	
    class_<Simulation>("Simulation")
		// The logfile name and RNG seed are both optional, but the logfile name must be set if the RNG is:
		.constructor<int, IntegerVector, int>()
		.constructor<int, IntegerVector, int, std::string>()
		.constructor<int, IntegerVector, int, std::string, long>()
		
	  	.method("Reset", &Simulation::Reset, "Reset the simulation")
	  	.method("Initialise", &Simulation::Initialise, "Initialise the simulation")
		.method("Update", &Simulation::Update, "Update the simulation")
	    .method("SaveParameters", &Simulation::SaveParameters, "Save the agent parameters to the demography")
		.method("GetPrevalence", &Simulation::GetPrevalence, "Get the prevalence in the specified agent type")
		.method("GetPrevalences", &Simulation::GetPrevalences, "Get the prevalence at all time points")
		.method("GetCumulativePrevalences", &Simulation::GetCumulativePrevalences, "Get the cumulative prevalence at all time points")
		.method("GetObservedPrevalences", &Simulation::GetObservedPrevalences, "Get the observed prevalence at all time points")
		.method("GetCumulativeObservedPrevalences", &Simulation::GetCumulativeObservedPrevalences, "Get the cumulative observed prevalence at all time points")
		.method("Infect", &Simulation::Infect, "Infect an agent")
		.method("Remove", &Simulation::Remove, "Remove an agent")
  		.method("FirstStateTimes", &Simulation::GetFirstTime, "Get the time that each agent transitioned to one of the input states")
		.method("RNG", &Simulation::SetRNG, "Re-set the RNG seed")

		.property("StateMatrix", &Simulation::GetStateMatrix, "Get the historic state matrix for all agents")
  		.property("CurrentStates", &Simulation::GetStates, "Get the states of all agents")
		.property("TimePoint", &Simulation::GetTimePoint, "Get the iteration number")
		.property("BaseClass", &Simulation::GetBaseClass, "Get the base class (to ensure this is a type of network)")
				
    ;
	

}
