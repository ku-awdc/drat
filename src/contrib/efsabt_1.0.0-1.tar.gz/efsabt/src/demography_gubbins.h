/*

 demography_gubbins.h
 Use this file as an example derived class for demography
 
 A single object of this class is needed for each set of simulations.  The function of this class is to 
 provide a means of passing information between derived agent classes and R.
 
 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.
 
 */


#ifndef DEMOG_GUBBINS_H
#define DEMOG_GUBBINS_H

#include "fixed_demography_base.h"
#include "agent_gubbinsfarm.h"

#include <Rcpp.h>
#include <vector>

class GubbinsDemography : public Demography

{
protected:
	
	Rcpp::NumericMatrix mp_FixedParameters;
	Rcpp::NumericMatrix mp_VariableParameters;

	Rcpp::IntegerVector mp_WeatherStations;
	std::vector<Rcpp::NumericVector> mp_TemperatureData;
	
	Rcpp::IntegerMatrix mp_CattleNumbers;
	Rcpp::IntegerMatrix mp_SheepNumbers;
	Rcpp::IntegerMatrix mp_VectorNumbers;
	
	// This demography needs to have a GubbinsFarm (or derived from):
	GubbinsFarm* GetGubbinsFarmPointer(long AgentNumber, MetaPop* p_MetaPop);
	
public:
	
	// Public constructor, to be called by the user before setting up a simulation.
    GubbinsDemography(Rcpp::NumericMatrix FixedParameters, Rcpp::NumericMatrix VariableParameters, Rcpp::NumericMatrix TemperatureData, Rcpp::IntegerVector AgentStates, Rcpp::IntegerVector AgentTypes, std::string LogName = "GubbinsDemography.txt");
	
	// Function used within R to check that the number of agents is consistent for the simulation
	long GetNumberOfAgents(){ return(Demography::GetNumberOfAgents()); }
	// Function used within R to get the demography ID
	int GetDemographyID(){ return(Demography::GetDemographyID()); }
	Rcpp::StringVector GetBaseClass(){ return(Demography::GetBaseClass()); }
	Rcpp::IntegerVector GetInitialisationStates(){ return(Demography::GetInitialisationStates()); }
	void SetInitialisationStates(Rcpp::IntegerVector States){ return(Demography::SetInitialisationStates(States)); }
	// Both must be defined like this in all inherited classes to allow exposure in Rcpp module
	// http://lists.r-forge.r-project.org/pipermail/rcpp-devel/2013-October/006517.html

	// The over-ridden functions:
	void UpdateAgentParameters(long AgentNumber, long IndexNumber, MetaPop* p_MetaPop);
	void RetrieveAgentParameters(long AgentNumber, long IndexNumber, MetaPop* p_MetaPop);
	void Reset(MetaPop* p_MetaPop);
	
	virtual Rcpp::NumericMatrix GetFixedParameters();
	virtual void SetFixedParameters(Rcpp::NumericMatrix NewFixedParameters);
	virtual Rcpp::NumericMatrix GetVariableParameters();
	virtual void SetVariableParameters(Rcpp::NumericMatrix NewVariableParameters);

	// Function to check the number of agents is consistent - can be overridden:
	bool CheckNumberOfAgents(long InputNumber);
	int MaxDays();
	
	// Can be used from R:
	Rcpp::IntegerMatrix GetCattleNumbers();
	Rcpp::IntegerMatrix GetSheepNumbers();
	Rcpp::IntegerMatrix GetVectorNumbers();
	
	/*
	void SetNumberOfCattle(Rcpp::IntegerVector NumberOfCattle);
	void SetNumberOfSheep(Rcpp::IntegerVector NumberOfSheep);
	*/
	
	// Get all agent states as a vector - state is an integer not the State enum
	const Rcpp::IntegerVector GetStates();
		
	// The destructor
	virtual ~GubbinsDemography();		
};

#endif  // DEMOG_GUBBINS_H
