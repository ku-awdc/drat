/*
 The logger utilities
 This code should not need to be modified
  
 Use the LOG and DLOG macros to log information to file.
 Use the stopifnot() and stopifnot_msg() macros to check an input parameter value.
 Use the assert() and assert_msg() macros for debugging assertions.

 To use the logging macros, first a log class must be set up and assigned as a pointer to a variable (possibly global)
 called 'logger'.  The loglevel threshold can be altered using the SetLevel functions (there are separate levels
 for file and screen for the ScreenAndFile logger).  

 While there are other public functions with these classes which could be used directly, only usage of the
 macros provided allows the logging to be compiled away to nothing when not in debug mode.
 
 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.
 
 */


#ifndef LOGGER_H
#define LOGGER_H


// Defines Rf_error() which we are using as an R-friendly alternative to assert()
#include <Rcpp.h>

// fixed_settings.h contains the NDEBUG, FORCE_DLOG and DEBUGLOG definitons:
#include "fixed_settings.h"

// Other includes needed for the logger class:
#include <iostream>
#include <fstream>
#include <streambuf>
#include <exception>
#include <time.h>

/* The log level enum is used for the logger classes. Each logger object has a loglevel parameter - 
 if the log request is given a lower priority than the loglevel cutoff specified, it won't be printed.  
 Add more log levels for finer control
 */
enum TLogLevel {logHIGHEST, logASSERTERROR, logERROR, logWARNING, logINFO, logDEBUG, logDEBUG1, logDEBUG2, logDEBUG3, logDEBUG4, logLOWEST};


// The following macros implement R-friendly exceptions which don't bypass the relevant destructors
// std::range_error seems to be the only one that doesn't crash the full program...
// Using Rf_error results in a longjmp:  http://lists.r-forge.r-project.org/pipermail/rcpp-devel/2015-March/008501.html
// Using Rcpp::stop() also seems to bypass destructors of e.g. Network when it is eventually removed in R

// A custom stopifnot macro that is compatible with R and present even with NDEBUG - intended for checking input parameters only
#define stopifnot(condition) \
do { \
if (! (condition)) { \
std::stringstream err_msg; \
err_msg << "Check condition failed: " #condition; \
if(DEBUGLOG) LOG(logASSERTERROR) << err_msg.str() << std::endl; \
throw std::range_error(err_msg.str().c_str()); \
} \
} while (false)

// A custom stopifnot macro that allows a different message, is compatible with R and present even with NDEBUG - intended for checking input parameters only
#define stopifnot_msg(condition, message) \
do { \
if (! (condition)) { \
std::stringstream err_msg; \
err_msg << message << std::endl << "  (Check condition failed in function " << __FUNCTION__ << ", file " << __FILE__ \
<< ", line " << __LINE__ << ")"; \
if(DEBUGLOG) LOG(logASSERTERROR) << err_msg.str() << std::endl; \
throw std::range_error(err_msg.str().c_str()); \
} \
} while (false)

// A custom assert macro that is compatible with R, but still compiles to nothing if NDEBUG has been defined (similar to assert)
#ifndef NDEBUG
#   define assert(condition) \
do { \
if (! (condition)) { \
std::stringstream err_msg; \
err_msg << "Assertion failed: " #condition ", function " << __FUNCTION__ << ", file " << __FILE__ \
<< ", line " << __LINE__ << "."; \
if(DEBUGLOG) LOG(logASSERTERROR) << err_msg.str() << std::endl; \
throw std::range_error(err_msg.str().c_str()); \
} \
} while (false)
#else
#   define assert(condition) do { } while (false)
#endif

// A custom assert macro that allows a different message, but still compiles to nothing if NDEBUG has been defined (similar to assert)
#ifndef NDEBUG
#   define assert_msg(condition, message) \
do { \
if (! (condition)) { \
std::stringstream err_msg; \
err_msg << message << std::endl << "  (Assertion failed in function " << __FUNCTION__ << ", file " << __FILE__ \
<< ", line " << __LINE__ << ")"; \
if(DEBUGLOG) LOG(logASSERTERROR) << err_msg.str() << std::endl; \
throw std::range_error(err_msg.str().c_str()); \
} \
} while (false)
#else
#   define assert_msg(condition, message) do { } while (false)
#endif

/* A custom assert helper macro - this only runs the code specified if debugging (ie setup/teardown for assert). 

 It is VERY important (and totally unchecked) that the code has no side effects!  Example usage:
 
 debug(
 
 for(int i=0; i<100; i++){
 
 assert_msg(i<(i+1), "Something is very wrong");
 
 }
 
 );
	
 */
	
#ifndef NDEBUG
#   define debug(code) \
do { \
code \
} while (false)
#else
#   define debug(code) do { } while (false)
#endif


#if FORCE_DLOG
	// LOG() is the macro used to write to log files.  If DEBUGLOG is set to false, it should compile to nothing like assert
	#define LOG(level) if(DEBUGLOG) logger->WriteLog(level) << "Function: " << __FUNCTION__ << ", File: " << __FILE__ << ", Line No: " << __LINE__ << "\n  -:- "
#else
#define LOG(level) if(DEBUGLOG) logger->WriteLog(level)
#endif
/* DLOG() is similar to LOG(), but also logs the file, line and function called from.  To force all LOG() calls to do the 
 same, change the definition of FORCE_DLOG (in settings.h) to true
 */
#define DLOG(level) if(DEBUGLOG) logger->WriteLog(level) << "Function: " << __FUNCTION__ << ", File: " << __FILE__ << ", Line No: " << __LINE__ << "\n -:-  "


class Logger
{
private:
	struct nullstream:
	std::ostream {
		struct nullbuf: std::streambuf {
			int overflow(int c) { return traits_type::not_eof(c); }
		} m_sbuf;
		nullstream(): std::ios(&m_sbuf), std::ostream(&m_sbuf) {}
	};
	
	Logger();
	
protected:
		
	int m_nLevel;

	Logger(int level){
		SetLevel(level);
	}
	
public:
	virtual std::ostream& WriteLog(int level) = 0;
		
	nullstream myns;
	virtual int GetLevel(){
		return(m_nLevel);
	}
	virtual void SetLevel(int level){
		m_nLevel = level;
	}
	virtual void SetScreenLevel(int level){
		
	}
	virtual void SetFileLevel(int level){
		
	}
	
	virtual ~Logger(){
		
	};
};


class FileLogger: public Logger
{
private:
	FileLogger();
	
protected:
	
	std::string m_file;
	
public:
	
	std::ofstream logfile;
	
	std::ostream& WriteLog(int level){
		logfile.flush();
		if(level <= GetLevel()){
			return logfile;
		}else{
			return myns;
		}
	}
	
	FileLogger(int level, std::string file) : Logger(level), m_file(file)
	{
		if(DEBUGLOG){
		    time_t     thetime = time(0);
		    struct tm  timestruct;
		    char       timestring[80];
		    timestruct = *localtime(&thetime);
		    strftime(timestring, sizeof(timestring), "%X on %Y-%m-%d", &timestruct);

			logfile.open(file.c_str());
			logfile << "Opening log file at " << timestring << "\nUsing file path: " << file << std::endl;
		}
	}
	
	~FileLogger(){
		if(DEBUGLOG){
		    time_t     thetime = time(0);
		    struct tm  timestruct;
		    char       timestring[80];
		    timestruct = *localtime(&thetime);
		    strftime(timestring, sizeof(timestring), "%X on %Y-%m-%d", &timestruct);

			logfile << "Closing log file at " << timestring << std::endl;
			logfile.flush();
			logfile.close();
		}
	};
};


#endif  // LOGGER_H
