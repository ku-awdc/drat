/*

 agent_base.cpp
 This file should not need to be modified

 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.

 */

#include "fixed_agent_base.h"

#include "fixed_logger.h"
#include "fixed_network_base.h"
#include "fixed_demography_base.h"
#include "fixed_settings.h"
#include "fixed_metapop.h"

#include <gsl/gsl_randist.h>

// Constructor
Agent::Agent(AgentType AT, int InputState, MetaPop *InputMetaPop)
: m_AgentType(AT), mp_MetaPop(InputMetaPop)
{
	
	// This base constructor will be called FIRST before the derived class constructors
	logger = mp_MetaPop->GetLogger();
	
	LOG(logINFO) << "Setting up the base Agent class" << std::endl;
	
	// Grab pointer to the RNG:
	r = mp_MetaPop->GetRNG();
	
	// Reset all agenttypeid to 0:
	for(int i=0; i<AT_Num; i++){
		m_AgentTypeID[i] = 0;
	}

	// SetupClassPointers is used only in Agent constructor - we know the final type of the agent anyway:
	SetupClassPointers(m_AgentType);
	// This MUST come before AddClassPointer
	
	/*
	AddClassPointer CAN be used in chained constructors if wanted - otherwise the base class will not be treated as a subtype of the intermediate chains
	Not specifying a chained constructor prevents the class being derived from
	Not specifying the 3-argument constructor prevents the class being a final class
	*/
	AddClassPointer(AT_Agent);

	// Initialise them to something just so we know for sure that it has been done:
	m_State = state_s;
	m_FirstInfectedTime = -1;
		
}

void Agent::SetupClassPointers(AgentType NewAgentType){	
	LOG(logINFO) << "Setting up class pointer for " << NewAgentType << std::endl; 	
	mp_MetaPop->SetupClassPointers(NewAgentType, this);
}
void Agent::AddClassPointer(AgentType NewAgentType){
	LOG(logINFO) << "Adding class pointer for " << NewAgentType << std::endl; 	
	m_AgentTypeID[((int) NewAgentType)] = mp_MetaPop->AddAgentType(NewAgentType, this);
	assert(m_AgentTypeID[((int) NewAgentType)]>0);
}



Agent::Agent()
{
	LOG(logERROR) << "The base agent class c'tor with no arguments should never be callable as everything should inheret from it virtually!!!" << std::endl;
	stopifnot_msg(false, "The base agent class c'tor with no arguments should never be callable as everything should inheret from it virtually!!!");
}


const int Agent::GetAgentID(AgentType AT){
	return(m_AgentTypeID[((int) AT)]);
}

const AgentType Agent::GetType (){
	return(m_AgentType);
}
const Rcpp::StringVector Agent::GetBaseClass(){
	Rcpp::StringVector temp("Agent");
	return(temp);
}

const bool Agent::IsInfected(){
	return(m_State == state_e || m_State == state_l || m_State == state_i || m_State == state_cc || m_State == state_cs || m_State == state_csc);
}
const bool Agent::IsObservedInfected(){
	return(false);
}
const int Agent::IsInfectious(){
	return((m_State == state_i || m_State == state_cc || m_State == state_cs || m_State == state_csc) ? 1 : 0);
}
const bool Agent::IsInfectable(){
	return(true);
}
const double Agent::GetAquisitionProb(){
	return((double) m_State == state_s);
}
const double Agent::GetTransmissionProb(){	
	return((double) m_State == state_e || m_State == state_i || m_State == state_cc || m_State == state_cs || m_State == state_csc);
}
const int Agent::GetTimeOfFirstInfection(){
	return(m_FirstInfectedTime);
}

const State Agent::GetState(){
	return(m_State);
}

void Agent::Infect(int InfectionForce){
	m_State = state_i;
	// Only if it hasn't been infected before:
	if(m_FirstInfectedTime == -1){
		m_FirstInfectedTime = GetTimePoint();
	}	
}

void Agent::Remove(){
	// Basic model is an SI model:
	m_State = state_s;	
}

void Agent::Vaccinate(){
	// This is a stub
}

void Agent::SetParameters(int InputState){
	// The initialise function is guaranteed to be called next (by Demography) so this is all we need to do:
	m_State = (State) InputState;
}

// Base function does nothing:
void Agent::Update(){
	
}

const int Agent::GetTimePoint(){
	return(mp_MetaPop->GetTimePoint());
}

void Agent::Initialise(){
	if(IsInfected()){
		m_FirstInfectedTime = GetTimePoint();
	}else{
		m_FirstInfectedTime = -1;
	}
	LOG(logINFO) << "Agent number " << m_AgentTypeID[AT_Agent] << " initialised" << std::endl;
}

Agent::~Agent(){
	// This derives so it needs to be virtual
	LOG(logINFO) << "Removing agent " << GetAgentID() << " (type " << GetType() << " number " << GetAgentID(GetType()) << ")" << std::endl;
}
