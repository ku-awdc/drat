/*

 agent_si.h
 A simple agent with unchanging states

 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.

 */


#ifndef SIAGENT_H
#define SIAGENT_H

#include "fixed_agent_base.h"

class SIAgent: public Agent
{

public:
	
    SIAgent(AgentType AT, int InputState, MetaPop *InputMetaPop); 
	virtual void Initialise();
	virtual void Infect(int InfectionForce);
	virtual void Remove();
	virtual ~SIAgent();
};

#endif  // SIAGENT_H
