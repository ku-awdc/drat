/*

 network_flat.h
 The simplest possible derived class from network_base
 
 Use this code as an example of a derived network class
 
 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.
 
 */


#include "fixed_network_base.h"

class FlatNetwork : public Network
{

protected:
	
	double m_TransmissionProb;
	double m_RemovalProb;
	
public:
	// Public constructor, to be called by the user before setting up a simulation.
    FlatNetwork(double TransmissionProb, double RemovalProb, long NumberOfAgents, std::string LogName = "FlatNetwork.txt");
	
	// The main functions for this (and derived) classes:
	void Transmission(MetaPop* p_MetaPop, int TimePoint, gsl_rng* r);
	void Removal(MetaPop* p_MetaPop, int TimePoint, gsl_rng* r);
	void Reset(MetaPop* p_MetaPop, int TimePoint, gsl_rng* r);
	
	// Function used within R to check that the number of agents is consistent for the simulation
	long GetNumberOfAgents(){ return(Network::GetNumberOfAgents()); }
	// Function used within R to get the network ID
	int GetNetworkID(){ return(Network::GetNetworkID()); }
	Rcpp::StringVector GetBaseClass(){ return(Network::GetBaseClass()); }
	// Both must be defined like this in all inherited classes to allow exposure in Rcpp module
	// http://lists.r-forge.r-project.org/pipermail/rcpp-devel/2013-October/006517.html
	
	// Function to check the number of agents is consistent - can be overridden:
	bool CheckNumberOfAgents(long InputNumber);
	
	
	// Optional - just for completeness:
	void SetTransmissionProb(double TransmissionProb);
	double GetTransmissionProb();

	void SetRemovalProb(double RemovalProb);
	double GetRemovalProb();
	
	~FlatNetwork();
	
};
