/*

 Agent pointer utilities
 This code should not need to be modified
 
 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.
 
 */

#ifndef AGENTPT
#define AGENTPT

#include "fixed_settings.h"
#include "fixed_logger.h"

#include <vector>


class MetaPop;
class Agent;

class AgentPointers {
	friend class MetaPop;
private:
	int m_FirstElement;
	int m_LastElement;
	int m_Number;
	bool m_FinalClassRefs;
	bool m_RegulatorStructs;
	
	Logger* logger;
	
	std::vector<Agent*> * m_vp;
	
	AgentType m_SetupAgentType;
	
	int m_MyAgentID;
	AgentType m_MyAgentType;
	
	
public:
	
	// The public consructor
	/* This is public to allow assignment construction for convinience.  The class is only ever usefully
	 constructed by MetaPop though.
	 */
	AgentPointers();
	
	// Returns a pointer to the specified agent
	/* i is the index of the agent to return a pointer to (index will be the number of the class
	 requested when the AgentPointer object was set up
	 */
	Agent* P(int i);
	
	// Get an Agent ID for the specified index
	int GetAgentID(int i);
	
	// Get the number of agent pointers in this object
	int size();
	
	// Get the pointer to the last agent in this object
	Agent* Last();
	
};


#endif
