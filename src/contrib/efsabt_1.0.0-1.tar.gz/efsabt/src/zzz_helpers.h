/*
 
 Kernal calculator
 This file should not need to be modified
 
 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.
 
 */


#include <Rcpp.h>

Rcpp::DataFrame GetSparseMatrix(Rcpp::NumericVector xLocations, Rcpp::NumericVector yLocations, Rcpp::NumericVector TransmissionProbs, double threshold, double alpha);
