/*

 network_structured.cpp
 The parent class for structured-type (Gubbins/SparseMatrix) networks.  Can not be used directly.

 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.

 */

#include "network_structured.h"

#include <Rcpp.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_math.h>

#include "fixed_settings.h"
#include "fixed_logger.h"
#include "fixed_metapop.h"


// Constructor
StructuredNetwork::StructuredNetwork(long NumberOfAgents, std::string LogName)
	: Network(NumberOfAgents, LogName)
{
	
	// Set up a vector to index all agents:
	Rcpp::IntegerVector temp(NumberOfAgents);
	mv_AllAgents = temp;
	for(long i=0; i<NumberOfAgents; i++){
		mv_AllAgents[i] = i+1;
	}
	
	LOG(logINFO) << "Setting up a StructuredNetwork with " << NumberOfAgents << " agents" << std::endl;
	
}


// This network works with only the number of agents specified initially:
bool StructuredNetwork::CheckNumberOfAgents(long InputNumber){
	return(InputNumber==m_agents);
}


bool StructuredNetwork::IsAgentAtRisk(long AgentID, MetaPop* p_MetaPop, int TimePoint, gsl_rng* r){

	LOG(logERROR) << "Attempt to use the stub class IsAgentAtRisk" << std::endl;
	stopifnot_msg(false, "Attempt to use the stub class IsAgentAtRisk");
	return(false);
}

// Work out how many infection events happen:
int StructuredNetwork::GetNewInfectionEvents(long TransmittingID, long AquiringID, long RiskIndex, int InfectiousAgents, int ExistingInfections, MetaPop* p_MetaPop, int TimePoint, gsl_rng* r){
	LOG(logERROR) << "Attempt to use the stub class GetNewInfectionEvents" << std::endl;
	stopifnot_msg(false, "Attempt to use the stub class GetNewInfectionEvents");
	return(0);
}

Rcpp::IntegerVector StructuredNetwork::GetRiskAgents(long AgentNumber){
	// For the base class the potential contacts are just all agents:
	return(mv_AllAgents);
}

// Functions to be overridden:
void StructuredNetwork::Transmission(MetaPop* p_MetaPop, int TimePoint, gsl_rng* r){
	
	long nfarms = p_MetaPop->GetNumberOfAgents();
	assert(nfarms == m_agents);
	
	// First get how many infectious agents each farm has:
	int infectious_agents[nfarms];
	bool agent_at_risk[nfarms];
	// Store the total number of infectious vectors:
	int total_infections[nfarms];
	
	LOG(logINFO) << "Acquiring infectiousness for " << nfarms << " farms" << std::endl;
	// A vector of indexes for infected farms:
	std::vector<long> infectedindex;
	infectedindex.resize(0);
	long numinf = 0;
	
	for(long i=0; i < nfarms; i++){
		infectious_agents[i] = p_MetaPop->GetAgentPointer(i+1)->IsInfectious();
		// Is this agent infectious?
		if(infectious_agents[i] >= 1){
			numinf++;
			infectedindex.push_back(i+1);
		}
		// Is this agent at risk of being infected?
		agent_at_risk[i] = IsAgentAtRisk(i+1, p_MetaPop, TimePoint, r);
		
		total_infections[i] = 0;
	}
	assert((int) infectedindex.size() == numinf);

	
	// Then loop over all farms if there are any infectious - loop source farms first, then destination:
	for(long ti=0; ti < ((int) infectedindex.size()); ti++){
		
		// Which farm is this?
		long t = infectedindex[ti]-1;
		assert_msg(t>=0 && t<m_agents, "InfectedIndex " << ti << " was " << infectedindex[ti] << " and should be between 1 and " << m_agents);
		
		// Get the potentially infectious contacts from this farm:
		Rcpp::IntegerVector riskagents = GetRiskAgents(t+1);
		
		for(long ai=0; ai < ((int) riskagents.length()); ai++){
			// Which farm is this?
			long a = riskagents[ai]-1;
			assert_msg(a>=0 && a<m_agents, "Riskagents " << ai << " was " << riskagents[ai] << " and should be between 1 and " << m_agents);
		
			// Only go further if this farm is infectable (ignore transmission to self if it happens to be in the vector of risks)
			if(agent_at_risk[a] && t!=a){
				// Work out how many infection events happen:
				total_infections[a] += GetNewInfectionEvents(t+1, a+1, ai, infectious_agents[t], total_infections[a], p_MetaPop, TimePoint, r);
			}
		}	
	}
	
	long num_infectable = 0;
	long num_infected = 0;
	
	for(long a=0; a < nfarms; a++){
		num_infectable += (int) agent_at_risk[a];
		if(total_infections[a] >= 1){
			num_infected++;
			p_MetaPop->GetAgentPointer(a+1)->Infect(total_infections[a]);
			LOG(logINFO) << "Number of infectious agents for farm " << a+1 << " : " << total_infections[a] << std::endl;
		}
	}
	
	LOG(logINFO) << num_infected << " of " << num_infectable << " infectable farms became infected" << std::endl;
	
}


void StructuredNetwork::Removal(MetaPop* p_MetaPop, int TimePoint, gsl_rng* r){
	// No removal for the kernal class
}

void StructuredNetwork::Reset(MetaPop* p_MetaPop, int TimePoint, gsl_rng* r){
	LOG(logINFO) << "Resetting StructuredNetwork" << std::endl;
	// Nothing to do at reset time
}

StructuredNetwork:: ~StructuredNetwork(){
	
	LOG(logINFO) << "Removing StructuredNetwork" << std::endl;
	
}
