/*

 network_flat.cpp
 Use this code as an example of a derived network class

 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.

 */

#include "network_flat.h"

#include <Rcpp.h>
#include <gsl/gsl_randist.h>

#include "fixed_settings.h"
#include "fixed_logger.h"
#include "fixed_metapop.h"


// Constructor
FlatNetwork::FlatNetwork(double TransmissionProb, double RemovalProb, long NumberOfAgents, std::string LogName)
	: Network(NumberOfAgents, LogName)
{
	
	LOG(logINFO) << "Setting up a constant class network with TransmissionProb " << TransmissionProb << " and RemovalProb " << RemovalProb << std::endl;
	SetTransmissionProb(TransmissionProb);
	SetRemovalProb(RemovalProb);
	
}


// Exposed back to the R method for completeness:
void FlatNetwork::SetTransmissionProb(double TransmissionProb){
	
	LOG(logINFO) << "Changing TransmissionProb to " << TransmissionProb << std::endl;
	
	stopifnot_msg(TransmissionProb >= 0.0, "Invalid TransmissionProb (" << TransmissionProb << ") - this must be above 0");
	stopifnot_msg(TransmissionProb <= 1.0, "Invalid TransmissionProb (" << TransmissionProb << ") - this must be below 1");
	
	m_TransmissionProb = TransmissionProb;
	
    debug(
 
		assert(m_TransmissionProb >= 0.0);
		assert(m_TransmissionProb <= 1.0);
 
    );
}
double FlatNetwork::GetTransmissionProb(){
	return(m_TransmissionProb);
}

// Exposed back to the R method for completeness:
void FlatNetwork::SetRemovalProb(double RemovalProb){
	
	LOG(logINFO) << "Changing RemovalProb to " << RemovalProb << std::endl;
	
	stopifnot_msg(RemovalProb >= 0.0, "Invalid RemovalProb (" << RemovalProb << ") - this must be above 0");
	stopifnot_msg(RemovalProb <= 1.0, "Invalid RemovalProb (" << RemovalProb << ") - this must be below 1");
	
	m_RemovalProb = RemovalProb;
	
    debug(
 
		assert(m_RemovalProb >= 0.0);
		assert(m_RemovalProb <= 1.0);
 
    );
}
double FlatNetwork::GetRemovalProb(){
	return(m_RemovalProb);
}


// This network works with any number of agents:
bool FlatNetwork::CheckNumberOfAgents(long InputNumber){
	return(true);
}


// Functions to be overridden:
void FlatNetwork::Transmission(MetaPop* p_MetaPop, int TimePoint, gsl_rng* r){
	
	long nfarms = p_MetaPop->GetNumberOfAgents();

	// The transmission probablility for each farm is just the transmission prob * number of infected farms:
	double infectedfarms = (p_MetaPop->GetPrevalence() * nfarms);
	double transmission = infectedfarms * m_TransmissionProb;
	
	// Sample the number of farms to add infection to from a Binomial distribution:
	long ntoinfect = gsl_ran_binomial(r, transmission, nfarms);
	
	if(ntoinfect > 0){
		LOG(logINFO) << "Infecting " << ntoinfect << " farms" << std::endl;
		// Then sample the farm numbers themselves:
		long farmstoinfect[ntoinfect], allfarms[nfarms];
		for (long i = 0; i < nfarms; i++)
		  {
		    allfarms[i] = i+1;
		  }
		gsl_ran_choose (r, farmstoinfect, ntoinfect, allfarms, nfarms, sizeof (long));
	
		// Then infect the farms with a single infectious vector (represents low infectivity):
		for(long i=0; i<ntoinfect; i++){
			p_MetaPop->GetAgentPointer(farmstoinfect[i])->Infect(1);
		}
	}
}


void FlatNetwork::Removal(MetaPop* p_MetaPop, int TimePoint, gsl_rng* r){
	
	long nfarms = p_MetaPop->GetNumberOfAgents();
	
	// We can work out how many farms to remove:
	long infectedfarms[nfarms];  // we will fill up with farm numbers up to totalinfected
	long totalinfected=0;
	for(long i=1; i<=nfarms; i++){
		if(p_MetaPop->GetAgentPointer(i)->IsInfected()){
			infectedfarms[totalinfected] = i;
			totalinfected++;
		}
	}
	// Sample the number of farms to add remove from a Binomial distribution:
	if(totalinfected > 0){
		long ntoremove = gsl_ran_binomial(r, m_RemovalProb, totalinfected);
		LOG(logINFO) << "Removing " << ntoremove << " infected farms" << std::endl;
	
		if(ntoremove > 0){
			// Then sample the farm numbers themselves:
			long farmstoremove[ntoremove];
			gsl_ran_choose (r, farmstoremove, ntoremove, infectedfarms, totalinfected, sizeof (long));
			// Note that infectedfarms is longer than totalinfected but I think that's OK!
			
			// Then uninfect the farms:
			for(long i=0; i<ntoremove; i++){
				assert(p_MetaPop->GetAgentPointer(farmstoremove[i])->IsInfected());
				p_MetaPop->GetAgentPointer(farmstoremove[i])->Remove();
			}
		}
	}
}

void FlatNetwork::Reset(MetaPop* p_MetaPop, int TimePoint, gsl_rng* r){
	LOG(logINFO) << "Resetting constant network" << std::endl;
	// Nothing to do at reset time
}

FlatNetwork:: ~FlatNetwork(){
	
	LOG(logINFO) << "Removing FlatNetwork" << std::endl;
	
}
