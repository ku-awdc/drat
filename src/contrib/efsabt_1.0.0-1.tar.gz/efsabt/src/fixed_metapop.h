/*
 MetaPop
 The metapopulation class
 This file should not need to be modified
 
 A single object of this class is created for each simulation.  It keeps a record
 of the agents in the system, and stores the pointers to them in a std::vector.  
 These vectors of pointers allow multiple objects of different derived classes to be mixed.  
 There should be no need to modify this code.

 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.
 
*/

#ifndef METAPOP_H
#define METAPOP_H

#include "fixed_settings.h"
#include "fixed_demography_base.h"
#include "fixed_network_base.h"

#include <sstream>
#include <fstream>
#include <iostream>
#include <vector>
#include <gsl/gsl_rng.h>

class Logger;
class Agent;

class MetaPop
{
	// Agent needs to be a friend so it can add to the vector of agent pointers, and simulation needs to be a friend so
	// it can delete the agents (this can't be done by MetaPop as agent can't be fully declared before metapop
	friend class Agent;
	friend class Simulation;

private:
	
	// The arguments passed in the constructor:
	long m_nAgents;
	// Pointer to the Demography class that is passed into the simulation:
	Demography *mp_Demography;
	// Pointer to the logger class object:
	Logger *logger;
	// The ID number - matches the simulation ID number
	int m_ID;
	
	// The RNG - it is shared by the GetRNG function:
	gsl_rng *r;

	// The time point - stored here so that anyone can access it:
	int m_TimePoint;
	
	// Point the metapopulation to itself, just so we can use the LOG() preprocessor macro within this class (don't use it for anything else!)
	MetaPop *mp_MetaPop;
	
	// The numbers of agent that are or derive from each agent class:
	int m_AgentClassNumbers[AT_Num];
	int m_AgentClassNumbersFinalClass[AT_Num];
	
	// These objects and functions are to do with the agent pointers. There is a pair of vectors for each agent type (themselves in
	// a vector), holding pointers to each object with that class membership (including inherited classes).
	std::vector< std::vector<Agent*> > m_AgentPointers;
	std::vector< std::vector<Agent*> > m_AgentPointersFinalClass;
	std::vector< std::vector<bool> > m_AgentClassMemberships;
	
	// Function to update structs (when agents are added these are deleted and re-created automatically):
	void UpdateStructs();
	void DeleteStructs();
	int m_StructsLength;
	
	// Set the time point - used by simulation:
	void SetTimePoint(int Time);
	
	// This function gets all pointers to all agents of (or deriving from) the specified class:
	AgentPointers GetAgentPointers(AgentType AT = AT_Agent);

	// private default constructor - prevents being initialised without struct for demographies
    MetaPop() { } 
	
public:
	
	
	//! Public constructor for the metapop, to be called from simulation.
	//	Each instance of the simulation class creates a single metapop object.  There shouldn't be any need to modify this class. 
	MetaPop(Demography *InputDemography, Logger *InputLogger, int SimulationID, gsl_rng* input_r);
	
	// Get the simulation number
	int GetID();
	
	// Get the current time point:
	int GetTimePoint();
	
	// Get the number of agents in the simulation.
	long GetNumberOfAgents(AgentType AgentClass = AT_Agent);
	
	// Function to return a pointer to the specified agent
	// Indexing can be relative to any agent type, with the first object of each type starting indexing at 0.
	Agent* GetAgentPointer(long ID, AgentType AT = AT_Agent);

	// Get the current between-agent prevalence:
	double GetPrevalence(AgentType AgentClass = AT_Agent);
	
	// Used by the agents to add themselves to the metapopulation:
	int AddAgentType(AgentType AT, Agent* AgentPointer);
	void SetupClassPointers(AgentType AT, Agent* AgentPointer);
			
	// Function to return a pointer to the active logger file
	// Ensures that all objects within this simulation will log to the same file 
	Logger* GetLogger();
	// Return pointers to the demography and RNG used by this MetaPop:
	Demography* GetDemography();
	gsl_rng* GetRNG();
	
	// Public destructor, closes logger file and removes agents
	~ MetaPop();

};

#endif
