/*
 Fixed settings
 There should be no need to modify this file
 All user-modifiable settings are in the settings.h/cpp files
 
 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.
 
 */


#include "fixed_settings.h"
#include <Rcpp.h>

#include "fixed_metapop.h"
#include "fixed_network_base.h"
#include "fixed_logger.h"

#include <gsl/gsl_sf_log.h>
#include <gsl/gsl_sf_exp.h>
#include <gsl/gsl_cdf.h>


// Used in R to query the optimiser setting:
int GetDebugSetting(){
	return((int) DEBUG_MODE);
}


// Used in an R test file as well as in the constructor for simulation:
void CheckAgentTypes(){
	Rcpp::StringVector types = AvailableAgentTypes();

	// Check that the number of agent types matches the enum length:
	// Can't use stopifnot here as there is no logger set up:
	if(types.size() != ((int) AT_Num)){
		std::stringstream err_msg;
		err_msg << "Number of available agent types (" << types.size() << ") does not match enum length (" << ((int) AT_Num) << ")";
		throw std::range_error(err_msg.str().c_str());
	}
	// The enum is defined in settings.h
}


Rcpp::DataFrame GetPossibleStates(){;
	
	Rcpp::StringVector states = Rcpp::StringVector::create(
		"Susceptible",
		"Exposed",
		"Latent",
		"Infective",
		"ClinicalSheep",
		"ClinicalCattle",
		"ClinicalSheep&Cattle",
		"ClinicalSheep&Infective",
		"ClinicalCattle&Infective",
		"ClinicalSheep&Cattle&Infective",
		"Recovered"
	);
	
	Rcpp::StringVector descs = Rcpp::StringVector::create(
		"No infected/latent vectors or hosts",
		"Infected sheep/cattle and/or infective midges brought onto farm",
		"Midges in incubation period",
		"infective midges",
		"Clinical signs in sheep, no infective midges",
		"Clinical signs in cattle, no infective midges",
		"Clinical signs in sheep and cattle, no infective midges",
		"Clinical signs in sheep, with infective midges",
		"Clinical signs in cattle, with infective midges",
		"Clinical signs in sheep and cattle, with infective midges",
		"No infectable sheep or cattle and all midges susceptible"
	);
	
	Rcpp::IntegerVector ints(states.size());
	for(int i=0; i<((int) states.size()); i++){
		ints[i] = i;
	}
	
	if(states.size() != descs.size()){
		std::stringstream err_msg;
		err_msg << "Number of states  (" << states.size() << ") does not match the number of descriptions (" << descs.size() << ")";
		throw std::range_error(err_msg.str().c_str());
	}

	if(states.size() != ((int) n_states)){
		std::stringstream err_msg;
		err_msg << "Number of states (" << states.size() << ") does not match enum length (" << ((int) n_states) << ")";
		throw std::range_error(err_msg.str().c_str());
	}
	
	Rcpp::DataFrame retval = Rcpp::DataFrame::create(Rcpp::Named("State")=states, Rcpp::Named("Description") = descs, Rcpp::Named("Integer")=ints);
	
	return(retval);
}


std::ostream& operator<<(std::ostream &out, AgentType AT)
{
	// This prints the relevant AgentType names:
	Rcpp::StringVector types = AvailableAgentTypes();
	out << types[(int) AT];
	return out;
}

// Utility functions for logit and inv_logit:
double inv_logit(double x){
	return(gsl_cdf_logistic_P(x, 0));
}
double logit(double p){
	return(gsl_cdf_logistic_Q(p, 0));
}
// And alternative log and exp functions from gsl:
double gexp(double x){
	return(gsl_sf_exp(x));
}
double glog(double p){
	return(gsl_sf_log(p));
}

