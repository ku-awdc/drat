/*

 demography_base.cpp
 This file should not need to be modified.  A base class demography can be used by an active simulation.

 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.

 */

#include "fixed_demography_base.h"

#include "fixed_settings.h"
#include "fixed_logger.h"

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <time.h>
#include <Rcpp.h>

// demography ID generator using a static variable:
int Demography::s_IDGen = 1;
// To hold the demography pointers:
std::vector<Demography*> global_DemographyPointers;
// To check if it has been deleted:
std::vector<bool> global_DemographyActive;
// To check if it is being used:
std::vector<int> global_DemographyUsed;

// Constructor
Demography::Demography(Rcpp::IntegerVector AgentStates, Rcpp::IntegerVector AgentTypes, std::string LogName)
  : mp_AgentStates(AgentStates)
{
	logger = new FileLogger(logDEBUG3, LogName);

	// Check the available agent types:
	Rcpp::StringVector types = AvailableAgentTypes();
	LOG(logINFO) << "There are a total of " << types.size() << " agent types available as follows:" << std::endl;
	for(int i=0; i<types.size(); i++){
		LOG(logINFO) << types[i] << ", ";
	}
	LOG(logINFO) << std::endl;
	
	
	m_agents = AgentTypes.size();
	
	// Check some input parameters (from R):
	stopifnot_msg(m_agents > 0, "Invalid NumberOfAgents (" << m_agents << ") - this must be greater than 0");
	stopifnot_msg(m_agents <= 500000, "Cannot use more than half a million agents");
	
	stopifnot_msg(((int) mp_AgentStates.size()) == m_agents, "The length of the vector for agent states provided (" << ((int) mp_AgentStates.size()) << ") does not match the number of agents registered (" << m_agents << ")");
			
	// Convert Rcpp vectors to required format:
	mp_AgentTypes.resize(m_agents);
	int enumsize = (int) AT_Num;
	for(long i=0; i<m_agents; i++){
		// Check the Agent Type is valid first:
		stopifnot_msg(AgentTypes[i] > 0, "Agent Type index must be greater than 1");
		stopifnot_msg(AgentTypes[i] > 1, "Cannpt create an Agent of the base Agent class");
		stopifnot_msg(AgentTypes[i] <= enumsize, "A specified Agent Type index (" << AgentTypes[i] << ") was greater than the number of different Agent Types available (" << enumsize << ")");
		
		// Note that we always -1 to the input Agent Type - start index at 1 in R but 0 in C++
		mp_AgentTypes[i] = (AgentType) (AgentTypes[i]-1);
		
		// The input states are checked by the Agent constructors - just check they match here to check the clone worked:
		assert(AgentStates[i] == mp_AgentStates[i]);

		LOG(logINFO) << "Registering " << mp_AgentTypes[i] << " with a state of " << mp_AgentStates[i] << std::endl;
		
 	}
 
	// Set up the vector for agent states:
	Rcpp::IntegerVector mp_AgentStates(m_agents);
	debug(
		for(long i=0; i<m_agents; i++){
			assert(mp_AgentStates[i] == 0);
		}
	);
	
	// 0 means no limitations:
	m_MaxDays = 0;
	
	
	// From here the constructor must succeed:
	m_ID = s_IDGen++;
	LOG(logINFO) << "Creating demography number " << m_ID << " with " << m_agents << " agents" << std::endl;
	
	// If this is the first demography, set up the vectors:
	if(m_ID==1){
		global_DemographyPointers.resize(0);
		global_DemographyActive.resize(0);
		global_DemographyUsed.resize(0);
		// Remove element 0:
		global_DemographyPointers.push_back(0);
		global_DemographyActive.push_back(false);
		global_DemographyUsed.push_back(0);
	}
	global_DemographyPointers.push_back(this);
	global_DemographyActive.push_back(true);
	global_DemographyUsed.push_back(0);
	
}

Rcpp::NumericMatrix Demography::GetFixedParameters(){
	stopifnot_msg(false, "There are no fixed parameters for the base demography class");
}
void Demography::SetFixedParameters(Rcpp::NumericMatrix NewFixedParameters){
	stopifnot_msg(false, "There are no fixed parameters for the base demography class");
}
Rcpp::NumericMatrix Demography::GetVariableParameters(){
	stopifnot_msg(false, "There are no variable parameters for the base demography class");
}
void Demography::SetVariableParameters(Rcpp::NumericMatrix NewVariableParameters){
	stopifnot_msg(false, "There are no variable parameters for the base demography class");
}

void Demography::UpdateAgentsWrapper(MetaPop* p_MetaPop){

	// The function that actually does the updating:
	for(long i=0; i<p_MetaPop->GetNumberOfAgents(AT_Agent); i++){
		UpdateAgentParameters(i+1, i, p_MetaPop);
	}
}

// Functions to be overridden:
void Demography::UpdateAgentParameters(long AgentNumber, long IndexNumber, MetaPop* p_MetaPop){
	p_MetaPop->GetAgentPointer(AgentNumber)->SetParameters(mp_AgentStates[IndexNumber]);
}

void Demography::RetrieveAgentsWrapper(MetaPop* p_MetaPop, long AgentNumber){

	// Check that indexing matches agent ID:
	assert(p_MetaPop->GetAgentPointer(1)->GetAgentID() == 1);

	// The function that actually does the updating:
	if(AgentNumber==0){
		for(long i=0; i<p_MetaPop->GetNumberOfAgents(AT_Agent); i++){
			RetrieveAgentParameters(i+1, i, p_MetaPop);
		}
	}else{
		RetrieveAgentParameters(AgentNumber, AgentNumber-1, p_MetaPop);
	}
}

void Demography::ResetWrapper(MetaPop* p_MetaPop){
	Reset(p_MetaPop);
}

int Demography::MaxDays(){
	// 0 means no limitations
	return(m_MaxDays);
}

// Functions to be overridden:
void Demography::RetrieveAgentParameters(long AgentNumber, long IndexNumber, MetaPop* p_MetaPop){
	// Base class does nothing
}


void Demography::Reset(MetaPop* p_MetaPop){
	// The base class does nothing
}

std::vector<AgentType> Demography::GetAgentTypes(){
	return(mp_AgentTypes);
}

Rcpp::IntegerVector Demography::GetAgentStates(long AgentNumber){
	stopifnot_msg(AgentNumber >= 0, "The AgentNumber provided (" << AgentNumber << ") must be 1 or above (or 0 to return all agents)");
	stopifnot_msg(AgentNumber <= GetNumberOfAgents(), "The AgentNumber provided (" << AgentNumber << ") is greater than the number of agents available (" << GetNumberOfAgents() << ")");
	
	if(AgentNumber==0){
		return(mp_AgentStates);
	}else{
		Rcpp::IntegerVector retval(1);
		// i-1 as indexing starts at 0 for the mp_AgentStates vector:
		retval[0] = mp_AgentStates[AgentNumber-1];
		return(retval);
	}

	return(mp_AgentStates);
}

Rcpp::IntegerVector Demography::GetInitialisationStates(){
	assert(mp_AgentStates.length() == m_agents);
	return(mp_AgentStates);
}

void Demography::SetInitialisationStates(Rcpp::IntegerVector States){
	stopifnot_msg(States.length() == m_agents, "The length of the vector supplied for the states does not match the number of agents");
	mp_AgentStates = States;
}

int Demography::GetNumberOfAgents(){
	return(m_agents);
}

bool Demography::CheckNumberOfAgents(long InputNumber){
	return(InputNumber == GetNumberOfAgents());
}

int Demography::GetDemographyID(){
	return(m_ID);
}
Rcpp::StringVector Demography::GetBaseClass(){
	Rcpp::StringVector temp("Demography");
	return(temp);
}

// Destructor
Demography :: ~Demography(){
	
	// Do this first to check it is OK to delete:
	if(global_DemographyUsed[GetDemographyID()]!=0){
		std::stringstream err_msg;
		err_msg << "Removing demography number " << GetDemographyID() << " while it is being used by " << global_DemographyUsed[GetDemographyID()] << " simulations.  This could cause a segfault.  You should delete all active simulations (and possibly restart your R session)." << std::endl;
		LOG(logERROR) << err_msg.str() << std::endl;
//		Rf_warning(err_msg.str().c_str());
	}
	
	
	LOG(logINFO) << "Removing demography number " << GetDemographyID() << std::endl;

	// Deactivate this demography:
	global_DemographyPointers[GetDemographyID()] = 0;
	global_DemographyActive[GetDemographyID()] = false;
	
	delete logger;
	logger=0;
	
}
