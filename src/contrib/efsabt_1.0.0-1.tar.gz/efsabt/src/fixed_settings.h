/*
 Fixed settings
 There should be no need to modify this file
 All user-modifiable settings are in the settings.h/cpp files
 
 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.
 
 */


// Includes the agent type definitions:
#include "settings.h"

#include "fixed_agentpointers.h"

#include <iostream>
#include <Rcpp.h>

#ifndef FIXED_SETTINGS_H
#define FIXED_SETTINGS_H

// DEBUG_MODE should be defined by Makevars - but just in case to allow compilation with a warning:
#ifndef DEBUG_MODE
#define DEBUG_MODE 0
#warning The DEBUG_MODE macro was set to 0 (registered as undefined in fixed_settings.h) 
#endif


// Full Optimisation:
#if DEBUG_MODE <= 0
// Set by R CMD SHLIB automatically so no need to do it here:
//#define NDEBUG
#define DEBUGLOG false
#define FORCE_DLOG false
#endif

// First the assert macros only:
#if DEBUG_MODE == 1
// Set by R CMD SHLIB automatically - undefine it:
#undef NDEBUG
#define DEBUGLOG false
#define FORCE_DLOG false
#endif

// Then the assert macros and log file:
#if DEBUG_MODE == 2
// Set by R CMD SHLIB automatically - undefine it:
#undef NDEBUG
#define DEBUGLOG true
#define FORCE_DLOG false
#endif

// Then the assert macros and log file with line numbers:
#if DEBUG_MODE >= 3
// Set by R CMD SHLIB automatically - undefine it:
#undef NDEBUG
#define DEBUGLOG true
#define FORCE_DLOG true
#endif

// Used in R to query the optimiser setting:
int GetDebugSetting();

std::ostream& operator<<(std::ostream &out, AgentType AT);

void CheckAgentTypes();

double logit(double);
double inv_logit(double);

// enum for states:
enum State { state_s, state_e, state_l, state_i, state_cs, state_cc, state_csc, state_cs_i, state_cc_i, state_csc_i, state_r, n_states };
// For descriptions of states, see fixed_settings.cpp

Rcpp::DataFrame GetPossibleStates();

#endif  // FIXED_SETTINGS_H
