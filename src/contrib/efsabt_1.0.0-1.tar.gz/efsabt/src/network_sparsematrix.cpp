/*

 network_sparsematrix.cpp
 Use this code as an example of a derived network class

 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.

 */

#include "network_sparsematrix.h"

#include <Rcpp.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_math.h>
#include <gsl/gsl_pow_int.h>

#include "fixed_settings.h"
#include "fixed_logger.h"
#include "fixed_metapop.h"


// Constructor
SparseMatrixNetwork::SparseMatrixNetwork(Rcpp::DataFrame SparseMatrix, Rcpp::NumericVector AquisitionProbs, double InfectiousAgentProb, long NumberOfAgents, std::string LogName)
	: StructuredNetwork(NumberOfAgents, LogName), mp_AquisitionProbs(AquisitionProbs), m_InfectiousAgentProb(InfectiousAgentProb)
{
	
	LOG(logINFO) << "Setting up a SparseMatrixNetwork with " << NumberOfAgents << " agents" << std::endl;
	
	stopifnot(NumberOfAgents > 0);
	stopifnot(((int) SparseMatrix.size()) == 3);
	
	// Transfer the information from the sparse matrix:
	mv_Sources = SparseMatrix["Source"];
	mv_Destinations = SparseMatrix["Destination"];
	mv_Probabilities = SparseMatrix["Probability"];
	// These ARE protected by Rcpp on the R-side so can't be deleted until this instance is removed
	
	// Our vectors of start and end points:
	mv_StartPoints.resize(NumberOfAgents);
	mv_EndPoints.resize(NumberOfAgents);

	// Build the index start and end points - the first start point is the start of the vector:
	long lastsource = 0;
	mv_StartPoints[0] = 0;

	long source = mv_Sources[0];
	stopifnot_msg(source >= lastsource, "The data frame provided for SparseMatrix must be sorted (in increasing order) on the source farm");
	stopifnot(source >= 1 && source <= NumberOfAgents);
	stopifnot(mv_Destinations[0] >= 1 && mv_Destinations[0] <= NumberOfAgents);
	stopifnot(mv_Probabilities[0] >= 0.0 && mv_Probabilities[0] <= 1.0);
	// If we have skipped some source farms they will have startat and endat -1 (nothing infectable):
	for(long skipped=(lastsource+1); skipped < source; skipped++){
		mv_StartPoints[skipped-1] = -1;
		mv_EndPoints[skipped-1] = -1;		
	}
	lastsource = source;
	
	// Start looping from the second row:
	for(long i=1; i < ((long long) SparseMatrix.nrows()); i++){
		long source = mv_Sources[i];
		stopifnot_msg(source >= lastsource, "The data frame provided for SparseMatrix must be sorted (in increasing order) on the source farm");
		stopifnot(source >= 1 && source <= NumberOfAgents);
		stopifnot(mv_Destinations[i] >= 1 && mv_Destinations[i] <= NumberOfAgents);
		stopifnot(mv_Probabilities[i] >= 0.0 && mv_Probabilities[i] <= 1.0);
		
		// If the source farm changes, update the end and start points:
		if(source > lastsource){
			// If we have skipped some source farms they will have startat and endat -1 (nothing infectable):
			for(long skipped=(lastsource+1); skipped < source; skipped++){
				mv_StartPoints[skipped-1] = -1;
				mv_EndPoints[skipped-1] = -1;
			}
			mv_EndPoints[lastsource-1] = i-1;
			mv_StartPoints[source-1] = i;
		}
		
		lastsource = source;	
	}
	// The last end point is the end of the vector:
	mv_EndPoints[lastsource-1] = (SparseMatrix.nrows()-1);

	// We might have skipped some agents if the last agent is not associated with probabilities:
	for(long skipped=(lastsource+1); skipped<=NumberOfAgents; skipped++){
		assert(skipped > lastsource);
		assert(skipped <= NumberOfAgents);
		assert(lastsource != NumberOfAgents);
		mv_StartPoints[skipped-1] = -1;
		mv_EndPoints[skipped-1] = -1;				
	}
	
	// Now loop back through and check everything:
	debug({
		long totalunused = 0;
		long long last_row_used = -1;
		for(long a=0; a < NumberOfAgents; a++){
			bool agent_used = false;
			assert(mv_StartPoints[a] < ((long long) SparseMatrix.nrows()));
			assert(mv_EndPoints[a] < ((long long) SparseMatrix.nrows()));
			if(mv_StartPoints[a] > -1) for(long i = mv_StartPoints[a]; i <= mv_EndPoints[a]; i++){
				long source = mv_Sources[i];
				assert_msg(source == (a+1), "Expected a source farm of " << a+1 << " but got " << source << " (index is " << i << " from a start/end point of " << mv_StartPoints[a] << "/" << mv_EndPoints[a] << ")");
				agent_used = true;
				assert_msg(i == (last_row_used+1), "Expected the last row used to be " << i-1 << " but got " << last_row_used << " (index is " << i << " from a start/end point of " << mv_StartPoints[a] << "/" << mv_EndPoints[a] << ")");
				last_row_used++;
			}
			if(!agent_used){
				totalunused++;
				assert_msg(mv_StartPoints[a] == -1, "Startpoint for unused agent " << a+1 << " not -1 - range is " << mv_StartPoints[a] << " - " << mv_EndPoints[a]);
				assert_msg(mv_EndPoints[a] == -1, "Endpoint for unused agent " << a+1 << " not -1 - range is " << mv_StartPoints[a] << " - " << mv_EndPoints[a]);
			}else{
				assert_msg(mv_StartPoints[a] > -1, "Startpoint for unused agent " << a+1 << " not >=0 - range is " << mv_StartPoints[a] << " - " << mv_EndPoints[a]);
				assert_msg(mv_EndPoints[a] > -1, "Endpoint for unused agent " << a+1 << " not >=0 - range is " << mv_StartPoints[a] << " - " << mv_EndPoints[a]);
			}
		}
		assert(((long long) SparseMatrix.nrows()) == (last_row_used+1));
		LOG(logINFO) << "A total of " << totalunused << " agents did not have a destination connection" << std::endl;
	});
	
	stopifnot_msg(m_InfectiousAgentProb >= 0 && m_InfectiousAgentProb <= 1, "The infectious agent probability must be between 0-1");
	
}

Rcpp::IntegerVector SparseMatrixNetwork::GetRiskAgents(long AgentNumber){
	
	long startpoint = mv_StartPoints[AgentNumber-1];
	long endpoint = mv_EndPoints[AgentNumber-1];

	// It's possible this agent has no risks:
	if(startpoint == -1){		
		assert(endpoint == -1);
		Rcpp::IntegerVector retvalzero;
		return(retvalzero);
	}
	
	long length = (endpoint-startpoint)+1;
	Rcpp::IntegerVector retval(length);

	for(long i=0; i<length; i++){
		retval[i] = startpoint+i;
	}
	
	return(mv_Destinations[retval]);
	
}

bool SparseMatrixNetwork::IsAgentAtRisk(long AgentID, MetaPop* p_MetaPop, int TimePoint, gsl_rng* r){
	// If the farm is infectable, test if the farm aquires infection (copied from Gubbins):
	bool atrisk = p_MetaPop->GetAgentPointer(AgentID)->IsInfectable() && gsl_ran_bernoulli(r, mp_AquisitionProbs[AgentID-1]);
	return(atrisk);
}

// Work out how many infection events happen:
int SparseMatrixNetwork::GetNewInfectionEvents(long TransmittingID, long AquiringID, long RiskIndex, int InfectiousAgents, int ExistingInfections, MetaPop* p_MetaPop, int TimePoint, gsl_rng* r){
	
	assert(RiskIndex >= 0 && RiskIndex < ((long) mv_Probabilities.length()));
	
	// The relevant risk index is mv_StartPoints[TransmittingID-1] + RiskIndex:
	long usingindex = mv_StartPoints[TransmittingID-1] + RiskIndex;
	
	assert_msg(mv_StartPoints[TransmittingID-1] <= usingindex && mv_EndPoints[TransmittingID-1] >= usingindex, "Got a usingindex of " << usingindex << " for agent " << TransmittingID << " to " << AquiringID << " (RiskIndex " << RiskIndex << ") with a start:end range of " << mv_StartPoints[TransmittingID-1] << " - " << mv_EndPoints[TransmittingID-1]);
	
	assert(mv_Sources[usingindex] == TransmittingID);
	assert(mv_Destinations[usingindex] == AquiringID);
	
	// The stored connection weight:
	double weight = mv_Probabilities[usingindex];
	
	// First see if any infectious agents make it over (i.e. a 'packet' of infectious agents is possible):
	bool anyinfections = (bool) gsl_ran_bernoulli(r, weight);
	
	int newinfections = 0;
	// Then the proportion of available infectious agents with a minimum of 1:
	if(anyinfections){
		newinfections = gsl_ran_binomial(r, m_InfectiousAgentProb, InfectiousAgents);
		newinfections = std::max(newinfections, 1);
	}
	return(newinfections);
}


SparseMatrixNetwork:: ~SparseMatrixNetwork(){
	
//	m_kno.close();
	LOG(logINFO) << "Removing SparseMatrixNetwork" << std::endl;
	
}
