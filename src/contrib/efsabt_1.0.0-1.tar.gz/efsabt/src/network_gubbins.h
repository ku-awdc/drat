/*

 network_gubbins.h
 The Gaussian network used by Szmaragd et al

 Use this code as an example of a derived network class
 
 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.
 
 */


#include "fixed_network_base.h"
#include "network_structured.h"

class GubbinsNetwork : public StructuredNetwork
{

protected:
	
	// A pre-calculated vector of vectors of distance kernals:
	// std::vector< std::vector<double> > mp_Kernals;
	
	// The kernal function:
	double Kernal(long source_farm, long destination_farm);
	
	// Overwritten functions:
	virtual bool IsAgentAtRisk(long AgentID, MetaPop* p_MetaPop, int TimePoint, gsl_rng* r);
	virtual int GetNewInfectionEvents(long TransmittingID, long AquiringID, long RiskIndex, int InfectiousAgents, int ExistingInfections, MetaPop* p_MetaPop, int TimePoint, gsl_rng* r);
	
	Rcpp::NumericVector mp_xlocations;
	Rcpp::NumericVector mp_ylocations;
	
	// Pre-calculated vectors of aquisition and transmission risks:
	Rcpp::NumericVector mp_TransmissionProbs;
	Rcpp::NumericVector mp_AquisitionProbs;
	
	
public:
	// Public constructor, to be called by the user before setting up a simulation.
    GubbinsNetwork(Rcpp::IntegerVector FarmTypes, Rcpp::NumericVector xlocations, Rcpp::NumericVector ylocations, long NumberOfAgents, std::string LogName = "GubbinsNetwork.txt");
	
	// Function used within R to check that the number of agents is consistent for the simulation
	long GetNumberOfAgents(){ return(Network::GetNumberOfAgents()); }
	// Function used within R to get the network ID
	int GetNetworkID(){ return(Network::GetNetworkID()); }
	Rcpp::StringVector GetBaseClass(){ return(Network::GetBaseClass()); }
	// Both must be defined like this in all inherited classes to allow exposure in Rcpp module
	// http://lists.r-forge.r-project.org/pipermail/rcpp-devel/2013-October/006517.html
	
	~GubbinsNetwork();
	
};
