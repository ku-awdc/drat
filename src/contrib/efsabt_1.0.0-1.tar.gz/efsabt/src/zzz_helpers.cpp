/*
 
 Kernal calculator
 This file should not need to be modified
 
 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.
 
 */

#include "zzz_helpers.h"
#include "fixed_settings.h"
#include "fixed_logger.h"
#include <Rcpp.h>
#include <gsl/gsl_pow_int.h>

Rcpp::DataFrame GetSparseMatrix(Rcpp::NumericVector xLocations, Rcpp::NumericVector yLocations, Rcpp::NumericVector TransmissionProbs, double threshold, double alpha){
	
	long nfarms = xLocations.length();
	if(xLocations.length() != yLocations.length()){
		std::stringstream err_msg;
		err_msg << "Length of xLocations and yLocations doesn't match";
		throw std::range_error(err_msg.str().c_str());
	}
	if(nfarms != ((int) TransmissionProbs.length())){
		std::stringstream err_msg;
		err_msg << "Length of TransmissionProbs doesn't match the number of farms";
		throw std::range_error(err_msg.str().c_str());		
	}
	if(threshold < 0){
		std::stringstream err_msg;
		err_msg << "The threshold must be > 0";
		throw std::range_error(err_msg.str().c_str());		
	}
	
	// kernal par is 0.0341 in fortran code
	// double alpha = 0.0341;
	
	// Do a first pass to figure out the dimensions:
	unsigned long long numrows = 0;
	unsigned long long checkindex = 0;

	for(long t=0; t<nfarms; t++){
		for(long a=0; a<nfarms; a++){
			double dx = std::abs(xLocations[t] - xLocations[a]);
			double dy = std::abs(yLocations[t] - yLocations[a]);
			double distance2 = gsl_pow_2(dx) + gsl_pow_2(dy);
	
			double kernal = TransmissionProbs[t] * (alpha / sqrt(3.14159)) * std::exp(-(gsl_pow_2(alpha) * distance2));
			
			// Don't include transmission from farm to self:
			if(kernal >= threshold && t!=a){
				numrows++;
				
				debug({
					// Check that the int doesn't go back to 0:
					checkindex++;
					if(checkindex < numrows){
						std::stringstream err_msg;
						err_msg << "The unsigned long long number of rows maxed out after " << numrows << " - you need to reduce the threshold parameter";
						throw std::range_error(err_msg.str().c_str());								
					}
				});
			}
		}
	}
  // To silence unused variable warning:
  checkindex++;
	
	// The SparseMatrix must be equal to or less than 2147483647 (2^31 -1) rows to keep within long int limits
	if(numrows > 2147483647){
		std::stringstream err_msg;
		err_msg << "Attempting to create a SparseMatrix with " << numrows << " rows, which is " << (numrows-2147483647) << " greater than the limit of 2147483647 - you need to reduce the threshold parameter";
		throw std::range_error(err_msg.str().c_str());
	}
	// Give a warning about high memory usage for greater than around 1600000000 rows (max for UK farms should be 1523156189 with threshold 10^-6)
	
	
	{
	std::stringstream out_msg;
	out_msg << "Building a sparse matrix with " << numrows << " rows" << std::endl;
	Rprintf(out_msg.str().c_str());
	}
	
	Rcpp::IntegerVector source(numrows);
	Rcpp::IntegerVector dest(numrows);
	Rcpp::NumericVector probs(numrows);

	debug({
		// Check the dimensions:
		if((unsigned long long) source.length() != numrows){
			std::stringstream err_msg;
			err_msg << "The sparse matrix was created with " << source.length() << " rows instead of the requested " << numrows;
			throw std::range_error(err_msg.str().c_str());								
		}
	});
	
	{
	std::stringstream out_msg;
	out_msg << "Populating the matrix" << std::endl;
//	Rprintf(out_msg.str().c_str());
	}
	
	// And another pass to save the results:
	unsigned long long rowindex = 0;
	for(long t=0; t<nfarms; t++){
		for(long a=0; a<nfarms; a++){
			double dx = std::abs(xLocations[t] - xLocations[a]);
			double dy = std::abs(yLocations[t] - yLocations[a]);
			double distance2 = gsl_pow_2(dx) + gsl_pow_2(dy);
	
			double kernal = TransmissionProbs[t] * (alpha / sqrt(3.14159)) * std::exp(-(gsl_pow_2(alpha) * distance2));
			
			// Don't include transmission from farm to self:
			if(kernal >= threshold && t!=a){
				
				debug({
					if(rowindex >= numrows){
						std::stringstream err_msg;
						err_msg << "Non-consistent determination of threshold - expected " << numrows << " and got up to " << rowindex;
						throw std::range_error(err_msg.str().c_str());								
					}
					
					if(kernal <0 || kernal > 1){
						std::stringstream err_msg;
						err_msg << "Kernal is " << kernal << " for transmission from farm " << t+1 << " to farm " << a+1;
						throw std::range_error(err_msg.str().c_str());
					}
				});
				
				source[rowindex] = t+1;
				dest[rowindex] = a+1;
				probs[rowindex] = kernal;	
				rowindex++;
			}
		}
	}
	
	{
	std::stringstream out_msg;
	out_msg << "Checking matrix" << std::endl;
//	Rprintf(out_msg.str().c_str());
	}

	if(rowindex != numrows){
		std::stringstream err_msg;
		err_msg << "Non-consistent determination of threshold - expected " << numrows << " and got " << rowindex;
		throw std::range_error(err_msg.str().c_str());								
	}
	
	Rcpp::DataFrame dfout = Rcpp::DataFrame::create(Rcpp::Named("Source")=source, Rcpp::Named("Destination")=dest, Rcpp::Named("Probability")=probs);

	{
	std::stringstream out_msg;
	out_msg << "Returning a matrix with " << dfout.size() << " columns and " << dfout.nrows() << " rows" << std::endl;
//	Rprintf(out_msg.str().c_str());
	}
	
	return(dfout);
}
