/*
 Customisable settings
 When agents are added they will need to be added to this file
  
 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.
 
 */


#ifndef SETTINGS_H
#define SETTINGS_H

#include <iostream>
#include <Rcpp.h>


// Allow over-riding of the DEBUG_MODE set by Makevars.(w)in
// But it is better to use the EFSA_BT_DEBUG_MODE variable that can be set from the command line!
/*
 	#undef DEBUG_MODE
	#define DEBUG_MODE 2
	#warning Over-riding system setting of DEBUG_MODE in settings.h
*/
/*
	The options for debugging are:
	0  -  Optimised
	1  -  Assert macros only
	2  -  Assert macros and log files
	3  -  Assert macros and log files with line numbers
*/

/* The AgentType enum contains all the Agent types, and is used quite a bit in different places of the general
 code.  To add a derived agent class, the class needs to be added to this enum, the AvailableAgentTypes function and the AgentFactory function.
*/
// This must ALWAYS start with AT_Agent and end with AT_Num
enum AgentType{ AT_Agent, AT_SIAgent, AT_GubbinsFarm, AT_Num };

// The rest of this file does not need to be modified - but you need to modify the two functions in settings.cpp to match the enum above


// Forward declaration of necessary base classes:
class Agent;
class Demography;
class Network;
class MetaPop;

// Modify these two functions in settings.cpp:
Rcpp::StringVector AvailableAgentTypes();
void AddAgent(AgentType Type, int InputState, MetaPop *InputMetaPop);

#endif  // SETTINGS_H
