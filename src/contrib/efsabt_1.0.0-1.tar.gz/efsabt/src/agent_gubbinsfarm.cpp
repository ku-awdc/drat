/*

 agent_gubbinsfarm.cpp
 Use this file as an example of a derived agent class

 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.

 */

#include "agent_gubbinsfarm.h"

#include "fixed_logger.h"
#include "fixed_metapop.h"
#include "fixed_network_base.h"
#include "fixed_demography_base.h"

#include <gsl/gsl_randist.h>
#include <gsl/gsl_pow_int.h>


// Constructors
GubbinsFarm::GubbinsFarm(AgentType AT, int InputState, MetaPop *InputMetaPop)
	: Agent(AT, InputState, InputMetaPop)
{
	AddClassPointer(AT_GubbinsFarm);	
}

void GubbinsFarm::SetParameters(State InputState, Rcpp::NumericMatrix* FixedParameters, Rcpp::NumericMatrix* VariableParameters, Rcpp::NumericVector* temperatures){
	
	LOG(logINFO) << "Setting parameters for GubbinsFarm number " << GetAgentID() << std::endl;
	
	m_State = InputState;
	
	debug(
		int numfixed = 13;
		int numvariable = 17;	
		assert((*FixedParameters).ncol() == numfixed);
		assert((*VariableParameters).ncol() == 2);
		assert((*VariableParameters).nrow() == numvariable);
	);
	
	assert(GetAgentID() >= 1 && GetAgentID() <= (*FixedParameters).nrow());
	
	LOG(logINFO) << "Setting fixed parameters" << std::endl;
	
	// The fixed parameters:
	int fpi = 0;
	m_WeatherStation = 	lround((*FixedParameters)(GetAgentID()-1,fpi));
	fpi++;
	m_TotalCattle = lround((*FixedParameters)(GetAgentID()-1,fpi));
	fpi++;
	m_TotalSheep = lround((*FixedParameters)(GetAgentID()-1,fpi));
	fpi++;
	double min_vector_ratio = (*FixedParameters)(GetAgentID()-1,fpi);
	fpi++;
	double max_vector_ratio = (*FixedParameters)(GetAgentID()-1,fpi);
	fpi++;
	m_SuspicionTimePoint = lround((*FixedParameters)(GetAgentID()-1,fpi));
	fpi++;
	m_StagesViraemiaCattle = lround((*FixedParameters)(GetAgentID()-1,fpi));
	fpi++;
	m_StagesViraemiaSheep = lround((*FixedParameters)(GetAgentID()-1,fpi));
	fpi++;
	m_DurationViraemiaCattle = 1.0 / (*FixedParameters)(GetAgentID()-1,fpi);
	fpi++;
	m_DurationViraemiaSheep = 1.0 / (*FixedParameters)(GetAgentID()-1,fpi);
	fpi++;
	m_BloodMealFrequencyEffect = (*FixedParameters)(GetAgentID()-1,fpi);
	fpi++;
	m_VaccinationTime = lround((*FixedParameters)(GetAgentID()-1,fpi));
	fpi++;
	m_TimeStepsWithinHour = lround((*FixedParameters)(GetAgentID()-1,fpi));
	fpi++;
	
	assert(m_StagesViraemiaCattle > 0);
	assert(m_StagesViraemiaSheep > 0);
	assert(m_TimeStepsWithinHour > 0);
	assert(m_DurationViraemiaCattle > 0);
	assert(m_DurationViraemiaSheep > 0);
	assert(m_BloodMealFrequencyEffect > 0);
	
	// These should be checked by Demography so only assert rather than stopifnot here:
	assert(m_TotalCattle >= 0);
	assert(m_TotalSheep >= 0);
	assert(m_TotalSheep+m_TotalCattle >= 1);
	
	assert(temperatures->length()>=24);
	m_Temperatures = temperatures;	
	

	LOG(logINFO) << "Setting variable parameters " << std::endl;
	
	// Some parameters that are chosen randomly by the class at setparameter (not initialise) time:
	// The ranges for variable parameters are used in the functions below:
	
	int vpi = 0;
	assert((*VariableParameters)(0,0) >= 0.0 && (*VariableParameters)(0,1) <= 1.0);
	m_ProbTransVectorHost = gsl_ran_flat(r, (*VariableParameters)(0,0), (*VariableParameters)(0,1));		// Gubbins model:  B
	vpi++;
	
	assert((*VariableParameters)(1,0) >= 0.0 && (*VariableParameters)(1,1) <= 1.0);
	m_ProbTransHostVector = gsl_ran_flat(r, (*VariableParameters)(1,0), (*VariableParameters)(1,1));	// Gubbins model:  Beta
	vpi++;
	
	assert((*VariableParameters)(vpi,0) >= 0.0 && (*VariableParameters)(vpi,1) <= 1.0);
	m_MinVectorMortality = gsl_ran_flat(r, (*VariableParameters)(vpi,0), (*VariableParameters)(vpi,1));
	vpi++;
	
	// Mortality rates and clinical signs are pre- and post- a given time point (fixed parameter)
	assert((*VariableParameters)(vpi,0) >= 0.0 && (*VariableParameters)(vpi,1) <= 1.0);
	m_MortalityRateCattlePre = gsl_ran_flat(r, (*VariableParameters)(vpi,0), (*VariableParameters)(vpi,1));	// Gubbins model:  dC	!between 0-0.18%
	vpi++;

	assert((*VariableParameters)(vpi,0) >= 0.0 && (*VariableParameters)(vpi,1) <= 1.0);
	m_ClinicalSignsCattlePre = gsl_ran_flat(r, (*VariableParameters)(vpi,0), (*VariableParameters)(vpi,1));
	vpi++;
	
	assert((*VariableParameters)(vpi,0) >= 0.0 && (*VariableParameters)(vpi,1) <= 1.0);						
	m_MortalityRateSheepPre = gsl_ran_flat(r, (*VariableParameters)(vpi,0), (*VariableParameters)(vpi,1));		// Gubbins model:  dS
	vpi++;

	assert((*VariableParameters)(vpi,0) >= 0.0 && (*VariableParameters)(vpi,1) <= 1.0);						
	m_ClinicalSignsSheepPre = gsl_ran_flat(r, (*VariableParameters)(vpi,0), (*VariableParameters)(vpi,1));
	vpi++;

	assert((*VariableParameters)(vpi,0) >= 0.0 && (*VariableParameters)(vpi,1) <= 1.0);
	m_MortalityRateCattlePost = gsl_ran_flat(r, (*VariableParameters)(vpi,0), (*VariableParameters)(vpi,1));	// Gubbins model:  dC	!between 0-0.18%
	vpi++;

	assert((*VariableParameters)(vpi,0) >= 0.0 && (*VariableParameters)(vpi,1) <= 1.0);
	m_ClinicalSignsCattlePost = gsl_ran_flat(r, (*VariableParameters)(vpi,0), (*VariableParameters)(vpi,1));
	vpi++;
	
	assert((*VariableParameters)(vpi,0) >= 0.0 && (*VariableParameters)(vpi,1) <= 1.0);						
	m_MortalityRateSheepPost = gsl_ran_flat(r, (*VariableParameters)(vpi,0), (*VariableParameters)(vpi,1));		// Gubbins model:  dS
	vpi++;

	assert((*VariableParameters)(vpi,0) >= 0.0 && (*VariableParameters)(vpi,1) <= 1.0);						
	m_ClinicalSignsSheepPost = gsl_ran_flat(r, (*VariableParameters)(vpi,0), (*VariableParameters)(vpi,1));
	vpi++;

	assert((*VariableParameters)(vpi,0) >= 0.0 && (*VariableParameters)(vpi,1) <= 1.0);						
	double vectorpreference = gsl_ran_flat(r, (*VariableParameters)(vpi,0), (*VariableParameters)(vpi,1));	
	vpi++;
	
	{
		int minrange = lround((*VariableParameters)(vpi,0));
		int maxrange = lround((*VariableParameters)(vpi,1));
		if(minrange == maxrange){
			m_ExtrinsicIncubationStages = minrange;
		}else{
			m_ExtrinsicIncubationStages = gsl_rng_uniform_int(r, (maxrange - minrange - 1)) + minrange;		// Gubbins model:  K  
		}
	}
	assert(m_ExtrinsicIncubationStages >= 2);				// Range 2-100 - Gubbins model is 1-100 but this makes life hard
	vpi++;
	
	assert((*VariableParameters)(vpi,0) >= 0.0 && (*VariableParameters)(vpi,1) <= 1.0);						
	m_VaccineEfficacyCattle = gsl_ran_flat(r, (*VariableParameters)(vpi,0), (*VariableParameters)(vpi,1));	
	vpi++;

	assert((*VariableParameters)(vpi,0) >= 0.0 && (*VariableParameters)(vpi,1) <= 1.0);						
	m_VaccineEfficacySheep = gsl_ran_flat(r, (*VariableParameters)(vpi,0), (*VariableParameters)(vpi,1));	
	vpi++;
	
	{
		int minrange = lround((*VariableParameters)(vpi,0));
		int maxrange = lround((*VariableParameters)(vpi,1));
		
		if(minrange == maxrange){
			m_TimeToVaccineEffectCattle = minrange;
		}else{
			m_TimeToVaccineEffectCattle = gsl_rng_uniform_int(r, (maxrange - minrange - 1)) + minrange;
		}
	}
	assert(m_TimeToVaccineEffectCattle >= 0);
	vpi++;

	{
		int minrange = lround((*VariableParameters)(vpi,0));
		int maxrange = lround((*VariableParameters)(vpi,1));
		if(minrange == maxrange){
			m_TimeToVaccineEffectSheep = minrange;
		}else{
			m_TimeToVaccineEffectSheep = gsl_rng_uniform_int(r, (maxrange - minrange - 1)) + minrange;
		}
	}
	assert(m_TimeToVaccineEffectSheep >= 0);
	vpi++;

	// End of parameters read in

	// Vector host ratio is variable but from fixed parameters:
	double vector_host_ratio = gsl_ran_flat(r, min_vector_ratio, max_vector_ratio);
	
	
	m_DeltaTime = 1.0/(24.0 * (double) m_TimeStepsWithinHour);
	
	/*
	// This is how it is coded in Fortran:
		double vectorhostratio = gsl_ran_flat(r, 0.0, 5000.0);	// Gubbins model:  m
		
	// Calculate vectors here:
	if(m_TotalCattle > 0 && m_TotalSheep > 0){
		m_VectorCattleRatio = vectorhostratio;
		m_VectorSheepRatio = vectorhostratio * ((double) m_TotalCattle / (double) m_TotalSheep);
	
		m_VectorPreference = (double) m_TotalCattle / ((double) m_TotalCattle + vectorpreference * (double) m_TotalSheep);  // Gubbins model:  Phi
	
		// Gubbins model has a mistake for cattle+sheep farms?? - vectors are only based on cattle numbers
		// m_TotalVectors = (int) m_VectorCattleRatio * (double) m_TotalCattle;
		// Should be?:
		m_TotalVectors = (int) round(m_VectorCattleRatio * (double) m_TotalCattle + m_VectorSheepRatio * (double) m_TotalSheep);
	}else if(m_TotalCattle > 0){
		m_VectorCattleRatio = vectorhostratio;
		m_VectorSheepRatio = 0.0;
		m_VectorPreference = 1.0;
		m_TotalVectors = (int) m_VectorCattleRatio * (double) m_TotalCattle;
	}else if(m_TotalSheep > 0){
		m_VectorCattleRatio = 0.0;
		m_VectorSheepRatio = vectorhostratio;
		m_VectorPreference = 0.0;
		m_TotalVectors = (int) m_VectorSheepRatio * (double) m_TotalSheep;
	}else{
		stopifnot_msg(false, "Sheep+Cattle == 0");
	}
	m_TotalVectors = std::max(m_TotalVectors, 1);
	*/

	if(m_TotalCattle > 0 && m_TotalSheep > 0){
		
		m_VectorCattleRatio = vector_host_ratio;
		m_VectorSheepRatio = vector_host_ratio;// * ((double) m_TotalCattle / (double) m_TotalSheep);
		m_VectorPreference = (double) m_TotalCattle / ((double) m_TotalCattle + vectorpreference * (double) m_TotalSheep);  // Gubbins model:  Phi
		m_TotalVectors = lround(m_VectorCattleRatio * (double) m_TotalCattle + m_VectorSheepRatio * (double) m_TotalSheep);
	
	}else if(m_TotalCattle > 0){
		m_VectorCattleRatio = vector_host_ratio;
		m_VectorSheepRatio = 0.0;
		m_VectorPreference = 1.0;
		m_TotalVectors = (int) (m_VectorCattleRatio * (double) m_TotalCattle);			
	}else if(m_TotalSheep > 0){
		m_VectorCattleRatio = 0.0;
		m_VectorSheepRatio = vector_host_ratio;
		m_VectorPreference = 0.0;
		m_TotalVectors = (int) (m_VectorSheepRatio * (double) m_TotalSheep);			
	}else{
		stopifnot_msg(false, "Sheep+Cattle == 0");
	}
	m_TotalVectors = std::max(1, m_TotalVectors);  // Need a minimum of 1 vector otherwise get div 0 errors
	assert(m_TotalVectors > 0);
		
	LOG(logINFO) << "Finished setting parameters for gubbins farm number " << m_AgentTypeID[AT_GubbinsFarm] << " - first of " << m_Temperatures->size() << " temps is " << (*m_Temperatures)[0] << std::endl;
	
	assert(m_StagesViraemiaCattle >= 2);
	assert(m_StagesViraemiaSheep >= 2);
	assert(m_ExtrinsicIncubationStages >= 2);
	
	assert((*FixedParameters).ncol() == fpi);
	assert((*VariableParameters).nrow() == vpi);
	
}


void GubbinsFarm::Initialise(){
	
	// Set up int arrays for infected stages:
	mp_InfectedCattle.resize(m_StagesViraemiaCattle);
	for(int i=0; i<m_StagesViraemiaCattle; i++){
		mp_InfectedCattle[i] = 0;
	}
	mp_InfectedSheep.resize(m_StagesViraemiaSheep);
	for(int i=0; i<m_StagesViraemiaSheep; i++){
		mp_InfectedSheep[i] = 0;
	}
	mp_LatentVectors.resize(m_ExtrinsicIncubationStages);
	for(int i=0; i<m_ExtrinsicIncubationStages; i++){
		mp_LatentVectors[i] = 0;
	}
	
	// This re-initialises the farm given the starting parameters initially given to it:
	m_SusceptibleCattle = m_TotalCattle;
	m_DeadCattle = 0;
	m_RecoveredCattle = 0;
	m_VaccinatedCattle = 0;

	m_SusceptibleSheep = m_TotalSheep;
	m_DeadSheep = 0;
	m_RecoveredSheep = 0;
	m_VaccinatedSheep = 0;

	m_SusceptibleVectors = m_TotalVectors;
	m_InfectiousVectors = 0;
		
	m_CumulativeInfectedSheep = 0;
	m_CumulativeInfectedCattle = 0;
	m_CumulativeInfectiousVectors = 0;
	
	if(m_State == state_e){
		Infect();
	}else if(m_State == state_s){
		// Do nothing
	}else{
		stopifnot_msg(false, "Attempted to (re)initialise GubbinsFarm with non-supported initialisation state " << m_State);		
	}
			
	LOG(logINFO) << "GubbinsFarm number " << m_AgentTypeID[AT_GubbinsFarm] << " initialised" << std::endl;
	
}


void GubbinsFarm::Infect(int InfectionForce){
	
	// TODO:  Infecting always adds new infected midges (default 5 follows Gubbins model)
	// Since vector numbers are constant, just convert max InfectionForce susceptible to infected
	int toinf = std::min(InfectionForce, m_SusceptibleVectors);
	m_InfectiousVectors += toinf;
	m_SusceptibleVectors -= toinf;
	if(m_State == state_s && m_InfectiousVectors>0){
		m_State = state_e;
		LOG(logINFO) << "Infected a GubbinsFarm" << std::endl;
	}
	
}

void GubbinsFarm::Remove(){
	// Ignore if the new State equals the old state:
	if(m_State != state_s){
		m_State = state_s;
		Initialise();
	}
}

Rcpp::IntegerVector GubbinsFarm::GetCattleNumbers(){
	Rcpp::IntegerVector toret(6);
	toret[0] = m_SusceptibleCattle;
	toret[1] = 0;
	for(int s=0; s<m_StagesViraemiaCattle; s++){
		toret[1] += mp_InfectedCattle[s];
	}
	toret[2] = m_DeadCattle;
	toret[3] = m_RecoveredCattle;
	toret[4] = m_VaccinatedCattle;
	toret[5] = m_CumulativeInfectedCattle;
	
	assert(m_TotalCattle == (toret[0]+toret[1]+toret[2]+toret[3]+toret[4]));
	assert(m_CumulativeInfectedCattle >= 0);
	return(toret);
}

Rcpp::IntegerVector GubbinsFarm::GetSheepNumbers(){
	Rcpp::IntegerVector toret(6);
	toret[0] = m_SusceptibleSheep;
	toret[1] = 0;
	for(int s=0; s<m_StagesViraemiaSheep; s++){
		toret[1] += mp_InfectedSheep[s];
	}
	toret[2] = m_DeadSheep;
	toret[3] = m_RecoveredSheep;
	toret[4] = m_VaccinatedSheep;
	toret[5] = m_CumulativeInfectedSheep;

	assert(m_TotalSheep == (toret[0]+toret[1]+toret[2]+toret[3]+toret[4]));
	assert(m_CumulativeInfectedSheep >= 0);
	return(toret);
}

Rcpp::IntegerVector GubbinsFarm::GetVectorNumbers(){
	Rcpp::IntegerVector toret(4);
	toret[0] = m_SusceptibleVectors;
	toret[1] = 0;
	for(int s=0; s<m_ExtrinsicIncubationStages; s++){
		toret[1] += mp_LatentVectors[s];
	}
	toret[2] = m_InfectiousVectors;
	toret[3] = m_CumulativeInfectiousVectors;

	assert(m_TotalVectors == (toret[0]+toret[1]+toret[2]));
	assert(m_CumulativeInfectiousVectors >= 0);
	return(toret);
}

const double GubbinsFarm::GetTodaysTemp(int hour){
	assert(hour >= 0 && hour <= 23);
	int tp = (GetTimePoint()-1)*24 + hour;
	return((*m_Temperatures)[tp]);
	
}

const bool GubbinsFarm::IsInfected(){
	return(m_State == state_e || m_State == state_l || m_State == state_i || m_State == state_cc || m_State == state_cs || m_State == state_csc || m_State == state_cc_i || m_State == state_cs_i || m_State == state_csc_i);
}

const bool GubbinsFarm::IsInfectable(){
	return(m_State != state_r);
}

const bool GubbinsFarm::IsObservedInfected(){
	return(m_State == state_cc || m_State == state_cs || m_State == state_csc || m_State == state_cc_i || m_State == state_cs_i || m_State == state_csc_i);
}

const int GubbinsFarm::IsInfectious(){

	int toreturn = m_InfectiousVectors;
	// If the infectious vectors aren't home-grown then the farm isn't infectious (follows Gubbins):
	if(m_CumulativeInfectiousVectors == 0){
		toreturn = 0;
	}
		
	debug(
		if(m_State==state_i || m_State==state_cs_i || m_State==state_cc_i || m_State==state_csc_i){
			assert(toreturn > 0);
		}else{
			assert(toreturn == 0);
		}
	);

	return(toreturn);
}

void GubbinsFarm::Update(){
	
	// If the time point is after or equal to the suspicion time:
	double ClinicalSignsSheep;
	double ClinicalSignsCattle;
	double MortalityRateCattle;
	double MortalityRateSheep;
	if(GetTimePoint() >= m_SuspicionTimePoint){
		ClinicalSignsSheep = m_ClinicalSignsSheepPost;
		ClinicalSignsCattle = m_ClinicalSignsCattlePost;
		MortalityRateCattle = m_MortalityRateCattlePost;
		MortalityRateSheep = m_MortalityRateSheepPost;
	}else{
		ClinicalSignsSheep = m_ClinicalSignsSheepPre;
		ClinicalSignsCattle = m_ClinicalSignsCattlePre;
		MortalityRateCattle = m_MortalityRateCattlePre;
		MortalityRateSheep = m_MortalityRateSheepPre;
	}
	
	// We only need to do this if state is not susceptible:
	if(m_State != state_s){
		
		assert(ClinicalSignsSheep*m_DeltaTime >= 0 && ClinicalSignsSheep*m_DeltaTime <= 1);
		assert(ClinicalSignsCattle*m_DeltaTime >= 0 && ClinicalSignsCattle*m_DeltaTime <= 1);
		assert(MortalityRateCattle*m_DeltaTime >= 0 && MortalityRateCattle*m_DeltaTime <= 1);
		assert(m_DurationViraemiaCattle*m_DeltaTime*m_StagesViraemiaCattle >= 0 && m_DurationViraemiaCattle*m_DeltaTime*m_StagesViraemiaCattle <= 1);
		assert(MortalityRateSheep*m_DeltaTime >= 0 && MortalityRateSheep*m_DeltaTime <= 1);
		assert(m_DurationViraemiaSheep*m_DeltaTime*m_StagesViraemiaSheep >= 0 && m_DurationViraemiaSheep*m_DeltaTime*m_StagesViraemiaSheep <= 1);
		assert(m_DeltaTime >= 0 && m_DeltaTime <= 1);
		assert(m_VectorSheepRatio >= 0);
		assert(m_VectorCattleRatio >= 0);
		
		// Set up states - if the farm changes state at any point during the 24 hours, record the highest state as the true state for this time step:
		bool isexposed = false;
		bool islatent = false;
		bool isclinicalsheep = false;
		bool isclinicalcattle = false;
		
		// Calculate vaccine protection:
		double vaccprotsheep = 0.0;
		double vaccprotcattle = 0.0;		
		if(m_VaccinationTime != -1 && m_VaccinationTime >= GetTimePoint()){
			/*
			C Calculate protection due to vaccination in (1) sheep and (2) cattle
			C
				  IF (TVax.GE.0.0) THEN
				    Vaxprot(1)=MIN(MAX(0.0,Vacc(1)*(DFLOAT(T0)+T-TVax)/14),
			     +				   Vacc(1))
				    Vaxprot(2)=MIN(MAX(0.0,Vacc(1)*(DFLOAT(T0)+T-TVax)/Vacc(2)),
			     +				   Vacc(1))
				  ELSE
				    Vaxprot(1)=0.0
				    Vaxprot(2)=0.0
				  END IF
			*/
			vaccprotsheep = m_VaccineEfficacySheep * std::min(1.0, (double) (GetTimePoint()-m_VaccinationTime) / m_TimeToVaccineEffectSheep);
			vaccprotcattle = m_VaccineEfficacyCattle * std::min(1.0, (double) (GetTimePoint()-m_VaccinationTime) / m_TimeToVaccineEffectCattle);
		}
		
		// Run for 24 hours:
		for(int t=0; t<24; t++){

			double temp = GetTodaysTemp(t);
	
			// The reciprocal of the time interval between blood meals:
			double alpha = std::max(0.0, 0.000171*temp*(temp-3.6966)*std::pow(41.8699-temp, 1.0/2.71) * m_BloodMealFrequencyEffect);
			// A=DMAX1(0.0,0.000171*Temp(Hour)*(Temp(Hour)-3.6966)*(41.8699-Temp(Hour))**(1/2.71))
	  	 
	  	  	// Extrinsic incubation period mean:
			double incubationperiod = std::max(0.0, 0.0003*temp*(temp-10.4057));
	  	  	// Nu=DMAX1(0.0,0.0003*Temp(Hour)*(Temp(Hour)-10.4057))
			
			// Vector recovery rate (death and recruitment are the same):
			double vectormort = 0.008941*std::exp(0.1547*temp);
			// Mu=0.008941*DEXP(0.1547*Temp(Hour))
			vectormort = std::max(std::min(vectormort, 1.0), m_MinVectorMortality);
		
			assert_msg(alpha >= 0, "" << alpha << " " << temp);
			assert_msg(m_VectorPreference >= 0, m_VectorPreference);
			assert_msg((1-m_VectorPreference) >= 0, (1-m_VectorPreference));
			assert_msg(m_VectorCattleRatio >= 0, m_VectorCattleRatio);
			assert_msg(m_VectorSheepRatio >= 0, m_VectorSheepRatio);
			

			// Loop time steps within 24 hours:
			for(int twh=0; twh<m_TimeStepsWithinHour; twh++){
				
				assert_msg((((double) m_InfectiousVectors) / ((double) m_TotalVectors)) >= 0, (((double) m_InfectiousVectors) / ((double) m_TotalVectors)));
								
				// Compute the force of infection for each species
				double lambda_cattle = m_ProbTransVectorHost * alpha * m_VectorPreference * m_VectorCattleRatio 
					* (((double) m_InfectiousVectors) / ((double) m_TotalVectors)) * (1 - vaccprotcattle);
				assert_msg(lambda_cattle*m_DeltaTime >= 0, lambda_cattle*m_DeltaTime);
		//		C Cattle	
		//			LambdaC=B*A*Phi*mC*(DFLOAT(I)/DFLOAT(N))*(1-Vaxprot(2))

				assert_msg(m_ProbTransVectorHost >= 0, m_ProbTransVectorHost);
				assert_msg(alpha >= 0, "" << alpha << " " << temp);
				assert_msg((1-m_VectorPreference) >= 0, (1-m_VectorPreference));
				assert_msg(m_VectorSheepRatio >= 0, m_VectorSheepRatio);
				assert_msg((((double) m_InfectiousVectors) / ((double) m_TotalVectors)) >= 0, (((double) m_InfectiousVectors) / ((double) m_TotalVectors)));
			
				double lambda_sheep = m_ProbTransVectorHost * alpha * (1-m_VectorPreference) * m_VectorSheepRatio 
					* (((double) m_InfectiousVectors) / ((double) m_TotalVectors)) * (1 - vaccprotsheep);
				assert_msg(lambda_sheep*m_DeltaTime >= 0, lambda_sheep*m_DeltaTime);
		//		C Sheep
		//			LambdaS=B*A*(1.0-Phi)*mS*(DFLOAT(I)/DFLOAT(N))*(1-Vaxprot(1))
		
				double lambda_vectors = 0;
				if(m_TotalCattle > 0){
					for(int s=0; s<m_StagesViraemiaCattle; s++){
						lambda_vectors += m_ProbTransHostVector * alpha * m_VectorPreference 
							* ((double) mp_InfectedCattle[s] / (double) m_TotalCattle) * (1  - vaccprotcattle);
		//				LambdaV=LambdaV+Beta*A*Phi*(DFLOAT(YC(J))/DFLOAT(HC)) *(1-Vaxprot(2))
					}
				}
				if(m_TotalSheep > 0){
					for(int s=0; s<m_StagesViraemiaSheep; s++){
						lambda_vectors += m_ProbTransHostVector * alpha * (1-m_VectorPreference) 
							* ((double) mp_InfectedSheep[s] / (double) m_TotalSheep) * (1 - vaccprotsheep);
		//  			  LambdaV=LambdaV+Beta*A*(1-Phi)*(DFLOAT(YS(J))/DFLOAT(HS))*(1-Vaxprot(1))
					}
				}
				assert(lambda_vectors*m_DeltaTime >= 0);
		
				// Compute the number of transitions:
				int cattle_fromsus = gsl_ran_binomial(r, lambda_cattle*m_DeltaTime, m_SusceptibleCattle);
				int sheep_fromsus = gsl_ran_binomial(r, lambda_sheep*m_DeltaTime, m_SusceptibleSheep);
				
				int cattle_frominf[m_StagesViraemiaCattle];
				int cattle_dead[m_StagesViraemiaCattle];
				for(int s=0; s<m_StagesViraemiaCattle; s++){
					cattle_dead[s] = gsl_ran_binomial(r, MortalityRateCattle*m_DeltaTime, mp_InfectedCattle[s]);

					assert(mp_InfectedCattle[s]-cattle_dead[s] >= 0);
					cattle_frominf[s] = gsl_ran_binomial(r, m_DurationViraemiaCattle*m_DeltaTime*m_StagesViraemiaCattle, mp_InfectedCattle[s]-cattle_dead[s]);
				}

				int sheep_frominf[m_StagesViraemiaSheep];
				int sheep_dead[m_StagesViraemiaSheep];
				for(int s=0; s<m_StagesViraemiaSheep; s++){
					sheep_dead[s] = gsl_ran_binomial(r, MortalityRateSheep*m_DeltaTime, mp_InfectedSheep[s]);

					assert(mp_InfectedSheep[s]-sheep_dead[s] >= 0);
					sheep_frominf[s] = gsl_ran_binomial(r, m_DurationViraemiaSheep*m_DeltaTime*m_StagesViraemiaSheep, mp_InfectedSheep[s]-sheep_dead[s]);
				}
			
		/*		C Compute the number of transitions of each type during the time step
				C
				C Cattle (infection, death, advance through infection stages)
					NInfC=HOWMANY(XC,LambdaC*DT)
					DO J=1,NC
					  NDeadC(J)=HOWMANY(YC(J),dC*DT)
					  NAdvC(J)=HOWMANY(YC(J),DFLOAT(NC)*rC*DT)
					END DO
				C
				C Sheep (infection, death, advance through infection stages)
					NInfS=HOWMANY(XS,LambdaS*DT)
					DO J=1,NS
					  NDeadS(J)=HOWMANY(YS(J),dS*DT)
					  NAdvS(J)=HOWMANY(YS(J),DFLOAT(NS)*rS*DT)
					END DO
		*/
		
				// Compute vector transitions:
				int vectors_fromsus = gsl_ran_binomial(r, lambda_vectors*m_DeltaTime, m_SusceptibleVectors);
			
				assert(vectormort*m_DeltaTime >= 0 && vectormort*m_DeltaTime <= 1);
				assert_msg((((double) m_ExtrinsicIncubationStages) * incubationperiod * m_DeltaTime) >= 0 && (((double) m_ExtrinsicIncubationStages) * incubationperiod *m_DeltaTime) <= 1, (double) m_ExtrinsicIncubationStages << " * " << incubationperiod << " * " << m_DeltaTime << " is not 0-1");
			
				int vectors_fromlatent[m_ExtrinsicIncubationStages];
				int vectors_dead[m_ExtrinsicIncubationStages];
				int vectors_totaldead = 0;
				for(int s=0; s<m_ExtrinsicIncubationStages; s++){
					vectors_dead[s] = gsl_ran_binomial(r, vectormort*m_DeltaTime, mp_LatentVectors[s]);
					vectors_totaldead += vectors_dead[s];
					assert(mp_LatentVectors[s]-vectors_dead[s] >= 0);
					vectors_fromlatent[s] = gsl_ran_binomial(r, (double) m_ExtrinsicIncubationStages * incubationperiod * m_DeltaTime, mp_LatentVectors[s]-vectors_dead[s]);
				}
				int vectors_frominf = gsl_ran_binomial(r, vectormort*m_DeltaTime, m_InfectiousVectors);
				vectors_totaldead += vectors_frominf;
		/*		
				C Vectors (infection, death, advance through infection stages,
				C recruitment; N.B.: the number of recruited vectors is chosen to
				C ensure a constant vector population)
					NInfV=HOWMANY(S,LambdaV*DT)
					DO J=1,K
					  NDeadV(J)=HOWMANY(L(J),Mu*DT)
					  NAdvV(J)=HOWMANY(L(J),DFLOAT(K)*Nu*DT)
					END DO
					NDeadV(K+1)=HOWMANY(I,Mu*DT)
					NRecV=0
					DO J=1,K+1
					  NRecV=NRecV+NDeadV(J)
					END DO
		*/
		
				// Update the populations:
				
				int newdeadcattle = 0;
				int newdeadsheep = 0;
				
				m_SusceptibleCattle += (-cattle_fromsus);  // No recruitment to susceptible
				mp_InfectedCattle[0] += (cattle_fromsus - (cattle_frominf[0] + cattle_dead[0]));
				m_CumulativeInfectedCattle += cattle_fromsus;
				
				newdeadcattle += cattle_dead[0];
				for(int s=1; s<m_StagesViraemiaCattle; s++){
					mp_InfectedCattle[s] += (cattle_frominf[s-1] - (cattle_frominf[s] + cattle_dead[s]));
					newdeadcattle += cattle_dead[s];
				}
				m_RecoveredCattle += cattle_frominf[m_StagesViraemiaCattle-1];  // No loss from recovered stage
				m_DeadCattle += newdeadcattle;
				
				m_SusceptibleSheep += (-sheep_fromsus);  // No recruitment to susceptible
				mp_InfectedSheep[0] += (sheep_fromsus - (sheep_frominf[0] + sheep_dead[0]));
				m_CumulativeInfectedSheep += sheep_fromsus;
				
				newdeadsheep += sheep_dead[0];
				for(int s=1; s<m_StagesViraemiaSheep; s++){
					mp_InfectedSheep[s] += (sheep_frominf[s-1] - (sheep_frominf[s] + sheep_dead[s]));
					newdeadsheep += sheep_dead[s];
				}
				m_RecoveredSheep += sheep_frominf[m_StagesViraemiaSheep-1];  // No loss from recovered stage
				m_DeadSheep += newdeadsheep;
				
				m_SusceptibleVectors += (vectors_totaldead - vectors_fromsus);  // totaldead is from all latent and infected stages
				
				mp_LatentVectors[0] += (vectors_fromsus - (vectors_fromlatent[0] + vectors_dead[0]));
				
				for(int s=1; s<m_ExtrinsicIncubationStages; s++){
					mp_LatentVectors[s] += (vectors_fromlatent[s-1] - (vectors_fromlatent[s] + vectors_dead[s]));
				}
				m_InfectiousVectors += (vectors_fromlatent[m_ExtrinsicIncubationStages-1] - vectors_frominf);  // Die and reincarnate as susceptible
				m_CumulativeInfectiousVectors += vectors_fromlatent[m_ExtrinsicIncubationStages-1];
				
				/*
				C Update the populations, ensuring they are always non-negative
				C
				C Cattle
					XC=MAX(0,XC-NInfC)
					YC(1)=MAX(0,YC(1)+NInfC-NAdvC(1)-NDeadC(1))
					DO J=2,NC
					  YC(J)=MAX(0,YC(J)+NAdvC(J-1)-NAdvC(J)-NDeadC(J))
					END DO
					ZC=ZC+NAdvC(NC)
				C
				C Sheep
					XS=Max(0,XS-NInfS)
					YS(1)=MAX(0,YS(1)+NInfS-NAdvS(1)-NDeadS(1))
					DO J=2,NS
					  YS(J)=MAX(0,YS(J)+NAdvS(J-1)-NAdvS(J)-NDeadS(J))
					END DO
					ZS=ZS+NAdvS(NS)
				C
				C Vectors	
					S=MAX(0,S-NInfV)
					L(1)=MAX(0,L(1)+NInfV-NAdvV(1)-NDeadV(1))
					DO J=2,K
					  L(J)=MAX(0,L(J)+NAdvV(J-1)-NAdvV(J)-NDeadV(J))
					END DO
					I=MAX(0,I+NAdvV(K)-NDeadV(K+1))
					NewI=NAdvV(K)
				C
				C Compute the number of dead cattle and sheep
				C
				C Cattle
					DeadC=0
					DO J=1,NC
					  DeadC=DeadC+NDeadC(J)
					END DO
				C
				C Sheep
					DeadS=0
					DO J=1,NS
					  DeadS=DeadS+NDeadS(J)
					END DO
				C
				C */

				// Finally do clinical - clinical is not a stage but a possible observation of all infected - only if stage!=c
		
				debug(
	
					int ic=0;
					for(int s=0; s<m_StagesViraemiaCattle; s++){
						assert(mp_InfectedCattle[s] >= 0);
						ic += mp_InfectedCattle[s];
					}
					int is=0;
					for(int s=0; s<m_StagesViraemiaSheep; s++){
						assert(mp_InfectedSheep[s] >= 0);
						is += mp_InfectedSheep[s];
					}
					int lv=0;
					for(int s=0; s<m_ExtrinsicIncubationStages; s++){
						assert(mp_LatentVectors[s] >= 0);
						lv += mp_LatentVectors[s];
					}
		
					assert(m_SusceptibleSheep >= 0);
					assert(m_DeadSheep >= 0);
					assert(m_RecoveredSheep >= 0);
					assert(m_VaccinatedSheep >= 0);

					assert(m_SusceptibleCattle >= 0);
					assert(m_DeadCattle >= 0);
					assert(m_RecoveredCattle >= 0);
					assert(m_VaccinatedCattle >= 0);

					assert(m_SusceptibleVectors >= 0);
					assert(m_InfectiousVectors >= 0);
		
					assert_msg(m_TotalSheep == (m_SusceptibleSheep+is+m_DeadSheep+m_RecoveredSheep+m_VaccinatedSheep), "Expected " << m_TotalSheep << " total sheep but got " << m_SusceptibleSheep << " + " << ic << " + " << m_DeadSheep << " + " << m_RecoveredSheep << " + " << m_VaccinatedSheep);
					assert_msg(m_TotalCattle == (m_SusceptibleCattle+ic+m_DeadCattle+m_RecoveredCattle+m_VaccinatedCattle), "Expected " << m_TotalCattle << " total cattle but got " << m_SusceptibleCattle << " + " << ic << " + " << m_DeadCattle << " + " << m_RecoveredCattle << " + " << m_VaccinatedCattle);
					assert_msg(m_TotalVectors == (m_SusceptibleVectors+lv+m_InfectiousVectors), "Expected " << m_TotalVectors << " total vectors but got " << m_SusceptibleVectors << " + " << lv << " + " << m_InfectiousVectors);	
				);
				

				// Work out the state we are in (including clinical signs):
				int totalinfsheep = 0;
				for(int s=0; s<m_StagesViraemiaSheep; s++){
					totalinfsheep += mp_InfectedSheep[s];
				}
				isexposed = isexposed || (totalinfsheep > 0);
		
				int totalinfcattle = 0;
				for(int s=0; s<m_StagesViraemiaCattle; s++){
					totalinfcattle += mp_InfectedCattle[s];
				}
				isexposed = isexposed || (totalinfcattle > 0);
				
				// If the farm has infected midges that aren't homegrown, register it as exposed so the outbreak continues at the next time step:
				isexposed = isexposed || (m_InfectiousVectors > 0 && m_CumulativeInfectiousVectors==0);
				
				for(int s=0; s<m_ExtrinsicIncubationStages; s++){
					islatent = islatent || (mp_LatentVectors[s] > 0);
				}
				
				int clinicalsheep = gsl_ran_binomial(r, ClinicalSignsSheep*m_DeltaTime, totalinfsheep);
				int clinicalcattle = gsl_ran_binomial(r, ClinicalSignsCattle*m_DeltaTime, totalinfcattle);

				isclinicalsheep = isclinicalsheep || (clinicalsheep > 0) || (newdeadsheep > 0);
				isclinicalcattle = isclinicalcattle || (clinicalcattle > 0) || (newdeadcattle > 0);
		
			} // End loop for time steps within hour
		} // End loop for 24 hours
		
		// A farm isn't infective until it has produced its own infectious vectors - follows Gubbins:
		// Also, for a farm to be infective now it must have infectious vectors at the end of the day:
		bool isinfective = (m_InfectiousVectors > 0 && m_CumulativeInfectiousVectors > 0);
		
		// Update the state for this day:
		// The states:
		// enum State { state_s, state_e, state_l, state_i, state_cs, state_cc, state_csc, state_cs_i, state_cc_i, state_csc_i, state_r, n_states };

		// First - are there infective midges?
		if(isinfective){
			if(isclinicalsheep && isclinicalcattle){
				m_State = state_csc_i;
			}else if(isclinicalsheep){
				assert(!isclinicalcattle);
				m_State = state_cs_i;
			}else if(isclinicalcattle){
				assert(!isclinicalsheep);
				m_State = state_cc_i;
			}else{
				m_State = state_i;
			}

		}else{
			
			if(isclinicalsheep && isclinicalcattle){
				m_State = state_csc;
			}else if(isclinicalsheep){
				assert(!isclinicalcattle);
				m_State = state_cs;
			}else if(isclinicalcattle){
				assert(!isclinicalsheep);
				m_State = state_cc;
			}else if(islatent){
				m_State = state_l;
			}else if(isexposed){
				m_State = state_e;
			}else{
				if(m_RecoveredCattle == m_TotalCattle && m_RecoveredSheep == m_TotalSheep){
					m_State = state_r;
				}else{
					m_State = state_s;
				}
			}
		}
		
	}  // endif state not susceptible
	
//	LOG(logINFO) << "Updated agent " << GetAgentID() << " with state " << m_State << std::endl;
}

GubbinsFarm::~GubbinsFarm(){
	// Virtual destructor
	LOG(logINFO) << "Removing GubbinsFarm number " << GetAgentID(AT_GubbinsFarm) << " (agent number " << GetAgentID(AT_Agent) << ")" << std::endl;
	/*
	delete DiseaseModel;
	Actor::DiseaseModel = 0;
	 */
}
