/*

 network_gubbins.cpp
 Use this code as an example of a derived network class

 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.

 */

#include "network_gubbins.h"

#include <Rcpp.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_math.h>
#include <gsl/gsl_pow_int.h>

#include "fixed_settings.h"
#include "fixed_logger.h"
#include "fixed_metapop.h"


// Constructor
GubbinsNetwork::GubbinsNetwork(Rcpp::IntegerVector FarmTypes, Rcpp::NumericVector xlocations, Rcpp::NumericVector ylocations, long NumberOfAgents, std::string LogName)
	: StructuredNetwork(NumberOfAgents, LogName), mp_xlocations(xlocations), mp_ylocations(ylocations)
{
	
	LOG(logINFO) << "Setting up a GubbinsNetwork with " << NumberOfAgents << " agents" << std::endl;
	
	stopifnot_msg(FarmTypes.size() == NumberOfAgents, "The length of the vector provided for the farm types does not match the number of agents");
	stopifnot(NumberOfAgents > 0);
	
	stopifnot_msg(xlocations.size() == NumberOfAgents, "The length of the vector provided for the xlocations does not match the number of agents");
	stopifnot_msg(ylocations.size() == NumberOfAgents, "The length of the vector provided for the ylocations does not match the number of agents");
		
	// Set up the transmission and aquisition risks:
	Rcpp::NumericVector temp1(NumberOfAgents, 1);
	Rcpp::NumericVector temp2(NumberOfAgents, 1);
	mp_TransmissionProbs = temp1;
	mp_AquisitionProbs = temp2;
	for(long i=0; i<FarmTypes.size(); i++){
		// These are obtained from the paper:
		bool sheep = FarmTypes[i]==1 || FarmTypes[i]==3;
		double ap = std::exp(0.562 + ((sheep) ? -1.330 : 0));
		mp_AquisitionProbs[i] = ap / (1 + ap);
		double tp = std::exp(-2.149 + ((sheep) ? 30.095 : 0));
		mp_TransmissionProbs[i] = tp / (1 + tp);
		
		assert(mp_TransmissionProbs[i] >= 0 && mp_TransmissionProbs[i] <= 1);
		assert(mp_AquisitionProbs[i] >= 0 && mp_AquisitionProbs[i] <= 1);
		
	}
	
	/*
	// Can't store a Kernal matrix for more than around 50,000 agents
	// But we can create a vector of vectors and do it for only infected agents
	mp_Kernals.resize(m_agents);
	for(long i=0; i<m_agents; i++){
		mp_Kernals[i].resize(0);
	}
	*/
	
}

bool GubbinsNetwork::IsAgentAtRisk(long AgentID, MetaPop* p_MetaPop, int TimePoint, gsl_rng* r){
	// If the farm is infectable, test if the farm aquires infection (copied from Gubbins):
	bool atrisk = p_MetaPop->GetAgentPointer(AgentID)->IsInfectable() && gsl_ran_bernoulli(r, mp_AquisitionProbs[AgentID-1]);
	return(atrisk);
}


int GubbinsNetwork::GetNewInfectionEvents(long TransmittingID, long AquiringID, long RiskIndex, int InfectiousAgents, int ExistingInfections, MetaPop* p_MetaPop, int TimePoint, gsl_rng* r){
	
	// For Gubbins network, only a single transmission event of exactly 5 midges occurs:
	if(ExistingInfections > 0){
		return(0);
	}
	// First see if any infectious agents make it over (i.e. a 'packet' of infectious agents is possible):
	bool anyinfections = (bool) gsl_ran_bernoulli(r, mp_TransmissionProbs[TransmittingID-1] * Kernal(TransmittingID-1, AquiringID-1));
	
	// For Gubbins network, only a single transmission event of exactly 5 midges occurs:
	return(5 * anyinfections);
}

// To be derived from for different kernals - this is a stub:
double GubbinsNetwork::Kernal(long source_farm, long destination_farm){
	
	/*
	// If prevalence becomes high with the full farms we will run out of memory here!
	if(mp_Kernals[source_farm].size() == 0){
		LOG(logINFO) << "Calculating kernal distances for source farm " << source_farm << std::endl;
		
		mp_Kernals[source_farm].resize(m_agents);
		
		// kernal par is 0.0341 in fortran code
		double alpha = 0.0341;		
		
		for(long i=0; i<m_agents; i++){	
			
			// From Gubbins model:
			// PrI=PrTrans(K)*(A/SQRT(3.14159))*DEXP(-((A*A)*Dist2))
				
			// Kernal is based on distance:
			double dx = std::abs(mp_xlocations[source_farm] - mp_xlocations[i]);
			double dy = std::abs(mp_ylocations[source_farm] - mp_ylocations[i]);
			double distance2 = gsl_pow_2(dx) + gsl_pow_2(dy);
			
			double kernal = (alpha / sqrt(3.14159)) * std::exp(-(gsl_pow_2(alpha) * distance2));
			
			// Transmission and aquisition probs are handled elsewhere
			
			mp_Kernals[source_farm][i] = kernal;
			//m_kno << source_farm+1 << "," << i+1 << "," << std::sqrt(distance2) << "," << kernal << "\n";
			
		}
	}

	assert_msg(mp_Kernals[source_farm][destination_farm] >= 0 && mp_Kernals[source_farm][destination_farm] <= 1, "The Kernal function returned " << mp_Kernals[source_farm][destination_farm] << " (outside the range 0,1) for transmission from farm " << source_farm+1 << " to farm " << destination_farm+1);
	
	return(mp_Kernals[source_farm][destination_farm]);
	*/
	
	double dx = std::abs(mp_xlocations[source_farm] - mp_xlocations[destination_farm]);
	double dy = std::abs(mp_ylocations[source_farm] - mp_ylocations[destination_farm]);
	double distance2 = gsl_pow_2(dx) + gsl_pow_2(dy);
	
	// kernal par is 0.0341 in fortran code
	double alpha = 0.0341;
	double kernal = (alpha / sqrt(3.14159)) * std::exp(-(gsl_pow_2(alpha) * distance2));
	
	assert_msg(kernal >= 0 && kernal <= 1, "The Kernal function returned " << kernal << " (outside the range 0,1) for transmission from farm " << source_farm+1 << " to farm " << destination_farm+1);
	
	return(kernal);
}


GubbinsNetwork:: ~GubbinsNetwork(){
	
//	m_kno.close();
	LOG(logINFO) << "Removing GubbinsNetwork" << std::endl;
	
}
