/*

 network_sparsematrix.h
 Use this code as an example of a derived network class
 
 A flexible sparse matrix representation of a directed network
 
 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.
 
 */


#include "fixed_network_base.h"
#include "network_structured.h"

#include <Rcpp.h>

class SparseMatrixNetwork : public StructuredNetwork
{

protected:
	
	// Vectors derived from the data frame passed to us (no copying should occur):
    Rcpp::IntegerVector mv_Sources;
    Rcpp::IntegerVector mv_Destinations;
    Rcpp::NumericVector mv_Probabilities;
	
	// A pre-calculated vector of startpoints and endpoints to use relative to the source farm indexes:
	std::vector< long > mv_StartPoints;
	std::vector< long > mv_EndPoints;
	
	// Overwritten functions:
	virtual bool IsAgentAtRisk(long AgentID, MetaPop* p_MetaPop, int TimePoint, gsl_rng* r);
	virtual int GetNewInfectionEvents(long TransmittingID, long AquiringID, long RiskIndex, int InfectiousAgents, int ExistingInfections, MetaPop* p_MetaPop, int TimePoint, gsl_rng* r);
	virtual Rcpp::IntegerVector GetRiskAgents(long AgentNumber);
	
	// Pre-calculated vectors of aquisition risks:
	Rcpp::NumericVector mp_AquisitionProbs;

	// The individual infectious agent probability:
	double m_InfectiousAgentProb;
	
	
public:
	// Public constructor, to be called by the user before setting up a simulation.
    SparseMatrixNetwork(Rcpp::DataFrame SparseMatrix, Rcpp::NumericVector AquisitionProbs, double InfectiousAgentProb, long NumberOfAgents, std::string LogName = "SparseMatrixNetwork.txt");
	
	// Transmission/removal/rest are not changed from kernal class
	
	// Function used within R to check that the number of agents is consistent for the simulation
	long GetNumberOfAgents(){ return(Network::GetNumberOfAgents()); }
	// Function used within R to get the network ID
	int GetNetworkID(){ return(Network::GetNetworkID()); }
	Rcpp::StringVector GetBaseClass(){ return(Network::GetBaseClass()); }
	// Both must be defined like this in all inherited classes to allow exposure in Rcpp module
	// http://lists.r-forge.r-project.org/pipermail/rcpp-devel/2013-October/006517.html
	
	~SparseMatrixNetwork();
	
};
