/*

 agent_base.h
 This file should not need to be modified

 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.

 */


#ifndef AGENT_H
#define AGENT_H

#include "fixed_settings.h"


#include <gsl/gsl_rng.h>
#include <iostream>
#include <fstream>
#include <Rcpp.h>

class Logger;
class MetaPop;

/// A virtual base class for all types of agent

class Agent
{
	
private:
	// This is only needed for the Agent constructor:
	void SetupClassPointers(AgentType NewAgentType);
	

protected:
	
	Agent(AgentType AT, int InputState, MetaPop *InputMetaPop); 
	
	Agent();
	
	//! The class (derived from agent) that this instance belongs to
	AgentType m_AgentType;
	
	// The index of this object by each available agent class 
	/* The array is indexed so that you can calculate the index number of this object
	 according to all of the agent classes - if the number is 0 then this object does not
	 derive from that class, otherwise it is the index number of that class (guaranteed to
	 be a unique object).  eg. m_AgentTypeID[AT_Agent] will be the agent ID, m_AgentTypeID[AT_Farm]
	 is the farm number.
	 */
	int m_AgentTypeID[((int) AT_Num)];
	
	//! Pointer to the logger class
	Logger *logger;
	
	//! Pointer to the RNG
	gsl_rng *r;
	
	// The infection state
	State m_State;
	int m_FirstInfectedTime;

	//! Pointer to the metapopulation
	MetaPop *mp_MetaPop;
	
	// Function necessary for controlling class types - MUST BE CALLED FROM EACH CHAINED CONSTRUCTOR
	/* A call to this function in the constructor of a class registers that the object
	 being created is derived from that class.  This is necessary for AgentPointer functions
	 to work as expected.  A call to AddClassPointer(AT_xxx) must be placed in parameterless
	 (to be called from a derived function) constructor for each agent derived class.  See the 
	 code for (eg) Farm for an example.
	 */
	void AddClassPointer(AgentType NewAgentType);
	
	// Returns the current time point - not intended to be overridden:
	const int GetTimePoint();
		
public:
	
	// Is this agent classified as infected for the purposes of prevalence?
	virtual const bool IsInfected();
	// Is this agent classified as observed infected for the purposes of observed prevalence?
	virtual const bool IsObservedInfected();
	// Is this agent infectious for the purposes of spreading disease?
	virtual const int IsInfectious();
	// Is this agent able to be infected?
	virtual const bool IsInfectable();
	// The base function just asks if m_State is greater than 0
	
	// Get the current state:
	virtual const State GetState();
	// Get the time of first infection (-1 means not infected):
	virtual const int GetTimeOfFirstInfection();
	
	// A function called to give the agent the necessary parameters (only the state for base class):
	void SetParameters(int State);
	// This will be done by Demography right at the start and again as needed
	// Note that this is NOT virtual as the signature should not match derived classes anyway
		// AND it is only used by Demography which should know and use the final class
	
	// A re-initialisation function called to set up the agent with the parameters it is holding:
	virtual void Initialise();
	// The intent is to set up the internal state of the model
	// This will always be done by Demography after SetParameters and also again as needed
	
	// Function called by network to see if this agent can infect others:
	virtual const double GetTransmissionProb();
	// Function called by network to see if this agent can be infected by others:
	virtual const double GetAquisitionProb();
		
	// Functions that may be called by network/demography to change the state of infection within this agent (e.g. infection, vaccination, culling etc):
	virtual void Infect(int InfectionForce = 1);
	virtual void Remove();
	virtual void Vaccinate();
	
	// The workhorse function that updates the internal model:
	virtual void Update();
	
	// Function to get the agent type of this object - not intended to be overridden
	const AgentType GetType();
	// Just used in R to ensure this is the correct class:
	const Rcpp::StringVector GetBaseClass();
	
	// Function to return the AgentID of this object - not intended to be overridden
	const int GetAgentID(AgentType AT = AT_Agent);
	
	// Virtual destructor (no memory to free for Agent, but may be for derived classes)
	virtual ~Agent();

};

#endif
