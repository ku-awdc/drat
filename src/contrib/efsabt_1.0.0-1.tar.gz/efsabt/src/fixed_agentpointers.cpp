/*

 Agent pointer utilities
 This code should not need to be modified
 
 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.
 
 */

#include "fixed_agentpointers.h"
#include "fixed_agent_base.h"
#include "fixed_settings.h"

AgentPointers::AgentPointers(){
	m_FirstElement = 0;
	m_LastElement = 0;
	m_Number = 0;
	m_vp = 0;
	m_SetupAgentType = AT_Agent;
	m_MyAgentID = -1;
	m_MyAgentType = AT_Agent;
	m_FinalClassRefs = false;
	m_RegulatorStructs = false;
	
	logger = 0;
}


Agent* AgentPointers::P(int i){
	assert_msg(i >=0 && i <m_Number, "Asking for element " << i << " of " << m_Number << " (max " << m_Number-1 << ")");
	return((*m_vp)[i]);
}

/*
int AgentPointers::GetAgentID(int i, AgentType AT){
	return(P(i)->GetAgentID(AT));
}*/

int AgentPointers::GetAgentID(int i){
	return(P(i)->GetAgentID(m_SetupAgentType));
}


int AgentPointers::size(){
	return(m_Number);
}

Agent* AgentPointers::Last(){
	return(P(m_Number-1));
}
