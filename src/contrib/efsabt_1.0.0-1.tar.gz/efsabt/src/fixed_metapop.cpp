/*
 MetaPop
 The metapopulation class
 This file should not need to be modified
 
 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.
 
*/

#include "fixed_metapop.h"

#include "fixed_logger.h"
#include "fixed_network_base.h"
#include "fixed_demography_base.h"

#include "fixed_settings.h"

// Constructor.
MetaPop::MetaPop(Demography *InputDemography, Logger *InputLogger, int SimulationID, gsl_rng* input_r)
	: mp_Demography(InputDemography), m_ID(SimulationID), r(input_r)
{
		
	// Point the metapopulation to itself, just so we can use the LOG() preprocessor macro within this class (don't use it for anything else!)
	mp_MetaPop = this;
	logger = InputLogger;
	
	// Get the number of agents from the demography so that we can use it for this simulation:
	m_nAgents = mp_Demography->GetNumberOfAgents();
	
	LOG(logINFO) << "Setting up a metapopulation with " << m_nAgents << " agents" << std::endl;
	
	m_StructsLength = 0;
	
	// First set all agent tallies to zero:
	m_AgentPointers.resize(AT_Num);
	m_AgentPointersFinalClass.resize(AT_Num);
	m_AgentClassMemberships.resize(AT_Num);
	for(int i=0; i<AT_Num; i++){
		m_AgentClassNumbers[i]=0;
		m_AgentClassNumbersFinalClass[i]=0;
		m_AgentPointers[i].resize(0);
		m_AgentPointers[i].reserve(m_nAgents);
		m_AgentPointersFinalClass[i].resize(0);		
		m_AgentPointersFinalClass[i].reserve(m_nAgents);
		m_AgentClassMemberships[i].resize(0);
		m_AgentClassMemberships[i].reserve(m_nAgents);
	}
	
	// Then get the agent types and states from Demography:
	std::vector<AgentType> types = mp_Demography->GetAgentTypes();
	Rcpp::IntegerVector states = mp_Demography->GetAgentStates();
	
	// Then loop through the agents to add them:
	for(long i=0; i<m_nAgents; i++){
		
		// Create the new agent:
		LOG(logINFO) << "Creating a " << types[i] << std::endl;
		AddAgent(types[i], states[i], mp_MetaPop);

		// Note that we only create the new agent here - in the constructor for the agent (and derived classes)
		// they use the AddAgentType function to add themselves onto the stored vector
	}
	
	LOG(logINFO) << "Agents setup complete" << std::endl;
	
	// Now check that we have the right number of agents and that the class and finalclass numbers are consistent:
	debug(
		AgentPointers ap = GetAgentPointers(AT_Agent);
		assert_msg(ap.size() == m_nAgents, "The number of agents created (" << ap.size() << ") did not match the number of agents requested (" << m_nAgents << ")" << std::endl);
		
		for(int i=0; i<AT_Num; i++){
			AgentPointers ap = GetAgentPointers((AgentType) i);
			LOG(logINFO) << ap.size() << " instances of agent class " << ((AgentType) i) << " registered" << std::endl;
			
				assert_msg(ap.size() <= m_nAgents, "The number of agent class " << ((AgentType) i) << " created (" << ap.size() << ") was greater than the number of agents requested (" << m_nAgents << ")" << std::endl);
				assert_msg(m_AgentClassNumbers[i] >= m_AgentClassNumbersFinalClass[i], "The number of agent class " << ((AgentType) i) << " created (" << m_AgentClassNumbers[i] << ") was less than the number of final class agents of the same class created (" << m_AgentClassNumbersFinalClass[i] << ") - check that this agent class calls AddClassPointer(AgentType) in its constructor" << std::endl);

		}
		
		for(long i=0; i<m_nAgents; i++){
			assert_msg(types[i] == ap.P(i)->GetType(), "The requested class (" << types[i] << ") of agent number " << i+1 << " did not match the registered class (" << ap.P(i)->GetType() << ") - have you remembered to call AddClassPointer() correctly in the final class constructor?" << std::endl);
		}
	);
	
	m_TimePoint = 0;
		
	LOG(logINFO) << "Metapopulation setup complete" << std::endl;
	
}

Logger* MetaPop::GetLogger(){
	return(logger);
}
Demography* MetaPop::GetDemography(){
	return(mp_Demography);
}
gsl_rng* MetaPop::GetRNG(){
	return(r);
}

void MetaPop::SetTimePoint(int Time){
	m_TimePoint = Time;
}
int MetaPop::GetTimePoint(){
	return(m_TimePoint);
}


// This function gets pointers to all agents:
AgentPointers MetaPop::GetAgentPointers(AgentType AT){
	
	AgentPointers pointers;
	long N=0;
	
	N = m_AgentClassNumbers[AT];
	pointers.m_vp = (&(m_AgentPointers[AT]));

	pointers.m_Number = N;
	pointers.m_LastElement = (N-1);
	pointers.m_FirstElement = 0;
	pointers.m_SetupAgentType = AT;
	
	pointers.logger = logger;
	
	return(pointers);	
}



long MetaPop::GetNumberOfAgents(AgentType AT)
{
	long retval = 0;
	retval = m_AgentClassNumbers[AT];
	return(retval);
}

double MetaPop::GetPrevalence(AgentType AgentClass)
{
	
	long nagents = GetNumberOfAgents(AgentClass);
	assert(nagents > 0);
	
	long npos = 0;
	
	// Agent numbers start at 1:
	for(long i=1; i <= nagents; i++){
		npos += GetAgentPointer(i, AgentClass)->IsInfected();
	}
		
	return((double) npos / (double) nagents);
}


Agent* MetaPop::GetAgentPointer(long ID, AgentType AT){
	
	Agent* AP = 0;
	assert_msg(ID>0, "Agent ID must be >0");

	assert_msg(m_AgentClassNumbers[AT]>=ID, "Incorrect agent ID specified");
	AP = m_AgentPointers[AT][ID-1];		
	
	return(AP);
}

void MetaPop::SetupClassPointers(AgentType AT, Agent* AgentPointer){
	
	// This is called by the constructors of the agents themselves
	LOG(logINFO) << "Setting up a new class membership vector" << std::endl;
	for(int i=0; i<AT_Num; i++){
		m_AgentClassMemberships[i].push_back(false);
	}
	LOG(logINFO) << "Adding the agent to the final class membership for " << AT << std::endl;
	m_AgentClassNumbersFinalClass[AT]++;
	m_AgentPointersFinalClass[AT].push_back(AgentPointer);
		
}

int MetaPop::AddAgentType(AgentType AT, Agent* AgentPointer){
	
	// This is called by the constructors of the agents themselves
	LOG(logINFO) << "Adding the agent to the class membership for " << AT << std::endl;
	m_AgentClassNumbers[AT]++;
	m_AgentPointers[AT].push_back(AgentPointer);
	
	// Change the last element of the class memberships (corresponding to this object)
	// to true:
	m_AgentClassMemberships[AT].back() = true;
	
	return(m_AgentClassNumbers[AT]);
}


int MetaPop::GetID(){
	return(m_ID);
}


MetaPop::~MetaPop(){
	
	LOG(logINFO) << "Destroying MetaPopulation object" << std::endl;
	
}
