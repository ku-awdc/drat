/*

 network_base 
 The network_base class
 This file should not need to be modified
 
 A single object of this class is needed for each set of simulations.  The function of this class is to 
 provide a means of calculating the (directed) connection probability between two farms.
 This base class does no connection probabilities - you must derive from this class to do something.
 The functions to override are GetConnectionProb and theructor (and maybe also destructor).
 
 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.
 
 */


#include "fixed_settings.h"

#include <iostream>
#include <fstream>
#include <vector>
#include <gsl/gsl_rng.h>

class Logger;

#ifndef NETWORK_BASE_H
#define NETWORK_BASE_H


class Network
{

protected:
	
	Logger* logger;
	long m_agents;

	int m_ID;
	// The static variable for IDGen allows each network to know its unique ID
    static int s_IDGen;
	
	int m_MaxDays;
	
	// Protected constructor, to be called by derived classes which are set up by the user before setting up a simulation.
    Network(long NumberOfAgents, std::string LogName);
	
public:
	// For simulation to check the maximum time points:
	virtual int MaxDays();
	
	// Get the ID of this network:
	int GetNetworkID();
	// Used from R:
	Rcpp::StringVector GetBaseClass();
		
	// Function used by simulation to check that the number of agents is consistent with that passed to the simulation
	virtual bool CheckNumberOfAgents(long InputNumber);
	// Function used by R:
	virtual long GetNumberOfAgents();
	
	// The main functions for this (and derived) classes - virtual to ensure that the child function is always used:
	virtual void Transmission(MetaPop* p_MetaPop, int TimePoint, gsl_rng* r);
	virtual void Removal(MetaPop* p_MetaPop, int TimePoint, gsl_rng* r);
	virtual void Vaccination(MetaPop* p_MetaPop, int TimePoint, gsl_rng* r);
	virtual void Reset(MetaPop* p_MetaPop, int TimePoint, gsl_rng* r);
	
	// A wrapper for above - not intended to be overridden:
	void TransmissionWrapper(MetaPop* p_MetaPop);
	void ResetWrapper(MetaPop* p_MetaPop);

	// The destructor.  Responsible for closing the log file
	virtual ~Network();		
};

#endif  // NETWORK_BASE_H
