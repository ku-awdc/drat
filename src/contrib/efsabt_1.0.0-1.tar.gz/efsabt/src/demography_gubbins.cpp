/*

 demography_gubbins.cpp
 Use this file as an example derived class for demography

 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.

 */

#include "demography_gubbins.h"

#include <Rcpp.h>
#include <math.h>

#include "fixed_settings.h"
#include "fixed_logger.h"


// Constructor
GubbinsDemography::GubbinsDemography(Rcpp::NumericMatrix FixedParameters, Rcpp::NumericMatrix VariableParameters, Rcpp::NumericMatrix TemperatureData, Rcpp::IntegerVector AgentStates, Rcpp::IntegerVector AgentTypes, std::string LogName)
	: Demography(AgentStates, AgentTypes, LogName)
{
	
	LOG(logINFO) << "Setting up a Gubbins class demography" << std::endl;
	
	// Does all of the checking etc:
	SetFixedParameters(FixedParameters);
	SetVariableParameters(VariableParameters);

	// TODO:  Let agents handle their own temperature references
	Rcpp::IntegerVector tempweather(m_agents);
	mp_WeatherStations = tempweather;
	for(int i=0; i<m_agents; i++){
		mp_WeatherStations[i] = lround(mp_FixedParameters(i,0));
	}
	
	// Check the temperature data:
	m_MaxDays = (int) floor(TemperatureData.nrow() / 24);
	stopifnot_msg(Rcpp::min(mp_WeatherStations) > 0, "The ClosestWeatherStations must be indexed starting at 1");
	int maxstation = Rcpp::max(mp_WeatherStations);
	stopifnot_msg(TemperatureData.ncol() >= maxstation, "The number of columns of the temperature data (" << TemperatureData.ncol() << ") is greater than the number of weather stations (" << maxstation << ")");
	int minhours = 7 * 24;
	stopifnot_msg(TemperatureData.nrow() >= minhours, "The number of rows of the temperature data (" << TemperatureData.nrow() << ") is less than one week's worth (24 * 7)");	
	
	// Copy the temperature data into the vector:
	mp_TemperatureData.resize(maxstation);
	for(int i=0; i<maxstation; i++){
		Rcpp::NumericVector temps = TemperatureData( Rcpp::_, i);
		// Do a deep copy as the TemperatureData might go out of scope/be removed in R (and it isn't that big anyway)
		mp_TemperatureData[i] = Rcpp::clone(temps);
		debug(
			for(int j=0; j<TemperatureData.nrow(); j++){
				assert(std::abs(mp_TemperatureData[i][j] - TemperatureData(j,i)) < 0.00001);
			}
		);
	}
	
	
	// The number of infected animals is decided by the farm based on its state and number of animals
	// Set up empty matrices here:
	{
		Rcpp::IntegerMatrix temp1(m_agents, 6);
		mp_CattleNumbers = temp1;
		Rcpp::IntegerMatrix temp2(m_agents, 6);
		mp_SheepNumbers = temp2;	
		Rcpp::IntegerMatrix temp3(m_agents, 4);
		mp_VectorNumbers = temp3;	
	}

	// Informative column names:
	Rcpp::CharacterVector colnames1 = Rcpp::CharacterVector::create("Susceptible", "Infected", "Dead", "Recovered", "Vaccinated","CumulativeInfected");
	Rcpp::CharacterVector colnames2 = Rcpp::CharacterVector::create("Susceptible", "Latent", "Infectious","CumulativeInfectious");
	mp_CattleNumbers.attr("colnames") = colnames1;
	mp_SheepNumbers.attr("colnames") = colnames1;
	mp_VectorNumbers.attr("colnames") = colnames2;
		
}


Rcpp::NumericMatrix GubbinsDemography::GetFixedParameters(){
	return(mp_FixedParameters);
}
void GubbinsDemography::SetFixedParameters(Rcpp::NumericMatrix NewFixedParameters){
		
	mp_FixedParameters = NewFixedParameters;

	int numfixed = 13;
	stopifnot_msg(mp_FixedParameters.nrow() == m_agents, "The number of rows of fixed parameters provided (" << mp_FixedParameters.nrow() << ") does not match the number of farms (" << m_agents << ")");
	stopifnot_msg(mp_FixedParameters.ncol() == numfixed, "The fixed parameters must have " << numfixed << " columns");
	
	// TODO:  Should I do a deep copy of fixed and variable parameters???  Probably
}

Rcpp::NumericMatrix GubbinsDemography::GetVariableParameters(){
	return(mp_VariableParameters);
}
void GubbinsDemography::SetVariableParameters(Rcpp::NumericMatrix NewVariableParameters){
		
	mp_VariableParameters = NewVariableParameters;

	int numvariable = 17;
	stopifnot_msg(mp_VariableParameters.nrow() == numvariable, "The variable parameters must have " << numvariable << " rows");
	stopifnot_msg(mp_VariableParameters.ncol() == 2, "The variable parameters must have 2 columns (min, max)");
	
	// TODO:  Should I do a deep copy of fixed and variable parameters???  Probably
}

const Rcpp::IntegerVector GubbinsDemography::GetStates()
{
  return(mp_AgentStates);
}

/*
// TODO:  Replace with set fixed and variable parameters
// Check fixed parameters nrow is equal to number of agents, and that variable parameters ncol==2
void GubbinsDemography::SetNumberOfCattle(Rcpp::IntegerVector NumberOfCattle){
	
	stopifnot_msg(((long) NumberOfCattle.size()) == m_agents, "The length of the vector for number of cattle provided (" << ((long) NumberOfCattle.size()) << ") does not match the number of agents registered (" << m_agents << ")");

	LOG(logINFO) << "Copying the number of cattle pointer (NOT by value!)" << std::endl;
	mp_NumberOfCattle = NumberOfCattle;
	
}
void GubbinsDemography::SetNumberOfSheep(Rcpp::IntegerVector NumberOfSheep){
	
	stopifnot_msg(((long) NumberOfSheep.size()) == m_agents, "The length of the vector for number of sheep provided (" << ((long) NumberOfSheep.size()) << ") does not match the number of agents registered (" << m_agents << ")");

	LOG(logINFO) << "Copying the number of sheep pointer (NOT by value!)" << std::endl;
	mp_NumberOfSheep = NumberOfSheep;
	
}
*/


Rcpp::IntegerMatrix GubbinsDemography::GetCattleNumbers(){
	// This can change - the user has to make sure that Simulation::SaveParameters has been called first
	return(mp_CattleNumbers);
}
Rcpp::IntegerMatrix GubbinsDemography::GetSheepNumbers(){
	// This can change - the user has to make sure that Simulation::SaveParameters has been called first
	return(mp_SheepNumbers);
}
Rcpp::IntegerMatrix GubbinsDemography::GetVectorNumbers(){
	// This can change - the user has to make sure that Simulation::SaveParameters has been called first
	return(mp_VectorNumbers);
}


GubbinsFarm* GubbinsDemography::GetGubbinsFarmPointer(long AgentNumber, MetaPop* p_MetaPop){
	// This will fail if any of the agents don't derive from GubbinsFarm:
	// Needs to be from GubbinsFarm and not Farm as we have cattle AND sheep
	assert(p_MetaPop->GetNumberOfAgents(AT_Agent) == p_MetaPop->GetNumberOfAgents(AT_GubbinsFarm));
	GubbinsFarm* ap = static_cast<GubbinsFarm *>(p_MetaPop->GetAgentPointer(AgentNumber, AT_Agent));
	return(ap);
}

void GubbinsDemography::UpdateAgentParameters(long AgentNumber, long IndexNumber, MetaPop* p_MetaPop){
	LOG(logINFO) << "Updating parameters for agent " << AgentNumber << std::endl;		
	
	// Get the relevant temperature column for this data:
	int col = mp_WeatherStations[IndexNumber];
	assert_msg(col <= ((int) mp_TemperatureData.size()), "Requesting column " << col << " from a vector with " << mp_TemperatureData.size() << " pseudo-columns");
	
	GubbinsFarm* ap = GetGubbinsFarmPointer(AgentNumber, p_MetaPop);
	// Pass a pointer to the relevant temperature vector with the other info:
	Rcpp::NumericVector* tempref = &(mp_TemperatureData[col-1]);
	
	ap->SetParameters((State) mp_AgentStates[IndexNumber], &(mp_FixedParameters), &(mp_VariableParameters), tempref);
	
}
// Functions to be overridden:
void GubbinsDemography::RetrieveAgentParameters(long AgentNumber, long IndexNumber, MetaPop* p_MetaPop){

	LOG(logINFO) << "Retrieving parameters for agent " << AgentNumber;

//	mp_AgentStates[IndexNumber] = (int) GetAgentPointer(AgentNumber)->GetState();
	
	Rcpp::IntegerVector cattlenums = GetGubbinsFarmPointer(AgentNumber, p_MetaPop)->GetCattleNumbers();
	assert(cattlenums.size() == 6);
	for(int i=0; i<cattlenums.size(); i++){
		// Note:  parentheses not square brackets for assigning to matrix:
		mp_CattleNumbers(IndexNumber,i) = cattlenums[i];
	}
	Rcpp::IntegerVector sheepnums = GetGubbinsFarmPointer(AgentNumber, p_MetaPop)->GetSheepNumbers();
	assert(sheepnums.size() == 6);
	for(int i=0; i<sheepnums.size(); i++){
		mp_SheepNumbers(IndexNumber,i) = sheepnums[i];
	}
	Rcpp::IntegerVector vectornums = GetGubbinsFarmPointer(AgentNumber, p_MetaPop)->GetVectorNumbers();
	assert(vectornums.size() == 4);
	for(int i=0; i<vectornums.size(); i++){
		mp_VectorNumbers(IndexNumber,i) = vectornums[i];
	}

	LOG(logINFO) << " (State=" << mp_AgentStates[IndexNumber] << ")" << std::endl;	
}

void GubbinsDemography::Reset(MetaPop* p_MetaPop){
	LOG(logINFO) << "Resetting GubbinsDemography" << std::endl;
	// Nothing to do at reset time
}

// This network only works with the exact number set up with:
bool GubbinsDemography::CheckNumberOfAgents(long InputNumber){
	return(InputNumber == m_agents);
}


GubbinsDemography:: ~GubbinsDemography(){
	
	LOG(logINFO) << "Removing GubbinsDemography" << std::endl;
	
}
