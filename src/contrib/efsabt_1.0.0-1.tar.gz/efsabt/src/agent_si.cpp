/*

 agent_si.cpp
 A simple agent with unchanging states

 Created by Matthew Denwood as part of the R package efsabt.
 Copyright 2015. All rights reserved.

 */

#include "agent_si.h"

#include "fixed_logger.h"
#include "fixed_metapop.h"
#include "fixed_network_base.h"
#include "fixed_demography_base.h"

// Constructors
SIAgent::SIAgent(AgentType AT, int InputState, MetaPop *InputMetaPop)
	: Agent(AT, InputState, InputMetaPop)
{
	AddClassPointer(AT_SIAgent);
}

void SIAgent::Initialise(){
	
	// Nothing to do here except initialsie the base Agent m_State:
	Agent::Initialise();
	
	LOG(logINFO) << "SI agent number " << m_AgentTypeID[AT_SIAgent] << " initialised" << std::endl;
	
}

void SIAgent::Infect(int InfectionForce){
	
	// Just make the agent infectious
	m_State = state_i;
}

void SIAgent::Remove(){
	// Just make the agent susceptible
	m_State = state_s;
}


SIAgent::~SIAgent(){
	// Virtual destructor
	LOG(logINFO) << "Removing SIAgent number " << GetAgentID(AT_SIAgent) << " (agent number " << GetAgentID(AT_Agent) << ")" << std::endl;
}
