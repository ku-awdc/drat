#' Obtain a (lazy-evaluated) table via SQL
#' @name vs_table
#'
#' @param table Name of table to extract (or data frame with 1 row giving Table and Schema)
#' @param schema Schema of table to extract
#' @param reset Option to reset the SQL connection before retrieving the table
#'
#' @importFrom DBI dbConnect dbDisconnect dbListTables
#' @importFrom rJava .jgc
#' @importFrom RJDBC JDBC
#' @importFrom dbplyr in_schema
#' @importFrom dplyr tbl bind_rows
#' @importFrom tibble tibble
#' @importFrom stringr str_replace
#' @importFrom sodium data_decrypt sha256
#'
#' @export
vs_table <- function(table, schema=NULL, reset=FALSE){

  conn <- get_conn(reset=reset)
  .jgc()

  tabschm <- find_table(table, schema, sql=TRUE)

  rv <- tbl(conn, in_schema(tabschm[["Schema"]], tabschm[["Table"]]))
  attr(rv, "name") <- paste0(tabschm[["Schema"]], ".", tabschm[["Table"]])
  return(rv)
}


#' @rdname vs_table
#' @export
vs_list_tables <- function(schema=NULL, reset=FALSE){

  if(is.null(schema)){
    schema <- c(vs_username(), "IVH", "EKSTERN_KU")
  }
  schema |>
    lapply(function(x) tibble(Table = dbListTables(get_conn(reset=reset), schema=x) |> as.character(), Schema = x)) |>
    bind_rows()

}

