#' Set up SQL connection
#'
#' @param username Username to use
#'
#' @importFrom keyring key_list key_set key_get key_delete
#'
#' @export
vs_setup <- function(username = NULL){

  if(is.null(username)) stop("Supplied username is invalid")

  sapply(key_list("Oracle_VetStat")$username, function(x) key_delete("Oracle_VetStat", x))

  key_set("Oracle_VetStat", username)

  invisible(vs_username())
}


#' @rdname vs_setup
#' @export
vs_username <- function(){

  usn <- key_list("Oracle_VetStat")$username

  if(length(usn)==0L) stop("VetStat user not set up - run vs_setup")
  if(length(usn)>1L) stop("There are multiple VetStat users registered - run vs_setup to reset")

  return(usn)

}
