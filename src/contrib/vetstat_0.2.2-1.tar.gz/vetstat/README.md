# vetstat

Direct access to the VetStat database (only for use by KU staff/students with database access)

You can either install the development version of the package direct from GitHub, or install a (relatively) stable version from our drat repository using:

    install.packages("vetstat", repos=c("https://cran.rstudio.com/","https://ku-awdc.github.io/drat/"))
    
To get started:

1.  Ensure you have an account and password from KU-IT for accessing the VetStat Oracle database
2.  Install Java from https://www.java.com/ (unless you already have it)
3.  Install the R package using:
	  install.packages("vetstat", repos=c("https://cran.rstudio.com/","https://ku-awdc.github.io/drat/"))
4.  Connect to the KU VPN (Cisco) using your usual account and password
5.  Run the following in R to set up VetStat access:
	   library("vetstat")
	   vs_setup(username)
	   Where username is your KU username (in uppercase) - then enter your password when prompted
6.  To see what VetStat tables are available (and in which schema) run:
	  vs_list_tables() |> print(n=Inf)
7.  To extract a specific table from a specific schema run eg:
    vs_table("VT_VETSTAT_AKTIVTSTOF_MV", "EKSTERN_KU")
8.  Use dplyr verbs to filter/select/group/summarise/join the data like you normally would with an in-memory data frame.  For a refresher on dplyr see:
    https://www.costmodds.org/teaching/voc_data_science/topic3/



TODO

- CHR_ID to CHR_NR etc lookup tables - via CGI or FVST direct, or CHR extraction (BESNR CHR, maybe GIS)?
- Get access to ”dyredage” som bruges i VetStat opgørelser
- Scripts to automatically (re-)generate data under IVH from EKSTERN_KU (and other sources) (after checking sources)
- Change names etc beween EKSTERN_KU to IVH so it makes sense
- Helper functions for creating tables under own schema
- Run dbDisconnect on package unload/unattach (if necessary)
