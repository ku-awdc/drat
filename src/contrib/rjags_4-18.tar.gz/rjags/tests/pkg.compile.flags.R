rjags::pkg.compile.flags()
