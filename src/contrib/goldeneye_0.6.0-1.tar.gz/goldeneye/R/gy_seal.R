gy_seal <- function(){
  stop("Not yet implemented")
}

gy_unseal <- function(){
  stop("Not yet implemented")
}
