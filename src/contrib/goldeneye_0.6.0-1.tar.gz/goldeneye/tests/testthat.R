library(testthat)
library(goldeneye)

test_check("goldeneye")
