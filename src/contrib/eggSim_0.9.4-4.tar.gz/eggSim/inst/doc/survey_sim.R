## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval=FALSE---------------------------------------------------------------
#  install.packages('eggSim', repos=c(CRAN="https://cran.rstudio.com/", "ku-awdc"="https://ku-awdc.github.io/drat/"))

## ----setup--------------------------------------------------------------------
library("eggSim")
library("tidyverse")

## -----------------------------------------------------------------------------
scenarios <- survey_scenario(parasite = c("ascaris","trichuris","hookworm"))
scenarios

## -----------------------------------------------------------------------------
par_1 <- survey_parameters(design = c("NS_11"), parasite = c("ascaris"), method = c("kk"))
par_1

par_all <- survey_parameters(design = c("SS_11","SS_12","NS_11","NS_12","SSR_11","SSR_12"), parasite = c("ascaris","trichuris","hookworm"), method = c("kk","miniflotac","fecpak"))
length(par_all)
par_all[[1]]

## -----------------------------------------------------------------------------
results <- survey_sim(n_individ = seq(100,1000,by=10), scenario = scenarios, parameters = par_all, iterations = 1e3, cl=2L, output="summarised")

## -----------------------------------------------------------------------------
results_full <- survey_sim(n_individ = seq(100,1000,by=10), scenario = scenarios, parameters = par_1, iterations = 1e3, cl=2L, output="full")

## -----------------------------------------------------------------------------
pp <- "ascaris"
ggplot(results |> filter(parasite==pp), aes(x=n_individ, y=(failure_n/total_n), col=design, group=design)) +
  geom_line() +
  facet_grid(mean_epg ~ method) +
  labs(col=pp)

## -----------------------------------------------------------------------------
ggplot(results |> filter(parasite==pp), aes(x=n_individ, y=proportion_below, col=design, group=design)) +
    geom_line() +
    facet_grid(mean_epg ~ method) +
    labs(col=pp)

## -----------------------------------------------------------------------------
ggplot(results |> filter(parasite==pp), aes(x=-cost_mean, y=proportion_below, col=design, group=design)) +
  geom_line() +
  facet_grid(mean_epg ~ method) +
  labs(col=pp)

## -----------------------------------------------------------------------------
ggplot(results |> filter(parasite==pp), aes(x=-cost_mean, y=proportion_below, col=design, group=design)) +
  geom_line() +
  facet_grid(mean_epg ~ method) +
  labs(col=pp) +
  coord_cartesian(ylim=c(0.5, NA))

## ----eval=FALSE---------------------------------------------------------------
#  ?`eggSim-package`

## -----------------------------------------------------------------------------
sessionInfo()

