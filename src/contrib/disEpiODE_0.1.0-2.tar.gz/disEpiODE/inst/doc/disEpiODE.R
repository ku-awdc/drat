## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width=7
)

## ----eval=FALSE---------------------------------------------------------------
#  install.packages("disEpiODE",
#    repos=c("https://cran.rstudio.com/", "https://ku-awdc.github.io/drat/"))

## ----eval=FALSE---------------------------------------------------------------
#  install.packages("remotes")  # if necessary
#  remotes::install_github("https://github.com/ku-awdc/disEpiODE")

## -----------------------------------------------------------------------------
library("disEpiODE")
# vignette("disEpiODE", package="disEpiODE")

## -----------------------------------------------------------------------------
library("sf")
library("ggplot2")
theme_set(theme_light())

## -----------------------------------------------------------------------------
landscape <- create_landscape(scale=1.0)
ggplot(landscape) + geom_sf()

## -----------------------------------------------------------------------------
grid <- create_grid(landscape, patch_area = 0.001, 
  grid_type = "hexagon", rotate=0)
ggplot() +
  geom_sf(data=landscape) +
  geom_sf(data=grid)

## -----------------------------------------------------------------------------
grid_sq <- create_grid(landscape, patch_area = 0.01, 
  grid_type = "square")
ggplot() +
  geom_sf(data=landscape) +
  geom_sf(data=grid_sq)

## -----------------------------------------------------------------------------
grid_tri <- create_grid(landscape, patch_area = 0.002, 
  grid_type = "triangle", rotate=15)
ggplot() +
  geom_sf(data=landscape) +
  geom_sf(data=grid_tri)

## -----------------------------------------------------------------------------
nrow(grid); 1/0.001
nrow(grid_sq); 1/0.01
nrow(grid_tri); 1/0.002

## -----------------------------------------------------------------------------
farms <- create_farm_placement(landscape)
ggplot() +
  geom_sf(data=landscape) +
  geom_sf(aes(col=label), data=farms)

## -----------------------------------------------------------------------------
overlap <- create_farm_overlap(grid, farms)
init <- create_initial_state(grid, overlap, start_prev=0.5)

## -----------------------------------------------------------------------------
kernel <- create_kernel("half-normal", sigma=0.08456)
kernel(seq(0,0.5,by=0.1))

## -----------------------------------------------------------------------------
beta_matrix <- create_transmission_matrix(grid, kernel, beta_baseline=0.05)
nrow(grid)
dim(beta_matrix)
beta_matrix[1:5,1:5]

## -----------------------------------------------------------------------------
taufun <- create_si_model(grid, beta_matrix, init, overlap, root="B")
(tau <- taufun(prevalence=0.5))

## -----------------------------------------------------------------------------
trajfun <- create_si_model(grid, beta_matrix, init, overlap, root="none")
results <- trajfun(time=seq(0, round(tau$Time[1]*2), by=10))
ggplot(results, aes(x=Time, y=Prevalence, col=Area)) + 
  geom_line() + 
  geom_hline(yintercept=0.5, lty="dashed") +
  geom_vline(xintercept=tau$Time[1], lty="dotted")

## -----------------------------------------------------------------------------
library("dplyr")
library("tibble")

landscape <- create_landscape(scale=1.0)
farms <- create_farm_placement(landscape)
kernel <- create_kernel("exponential", sigma=12.616)

tibble(PatchArea = 10^seq(0,-3,by=-0.05)) %>%
  rowwise() %>%
  group_split() %>%
  lapply(function(x){
    
    grid <- create_grid(landscape, patch_area = x$PatchArea, 
      grid_type="triangle", rotate=0)
    overlap <- create_farm_overlap(grid, farms)
    init <- create_initial_state(grid, overlap, start_prev=0.5)
    beta_matrix <- create_transmission_matrix(grid, kernel, beta_baseline=0.05)
    taufun <- create_si_model(grid, beta_matrix, init, overlap, root="B")
    tau <- taufun(prevalence=0.5)
    
    bind_cols(x, tau)
  }) %>%
  bind_rows() ->
  results
  

ggplot(results %>% filter(Area=="Population"), aes(x=PatchArea, y=Time)) +
  geom_line() +
  scale_x_log10_rev()

ggplot(results, aes(x=PatchArea, y=Prevalence, col=Area)) +
  geom_line() +
  scale_x_log10_rev()


