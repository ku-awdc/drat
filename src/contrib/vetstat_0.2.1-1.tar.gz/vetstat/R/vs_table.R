#' Obtain a (lazy-evaluated) table via SQL
#' @name vs_table
#'
#' @param table_name Name of table to extract (or data frame with 1 row giving Table and Schema)
#' @param schema Schema of table to extract
#' @param reset Option to reset the SQL connection before retrieving the table
#'
#' @importFrom DBI dbConnect dbDisconnect dbListTables
#' @importFrom rJava .jgc
#' @importFrom RJDBC JDBC
#' @importFrom dbplyr in_schema
#' @importFrom dplyr tbl bind_rows
#' @importFrom tibble tibble
#' @importFrom stringr str_replace
#' @importFrom sodium data_decrypt sha256
#'
#' @export
vs_table <- function(table_name, schema=NULL, reset=FALSE){

  conn <- get_conn(reset=reset)
  .jgc()

  if(is.data.frame(table_name)){
    stopifnot(nrow(table_name)==1L)
    if("Schema" %in% names(table_name)) schema <- table_name[["Schema"]]
    stopifnot("Table" %in% names(table_name))
    table_name <- table_name[["Table"]]
  }
  if(is.null(schema)){
    schema <- vs_username()
  }
  rv <- tbl(conn, in_schema(schema, table_name))
  attr(rv, "name") <- paste0(schema, ".", table_name)
  return(rv)
}


#' @rdname vs_table
#' @export
vs_list_tables <- function(schema=NULL, reset=FALSE){

  if(is.null(schema)){
    schema <- c(vs_username(), "IVH", "EKSTERN_KU")
  }
  schema |>
    lapply(function(x) tibble(Table = dbListTables(get_conn(reset=reset), schema=x) |> as.character(), Schema = x)) |>
    bind_rows()

}

