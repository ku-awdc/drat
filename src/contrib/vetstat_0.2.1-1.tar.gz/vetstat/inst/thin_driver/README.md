The Oracle JDBC (thin driver) is temporarily embedded within this R package, but can be freely downloaded separately from:

https://www.oracle.com/dk/database/technologies/appdev/jdbc-downloads.html

TODO:  Investigate licensing issues and the most appropriate way of distributing the .jar (e.g. as a separate download function within the R package, if re-distribution is not allowed and/or licenses are incompatible)
