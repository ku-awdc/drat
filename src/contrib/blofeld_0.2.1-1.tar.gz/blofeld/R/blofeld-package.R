#' @keywords internal
"_PACKAGE"

# The following block is used by usethis to automatically manage
# roxygen namespace tags. Modify with care!
## usethis namespace: start
#' @importFrom Rcpp loadModule
#' @useDynLib blofeld, .registration = TRUE
## usethis namespace: end
NULL
