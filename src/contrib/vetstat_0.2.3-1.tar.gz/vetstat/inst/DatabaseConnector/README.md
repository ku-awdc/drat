This can be re-obtained by running:

DatabaseConnector::downloadJdbcDrivers("oracle", pathToDriver=getwd())

TODO:  Investigate licensing issues and the most appropriate way of distributing the .jar (e.g. as a separate download function within the R package, if re-distribution is not allowed and/or licenses are incompatible), and rationalising with the thin driver in the other folder under inst
