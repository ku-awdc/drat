#' @importFrom rJava .jinit .jcall .jnew
## Internal functions, not exported

find_table <- function(table, schema=NULL, sql=TRUE){

  if(!is.null(schema)) return(list(Table=table, Schema=schema))

  if(is.data.frame(table)){
    stopifnot(nrow(table)==1L)
    if("Schema" %in% names(table)) schema <- table[["Schema"]]
    stopifnot("Table" %in% names(table))
    table <- table[["Table"]]
    return(list(Table=table, Schema=schema))
  }

  if(sql){
    vs_list_tables() |>
      filter(.data$Table == table) ->
      matches
  }else{
    vs_directory() |>
      filter(.data$Table == table) ->
      matches
  }

  if(nrow(matches)==0L) stop("Specified table '", table, "' does not exist")
  if(nrow(matches)>1L) stop("Specified table '", table, "' has multiple matches: please specify schema")

  return(matches)
}

get_conn <- function(username = vs_username(), reset=FALSE, min_ram=8, type="JDBC"){

  if(type=="JDBC"){
    conn <- get_conn_jdbc(username=username, reset=reset, min_ram=min_ram)
  }else if(type=="DatabaseConnector"){
    stop("Not currently available")
    conn <- get_conn_dc(username=username, reset=reset, min_ram=min_ram)
  }else{
    stop("Unrecognised SQL connection type")
  }

  if(conn$new){
    expdt <- dbGetQuery(conn$conn, "select * from USER_USERS") |> pull("EXPIRY_DATE")
    cat("New SQL connection established via ", type, "\n** Remember to change your password before ", as.character(as.Date(expdt)), "!!! **\n", sep="")
  }

  return(conn$conn)
}

get_conn_jdbc <- function(username = vs_username(), reset=FALSE, min_ram=8){

  newconn <- FALSE
  if(isTRUE(reset) || is.null(vs_env$active) || !isTRUE(vs_env$active)){

    jpar <- getOption("java.parameters")
    if(is.null(jpar) || (length(jpar)==1L && jpar=="-Xmx512m")){
      options(java.parameters = "-Xmx8g")
    }

    if(isTRUE(vs_env$active)){
      warning("Resetting active database connection: you should re-extract any tables you wish to join on the server")
      dbDisconnect(vs_env$jdbcConnection)
      vs_env$jdbcConnection <- NULL
    }else{
      .jinit()
      jram <- .jcall(.jnew("java/lang/Runtime"), "J", "maxMemory") / 1e9
      if(jram < min_ram){
        warning('You only have ', round(jram, 2), 'GB of RAM available to JAVA - restart R and then run e.g. options(java.parameters = "-Xmx8g") BEFORE loading the vetstat (or rJava) package')
      }
    }

    cstr_obfs |>
      unserialize() |>
      data_decrypt("vetstat" |> charToRaw() |> sha256()) |>
      unserialize() ->
      cstr

    vs_env$jdbcDriver <- JDBC("oracle.jdbc.OracleDriver", classPath = system.file("thin_driver","ojdbc8.jar",package="vetstat"))
    vs_env$jdbcConnection <- dbConnect(vs_env$jdbcDriver, cstr, username, key_get("Oracle_VetStat", username=vs_username()))
    vs_env$active <- TRUE
    newconn <- TRUE
  }

  ss <- try({
    ## List obtained from the bottom of the backend-Oracle file:
    dbplyr_edition.JDBCConnection <<- dbplyr:::dbplyr_edition.Oracle
    sql_query_select.JDBCConnection <<- dbplyr:::sql_query_select.Oracle
    sql_query_upsert.JDBCConnection <<- dbplyr:::sql_query_upsert.Oracle
    sql_translation.JDBCConnection <<- dbplyr:::sql_translation.Oracle
    sql_query_explain.JDBCConnection <<- dbplyr:::sql_query_explain.Oracle
    sql_table_analyze.JDBCConnection <<- dbplyr:::sql_table_analyze.Oracle
    sql_query_save.JDBCConnection <<- dbplyr:::sql_query_save.Oracle
    sql_values_subquery.JDBCConnection <<- dbplyr:::sql_values_subquery.Oracle
    setdiff.JDBCConnection <<- dbplyr:::setdiff.tbl_Oracle
    sql_expr_matches.JDBCConnection <<- dbplyr:::sql_expr_matches.Oracle
    db_supports_table_alias_with_as.JDBCConnection <<- dbplyr:::db_supports_table_alias_with_as.Oracle
  })
  if(inherits(ss, "try-error")) warning("Unable to set one or more SQL translation method - please report this to Matt")

  #sql_translation.JDBCConnection <<- dbplyr:::sql_translation.Oracle
  #sql_select.JDBCConnection <<- dbplyr:::sql_query_select.Oracle
  #sql_subquery.JDBCConnection <<- dbplyr:::sql_query_wrap.Oracle

  return(list(conn=vs_env$jdbcConnection, new=newconn))

}

get_conn_dc <- function(username = vs_username(), reset=FALSE, min_ram=8){

  newconn <- FALSE
  if(isTRUE(reset) || is.null(vs_env$active) || !isTRUE(vs_env$active)){

    jpar <- getOption("java.parameters")
    if(is.null(jpar) || (length(jpar)==1L && jpar=="-Xmx512m")){
      options(java.parameters = "-Xmx8g")
    }

    if(isTRUE(vs_env$active)){
      warning("Resetting active database connection: you should re-extract any tables you wish to join on the server")
      dbDisconnect(vs_env$jdbcConnection)
      vs_env$jdbcConnection <- NULL
    }else{
      .jinit()
      jram <- .jcall(.jnew("java/lang/Runtime"), "J", "maxMemory") / 1e9
      if(jram < min_ram){
        warning('You only have ', round(jram, 2), 'GB of RAM available to JAVA - restart R and then run e.g. options(java.parameters = "-Xmx8g") BEFORE loading the vetstat (or rJava) package')
      }
    }

    cstr_obfs |>
      unserialize() |>
      data_decrypt("vetstat" |> charToRaw() |> sha256()) |>
      unserialize() ->
      cstr

    vs_env$jdbcDriver <- JDBC("oracle.jdbc.OracleDriver", classPath = system.file("DatabaseConnector","ojdbc8.jar",package="vetstat"))
    vs_env$jdbcConnection <- dbConnect(vs_env$jdbcDriver, cstr, username, key_get("Oracle_VetStat", username=vs_username()))
    vs_env$active <- TRUE
    newconn <- TRUE
  }

  return(list(conn=vs_env$jdbcConnection, new=newconn))

}


vs_env <- new.env()

cstr_obfs <- as.raw(c(0x58, 0x0a, 0x00, 0x00, 0x00, 0x03, 0x00, 0x04, 0x03,
                      0x00, 0x00, 0x03, 0x05, 0x00, 0x00, 0x00, 0x00, 0x05, 0x55, 0x54,
                      0x46, 0x2d, 0x38, 0x00, 0x00, 0x02, 0x18, 0x00, 0x00, 0x00, 0xbb,
                      0xe9, 0x40, 0x3c, 0x3b, 0xe2, 0x47, 0x92, 0x6b, 0xad, 0x99, 0xfa,
                      0x8b, 0xac, 0x89, 0xb1, 0x16, 0x3c, 0xdb, 0xf9, 0x24, 0x46, 0xa0,
                      0xfc, 0x24, 0xb1, 0xa0, 0x3f, 0x28, 0x15, 0x61, 0x0f, 0xea, 0x7b,
                      0x06, 0x61, 0x8a, 0x06, 0xf4, 0xb1, 0xf0, 0xc5, 0xaf, 0xe8, 0x42,
                      0x82, 0x19, 0xfb, 0xb1, 0x67, 0xbf, 0x66, 0xd6, 0x6f, 0xf7, 0xfb,
                      0x43, 0xc0, 0xb4, 0xd5, 0x4f, 0x96, 0x15, 0x6c, 0x79, 0x2a, 0x0b,
                      0x4f, 0x79, 0xc0, 0xd6, 0x49, 0xee, 0xa7, 0x15, 0xfa, 0xd3, 0xbf,
                      0x93, 0xf1, 0xb2, 0xbc, 0x9b, 0x0f, 0x73, 0x94, 0x92, 0x4f, 0xa5,
                      0x0b, 0x4f, 0x6f, 0xa7, 0x5e, 0xce, 0x4b, 0x79, 0x4f, 0x8d, 0x2a,
                      0x9b, 0xce, 0xb0, 0x95, 0xc9, 0x00, 0x60, 0xca, 0x47, 0x74, 0xcc,
                      0x51, 0x25, 0x75, 0x74, 0x14, 0x9b, 0x83, 0xdf, 0x3f, 0xa0, 0xd2,
                      0x2a, 0xaa, 0x22, 0xc8, 0x82, 0x1e, 0xf4, 0x9a, 0x01, 0x74, 0xd1,
                      0x55, 0x25, 0x49, 0x3e, 0x1e, 0x5f, 0xa2, 0x36, 0x17, 0x04, 0xdf,
                      0x85, 0x90, 0xcd, 0xb1, 0xa2, 0x13, 0x17, 0xb7, 0x66, 0x0c, 0xae,
                      0xdc, 0x71, 0x17, 0xf7, 0xfe, 0x0d, 0x89, 0xde, 0xda, 0x14, 0xc1,
                      0x17, 0x78, 0x78, 0x0b, 0x7c, 0xe9, 0x58, 0x18, 0xdf, 0xb9, 0x58,
                      0x77, 0x58, 0xed, 0xe8, 0x00, 0x50, 0x65, 0xf3, 0x92, 0xff, 0x3b,
                      0x00, 0x00, 0x04, 0x02, 0x00, 0x00, 0x00, 0x01, 0x00, 0x04, 0x00,
                      0x09, 0x00, 0x00, 0x00, 0x05, 0x6e, 0x6f, 0x6e, 0x63, 0x65, 0x00,
                      0x00, 0x00, 0x18, 0x00, 0x00, 0x00, 0x18, 0x7d, 0x39, 0x6e, 0x24,
                      0xe2, 0xf7, 0xa5, 0xf9, 0xae, 0x9f, 0xbd, 0x9c, 0x92, 0xcc, 0x8a,
                      0x6c, 0x23, 0x4b, 0xfc, 0xf0, 0xb6, 0x8d, 0x0b, 0x3f, 0x00, 0x00,
                      0x00, 0xfe))
