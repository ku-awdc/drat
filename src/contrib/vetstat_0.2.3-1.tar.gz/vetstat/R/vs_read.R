#' Read a previously saved VetStat table, and list available saved tables
#' @name vs_read
#'
#' @param table name of the table to extract
#' @param schema name of the schema containing the table, or to list tables from (optional)
#' @param process_chunks a function to be used to process each chunk before returning - required for large data frames to reduce memory consumption
#' @param chunks which chunk(s) should be read back in (optional)
#' @param max_chunks a maximum number of chunks to return unprocessed
#' @param path folder containing saved output
#'
#' @export
vs_read <- function(table, schema=NULL, process_chunks=identity, chunks=NULL, max_chunks=50L){

  ## Note:  all of EKSTERN_KU.VT_VETSTAT_BEREGN_DOSER_MV i.e. 45 chunks takes 6.1 GB
  ## TODO:  look for use of group_by or summarise in body of process and return error

  tabschm <- find_table(table, schema, sql=FALSE)
  schema <- tabschm[["Schema"]]
  table <- tabschm[["Table"]]
  path <- file.path(vs_env$directory, paste0(schema, ".", table))

  if(!dir.exists(path)) stop("No matching folder")
  if(!file.exists(file.path(path, "info.rqs"))) stop("No info.rqs within specified folder")

  info <- qread(file.path(path, "info.rqs"))

  #info <- read_csv(file.path(path, "info.csv"), col_types=cols(
  #  Chunk = col_double(),
  #  Min = col_datetime(format = ""),
  #  Max = col_datetime(format = ""),
  #  Extracted = col_datetime(format = ""),
  #  Rows = col_double(),
  #  Name = col_character()
  # ))
  ## Note:  tz will be UTC not Europe/Copenhagen

  stopifnot(is.function(process_chunks))
  if(is.null(chunks) && identical(process_chunks, identity) && nrow(info)>max_chunks){
    stop("You are trying to return more than max_chunks without a processing function: specify a process_chunks function to reduce memory usage (i.e. either including filter, select or both) and try again")
  }
  funbody <- body(process_chunks) |> as.character()
  if(any(grepl("group_by", funbody)) || any(grepl("summarise", funbody))) stop("You can't use group_by or summarise in the process_chunks function")


  if(is.null(chunks)) chunks <- info[["Chunk"]]

  if(!all(chunks %in% info[["Chunk"]])) stop("Invalid chunk(s) specified")

  rv <- pblapply(chunks, function(c) qread(file.path(path, info[["Name"]][c])) |> process_chunks()) |> bind_rows()
  attr(rv, "extracted") <- info[["Extracted"]][chunks] |> max()
  attr(rv, "name") <- paste0(schema, ".", table)

  return(rv)
}

#' @rdname vs_read
#' @export
vs_directory <- function(schema = NULL){

  if(is.null(vs_env$directory)) stop("You need to run vs_set_directory")

  qread(file.path(vs_env$directory, "tables.rqs")) |>
    select(.data$Table, .data$Schema)

}

#' @rdname vs_read
#' @export
vs_set_directory <- function(path){

  stopifnot(is.character(path), length(path)==1L, !is.na(path))
  if(!dir.exists(path)) stop("The specified directory '", path, "' does not exist")
  if(!file.exists(file.path(path, "tables.rqs"))) stop("The specified directory '", path, "' does not appear to be valid (missing tables.rqs)")

  vs_env$directory <- path
}
