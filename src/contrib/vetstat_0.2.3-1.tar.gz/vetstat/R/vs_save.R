#' Save SQL tables to a file, and subsequently read from that file
#' @name vs_save
#'
#' @param table_name Name of table to extract (or data frame with 1 row giving Table and Schema)
#' @param schema Schema of table to extract
#' @param path folder to save output to
#' @param max_rows maximum number of rows to read via SQL in one chunk
#'
#' @importFrom dplyr pull count n group_split select mutate case_when collect filter
#' @importFrom rlang .data
#' @importFrom qs qsave qread
#' @importFrom stats quantile
#' @importFrom readr write_csv
#' @importFrom pbapply pblapply
#' @importFrom lubridate tz tz<- format_ISO8601
#'
#' @export
vs_save <- function(table_name, schema=NULL, path=getwd(), max_rows=1e6){

  tab <- vs_table(table_name, schema)

  if(!dir.exists(path)){
    stop("Specified path (", path, ") does not exist")
  }
  if(dir.exists(file.path(path, attr(tab, "name")))){
    stop("Save folder (", file.path(path, attr(tab, "name")), ") already exists")
  }
  dir.create(file.path(path, attr(tab, "name")))

  cat("Saving ", attr(tab, "name"), " to ", path, "...\n", sep="")
  st <- Sys.time()

  rows <- tab |> count() |> pull(n)

  if(rows > max_rows){

    stopifnot("OPRETTET_DATO" %in% (tab |> names()))
    oprd <- tab |> pull(.data$OPRETTET_DATO)
    breaks <- quantile(oprd, probs=seq(0,1,length.out=(rows %/% max_rows)+2L))
    breaks[1L] <- breaks[1L]-60

    tibble(Chunk = seq(1,length(breaks)-1L,by=1L), Min=breaks[-length(breaks)], Max=breaks[-1L]) |>
      mutate(Extracted = as.Date(NA_character_), Rows = NA_integer_, Name = case_when(
        max(.data$Chunk) == 1L ~ str_c(attr(tab, "name"), ".rqs"),
        TRUE ~ str_c(attr(tab, "name"), ".", format(.data$Chunk) |> str_replace(" ", "0"), ".rqs")
      )) |>
      group_split(.data$Name) |>
      pblapply(function(x){
        minoprd <- as.character(strftime(x[["Min"]], format="%Y-%m-%d %H:%M:%S"))
        maxoprd <- as.character(strftime(x[["Max"]], format="%Y-%m-%d %H:%M:%S"))

        ## https://www.sqlines.com/oracle-to-sql-server/to_date
        tab |>
          filter(.data$OPRETTET_DATO > to_date(minoprd, "YYYY-MM-DD HH24:MI:SS"),
                 .data$OPRETTET_DATO <= to_date(maxoprd, "YYYY-MM-DD HH24:MI:SS")) |>
          collect() ->
          tdat

        qsave(tdat, file=file.path(path, attr(tab, "name"), x[["Name"]]))

        x[["Rows"]] <- nrow(tdat)
        x[["Extracted"]] <- Sys.time()

        return(x)
      }) |>
      bind_rows() ->
      info

    tz(info[["Min"]]) <- Sys.timezone()
    tz(info[["Max"]]) <- Sys.timezone()
    qsave(info, file=file.path(path, attr(tab, "name"), "info.rqs"))

    info[["Min"]] <- format_ISO8601(info[["Min"]], usetz=TRUE)
    info[["Max"]] <- format_ISO8601(info[["Max"]], usetz=TRUE)

  }else{

    tibble(Chunk = 1L, Extracted = as.Date(NA_character_), Rows = NA_integer_, Name = case_when(
      max(.data$Chunk) == 1L ~ str_c(attr(tab, "name"), ".rqs"),
      TRUE ~ str_c(attr(tab, "name"), ".", format(.data$Chunk) |> str_replace(" ", "0"), ".rqs")
    )) |>
      group_split(.data$Name) |>
      pblapply(function(x){
        tab |>
          collect() ->
          tdat

        qsave(tdat, file=file.path(path, attr(tab, "name"), x[["Name"]]))

        x[["Rows"]] <- nrow(tdat)
        x[["Extracted"]] <- Sys.time()

        return(x)
      }) |>
      bind_rows() ->
      info

    qsave(info, file=file.path(path, attr(tab, "name"), "info.rqs"))
  }

  write_csv(info, file=file.path(path, attr(tab, "name"), "info.csv"))
  if(sum(info[["Rows"]])!=rows){
    warning("Mismatch between total rows saved (", sum(info[["Rows"]]), ") and total rows in database (", rows, ")")
  }

  cat("Done (total time: ", round(as.numeric(Sys.time()-st, units="secs")/60, 1), " minutes)\n", sep="")

  invisible(info)
}
