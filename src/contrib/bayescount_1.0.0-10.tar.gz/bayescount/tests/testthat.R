library(testthat)
library(bayescount)

test_check("bayescount")
