# bayescount
An R package for Statistical Analyses and Sample Size Calculations for Over-dispersed Count Data

For more information on the objectives and methods underlying this R package, see [this page](https://www.fecrt.com/framework)
