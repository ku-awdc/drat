## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup---------------------------------------------------------------
library("bayescount")
library('dplyr')
library('ggplot2')

## ------------------------------------------------------------------------
# Pre-treatment data:
data_1 <- c(14, 22, 7, 29, 11, 1, 39, 6, 3, 0)
# Post-treatment data:
data_2 <- c(0, 2, 1, 1, 2, 0, 5, 2, 0, 3)
efficacy_analysis(data_1, data_2, paired=TRUE, T_I=0.95, T_A=0.9)

cbind(pre=data_1, post=data_2)

## ------------------------------------------------------------------------
mean(data_1)
mean(data_2)

cov(cbind(pre=data_1, post=data_2))
cor(data_1, data_2)

## ------------------------------------------------------------------------
( efficacy <- 100* (1- mean(data_2)/mean(data_1)) )
efficacy_analysis(data_1, data_2, paired=TRUE, T_I=0.95, T_A=0.85)

## ------------------------------------------------------------------------
efficacy_analysis(data_1, data_2, paired=FALSE, T_I=0.95, T_A=0.85)

## ----eval=FALSE, include=TRUE--------------------------------------------
#  launch_shiny("data_analysis")

## ------------------------------------------------------------------------
efficacy_typologies(sum=c(400,20), N=c(10,10), k=c(1,1), cor=0.25, paired = TRUE,
                    T_I = 0.99, T_A = 0.95)

## ----eval=FALSE, include=TRUE--------------------------------------------
#  launch_shiny("typologies")

## ------------------------------------------------------------------------
sums <- c(sum(data_1), sum(data_2))
Ns <- c(length(data_1), length(data_2))
vars <- c(var(data_1), var(data_2))
ks <- (sums/Ns)^2 / (vars - sums/Ns)
cor <- cor(data_1, data_2)
efficacy_typologies(sums, Ns, ks, cor, paired=TRUE, T_I=0.95, T_A=0.85)
efficacy_analysis(data_1, data_2, paired=TRUE, T_I=0.95, T_A=0.85, use_ml=FALSE)

## ------------------------------------------------------------------------
typologies <- efficacy_frequencies(r=c(0.95, 0.99), paired = TRUE, T_I = 0.99, T_A = 0.95,
                    N = c(20, 20), mean=20, k=c(1,1), cor=0.25, iterations = 10^3)

library('dplyr')
typologies %>% filter(Method=='BNB')

## ------------------------------------------------------------------------
classifications <- typologies %>%
  group_by(Method, Efficacy, Classification) %>%
  summarise(Frequency = sum(Frequency), Proportion = sum(Proportion)) %>%
  ungroup()

classifications %>% filter(Method == 'BNB')

ggplot(classifications, aes(x=Method, y=Proportion, fill=Classification)) +
  geom_bar(stat='identity') +
  facet_wrap(~ paste0(Efficacy*100,"% efficacy")) +
	coord_flip()

## ----eval=FALSE, include=TRUE--------------------------------------------
#  launch_shiny("study_planning")

## ----bigsim--------------------------------------------------------------
# Values used for this vignette to reduce running time:
iters <- 10^2
by <- 0.025
Ns <- c(20, 91)

# Values used for the paper:
# iters <- 10^4
# by <- 0.001
# Ns <- c(20, 91, 1000)

# Set up the simulation parameters:
simpars <- structure(list(Parasite = c("Ascaris", "Hookworm", "Trichuris"
), Target = c(0.95, 0.7, 0.5), Delta = c(0.05, 0.05, 0.05), mu = c(1255, 
74, 162), k1 = c(0.08, 0.84, 0.92), k2 = c(0.0512, 0.58, 0.53
), cor = c(0.67, 0.65, 0.68)), class = "data.frame", row.names = c(NA, 
-3L))

simpars

simpars <- simpars %>%
	mutate(T_I=Target, T_A=Target-Delta, iters=iters, by=by) %>%
	full_join(expand.grid(Parasite=unique(simpars$Parasite), N=Ns, stringsAsFactors=FALSE),
	          by='Parasite')

# Run the Monte Carlo simulation:
results <- do.call('rbind', lapply(seq_len(nrow(simpars)), function(i){
  t <- Sys.time()
  
  pp <- simpars[i,,drop=FALSE]
  r <- seq(0, 1, by=pp$by)
  typologies <- efficacy_frequencies(r, paired = TRUE, T_I = pp$T_I, T_A = pp$T_A, 
          N = pp$N, mean=pp$mu, k=c(pp$k1,pp$k2), cor=pp$cor, iterations = pp$iters)
  
  cat("Time taken for parameter set ", i, ": ",
      round(as.numeric(Sys.time()-t, units='mins'),2), " minutes\n", sep="")
  rv <- typologies %>% mutate(Parasite = pp$Parasite, N = pp$N,
                              T_I = pp$T_I, T_A = pp$T_A)
  return( rv )
}))

# Summarise the results in the format needed for the figures:
classifications <- results %>%
	group_by(Parasite, N, T_I, T_A, Method, Efficacy, Classification) %>%
  summarise(Frequency = sum(Frequency), Proportion = sum(Proportion)) %>%
  ungroup() %>%
  mutate(N=factor(N)) %>%
	mutate(Parasite=factor(Parasite, levels=c('Hookworm','Ascaris','Trichuris')))

str(classifications)

inferiority_test <- results %>%
  filter(Classification %in% c('Reduced','Borderline')) %>%
	group_by(Parasite, N, T_I, T_A, Method, Efficacy) %>%
  summarise(Frequency = sum(Frequency), Probability = sum(Proportion)) %>%
  ungroup() %>%
  mutate(N=factor(N)) %>%
	mutate(Parasite=factor(Parasite, levels=c('Hookworm','Ascaris','Trichuris')))

str(inferiority_test)

equivalence_test <- results %>%
  filter(Classification %in% c('Adequate','Borderline')) %>%
	group_by(Parasite, N, T_I, T_A, Method, Efficacy) %>%
  summarise(Frequency = sum(Frequency), Probability = sum(Proportion)) %>%
  ungroup() %>%
  mutate(N=factor(N)) %>%
	mutate(Parasite=factor(Parasite, levels=c('Hookworm','Ascaris','Trichuris')))

str(equivalence_test)


## ----fig2----------------------------------------------------------------
theme_set(theme_light())

cols <- c("#F8766D","#619CFF","purple","#00BA38","orange")
names(cols) <- c("Reduced","Inconclusive","Borderline","Adequate","Method_Failure")
plnames <- c('Typology 1 (Reduced)', 'Typology 2 (Inconclusive)', 
             'Typology 3 (Borderline)', 'Typology 4 (Adequate)', "Failed")

ggplot(classifications %>%
         filter(N=='91', Efficacy <= T_I+0.1, Efficacy >= T_A-0.1), 
       aes(x=Efficacy*100, y=Proportion, col=Classification,
           fill=Classification)) +
	geom_bar(stat='identity', alpha=0.75) +
	scale_colour_manual(labels=plnames, values=cols) +
	scale_fill_manual(labels=plnames, values=cols) +
	geom_vline(aes(xintercept=T_A*100), col='black', lty='dashed') +
	geom_vline(aes(xintercept=T_I*100), col='black', lty='solid') +
	facet_grid(Method ~ Parasite, scales='free_x') +
	xlab('Simulated Efficacy (%)') +
	ylab(NULL) + 
	scale_y_continuous(labels=NULL) +
	scale_x_continuous(breaks=seq(0,100,by=5)) +
	theme(legend.position='bottom', legend.title=element_blank())


## ----figs1234------------------------------------------------------------
hcol <- 'grey'
hlty <- 'dashed'
vcol <- 'grey'
vlty <- 'dashed'

ggplot(inferiority_test %>% filter(Efficacy >= T_I), 
       aes(x=Efficacy*100, y=Probability, col=N)) +
	geom_line() +
	geom_hline(yintercept=0.025, col=hcol, lty=hlty) +
	facet_grid(Method ~ Parasite, scales='free') +
	ylab("Inferiority Test:  Type I Error Rate") + 
  xlab('Simulated Efficacy (%)') + ggtitle('Figure S1')

ggplot(inferiority_test %>% filter(Efficacy < T_I), 
       aes(x=Efficacy*100, y=1-Probability, col=N)) +
	geom_line() +
	geom_vline(aes(xintercept=T_A*100), data=simpars, col=vcol, lty=vlty) +
	facet_grid(Method ~ Parasite, scales='free') +
	ylab("Inferiority Test:  Type II Error Rate") + 
  xlab('Simulated Efficacy (%)') + ggtitle('Figure S2')

ggplot(equivalence_test %>% filter(Efficacy <= T_A), 
       aes(x=Efficacy*100, y=Probability, col=N)) +
	geom_line() +
	geom_hline(yintercept=0.025, col=hcol, lty=hlty) +
	facet_grid(Method ~ Parasite, scales='free') +
	ylab("Non-Inferioirty Test:  Type I Error Rate") + 
  xlab('Simulated Efficacy (%)') + ggtitle('Figure S3')

ggplot(equivalence_test %>% filter(Efficacy > T_A), 
       aes(x=Efficacy*100, y=1-Probability, col=N)) +
	geom_line() +
	geom_vline(aes(xintercept=T_I*100), data=simpars, col=vcol, lty=vlty) +
	facet_grid(Method ~ Parasite, scales='free') +
	ylab("Non-Inferioirty Test:  Type II Error Rate") + 
  xlab('Simulated Efficacy (%)') + ggtitle('Figure S4')

