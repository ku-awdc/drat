# vetstat
direct access to the VetStat database (only for use by KU staff/students with database access)
