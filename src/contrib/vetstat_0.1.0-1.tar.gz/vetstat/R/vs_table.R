#' Title
#'
#' @param table_name
#' @param schema
#'
#' @importFrom DBI dbConnect dbListTables
#' @importFrom RJDBC JDBC
#' @importFrom dbplyr in_schema
#' @importFrom dplyr tbl bind_rows
#' @importFrom tibble tibble
#' @importFrom stringr str_replace
#'
#' @export
vs_table <- function(table_name, schema=NULL){

  tbl(get_conn(), in_schema(schema, table_name))

}


#' @rdname vs_setup
#' @export
vs_list_tables <- function(schema=NULL){

  if(is.null(schema)){
    schema <- c(str_replace(vs_username(), "\\[IVH\\]", ""), "IVH", "EKSTERN_KU")
  }
  schema |>
    lapply(function(x) tibble(Table = dbListTables(get_conn(), schema=x) |> as.character(), Schema = x)) |>
    bind_rows()

}


get_conn <- function(){

  if(is.null(vs_env$active) || !isTRUE(vs_env$active)){
    usn <- vs_username()
    vs_env$jdbcDriver <- JDBC("oracle.jdbc.OracleDriver", classPath = system.file("thin_driver","ojdbc11.jar",package="vetstat"))
    vs_env$jdbcConnection <- dbConnect(vs_env$jdbcDriver, "jdbc:oracle:thin:@(DESCRIPTION=(Address=(protocol=tcp)(Host=vstodb01fl.unicph.domain)(Port=1521))(Connect_data=(Service_Name=PVST)))",usn,key_get("Oracle_VetStat", username=usn))
  }

  sql_translation.JDBCConnection <<- dbplyr:::sql_translation.Oracle
  sql_select.JDBCConnection <<- dbplyr:::sql_query_select.Oracle
  sql_subquery.JDBCConnection <<- dbplyr:::sql_query_wrap.Oracle

  return(vs_env$jdbcConnection)

}


vs_env <- new.env()
