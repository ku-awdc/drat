#' BirthFemaleEvents
#'
#' An example dataset needed to run the model
#' TODO: expand
#'
#' @format ## `BirthFemaleEvents`
#' A data frame with ?? rows and ?? columns
#' \describe{
#'   \item{X1}{TODO}
#' }
"BirthFemaleEvents"

#' CullingRates
#'
#' An example dataset needed to run the model
#' TODO: expand
#'
#' @format ## `CullingRates`
#' A data frame with ?? rows and ?? columns
#' \describe{
#'   \item{X1}{TODO}
#' }
"CullingRates"

#' Headcounts
#'
#' An example dataset needed to run the model
#' TODO: expand
#'
#' @format ## `Headcounts`
#' A data frame with ?? rows and ?? columns
#' \describe{
#'   \item{X1}{TODO}
#' }
"Headcounts"

#' Network
#'
#' An example dataset needed to run the model
#' TODO: expand
#'
#' @format ## `Network`
#' A data frame with ?? rows and ?? columns
#' \describe{
#'   \item{X1}{TODO}
#' }
"Network"

#' Inits
#'
#' An example dataset needed to run the model
#' TODO: expand
#'
#' @format ## `Inits`
#' A data frame with ?? rows and ?? columns
#' \describe{
#'   \item{X1}{TODO}
#' }
"Inits"

#' InitialInfection
#'
#' An example dataset needed to run the model
#' TODO: expand
#'
#' @format ## `InitialInfection`
#' A data frame with ?? rows and ?? columns
#' \describe{
#'   \item{X1}{TODO}
#' }
"InitialInfection"
