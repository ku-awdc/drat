## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library("PTBinraeR")

## -----------------------------------------------------------------------------
BirthFemaleEvents
CullingRates
Headcounts
Network
Inits
InitialInfection

