vMortThreshold0 <- 5
vMortThreshold1 <- 10
