vWaterThreshold0 <- 10
vWaterThreshold1 <- 15
vWaterThreshold2 <- 20
vWaterThreshold3 <- 30

vTroughLengthPerPig <- 0.4

vMortThreshold0 <- 6
vMortThreshold1 <- 11
vMortThreshold2 <- 15
