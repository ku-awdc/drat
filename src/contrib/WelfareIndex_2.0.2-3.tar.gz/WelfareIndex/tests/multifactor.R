library('WelfareIndex')

mf <- multifactor(list(1:2,3,4,5), levels=1:5, ordered=TRUE)
mf[c(1,4)]
mf[[1:2]]
df <- data.frame(mf=mf, c=1:4)
df
df$mf[1]

df[1:3,]

stopifnot(all(df[1:3,]$mf %in% 2:3 == c(TRUE, TRUE, FALSE)))
