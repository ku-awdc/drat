#' @title Default values for the animal welfare index model
#' @name default_weights
#' @aliases default_weights default_measures default_key default_functions

#' @description
#' Obtain the default weights/measures/key (as a data frame) or functions (as a named list) for the given animal group type

#' @seealso
#' \code{\link{WelfareIndex}}

#' @param type the animal category required: one of 'Cows', 'Calves', 'SowsAndGilts', 'FarrowingSows', 'Piglets', or 'Weaners'

#' @rdname default_weights
default_weights <- function(type){
  
  type <- checktype(type)
  
  fp <- system.file("extdata", paste0(type,"Weights.csv"), package = "WelfareIndex")
  
  if(type=='Custom')
    stop('There is no default file available for the Custom type')
  if(fp=='')
    stop(paste0('The default ', type, ' file could not be found in the expected location'))
  
  m <- checkcsvread(fp, sep=',', dec='.')
  
  return(m)
  
}

#' @rdname default_weights
default_variables <- function(type){
  
  type <- checktype(type)
  
  fp <- system.file("extdata", paste0(type,"Variables.R"), package = "WelfareIndex")
  
  if(type=='Custom')
    stop('There is no default file available for the Custom type')
  if(fp=='')
    stop(paste0('The default ', type, ' file could not be found in the expected location'))
  
  nenv <- new.env()
  source(fp, local=nenv)
  
  return(as.list(nenv))
  
}

#' @rdname default_weights
default_measures <- function(type){
	
	type <- checktype(type)
	
	fp <- system.file("extdata", paste0(type,"Measures.csv"), package = "WelfareIndex")
	
	if(type=='Custom')
		stop('There is no default file available for the Custom type')
	if(fp=='')
		stop(paste0('The default ', type, ' file could not be found in the expected location'))
	
	m <- checkcsvread(fp, sep=',', dec='.')

	return(m)
	
}

#' @rdname default_weights
default_functions <- function(type){
	
	type <- checktype(type)
	
	if(type=='Custom')
		stop('There is no default file available for the Custom type')
	
	fs <- try(funs <- get(paste0('dfun_', type)), silent=TRUE)
	
	if(inherits(fs, 'try-error'))
		stop(paste0('The default functions for ', type, ' could not be found'))
	
	return(funs)
	
}

#' @rdname default_weights
default_key <- function(type){
	
	type <- checktype(type)
	
	fp <- system.file("extdata", paste0(type,"Key.csv"), package = "WelfareIndex")

	if(type=='Custom')
		stop('There is no default file available for the Custom type')
	if(fp=='')
		stop(paste0('The default ', type, ' file could not be found in the expected location'))
	
	m <- checkcsvread(fp, sep=',', dec='.')

	return(m)
	
}

