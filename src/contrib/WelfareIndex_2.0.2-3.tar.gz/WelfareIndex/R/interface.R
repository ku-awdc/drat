#' @title The WelfareIndex model creator function and class
#' @name WelfareIndex
#' @aliases WelfareIndex welfareindex

#' @description
#' This function is used to create a welfare index model for a given animal type, and the return value is a model class containing all methods required to run the model and output the results.

#' @details
#' The welfare index model itself is written using an OOP-style of programming, so that the various elements of the model can be set/modified/accessed at any point using a single R object as the point of reference.  This minimises the possibilities for programming mistakes by the end user, but does result in code that may look a little strange to users who may be more used to the standard procedural style of R programming.  The best way to understand the code is using an example - see vignette('guide', package='WelfareIndex') for an overview.

#' @keywords models

#' @return
#' An object of class WelfareIndex.

#' @examples
#' \dontrun{
#' vignette('guide', package='WelfareIndex')
#' }

#' @param type the animal category required: one of 'Cows', 'Calves', 'SowsAndGilts', 'FarrowingSows', 'Piglets', 'Weaners', or 'Custom' for an empty model to which customised measures, functions and data key can be added.

#' @param table a vector of values to be matched against

#' @param baseline the 'year 0' welfare score from which to calculate the index

#' @param filename the name of the file to read/write

#' @param filenames a character vector of one or more names of files to be read

#' @param sep the separator character for the csv file (passed to \code{\link[utils]{read.csv}})

#' @param dec the decimal point character for the csv file (passed to \code{\link[utils]{read.csv}})

#' @param weights a data frame to use for weights

#' @param measures a data frame of measures to use

#' @param variables a named list of variables to use

#' @param functions a named list of functions to use

#' @param strict option to do additional checking of function declarations (e.g. use of disconnect for all data frames)

#' @param key a data frame to use for the data key

#' @param datalist a named list of data frames to use for one or more DataRelation (the DataRelation Farm must be contained in the list provided to the first call to this method)

#' @param fail_all_missing should the presence of all missing values trigger an error on the data check or just a warning?

#' @param fail_missing_chr should the absence of one or more required CHR in the data trigger an error on the data check or just a warning?

#' @param show_warnings should the generated warnings be displayed or suppressed?

#' @param warn_missing should warnings due to missing data be shown?

#' @param standardise_excel_names should the ExcelSheet and ExcelColumn entries be changed to match DataRelation and DataName?

#' @param relation which of the available DataRelations should be retrieved ('all' means all relations, and 'set' means only those that have been provided with data already)

#' @param chr which of the available CHR should be retrieved ('all' means all CHR)

#' @param which which of the available measures, criteria and farm scores should be retrieved ('measures' means all measures, 'criteria' means all criteria, and 'all' means all measures/criteria/farm score)

#' @param anonymise should the identifying features of the output be removed/anonymised? This requires the SetAnonymisation() method to have been run first.

#' @param impute should missing scores be imputed as the average of other scores?

#' @param excel_names option to use either ExcelSheet and Excel Column (TRUE) or DataRelation and DataName (FALSE) in the output

#' @param output either a file to write the error/warning messages to, or "" to output them on the console

#' @param allow_incomplete should the model be forced to run even if not all DataRelation entries are present?

#' @param return_distribution should the full distribution of bootstrapped index estimates be returned (as an element of the list named distribution)?

#' @param iterations the number of bootstrap iterations to use

#' @param include_validation should the validation measure be returned along with the "real" measures?

#' @param frequencies option to calculate the proportion of animals with each weighting for each measure and CHR (this requires running the model multiple times).

#' @param mapping an optional data frame giving a pseudo-anonymisation key (if omitted, then random mappings are generated so that the outputs are fully anonymised).

#' @param case_sensitive should the CHR mapping be treated as being case sensitive?

#' @param datalist a named list of data frames to set as data

#' @param ... additional arguments passed to underlying functions (or the names of variables or weights to over-write, in the case of ResetVariables and ResetWeights)


WelfareIndex <- setRefClass('WelfareIndex',
	fields = list(type='character', stored_measures='data.frame', stored_functions='list', stored_key='data.frame', stored_weights='data.frame', stored_variables='list', stored_data='list', input_stage='numeric', required_simple='character', required_relational='list', baseline='numeric', imputed_results='data.frame', nonimputed_results='data.frame', long_results='data.frame', anonymisation="character"), 

	methods = list(

	initialize = function(type, baseline=75){
		"Initialise a WelfareIndex model with given type"
		
		.self$type <- checktype(type)
		
		if(length(baseline)!=1 || !is.numeric(baseline)){
			stop('The argument to baseline was not recognised: it must be a numeric of length 1')
		}
		.self$baseline <- baseline
		
		# Setting variables and weights is optional:
		.self$stored_variables <- list()
		.self$stored_weights <- data.frame(Variable=character(0), Value=numeric(0))
		
		.self$input_stage <- 0
		if(.self$type != 'Custom'){
			# This is the general order that things must follow as checks are done in this order (input_stage is set by SetXXX):
			.self$SetMeasures(default_measures(.self$type))
			.self$SetFunctions(default_functions(.self$type))
			.self$SetWeights(default_weights(.self$type))
			.self$SetVariables(default_variables(.self$type))
			.self$SetKey(default_key(.self$type))
			cat('Setting new key values\n')			
		}
		
	},
	
	SetAnonymisation = function(mapping = NULL, case_sensitive=FALSE){
	  "Set the pseudo-anonymisation key to be used"
	  
	  if(.self$input_stage < 5){
	    stop("The data must be read before anonymisation can be set")
	  }
	  
	  allchr <- data.frame(CHR = unique(.self$stored_data$Farm$CHR))
	  stopifnot(length(allchr$CHR)>0)
	  
	  if(is.null(mapping)){
	    anon <- sample(paste("AN_", gsub(" ", "0", format(1:nrow(allchr))), sep=""))
	    names(anon) <- as.character(allchr$CHR)
	    
	    cat("Setting the anonymisation key\n")
	  }else{
	    
	    if(!inherits(mapping, "data.frame")) stop("The mapping provided must be a data frame")
	    if(! all(c("CHR","ACHR") %in% names(mapping))) stop("The mapping provided must have CHR and ACHR columns")
	    
	    mapping <- mapping[,c("CHR","ACHR")]
	    
	    if(case_sensitive){
	      mapping$CHRmt <- mapping$CHR
	      allchr$CHRmt <- allchr$CHR
	    }else{
	      mapping$CHRmt <- tolower(mapping$CHR)
	      allchr$CHRmt <- tolower(allchr$CHR)
	    }
	    mapping$CHR <- NULL
	    miss <- allchr$CHR[!allchr$CHRmt %in% mapping$CHRmt]
	    if(length(miss)>0) stop(paste("The following CHR are present in the data but not in the mapping provided: ", paste(miss, collapse=", ")))
	    
	    anonmt <- full_join(mapping, allchr, by="CHRmt") %>%
	      select(-.data$CHRmt) %>%
	      filter(!is.na(CHR))
	    
	    stopifnot(all(anonmt$CHR %in% allchr$CHR))

	    anon <- anonmt$ACHR
	    names(anon) <- anonmt$CHR
	    
	    cat("Setting the pseudo-anonymisation key\n")
	  }
	  
	  stopifnot(all(!is.na(anon)))
	  stopifnot(all(!is.na(names(anon))))
	  
	  .self$anonymisation <- anon
	},

	GetAnonymisation = function(){
	  "Get the pseudo-anonymisation key used"
	  
	  if(.self$input_stage < 5){
	    stop("The data must be read before anonymisation can be set")
	  }
	  
	  if(length(.self$anonymisation)==0) stop("Anonymisation has not been set:  use the SetAnonymisation method!")
	  
	  anon <- .self$anonymisation
	  
	  allchr <- .self$stored_data$Farm$CHR
	  stopifnot(length(allchr)>0)
    
	  if(any(!allchr %in% names(anon))){
	    .self$anonymisation <- character(0)
	    stop("One or more CHR is missing from the anonymisation key - you may need to use the SetAnonymisation method after re-reading data")
	  }	  
	  
	  return(data.frame(CHR = as.character(names(anon)), ACH = as.character(anon)))
	},
	
	ResetWeights = function(...){
	  "Over-write the value of one or more existing weight"
	  
	  if(.self$input_stage < 2){
	    stop("The measures and functions must be read before weights and variables can be set")
	  }
	  
	  newvals <- list(...)
	  
	  if(length(newvals)>0){
	    if(is.null(names(newvals)) || any(names(newvals)=="")){
	      stop('All arguments must be named')
	    }
	    if(any(table(names(newvals)) > 1)){
	      stop('All argument names must be unique')
	    }
	  }
	  
	  if(any(sapply(newvals, length)) != 1){
	    stop("One or more argument does not have a length of 1")
	  }
	  
	  weights <- .self$stored_weights
	  
	  # Remove weights to be over-written:
	  torem <- names(newvals)[names(newvals) %in% weights$Variable]
	  weights <- weights[!weights$Variable %in% torem,]
	  
	  # Process new values:
	  newweights <- data.frame(Variable = as.character(names(newvals)), Value = as.numeric(unlist(newvals)))

	  # Reset all values:
	  SetWeights(rbind(weights, newweights))
	  
	},
	
	SetWeights = function(weights){
	  "Set the weights to be used for this welfare index model"
	  
	  if(.self$input_stage < 2){
	    stop("The measures and functions must be read before weights and variables can be set")
	  }
	  
	  if(!inherits(weights, 'data.frame')){
	    stop('A data frame must be provided')
	  }
	  weights <- as.data.frame(weights)
	  if(!all(c('Variable','Value') %in% names(weights))){
	    stop('A data frame including the elements Variable & Value must be provided')
	  }
	  
	  weights <- weights[,c('Variable','Value')]
	  if(any(is.na(weights))){
	    stop('Missing values were detected in the weights specified')
	  }
	  
	  notallowed <- c('+','-','*','/','&','|','%','#','$','@','^',':',';','<','>','"',"'",'!','?',' ')
	  
	  if(nrow(weights)>0 && !is.character(weights$Variable)){
	    stop('The Variable element must be a character')
	  }
	  weights$Variable <- gsub(' *$', '', weights$Variable)
	  present <- vapply(notallowed, function(x) return(grepl(x, weights$Variable, fixed=TRUE)), FUN.VALUE=logical(length(weights$Variable)))
	  rows <- which(apply(present,1,any))
	  if(length(rows)>0){
	    stop(paste('Illegal characters found in Variable(s): ', paste(weights$Variable[rows], collapse=', '), ' - you cannot use any of the following characters:  ', paste(notallowed, collapse=', '), ' (or spaces, including at the end of the text)'), call.=FALSE)
	  }
	  
	  vartabs <- table(weights$Variable)[table(weights$Variable)!=1]
	  if(length(vartabs) > 0) stop(paste("Duplicated Variable name for the following weight(s): ", paste(names(vartabs), collapse=", ")))
	  
	  if(nrow(weights)>0 && (!is.numeric(weights$Value) || any(weights$Value < 0))){
	    stop('The Value element must be non-negative numeric variables')
	  }
	  
	  # Check it can be converted to list as it will be later:
	  fake <- checkvariables(weights)
	  
	  # Check all weights are used in the functions:
	  allfuns <- paste(as.character(.self$stored_functions), collapse="\n")
	  unused <- !sapply(weights$Variable, function(x) grepl(x, allfuns, fixed=TRUE))
	  if(any(unused)){
	    unused <- names(unused)[unused]
	    cat(paste('NOTE: The following weights are not required by the functions and will be ignored: ', paste(unused, collapse=', '), "\n"))
	  }
	  
	  # Remove completed model results if applicable:
	  if(.self$input_stage > 5){
	    cat('Setting new weights values (this means that the model will need to be re-run)\n')
	    .self$input_stage <- 5
	  }else{
	    if(nrow(weights)>0)
	      cat('Setting new weights\n')
	  }
	  
	  .self$stored_weights <- weights
	},
	
	GetWeights = function(){
	  "Extract the weights to be used for this welfare index model as a data frame (this can be used as a template for modifications)"
	  
	  return(.self$stored_weights)
	},
	
	ReadWeights = function(filename, sep=',', dec='.', ...){
	  "Read and set the weights to be used for this welfare index model from an external csv/xlsx file"
	  
	  stopifnot(length(filename)==1)
	  iscsv <- grepl('.\\.csv$',filename)
	  isxl <- grepl('.\\.xlsx$',filename)
	  if(!iscsv && !isxl){
	    stop('The filename provided was not recognised as a .csv or .xlsx file')
	  }
	  
	  if(!file.exists(filename)){
	    stop('The file specified does not exist in the current working directory')
	  }
	  
	  if(iscsv){
	    weights <- checkcsvread(filename, sep=sep, dec=dec, ...)
	    if(!all(c('Variable','Value') %in% names(weights))){
	      stop('Column headings including the elements Variable & Value must be provided in the csv file')
	    }		
	  }else{
	    weights <- read_excel(filename, sheet=1, col_names=TRUE)
	    if(!all(c('Variable','Value') %in% names(weights))){
	      stop('Column headings including the elements Variable & Value must be provided in the first sheet of the Excel file')
	    }		
	  }
	  
	  weights <- weights[!apply(is.na(weights),1,all),,drop=FALSE]
	  stopifnot(inherits(weights, 'data.frame'))
	  
	  .self$SetWeights(weights)
	  
	},
	
	WriteWeights = function(filename){
	  "Extract the weights to be used for this welfare index model and write them to a csv file (this can be used as a template for modifications)"
	  
	  stopifnot(length(filename)==1)
	  iscsv <- grepl('.\\.csv$',filename)
	  if(!iscsv){
	    stop('The filename provided must have a .csv extension')
	  }
	  
	  write.csv(.self$GetWeights(), file=filename, row.names=FALSE, na = "")
	},

	ResetVariables = function(...){
	  "Over-write the value of one or more existing variable"

	  if(.self$input_stage < 2){
	    stop("The measures and functions must be read before weights and variables can be set")
	  }
	  
	  newvals <- list(...)
	  
	  if(length(newvals)>0){
	    if(is.null(names(newvals)) || any(names(newvals)=="")){
	      stop('All arguments must be named')
	    }
	    if(any(table(names(newvals)) > 1)){
	      stop('All argument names must be unique')
	    }
	  }
	  
#	  if(any(sapply(newvals, length)) != 1){
#	    stop("One or more argument does not have a length of 1")
#	  }
	  
	  variables <- .self$stored_variables
	  
	  # Remove variables to be over-written:
	  torem <- names(newvals)[names(newvals) %in% names(variables)]
	  variables <- variables[!names(variables) %in% torem]

	  # Reset all values:
	  SetVariables(c(variables, newvals))
	  
	},
	
	SetVariables = function(variables){
	  "Set one or more of the variables to be used for this welfare index model"
	  
	  if(!inherits(variables, 'list')){
	    stop('A list must be provided')
	  }
	  if(length(variables)>0){
  	  if(is.null(names(variables)) || any(names(variables)=="")){
  	    stop('A named list must be provided')
  	  }
  	  if(any(table(names(variables)) > 1)){
  	    stop('A list with unique names must be provided')
  	  }
	  }
	  
	  # Check all variables are used in the functions:
	  allfuns <- paste(as.character(.self$stored_functions), collapse="\n")
	  unused <- !sapply(names(variables), function(x) grepl(x, allfuns, fixed=TRUE))
	  if(any(unused)){
	    unused <- names(unused)[unused]
	    cat(paste('NOTE: The following weights are not required by the functions and will be ignored: ', paste(unused, collapse=', '), "\n"))
	  }
	  
	  # Remove completed model results if applicable:
	  if(.self$input_stage > 5){
	    cat('Setting new variables values (this means that the model will need to be re-run)\n')
	    .self$input_stage <- 5
	  }else{
	    if(length(variables)>0)
	      cat('Setting new variables\n')
	  }
	  
	  .self$stored_variables <- variables
	},
	
	GetVariables = function(){
	  "Extract the variables to be used for this welfare index model as a named list (this can be used as a template for modifications)"
	  
	  return(.self$stored_variables)
	},
	
	ReadVariables = function(filename, sep=',', dec='.', ...){
	  "Read and set the variables to be used for this welfare index model from an external R/txt file"
	  
	  stopifnot(length(filename)==1)
	  istxt <- grepl('.\\.txt$',filename)
	  isR <- grepl('.\\.R$',filename)
	  if(!istxt && !isR){
	    stop('The filename provided was not recognised as a .txt or .R file')
	  }
	  
	  if(!file.exists(filename)){
	    stop('The file specified does not exist in the current working directory')
	  }
	  
	  variables <- new.env()
	  source(filename, local=variables)
	  
	  .self$SetVariables(as.list(variables))
	  
	},
	
	WriteVariables = function(filename){
	  "Extract the variables to be used for this welfare index model and write them to an R/txt file (this can be used as a template for modifications)"
	  
	  stopifnot(length(filename)==1)
	  iscsv <- grepl('.\\.csv$',filename)
	  if(! (grepl('.\\.txt$',filename) | grepl('.\\.R$',filename))){
	    stop('The filename provided must have a .txt or .R extension')
	  }
	  
	  cat("## Variables used for WelfareIndex model:\n", file=filename, append=FALSE)
	  ll <- .self$GetVariables()
	  dump(names(ll), file=filename, append=TRUE, envir=as.environment(ll))
	},
	
	
	SetMeasures = function(measures){
		"Set the measures to be used for this welfare index model"
		
		measures <- checkmeasures(measures)
				
		if(.self$input_stage > 1){
			cat('Setting new measure values (this means that the functions, key and data will have to be reset)\n')
		}else{
			cat('Setting new measure values\n')
		}
		
		.self$stored_measures <- measures
		.self$input_stage <- 1		
	},
	
	GetMeasures = function(include_validation=FALSE){
		"Extract the measures to be used for this welfare index model as a data frame (this can be used as a template for modifications)"
		
		if(.self$input_stage < 1){
			stop('No measures have been set!')
		}
		
	  msr <- .self$stored_measures
		if(!include_validation){
		  msr <- msr %>% filter(.data$Measure!="ValidationCheck")
		}
	  
		return( msr )
	},
	
	ReadMeasures = function(filename, sep=',', dec='.', ...){
		"Read and set the measures to be used for this welfare index model from an external csv/xlsx file"
		
		stopifnot(length(filename)==1)
		iscsv <- grepl('.\\.csv$',filename)
		isxl <- grepl('.\\.xlsx$',filename)
		if(!iscsv && !isxl){
			stop('The filename provided was not recognised as a .csv or .xlsx file')
		}
		
		if(!file.exists(filename)){
			stop('The file specified does not exist in the current working directory')
		}
		
		if(iscsv){
			measures <- checkcsvread(filename, sep=sep, dec=dec, ...)
			if(!all(c('Measure','Criteria') %in% names(measures))){
				stop('Column headings including the elements Measure & Criteria must be provided in the csv file')
			}
		}else{
			measures <- read_excel(filename, sheet=1, col_names=TRUE)
			if(!all(c('Measure','Criteria') %in% names(measures))){
				stop('Column headings including the elements Measure & Criteria must be provided in the first sheet of the Excel file')
			}		
		}
				
		measures <- measures[!apply(is.na(measures),1,all),,drop=FALSE]
		stopifnot(inherits(measures, 'data.frame'))
		
		if('Min' %in% names(measures))
			measures$Min <- as.numeric(measures$Min)
		if('Max' %in% names(measures))
			measures$Max <- as.numeric(measures$Max)

		.self$SetMeasures(measures)
		
	},

	WriteMeasures = function(filename, include_validation=FALSE){
		"Extract the measures to be used for this welfare index model and write them to a csv file (this can be used as a template for modifications)"
		
		stopifnot(length(filename)==1)
		iscsv <- grepl('.\\.csv$',filename)
		if(!iscsv){
			stop('The filename provided must have a .csv extension')
		}
		
		write.csv(.self$GetMeasures(include_validation=include_validation), file=filename, row.names=FALSE, na = "")
	},

	SetFunctions = function(functions, strict=FALSE){
		"Set the functions to be used for this welfare index model"
		
		if(.self$input_stage < 1){
			stop('Unable to set the functions as the measures have not yet been set')
		}

		funs <- verify_functions(functions, .self$stored_measures, strict=strict)
		
		if(.self$input_stage > 2){
			cat('Setting new function values (this means that the key and data will have to be reset)\n')
		}else{
			cat('Setting new function values\n')
		}
		
		.self$stored_functions <- funs$funs
		.self$required_simple <- funs$simpledata
		.self$required_relational <- funs$relationaldata
		
		.self$input_stage <- 2
	},
	
	GetFunctions = function(){
		"Extract the functions to be used for this welfare index model as a list of functions"
		
		if(.self$input_stage < 2){
			stop('No functions have been set!')
		}
		
		return(.self$stored_functions)
	},
	
	ReadFunctions = function(filename, strict=FALSE){
		"Read and set the functions to be used for this welfare index model from an external text file"
		
		funs <- parse_functions(filename)
		
		.self$SetFunctions(funs, strict=strict)
		
	},

	WriteFunctions = function(filename){
		"Extract the functions to be used for this welfare index model and write them to a text file (this can be used as a template for modifications)"
		
		stopifnot(length(filename)==1)
		isok <- grepl('.\\.txt$',filename) || grepl('.\\.R$',filename) || grepl('.\\.r$',filename)
		if(!isok){
			stop('The filename provided must have a .R or .txt extension')
		}
		
		funs <- .self$GetFunctions()
		# Ensures the functions are written in an order to match the measures:
		measures <- .self$stored_measures$Measure
		stopifnot(all(sort(measures) == sort(names(funs))))
		
		funchar <- capture.output(dump(measures, envir=as.environment(funs), file=""))
		funstarts <- grepl('function\\(.*\\)\\{', funchar)
		funassigns <- grepl('*. <-$', funchar)
		# Just in case there are strange usages in the functions:
		if(all(funassigns[-length(funassigns)] == funstarts[-1])){
			funchar[funassigns] <- paste0(endl, endl, funchar[funassigns], ' ')
			funchar[!funstarts] <- paste0(endl, funchar[!funstarts])
		}else{
			funchar <- paste0(endl, funchar)
		}
		funstring <- paste(funchar, collapse='')
		
		cat(funstring, file=filename, append=FALSE)
	},

	
	SetKey = function(key){
		"Set the key to be used for this welfare index model"
		
		if(.self$input_stage < 2){
			stop('Unable to set the key as the functions have not yet been set')
		}
		key <- verify_key(key, .self$required_simple, .self$required_relational, recnote=FALSE)
		
		if(any(key$Type[key$DataName!='CHR']=='group')){
			stop('It is not permitted to use the type "group" for the index model for anything other than CHR - you should change these to categories and specify levels')
		}
		
		
		if(.self$input_stage > 3){
			cat('Setting new key values (this means that the data will have to be reset)\n')
		}else{
			cat('Setting new key values\n')
		}
		
		.self$stored_key <- key
		.self$input_stage <- 3
	},
	
	GetKey = function(standardise_excel_names=FALSE){
		"Extract the key to be used for this welfare index model as a data frame"
		
		if(.self$input_stage < 3){
			stop('No key has been set!')
		}
		
		key <- .self$stored_key
		
		if(standardise_excel_names){
			isext <- key$ExcelSheet == '__external__'
			key$ExcelSheet[!isext] <- key$DataRelation[!isext]
			key$ExcelColumn[!isext] <- key$DataName[!isext]
		}
		
		return(key)		
	},
	
	ReadKey = function(filename, sep=',', dec='.', ...){
		"Read a key from file to be used for this welfare index model"
		
		stopifnot(length(filename)==1)
		iscsv <- grepl('.\\.csv$',filename)
		isxl <- grepl('.\\.xlsx$',filename)
		if(!iscsv && !isxl){
			stop('The filename provided was not recognised as a .csv or .xlsx file')
		}
		
		if(!file.exists(filename)){
			stop('The file specified does not exist in the current working directory')
		}
		
		if(iscsv){
			inputkey <- checkcsvread(filename, sep=sep, dec=dec, ...)
		}else{
			inputkey <- process_excel(filename, sheet=1)
		}
				
		inputkey <- inputkey[!apply(is.na(inputkey),1,all),,drop=FALSE]
		stopifnot(inherits(inputkey, 'data.frame'))

		.self$SetKey(inputkey)
		
	},
	
	WriteKey = function(filename, standardise_excel_names=FALSE){
		"Extract the key to be used for this welfare index model and write it to a csv file (this can be used as a template for modifications)"
		
		stopifnot(length(filename)==1)
		iscsv <- grepl('.\\.csv$',filename)
		if(!iscsv){
			stop('The filename provided must have a .csv extension')
		}
		
		write.csv(.self$GetKey(standardise_excel_names=standardise_excel_names), file=filename, row.names=FALSE, na = "")
	},
	
	GetDataRequirements = function(){
		"Extract the data requirements information as a named list of character vectors representing the DataNames required in each DataRelation"
		
		if(.self$input_stage < 3){
			stop('Unable to extract data requirements as the key has not yet been set')
		}
		
		key <- .self$GetKey()
		relations <- unique(key$DataRelation)
		
	},
	
	SetData = function(datalist, fail_all_missing=TRUE, fail_missing_chr=FALSE, show_warnings=TRUE, warn_missing=FALSE){
		"Set DataRelation sources from a named list"
		
		if(!is.list(datalist) || length(datalist)==0 || is.null(names(datalist)) || any(is.na(names(datalist))) || any(names(datalist)=='') || !all(sapply(datalist, inherits, what='data.frame'))){
			stop('The argument to datalist must be a named list of data frames with length > 0')
		}
		
		if(.self$input_stage < 3){
			stop('Unable to set data as the key has not yet been set')
		}
		
		output <- ""		
		if(is.character(show_warnings) && show_warnings[1]=='suppress'){
			output <- tempfile()
			on.exit(unlink(output))
			show_warnings <- FALSE
		}
		
		stopifnot(is.logical(fail_all_missing) && length(fail_all_missing)==1)
		stopifnot(is.logical(fail_missing_chr) && length(fail_missing_chr)==1)
		stopifnot(is.logical(show_warnings) && length(show_warnings)==1)
		
		key <- .self$GetKey()
		
		# If there is a Farm relation, add it first:
		if(any(names(datalist)=='Farm')){
			
			if(.self$input_stage > 4){
				cat('Setting new Farm values (this means that the rest of the data will have to be reset)\n')
			}else{
				cat('Setting new Farm values\n')
			}
		
			farmlist <- verify_data(data=datalist$Farm, relation='Farm', farms=NA, key=key, fail_all_missing=fail_all_missing, fail_missing_chr=fail_missing_chr, show_warnings=show_warnings, warn_missing=warn_missing, output=output)
		
			sd <- vector('list', length=length(unique(key$DataRelation)))
			names(sd) <- unique(key$DataRelation)
			sd$Farm <- farmlist
			.self$stored_data <- sd
			.self$input_stage <- 4
			
		}
		
		if(.self$input_stage < 4){
			stop('Unable to set data as the Farm values have not yet been set')
		}
		
		newdataset <- FALSE
		for(i in 1:length(datalist)){
			rel <- names(datalist)[i]
			if(rel=='Farm')
				next
			
			if(rel %in% names(.self$stored_data)){

				newdata <- verify_data(data=datalist[[i]], relation=rel, farms=.self$stored_data$Farm, key=key, fail_all_missing=fail_all_missing, fail_missing_chr=fail_missing_chr, show_warnings=show_warnings, warn_missing=warn_missing, output=output)
			
				wd <- which(names(.self$stored_data)==rel)
				stopifnot(length(wd)==1)
				.self$stored_data[[wd]] <- newdata
				newdataset <- TRUE
			}else{
				cat(paste0('NOTE: Ignoring unnecessary data "', rel, '"', endl))
			}
		}
		
		if(newdataset){
			if(.self$input_stage > 5){
				cat('Setting new data values (this means that the model will have to be rerun)\n')
			}else{
				cat('Setting new data values\n')
			}
			.self$input_stage <- 5				
		}
		
	},
	
	GetData = function(relation='all', chr='all', anonymise=FALSE, excel_names=FALSE){
		"Extract the data to be used for this welfare index model as a named list"
		
		if(.self$input_stage < 4){
			stop('No data has been set!')
		}
		
		stopifnot(length(anonymise)==1 && is.logical(anonymise) && !is.na(anonymise))
		stopifnot(length(excel_names)==1 && is.logical(excel_names) && !is.na(excel_names))
		
		stopifnot(length(chr)>0)
		stopifnot(length(relation)>0)
		
		alldata <- .self$stored_data
		key <- .self$GetKey()
		colchange <- key$ExcelColumn
		names(colchange) <- key$DataName
		sheetchange <- key$ExcelSheet
		names(sheetchange) <- key$DataRelation
		
		allchr <- unique(.self$stored_data$Farm$CHR)
		if('all' %in% tolower(chr))
			chr <- c(chr[tolower(chr)!='all'], allchr)		
		chr <- unique(chr)
		if(!all(chr %in% allchr)){
			unrec <- chr[! chr %in% allchr]
			stop(paste0('Unrecognised CHR(s): ', paste(unrec, collapse=", "), ' - choose from: ', paste(allchr, collapse=", ")))
		}

		if(anonymise){
		  # This is just to do the checking:
		  chrchange <- GetAnonymisation()
		  # This is the format needed:
		  chrchange <- .self$anonymisation
		}

		possrels <- unique(key$DataRelation)
		if('all' %in% tolower(relation))
			relation <- c(relation[tolower(relation)!='all'], possrels)		
		if('set' %in% tolower(relation))
			relation <- c(relation[tolower(relation)!='set'], names(alldata)[!sapply(alldata, is.null)])
		relation <- unique(relation)
		if(!all(relation %in% possrels)){
			unrec <- relation[! relation %in% possrels]
			stop(paste0('Unrecognised DataRelation(s): ', paste(unrec, collapse=", "), ' - choose from: ', paste(possrels, collapse=", ")))
		}
		possrels <- names(alldata)[!sapply(alldata, is.null)]
		if(!all(relation %in% possrels)){
			unrec <- relation[! relation %in% possrels]
			stop(paste0('Unable to save DataRelation(s): ', paste(unrec, collapse=", "), ' as they have not yet been set'))
		}
		
		for(i in 1:length(alldata)){
			rel <- names(alldata)[[i]]
			if(rel %in% relation){
				towrite <- alldata[[i]]
				if(excel_names){
					dn <- names(towrite)
					stopifnot(all(dn %in% names(colchange)))
					dn <- colchange[dn]
					names(towrite) <- dn
				}
				stopifnot(all(chr %in% towrite$CHR))
				towrite <- towrite[towrite$CHR %in% chr,]
				if(anonymise){
					towrite$CHR <- chrchange[towrite$CHR]
				}

				alldata[[i]] <- towrite
			}
			
		}
		
		toret <- alldata[relation]
		
		if(excel_names){
			an <- names(toret)
			stopifnot(all(an %in% names(sheetchange)))
			an <- sheetchange[an]
			names(toret) <- an
			toret <- toret[an!='__external__']
		}

		return(toret)
	},
	
	ReadData = function(filenames, output="", excel_names=TRUE, fail_all_missing=TRUE, fail_missing_chr=FALSE, show_warnings=TRUE, warn_missing=FALSE, sep=',', dec='.', ...){
		"Read and set the data to be used for this welfare index model from an external csv/xlsx file"
		
		if(.self$input_stage < 3){
			stop('Unable to set data as the key has not yet been set')
		}
		
		stopifnot(is.logical(excel_names) && length(excel_names)==1)		
		stopifnot(is.logical(fail_all_missing) && length(fail_all_missing)==1)
		stopifnot(is.logical(fail_missing_chr) && length(fail_missing_chr)==1)
		stopifnot(is.logical(show_warnings) && length(show_warnings)==1)
		
		if(!is.character(filenames)){
			stop('A character vector specifying a path to one or more files must be specified for the filenames argument', call.=FALSE)
		}
		if(length(output)==1){
			output <- rep(output, length(filenames))
		}
		stopifnot(length(output)==length(filenames))
		
		for(o in unique(output)){
			if(o!=""){
				cat('Creating data log file at ', as.character(Sys.time()), endl, endl, file=o, append=FALSE)
			}
		}
		
		success <- TRUE
		key <- .self$GetKey()

		alldata <- vector('list', length=length(filenames))
		for(f in 1:length(filenames)){
			cat('Reading and checking data from file ', filenames[f], endl, endl, file=output[f], append=TRUE)
			if(output[f]!="")
				cat('Reading and checking data from file ', filenames[f], endl)
				
			st <- Sys.time()
			
			te <- try(rawdata <- read_data(filenames[f], output[f], key, excel_names, sep=sep, dec=dec, ...), silent=TRUE)
			if(inherits(te, 'try-error')){
				cat(as.character(te), endl, file=output[f], append=TRUE)
				success <- FALSE
				next
			}
			
			stopifnot(!is.null(names(rawdata)) && 'Farm' %in% names(rawdata))
			
			# Do farms first and abort if it fails:
			te <- try(checkdata <- verify_data(data=rawdata$Farm, relation='Farm', farms=NA, key=key, fail_all_missing=fail_all_missing, fail_missing_chr=fail_missing_chr, show_warnings=show_warnings, warn_missing=warn_missing, output=output[f]), silent=TRUE)
			if(inherits(te, 'try-error')){
				cat(as.character(te), endl, file=output[f], append=TRUE)
				success <- FALSE
				next
			}
			farms <- checkdata
						
			stopifnot(is.list(rawdata))
			alldata[[f]] <- vector('list', length=length(rawdata))
			names(alldata[[f]]) <- names(rawdata)
			for(i in 1:length(rawdata)){
				if(names(rawdata)[i]=='Farm'){
					alldata[[f]][[i]] <- farms
					next
				}
				
				te <- try(alldata[[f]][[i]] <- verify_data(data=rawdata[[i]], relation=names(rawdata)[i], farms=farms, key=key, fail_all_missing=fail_all_missing, fail_missing_chr=fail_missing_chr, show_warnings=show_warnings, warn_missing=warn_missing, output=output[f]), silent=TRUE)
				if(inherits(te, 'try-error')){
					cat(as.character(te), endl, file=output[f], append=TRUE)
					success <- FALSE
				}
			}
						
			cat('Finished reading and checking data in ', as.numeric(difftime(Sys.time(), st, units='sec')), ' seconds', endl, endl, endl, sep='', file=output[f], append=TRUE)
						
		}
		
		if(!success)
			stop('One or more data checks failed: data has not been saved', call.=FALSE)
		
		lengths <- sapply(alldata, function(x) return(length(x)))
		stopifnot(all(lengths==lengths[1]))
		names1 <- names(alldata[[1]])
		bin <- sapply(alldata, function(x) stopifnot(all(names(x)==names1)))
		
		data <- lapply(1:lengths[1], function(i){
			tobind <- lapply(alldata, function(j){
				return(j[[i]])
			})
			stopifnot(!any(sapply(tobind, is.null)))
			
			ismf <- vapply(tobind, function(x) return(sapply(x, function(y) return(inherits(y, 'multifactor')))), logical(ncol(tobind[[1]])))
			anyismf <- apply(ismf,1,any)
			levs <- vector('list', length=ncol(tobind[[1]]))
		
			for(mf in which(anyismf)){
				# It is possible that 1 file is entirely blank for a data name in which case we need to take the levels from the non-blank one:
				findmf <- which(ismf[mf,])
				stopifnot(length(findmf)>0)
				levs[[mf]] <- levels(tobind[[findmf[1]]][,mf])
				for(bi in 1:length(tobind)){
					tobind[[bi]][,mf] <- as.character(tobind[[bi]][,mf])
				}
			}
		
			tobind$stringsAsFactors <- FALSE
			te <- try(bound <- do.call('rbind', tobind))
			for(mf in which(anyismf)){
				bound[,mf] <- as.character(multifactor(bound[,mf], levels=levs[[mf]], simplify2factor=FALSE))
			}

			return(bound)

		})
		names(data) <- names1
		
		.self$SetData(data, fail_all_missing=fail_all_missing, fail_missing_chr=fail_missing_chr, show_warnings='suppress')

	},
	
	WriteData = function(filename, relation='all', chr='all', anonymise=FALSE, excel_names=TRUE){
		"Extract the data to be used for this welfare index model and write it to a series of csv files"
		
		stopifnot(length(filename)==1)
		iscsv <- grepl('.\\.csv$',filename)
		if(!iscsv){
			stop('The filename provided must have a .csv extension')
		}
		
		basefile <- gsub('\\.csv$','',filename)
		
		alldata <- .self$GetData(relation=relation, chr=chr, anonymise=anonymise, excel_names=excel_names)
		
		for(i in 1:length(alldata)){
		  
			write.csv(alldata[[i]], file=paste0(basefile, '_', names(alldata)[[i]], '.csv'), row.names=FALSE, na = "")
		}
	},
	
	#GetCHRdates = function(){
  # FALSE
	#	"Extract the CHR and VisitDate information as a data frame"
		
	#	farm <- (.self$GetData('Farm', excel_names=FALSE))$Farm
		
	#	return(farm[,c('CHR','VisitDate'),drop=FALSE])
	#},
	
	RunModel = function(output="", allow_incomplete=FALSE, show_warnings=ifelse(output=="", FALSE, TRUE), frequencies=TRUE){
		"Run the index model and store results"
		
		if(.self$input_stage < 5){
			stop('Unable to run the model as the data has not yet been set')
		}
		
		stopifnot(is.logical(allow_incomplete) && length(allow_incomplete)==1)		
		show_warnings <- show_warnings
		stopifnot(is.logical(show_warnings) && length(show_warnings)==1)		
		
		data <- .self$stored_data
		key <- .self$GetKey()
		if(any(sapply(data, is.null))){
			md <- names(data)[sapply(data, is.null)]
			if(!allow_incomplete){
				stop(paste0('Unable to run the model without the following missing data relation(s): ', paste(md, collapse=', ')))
			}else{
				for(i in 1:length(md)){
					# This is guaranteed to not be Farm:
					reqdata <- key$DataName[key$DataRelation==md[i]]
					tl <- as.data.frame(lapply(reqdata, function(x) return(numeric(0))))
					names(tl) <- reqdata
					tl <- cbind(CHR=character(0), VisitDate=as.Date(numeric(0), origin='1999-01-01'), tl)
					data[[md[i]]] <- tl
				}
			}
		}
		
		stopifnot(length(output)==1)
		if(is.character(output)){
			outfile <- output
			output <- TRUE
		}else{
			stopifnot(is.logical(output))
			if(output){
				outfile <- ""
			}else{
				outfile <- tempfile()
				on.exit(unlink(outfile))
			}
		}
		
		variables <- c(checkvariables(.self$GetWeights()), .self$GetVariables())
		stopifnot(is.list(variables))
		measures <- .self$GetMeasures(include_validation=TRUE)
		
		# Not currently implemented but could be an argument to this function:
		fun_objects <- list()
		fun_objects <- c(fun_objects, variables, funs=list(.self$GetFunctions()))
		
		if(frequencies){
		  
		  fqmeasures <- .self$GetMeasures(include_validation=FALSE)
		  if(any(fqmeasures$Min > 0) | any(fqmeasures$Max < 1)) stop("All measures must have Min 0 and Max >=1 to use the GetFrequencies function")
		  
		  current_weights <- .self$GetWeights()
		  on.exit(capture.output(.self$SetWeights(current_weights)))
		  
		  wtnums <- current_weights %>%
		    separate(.data$Variable, c("Weight", "Index"), sep=-1, remove=FALSE) %>%
		    mutate(Index = as.numeric(.data$Index))
		  with(wtnums, stopifnot(all(!is.na(Index))))
		  
		  tfile <- tempfile()
		  
		  lapply(0:max(wtnums$Index), function(ind){
		    
		    cat("Pre-running model to obtain score", ind, "frequencies...\n")
		    
		    twts <- wtnums %>%
		      mutate(Value = case_when(
		        .data$Index == ind ~ 1,
		        TRUE ~ 0
		      ))
		    capture.output(.self$SetWeights(twts))
		    # NB: this function calls itself...
		    suppressWarnings(capture.output(.self$RunModel(output=tfile, allow_incomplete=TRUE, show_warnings=FALSE, frequencies=FALSE)))
		    
		    retval <- .self$GetFarmScores(impute=FALSE, anonymise=FALSE) %>%
		      pivot_longer(cols=!c(CHR, TotalAnimals), names_to="Measure", values_to="Frequency") %>%
		      mutate(Score = ind)
		    return(retval)
		  }) %>%
		    bind_rows() %>%
		    filter(Measure %in% fqmeasures$Measure) ->
		    fqres
		  
		  unlink(tfile)
		  capture.output(.self$SetWeights(current_weights))
		  
		  fqchk <- fqres %>%
		    group_by(CHR, Measure) %>%
		    summarise(Freq=sum(.data$Frequency), .groups="drop")
		  probs <- fqchk %>%
		    filter(!is.na(Freq), abs(Freq-1) > sqrt(.Machine$double.eps)) %>%
		    count(Measure)
		  if(nrow(probs)>0){
		    stop("Score frequencies for the following measure(s) do not sum to unity: ", paste(probs$Measure, collapse=", "), call.=FALSE)
		  } 
		  
		  fqres %>%
		    mutate(Score = paste0("Wt", Score)) %>%
		    pivot_wider(names_from = Score, values_from=Frequency, values_fill=NA_real_) ->
		    fqres

		  on.exit()
		}
		
		cat('Running the model to obtain scores...\n')
		st <- Sys.time()
		
		torun <- data$Farm[,c("CHR"),drop=FALSE]
		allres <- analyse_data(torun=torun, datalist=data, fun_objects=fun_objects, type=.self$type, measuresdf=measures, key=key, errorfile=outfile, show_warnings=show_warnings)
		
		if(frequencies){
		  allres <- allres %>%
		    full_join(fqres %>% select(-.data$TotalAnimals), by=c("CHR","Measure")) %>%
		    select(measure_index, CHR, Observer, VisitDate, Measure, entry_index, Value, starts_with("Wt"), everything())
		}
		
		.self$input_stage <- 6
		.self$long_results <- allres
		
		cat('Finished running the model in', as.numeric(difftime(Sys.time(), st, units='sec')), 'seconds\n')

		truemeas <- measures$Measure
		stopifnot(truemeas[1]=='ValidationCheck')
		matrixres <- matrix(as.numeric(NA), ncol=length(truemeas), nrow=nrow(torun), dimnames=list(NULL, c('TotalAnimals',truemeas[-1])))
		#matrixres <- cbind(data.frame(CHR=torun$CHR, VisitDate=torun$VisitDate, Observer=torun$Observer), matrixres)
		matrixres <- cbind(data.frame(CHR=torun$CHR,	Observer = "fake", VisitDate = as.Date("1970-01-01")), matrixres)
		stopifnot(ncol(matrixres) == length(truemeas)+3)

		for(i in 1:nrow(matrixres)){
		  for(j in 1:length(truemeas)){
		    meas <- truemeas[j]
		    rowind <- which(allres$CHR==matrixres$CHR[i] & allres$VisitDate==matrixres$VisitDate[i] & allres$Measure==meas)
		    stopifnot(length(rowind)==1)
		    matrixres[i,j+3] <- allres$Value[rowind]
		  }
		}
		
		imputedres <- matrixres
		nonimputedres <- matrixres
		for(i in 5:ncol(imputedres)){
		  if(any(!is.na(imputedres[,i])))
			  imputedres[is.na(imputedres[,i]),i] <- mean(imputedres[,i], na.rm=TRUE)
		}
		
		criteria <- unique(measures$Criteria)
		criteria <- criteria[criteria!='ValidationCheck']
		criteriascores1 <- matrix(as.numeric(NA), ncol=length(criteria)+1, nrow=nrow(torun), dimnames=list(NULL, c(criteria, 'FarmScore')))
		criteriascores2 <- criteriascores1
		for(i in 1:length(criteria)){
			# Criteria score is a simple mean of the relevant measure scores:
			relmeas <- measures$Measure[measures$Criteria==criteria[i]]
			criteriascores1[,i] <- apply(imputedres[,relmeas,drop=FALSE],1,mean,na.rm=FALSE)
			criteriascores2[,i] <- apply(nonimputedres[,relmeas,drop=FALSE],1,mean,na.rm=FALSE)
		}
		# Overall farm score is a simple mean of the measure scores (NOT criteria scores):
		relmeas <- measures$Measure[measures$Criteria!='ValidationCheck']
		criteriascores1[,'FarmScore'] <- apply(imputedres[,relmeas,drop=FALSE],1,mean,na.rm=FALSE)
		criteriascores2[,'FarmScore'] <- apply(nonimputedres[,relmeas,drop=FALSE],1,mean,na.rm=FALSE)
		
		imputedres <- cbind(imputedres, criteriascores1)
		if(any(is.na(imputedres))){
			# Don't look at CHR, VisitDate, Observer or TotalAnimals for missing stuff:
			anyna <- apply(is.na(imputedres[,-(1:4)]),2,any)
			allna <- apply(is.na(imputedres[,-(1:4)]),2,all)
			stopifnot(all(anyna==allna))
			
			whichna <- names(imputedres)[-(1:4)][anyna]
			warning(paste0('The following scores are missing for all farms as they could not be calculated for any farm: ', paste(whichna, collapse=', ')))
		}
		nonimputedres <- cbind(nonimputedres, criteriascores2)
		
		if(any(is.na(nonimputedres$TotalAnimals))){
			whichna <- which(is.na(nonimputedres$TotalAnimals))
			#warning(paste0('TotalAnimals results are missing for the following farm(s): ', paste(paste0(nonimputedres$CHR[whichna], ' (', nonimputedres$VisitDate[whichna], ' - ', nonimputedres$Observer[whichna], ')'), collapse=', ')))
			warning(paste0('TotalAnimals results are missing for the following farm(s): ', paste(nonimputedres$CHR[whichna], collapse=', ')), call.=FALSE)
		}
		
		stopifnot(ncol(imputedres)==ncol(nonimputedres))
		stopifnot(all(is.na(nonimputedres) >= is.na(imputedres)))
		
		.self$imputed_results <- imputedres
		.self$nonimputed_results <- nonimputedres
		.self$input_stage <- 6
		
		invisible(sum(allres$NumberOfErrors)==0)
	},
	
	GetResults = function(anonymise=FALSE){
		"Extract the long results obtained from running the index model (including all error and warning messages)"
		
		if(.self$input_stage < 6)
			stop("No results to return - run the model first!")
		
	  longres <- .self$long_results
	  longres[["VisitDate"]] <- NULL
	  longres[["Observer"]] <- NULL
	  
	  if(anonymise){
	    # This is just to do the checking:
	    anon <- GetAnonymisation()
	    # This is the format needed:
	    anon <- .self$anonymisation
	    longres$CHR <- anon[as.character(longres$CHR)]
	  }
	  
		return(longres)
	},
	
	WriteResults = function(filename, anonymise=FALSE){
		"Write the long results obtained from running the index model to file (including all error and warning messages)"

		if(.self$input_stage < 6)
			stop("No results to return - run the model first!")
		
		stopifnot(length(filename)==1)
		iscsv <- grepl('.\\.csv$',filename)
		if(!iscsv){
			stop('The filename provided must have a .csv extension')
		}
		
		longres <- .self$long_results
		longres[["VisitDate"]] <- NULL
		longres[["Observer"]] <- NULL
		
		if(anonymise){
		  # This is just to do the checking:
		  anon <- GetAnonymisation()
		  # This is the format needed:
		  anon <- .self$anonymisation
		  longres$CHR <- anon[as.character(longres$CHR)]
		}
		
		write.csv(longres, file=filename, row.names=FALSE, na = "")
	},
	
	GetIndex = function(return_distribution=FALSE, iterations=10000){
		"Get the final welfare index for this data"
		
	  if(.self$input_stage < 6)
	    stop("No results to output - run the model first!")
	  
	  stopifnot(length(return_distribution)==1 && !is.na(return_distribution) && is.logical(return_distribution))
		
		# Need to get FarmScore and TotalAnimals and bootstrap them together:
		fs <- .self$GetFarmScores('FarmScore')
		
		if(any(is.na(fs)))
			stop('The index score could not be calculated because one or more measure (and therefore criteria and farm score) was missing for all farms')
		
		tb <- .self$baseline
		stopifnot(length(tb==1) && !is.na(tb) && is.numeric(tb))
		
		farmscore <- fs$FarmScore
		N <- length(farmscore)
		stopifnot(N==nrow(fs))

		if(return_distribution && N < min_farms_index){
			stop(paste0('Bootstrap confidence intervals for the index result cannot be calculated with fewer than ', min_farms_index, ' farms'))
		}
		
		animals <- fs$TotalAnimals
		index <- mean(rep(farmscore, animals)) / tb * 100
		
		if(N >= min_farms_index){
			indices <- sapply(1:iterations, function(i){
				bootscores <- sample(farmscore, N, replace=TRUE)
				bootanimals <- sample(animals, N, replace=TRUE)
				bootindex <- mean(rep(bootscores, bootanimals)) / tb * 100
				return(bootindex)
			})
			confint <- quantile(indices, prob=c(0.025,0.975))
		}else{
			confint <- as.numeric(c(NA,NA))
		}
		names(confint) <- c('Lower95CI','Upper95CI')
		
		toret <- list(index=index, nfarms=N, nanimals=sum(animals), confint=confint, baseline=tb)
		if(return_distribution){
			toret$distribution <- indices
		}		
		class(toret) <- 'index_output'

		return(toret)
	},
	
	WriteIndex = function(filename){
		"Output a full report of summary statistics for each measure, crterion and overall index to file"

		if(.self$input_stage < 6)
			stop("No results to output - run the model first!")

		stopifnot(length(filename)==1)
		ismd <- grepl('.\\.html$',filename)
		if(!ismd){
			stop('The filename provided must have a .html extension')
		}
		
		criteria <- unique(.self$GetMeasures(include_validation=FALSE)$Criteria)
		measures <- unique(.self$GetMeasures(include_validation=FALSE)$Measure)

		is <- try(indexresults <- .self$GetIndex(), silent=TRUE)
		if(inherits(is, 'try-error'))
			indexresults <- as.numeric(NA)
		
		farm_imputed <- .self$GetFarmScores(impute=TRUE)
		farm_nonimputed <- .self$GetFarmScores(impute=FALSE)
		animal_imputed <- .self$GetAnimalScores(impute=TRUE)
		animal_nonimputed <- .self$GetAnimalScores(impute=FALSE)
		
		output_index(filename=filename, type=.self$type, indexresults=indexresults, criteria=criteria, measures=measures, farm_imputed=farm_imputed, farm_nonimputed=farm_nonimputed, animal_imputed=animal_imputed, animal_nonimputed=animal_nonimputed)
		
	},
	
	GetAnimalScores = function(which='all', chr='all', anonymise=FALSE, impute=TRUE){
		"Extract the full distribution of individual measure, criteria or overall scores at the individual animal level"
		
		# Has to be anonymise FALSE here so we can get TotalAnimals:
		fscores <- .self$GetFarmScores(which=which, chr=chr, anonymise=FALSE, impute=impute)
		
		stopifnot(length(anonymise)==1 && is.logical(anonymise) && !is.na(anonymise))
		stopifnot(length(impute)==1 && is.logical(impute) && !is.na(impute))
		
		stopifnot(length(unique(fscores$CHR))==nrow(fscores))
		allchr <- fscores$CHR
		tobind <- lapply(allchr, function(x){
			slice <- fscores[fscores$CHR==x,,drop=FALSE]
			stopifnot(nrow(slice)==1)
			rownames(slice) <- NULL
			if(slice$TotalAnimals < 1){
				slices <- cbind(Animal=numeric(0), slice[-1,])
			}else{
				slices <- cbind(Animal=1:slice$TotalAnimals, slice)
			}
			stopifnot(nrow(slices)==slice$TotalAnimals)
			return(slices)
		})
		
		toret <- do.call('rbind', args=tobind) %>% select(-TotalAnimals)
		stopifnot(nrow(toret)==sum(fscores$TotalAnimals))
		
		if(anonymise){
		  # This is just to do the checking:
		  anon <- GetAnonymisation()
		  # This is the format needed:
		  anon <- .self$anonymisation
		  toret$CHR <- anon[as.character(toret$CHR)]
		}
		
		return(toret)
	},
	
	GetFarmScores = function(which='all', chr='all', anonymise=FALSE, impute=TRUE){
		"Extract the full distribution of individual measure, criteria or overall scores at the farm level"
		
		if(.self$input_stage < 6)
			stop("No results to return - run the model first!")
		
		stopifnot(length(anonymise)==1 && is.logical(anonymise) && !is.na(anonymise))
		stopifnot(length(impute)==1 && is.logical(impute) && !is.na(impute))
		
		alldata <- .self$stored_data
		key <- .self$GetKey()
		measures <- .self$GetMeasures(include_validation=TRUE)
		
		stopifnot(length(chr)>0)
		stopifnot(length(which)>0)

		allchr <- unique(.self$stored_data$Farm$CHR)
		if('all' %in% tolower(chr))
			chr <- c(chr[tolower(chr)!='all'], allchr)		
		chr <- unique(chr)
		if(!all(chr %in% allchr)){
			unrec <- chr[! chr %in% allchr]
			stop(paste0('Unrecognised CHR(s): ', paste(unrec, collapse=", "), ' - choose from: ', paste(allchr, collapse=", ")))
		}

		posswhich <- unique(c(measures$Measure[measures$Measure!='ValidationCheck'], measures$Criteria[measures$Criteria!='ValidationCheck'], 'FarmScore'))
		if('all' %in% tolower(which))
			which <- c(which[tolower(which)!='all'], posswhich)
		if('measures' %in% tolower(which))
			which <- c(which[tolower(which)!='measures'], measures$Measure[measures$Measure!='ValidationCheck'])
		if('criteria' %in% tolower(which))
			which <- c(which[tolower(which)!='criteria'], measures$Criteria)
		which <- unique(which)

		if(!all(which %in% posswhich)){
			unrec <- which[! which %in% posswhich]
			stop(paste0('Unrecognised elements of the argument to which: ', paste(unrec, collapse=", "), ' - choose from the Measures (', paste(measures$Measure, collapse=", "), '), Criteria (', paste(unique(measures$Criteria), collapse=", "), ') or FarmScore'))
		}
		
		which <- c('CHR','TotalAnimals',which)

		if(impute){
			stopifnot(all(which %in% names(.self$imputed_results)))
		
			whichrow <- which(.self$imputed_results$CHR %in% chr)
			toret <- .self$imputed_results[whichrow,which]
		}else{
			stopifnot(all(which %in% names(.self$nonimputed_results)))
		
			whichrow <- which(.self$nonimputed_results$CHR %in% chr)
			toret <- .self$nonimputed_results[whichrow,which]
		}
		
		if(anonymise){
		  # This is just to do the checking:
		  anon <- GetAnonymisation()
		  # This is the format needed:
		  anon <- .self$anonymisation
		  toret$CHR <- anon[as.character(toret$CHR)]
		}
		
		return(toret)
	},
	
	WriteAnimalScores = function(filename, which='all', chr='all', anonymise=FALSE, impute=TRUE){
		"Write to file the full distribution of individual measure, criteria or overall scores at the individual animal level"
		
		stopifnot(length(filename)==1)
		iscsv <- grepl('.\\.csv$',filename)
		if(!iscsv){
			stop('The filename provided must have a .csv extension')
		}
		
		imputedres <- .self$GetAnimalScores(which=which, chr=chr, anonymise=anonymise, impute=impute)
		write.csv(imputedres, file=filename, row.names=FALSE, na = "")
		
	},

	WriteFarmScores = function(filename, which='all', chr='all', anonymise=FALSE, impute=TRUE){
		"Write to file the full distribution of individual measure, criteria or overall scores at the farm level"
		
		stopifnot(length(filename)==1)
		iscsv <- grepl('.\\.csv$',filename)
		if(!iscsv){
			stop('The filename provided must have a .csv extension')
		}
		
		imputedres <- .self$GetFarmScores(which=which, chr=chr, anonymise=anonymise, impute=impute)
		write.csv(imputedres, file=filename, row.names=FALSE, na = "")
		
	}
))
