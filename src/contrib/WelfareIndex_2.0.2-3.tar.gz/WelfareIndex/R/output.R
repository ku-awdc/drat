print.index_output <- function(x, digits=2, ...){
	
	stopifnot(all(c('index','nfarms','nanimals','confint','baseline') %in% names(x)))
	
	cat('The welfare index calculated from ', x$nanimals, ' on ', x$nfarms, ' farms is: ', round(x$index, digits=digits), '\n', sep='')
	if(x$nfarms >= min_farms_index){
		cat('The bootstrapped 95% confidence interval is: ', round(x$confint[1], digits=digits), '-', round(x$confint[2], digits=digits), '\n', sep='')
	}else{
		cat('[Bootstrapped confidence intervals cannot be calculated with fewer than ', min_farms_index, ' farms]\n', sep='')
	}

	invisible(x)	
}

output_index <- function(filename, type, indexresults, criteria, measures, farm_imputed, farm_nonimputed, animal_imputed, animal_nonimputed, digits=3){
	
	stopifnot(grepl('.\\.html$',filename))
	
  stopifnot(all(c('CHR','TotalAnimals','FarmScore',criteria,measures)%in%names(farm_imputed)), all(names(farm_imputed)==names(farm_nonimputed)), all(names(farm_imputed)[-(1:3)]==names(animal_imputed)[-(1:3)]), all(names(animal_imputed)==names(animal_nonimputed)))
  
	# stopifnot(all(c('CHR','VisitDate','TotalAnimals','FarmScore',criteria,measures)%in%names(farm_imputed)) && all(names(farm_imputed)==names(farm_nonimputed)) && all(names(farm_imputed)[-(1:4)]==names(animal_imputed)[-(1:4)]) && all(names(animal_imputed)==names(animal_nonimputed)))
	
	prettytypes <- c(Cows='Adult Cattle', Calves='Young Cattle', Piglets='Piglets', FarrowingSows='Farrowing Sows', SowsAndGilts='Sows and Gilts', Weaners='Weaners', Custom='Customised Measures/Functions')
	
	stopifnot(type %in% names(prettytypes))
	prettytype <- prettytypes[type]
	
	#datemin <- min(farm_imputed$VisitDate)
	#datemax <- max(farm_imputed$VisitDate)
	#stopifnot(inherits(datemin, 'Date') && datemax > datemin)
		
	numfarms <- nrow(farm_imputed)
	stopifnot(numfarms==length(unique(farm_imputed$CHR)))
	totalanimals <- farm_imputed$TotalAnimals
	stopifnot(sum(totalanimals)==nrow(animal_imputed))
	
	# Calcualte index here and CI
	if(identical(indexresults, as.numeric(NA))){
		indexstring <- 'The index score could not be calculated because one or more measure (and therefore criteria and farm score) was missing for all farms.'
	}else{
		indexstring <- paste0('The index score obtained relative to a baseline of ', round(indexresults$baseline, digits=digits), ' was ', round(indexresults$index, digits=digits), '.\n')
		if(numfarms >= min_farms_index){
			indexstring <- paste0(indexstring, 'This is associated with a 95% confidence interval of ', round(indexresults$confint[1], digits=digits), ' - ', round(indexresults$confint[2], digits=digits), ' based on non-parametric bootstrapping.')
		}else{
		 	indexstring <- paste0(indexstring, '[Bootstrapped confidence intervals cannot be calculated with fewer than ', min_farms_index, ' farms]')
		}
	}
	
	output <- paste0('
	
---
---

<center> <h1>WelfareIndex Report for ', prettytype, '</h1> </center>

---
---

This report summarises the welfare index results based on data obtained from ', numfarms, ' farms.  This represents a total of ', sum(totalanimals), ' animals, with a range of ', min(totalanimals), ' to ', max(totalanimals), ' per farm.

---
---

<center> <h2>Index</h2> </center>

', indexstring, '

---
---

<center> <h2>Overall scores</h2> </center>

Summary statistics for the full distribution of overall scores are given below:
')
	
	sd <- farm_imputed[,'FarmScore']
	if(any(is.na(sd))){
		stopifnot(all(is.na(sd)))
		output <- paste0(output, '
The overall scores could not be summarised because one or more dependent measure was missing for all farms.
')
	}else{
		tab <- data.frame(row=1:4, Mean=NA, StdDev=NA, Median=NA, Min=NA, Max=NA, Missing=NA)
		for(i in 1:4){
			if(i==1){
				using <- farm_nonimputed[,'FarmScore']
			}else if(i==2){
				using <- farm_imputed[,'FarmScore']
			}else if(i==3){
				using <- animal_nonimputed[,'FarmScore']
			}else if(i==4){
				using <- animal_imputed[,'FarmScore']
			}else{
				stop('Counting to 4 problem (farm score) - please file a bug report')
			}
			
			stopifnot(i %in% c(1,3) || sum(is.na(using))==0)
			
			tab$Mean[i] <- round(mean(using, na.rm=TRUE), digits)
			tab$StdDev[i] <- round(sd(using, na.rm=TRUE), digits)
			tab$Median[i] <- round(median(using, na.rm=TRUE), digits)
			tab$Min[i] <- round(min(using, na.rm=TRUE), digits)
			tab$Max[i] <- round(max(using, na.rm=TRUE), digits)
			if(i %in% c(1,3)){
				tab$Missing[i] <- paste0(sum(is.na(using)), " (", round(sum(is.na(using))/length(using) * 100, 1), "%)")
			}else{
				tab$Missing[i] <- "--"
			}
		}
		tab <- tab[,-1]
		rownames(tab) <- c('Farm level','Farm level (imputed)','Animal level','Animal level (imputed)')
		
		output <- paste0(output, '\n', paste(as.character(kable(tab, format='markdown', align='r')), collapse='\n'), '\n')
		
	}

	output <- paste0(output, '

---
---

<center> <h2>Criteria scores</h2> </center>

Summary statistics for the full distribution of scores for each criterion are given below:

---
')

	for(c in 1:length(criteria)){
		sd <- farm_imputed[,criteria[c]]
		if(any(is.na(sd))){
			stopifnot(all(is.na(sd)))
			output <- paste0(output, '
### ', criteria[c], '

This criterion could not be summarised because one or more dependent measure was missing for all farms.
')
		}else{
			tab <- data.frame(row=1:4, Mean=NA, StdDev=NA, Median=NA, Min=NA, Max=NA, Missing=NA)
			for(i in 1:4){
				if(i==1){
					using <- farm_nonimputed[,criteria[c]]
				}else if(i==2){
					using <- farm_imputed[,criteria[c]]
				}else if(i==3){
					using <- animal_nonimputed[,criteria[c]]
				}else if(i==4){
					using <- animal_imputed[,criteria[c]]
				}else{
					stop('Counting to 4 problem (criteria) - please file a bug report')
				}
				
				stopifnot(i %in% c(1,3) || sum(is.na(using))==0)
				
				tab$Mean[i] <- round(mean(using, na.rm=TRUE), digits)
				tab$StdDev[i] <- round(sd(using, na.rm=TRUE), digits)
				tab$Median[i] <- round(median(using, na.rm=TRUE), digits)
				tab$Min[i] <- round(min(using, na.rm=TRUE), digits)
				tab$Max[i] <- round(max(using, na.rm=TRUE), digits)
				if(i %in% c(1,3)){
					tab$Missing[i] <- paste0(sum(is.na(using)), " (", round(sum(is.na(using))/length(using) * 100, 1), "%)")
				}else{
					tab$Missing[i] <- "--"
				}
			}
			tab <- tab[,-1]
			rownames(tab) <- c('Farm level','Farm level (imputed)','Animal level','Animal level (imputed)')
			
			output <- paste0(output, '
### ', criteria[c], '\n', paste(as.character(kable(tab, format='markdown', align='r')), collapse='\n'), '\n')
		}
		
		if(c != length(criteria))
			output <- paste0(output, '\n---')
	}
	
	output <- paste0(output, '

---
---

<center> <h2>Measure scores</h2> </center>

Summary statistics for the full distribution of scores for each measure are given below:

---
')

	for(c in 1:length(measures)){
		sd <- farm_imputed[,measures[c]]
		if(any(is.na(sd))){
			stopifnot(all(is.na(sd)))
			output <- paste0(output, '
### ', measures[c], '

This measure could not be summarised because it was missing for all farms.
')
		}else{
			tab <- data.frame(row=1:4, Mean=NA, StdDev=NA, Median=NA, Min=NA, Max=NA, Missing=NA)
			for(i in 1:4){
				if(i==1){
					using <- farm_nonimputed[,measures[c]]
				}else if(i==2){
					using <- farm_imputed[,measures[c]]
				}else if(i==3){
					using <- animal_nonimputed[,measures[c]]
				}else if(i==4){
					using <- animal_imputed[,measures[c]]
				}else{
					stop('Counting to 4 problem (criteria) - please file a bug report')
				}
				
				stopifnot(i %in% c(1,3) || sum(is.na(using))==0)
				
				tab$Mean[i] <- round(mean(using, na.rm=TRUE), digits)
				tab$StdDev[i] <- round(sd(using, na.rm=TRUE), digits)
				tab$Median[i] <- round(median(using, na.rm=TRUE), digits)
				tab$Min[i] <- round(min(using, na.rm=TRUE), digits)
				tab$Max[i] <- round(max(using, na.rm=TRUE), digits)
				if(i %in% c(1,3)){
					tab$Missing[i] <- paste0(sum(is.na(using)), " (", round(sum(is.na(using))/length(using) * 100, 1), "%)")
				}else{
					tab$Missing[i] <- "--"
				}
			}
			tab <- tab[,-1]
			rownames(tab) <- c('Farm level','Farm level (imputed)','Animal level','Animal level (imputed)')
			
			output <- paste0(output, '
### ', measures[c], '\n', paste(as.character(kable(tab, format='markdown', align='r')), collapse='\n'), '\n')
			
		}

		if(c != length(measures))
			output <- paste0(output, '\n---')
		
	}
	
	output <- paste0(output, '

---
---

<center> <h3>Software information</h3> </center> 

This report was generated on ', as.character(Sys.time()), ' using WelfareIndex version ', packageDescription('WelfareIndex')$Version, '
	
')
	
	tf <- tempfile('folder')
	owd <- getwd()
	dir.create(tf)
	setwd(tf)
	cat(output, file=file.path(tf, 'knitsource.Rmd'), append=FALSE)

	# To update inbuilt vignette:  uncomment line below, then run:
	# index_example('cows', write_script=TRUE); setwd("CowsExample"); source('rscript.R')
	# then copy cows_2016_report.Rmd from desktop to vignette folder, then recomment line below
#	cat(output, file=file.path('~/Desktop', 'cows_2016_report.Rmd'), append=FALSE)

	knit2html(file.path(tf, 'knitsource.Rmd'), stylesheet = get_css(), quiet=TRUE)
	setwd(owd)
	file.copy(file.path(tf, 'knitsource.html'), filename, overwrite=TRUE)
	unlink(tf, recursive=TRUE)
	
	cat('The report document "', filename, '" was created in your current working directory.  Double-click the file to open.\n', sep='')
	
}


get_css <- function(){
	css <- "
	body, td {
	   font-family: sans-serif;
	   background-color: white;
	   font-size: 13px;
	}

	body {
	  max-width: 800px;
	  margin: auto;
	  padding: 1em;
	  line-height: 20px;
	}

	tt, code, pre {
	   font-family: 'DejaVu Sans Mono', 'Droid Sans Mono', 'Lucida Console', Consolas, Monaco, monospace;
	}

	h1 {
	   font-size:2.2em;
	}

	h2 {
	   font-size:1.8em;
	}

	h3 {
	   font-size:1.4em;
	}

	h4 {
	   font-size:1.0em;
	}

	h5 {
	   font-size:0.9em;
	}

	h6 {
	   font-size:0.8em;
	}

	a:visited {
	   color: rgb(50%, 0%, 50%);
	}

	pre, img {
	  max-width: 100%;
	}
	pre {
	  overflow-x: auto;
	}
	pre code {
	   display: block; padding: 0.5em;
	}

	code {
	  font-size: 92%;
	  border: 1px solid #ccc;
	}

	code[class] {
	  background-color: #F8F8F8;
	}

	table, td, th {
	  border: none;
	}

	blockquote {
	   color:#666666;
	   margin:0;
	   padding-left: 1em;
	   border-left: 0.5em #EEE solid;
	}

	hr {
	   height: 0px;
	   border-bottom: none;
	   border-top-width: thin;
	   border-top-style: dotted;
	   border-top-color: #999999;
	}

	@media print {
	   * {
	      background: transparent !important;
	      color: black !important;
	      filter:none !important;
	      -ms-filter: none !important;
	   }

	   body {
	      font-size:12pt;
	      max-width:100%;
	   }

	   a, a:visited {
	      text-decoration: underline;
	   }

	   hr {
	      visibility: hidden;
	      page-break-before: always;
	   }

	   pre, blockquote {
	      padding-right: 1em;
	      page-break-inside: avoid;
	   }

	   tr, img {
	      page-break-inside: avoid;
	   }

	   img {
	      max-width: 100% !important;
	   }

	   @page :left {
	      margin: 15mm 20mm 15mm 10mm;
	   }

	   @page :right {
	      margin: 15mm 10mm 15mm 20mm;
	   }

	   p, h2, h3 {
	      orphans: 3; widows: 3;
	   }

	   h2, h3 {
	      page-break-after: avoid;
	   }
	}

	table {
	  width: 100%;
	  text-align: right;
	  border-collapse: collapse;
	}
	table td, table th {
	  padding: 5px 4px;
	}
	table tbody td {
	  font-size: 13px;
	}
	table thead {
	  background: #CFCFCF;
	  background: -moz-linear-gradient(top, #dbdbdb 0%, #d3d3d3 66%, #CFCFCF 100%);
	  background: -webkit-linear-gradient(top, #dbdbdb 0%, #d3d3d3 66%, #CFCFCF 100%);
	  background: linear-gradient(to bottom, #dbdbdb 0%, #d3d3d3 66%, #CFCFCF 100%);
	  border-bottom: 3px solid #000000;
	}
	table thead th {
	  font-size: 15px;
	  font-weight: bold;
	  color: #000000;
	  text-align: right;
	}
	table tfoot {
	  font-size: 14px;
	  font-weight: bold;
	  color: #000000;
	  border-top: 3px solid #000000;
	}
	table tfoot td {
	  font-size: 14px;
	}
	"
	
	return(css)
}
