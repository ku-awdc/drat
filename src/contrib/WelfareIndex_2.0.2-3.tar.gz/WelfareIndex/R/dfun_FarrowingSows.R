dfun_FarrowingSows <-
list(ValidationCheck = function(TotalAnimals){  

	CheckNumeric(TotalAnimals)  

	return(TotalAnimals)
}, RestingArea = function(RestingArea_Crated){

	CheckCategories(RestingArea_Crated, c('db','mat','solid','slatted'))
	
	score <- numeric(length(RestingArea_Crated))
	
	for(i in 1:length(score)){
		if(RestingArea_Crated[i] %in% 'db') {
			score[i] <- wRestingCrated0
		} else if(RestingArea_Crated[i] %in% c('mat', 'solid')) {
			score[i] <- wRestingCrated1
		} else if(RestingArea_Crated[i] %in% c('slatted')) {
			score[i] <- wRestingCrated2
		}else{
			stop('Unrecognised category')
		}
	}

	return(mean(score))
}, RootingMaterial = function(Rooting_Type){

	CheckCategories(Rooting_Type, c('none','straw','grass','hardwood','softwood','chain','rope','sawdust'))

	nsows <- length(Rooting_Type)
	scores <- numeric(nsows)

	for(i in 1:nsows){
		if(Rooting_Type[i] %in% c('straw', 'grass')){
			scores[i] <- wRooting0
		}else if(Rooting_Type[i] %in% c('rope', 'sawdust')){
			scores[i] <- wRooting1
		}else if(Rooting_Type[i] %in% c('hardwood','softwood')){
			scores[i] <- wRooting2
		}else if(Rooting_Type[i] %in% c('chain')){
			scores[i] <- wRooting3
		}else if(Rooting_Type[i] %in% c('none')){
			scores[i] <- wRooting4
		}else{
			stop("Unrecognised type")
		}
	}

	return (mean(scores))
}, Stereotypy = function(Stereo){

	CheckCategories(Stereo, c('0','1'))

	w0 <- NumberEqual(Stereo, '0') * wStereo0
	w1 <- NumberEqual(Stereo, '1') * wStereo1

	score <- (w0 + w1) / NumberObs(Stereo)

	return(score)
}, Bursitis = function(Bursitis){
	
	CheckCategories(Bursitis, c('0','1'))
	
	w0 <- NumberEqual(Bursitis, '0') * wBursitis0
	w1 <- NumberEqual(Bursitis, '1') * wBursitis1
	
	score <- (w0 + w1) / NumberObs(Bursitis)
	
	return(score)
}, OvergrownClaws = function(OvergrownClaws){

	CheckCategories(OvergrownClaws, c('0','1'))

	w0 <- NumberEqual(OvergrownClaws, '0') * wOverGrownClaws0
	w1 <- NumberEqual(OvergrownClaws, '1') * wOverGrownClaws1

	score <- (w0 + w1) / NumberObs(OvergrownClaws)

	return(score)
}, FarrowingSystem = function(FarrowingSystem){

	CheckCategories(FarrowingSystem, c('loose','combi','crated'))
	
	w0 <- NumberEqual(FarrowingSystem, 'loose') * wFarrowingSystem0
	w1 <- NumberEqual(FarrowingSystem, 'combi') * wFarrowingSystem1
	w2 <- NumberEqual(FarrowingSystem, 'crated') * wFarrowingSystem2

	FarrowingSysScore <- (w0 + w1 +w2) / NumberObs(FarrowingSystem)

	return(FarrowingSysScore)
}, ManureOTBody = function(Hygiene){
	
	CheckCategories(Hygiene, c('0','1','2'))
	
	w0 <- NumberEqual(Hygiene, '0') * wHygiene0
	w1 <- NumberEqual(Hygiene, '1') * wHygiene1
	w2 <- NumberEqual(Hygiene, '2') * wHygiene2
	
	score <- (w0 + w1 + w2) / NumberObs(Hygiene)
	
	return(score)
}, IntegAlterations = function(IntegumentAlterations_individual){
	
	CheckCategories(IntegumentAlterations_individual, c('0','1'))
	
	w0 <- NumberEqual(IntegumentAlterations_individual, '0') * wIntAltlnX0
	w1 <- NumberEqual(IntegumentAlterations_individual, '1') * wIntAltlnX1
	
	score <- (w0 + w1) / NumberObs(IntegumentAlterations_individual)
	
	return(score)
}, Prolapse = function(Prolapse){
	
  CheckCategories(Prolapse, c('0','1'))
  
	nindivid <- length(Prolapse)
	scores_ind <- numeric(nindivid)
	
	for(i in 1:nindivid){
		# If this individual has neither type of prolapse then get the best score:
		if((Prolapse[i]=='0')){
			scores_ind[i] <- wProlapse0
		# Otherwise the worst score:
		}else if((Prolapse[i]=='1')){
			scores_ind[i] <- wProlapse1
		}else{
			stop('Unrecognised code')
		}
	}

	score <- mean(scores_ind)
	return(score)
}, HamperedRespiration = function(HamperedResp){

	CheckCategories(HamperedResp, c('0','1'))

	w0 <- NumberEqual(HamperedResp, '0') * wHampResp0
	w1 <- NumberEqual(HamperedResp, '1') * wHampResp1
	  
	score <- (w0 + w1) / NumberObs(HamperedResp)

	return(score)
}, ShoulderWounds = function(ShoulderWounds_individual){

	CheckCategories(ShoulderWounds_individual, c('0','1', '2'))
	
	w0 <- NumberEqual(ShoulderWounds_individual, '0') * wShoulder0
	w1 <- NumberEqual(ShoulderWounds_individual, '1') * wShoulder1
	w2 <- NumberEqual(ShoulderWounds_individual, '2') * wShoulder2
	
	score <- (w0 + w1 + w2) / NumberObs(ShoulderWounds_individual)
	
	return(score)
}, BodyCondition = function(BCS_individual){
	
	CheckCategories(BCS_individual, c('0','1'))
	
	w0 <- NumberEqual(BCS_individual, '0') * wBCS0
	w1 <- NumberEqual(BCS_individual, '1') * wBCS1
	
	score <- (w0 + w1) / NumberObs(BCS_individual)
	
	return(score)
}, Panting = function(Panting){
	
	CheckCategories(Panting, c('0','1'))
	
	w0 <- NumberEqual(Panting, '0') * wPanting0
	w1 <- NumberEqual(Panting, '1') * wPanting1
	
	score <- (w0 + w1) / NumberObs(Panting)
	
	return(score)
}, NestBuildingBehaviour = function(Nest_buil_Access){

	CheckCategories(Nest_buil_Access, c('yes','no'))

	w0 <- NumberEqual(Nest_buil_Access, 'yes') * wNestBuild0
	w1 <- NumberEqual(Nest_buil_Access, 'no') * wNestBuild1

	score <- (w0 + w1) / NumberObs(Nest_buil_Access)

	return(score)
}, Hernia = function(Hernia){

	CheckCategories(Hernia, c('0','1','2'))

	w0 <- NumberEqual(Hernia, '0') * wHernia0
	w1 <- NumberEqual(Hernia, '1') * wHernia1
	w2 <- NumberEqual(Hernia, '2') * wHernia2

	score <- (w0 + w1 + w2) / NumberObs(Hernia)

	return(score)
}, WaterSupply = function(water_functioning){
  
    CheckCategories(water_functioning, c('functioning','not_functioning'))
  
	w0 <- NumberEqual(water_functioning, 'functioning') * wWatersupplyFunc0
	w1 <- NumberEqual(water_functioning, 'not_functioning') * wWatersupplyFunc1

	score <- (w0 + w1) / NumberObs(water_functioning)
  
	return( score )
}, VulvaLesions = function(VulvaLesions_individual){

	CheckCategories(VulvaLesions_individual, c('0','1'))

	w0 <- NumberEqual(VulvaLesions_individual, '0') * wVulvaLesions0
	w1 <- NumberEqual(VulvaLesions_individual, '1') * wVulvaLesions1
	
	score <- (w0 + w1) / NumberObs(VulvaLesions_individual)
	
	return(score)
}, FarrowingRails = function(FarrowingRails){

	CheckCategories(FarrowingRails, c('present','not_present'))
	w0 <- NumberEqual(FarrowingRails, 'present') * wFarrowingRails0
	w1 <- NumberEqual(FarrowingRails, 'not_present') * wFarrowingRails1

	RailsScore <- (w0 + w1) / NumberObs(FarrowingRails)

	return(RailsScore)
}, Roughage = function(Roughage_Type){

	## Change:
	CheckCategories(Roughage_Type, c('none','straw','grass'))
  
	w0 <- NumberEqual(Roughage_Type, c("straw","grass")) * wRoughage0
	w1 <- NumberEqual(Roughage_Type, "none") * wRoughage1

	Roughagescore <- (w0 + w1) / NumberObs(Roughage_Type)

	return(Roughagescore)
}, CleanWater = function(water_functioning, water_clean){
	
	CheckCategories(water_functioning, c('functioning','not_functioning'))
	CheckCategories(water_clean, c('clean','dirty'))
  
	# Water needs to be clean & functioning to get the good score
	w0 <- sum(water_functioning == "functioning" & water_clean == "clean") * wWatersupplyClean0
	w1 <- sum(water_functioning != "functioning" | water_clean != "clean") * wWatersupplyClean1
	
	score <- (w0 + w1) / NumberObs(water_functioning)

	return( score )

}, FarrowingSpace = function(Crates = data.frame(SowLength, SowShoulderWidth, RearGateTop, RearGateBottom, Frontstanchion, Cratelength), Pens = data.frame(Penarea, Canturn)){

	# Calculate the crate scores, if any animals are crated:
	if(nrow(Crates)==0){
		cratescores <- numeric(0)
	}else{
		connect(Crates)
		
		CheckNumeric(SowShoulderWidth)
		CheckNumeric(SowLength)
		CheckNumeric(RearGateTop)
		CheckNumeric(RearGateBottom)
		CheckNumeric(Frontstanchion)
		CheckNumeric(Cratelength)

		nsows <- length(SowLength)
		scores <- numeric(nsows)
		for(i in 1:nsows){
			# Various requirements for the minumum dimensions for a good score:
			if((RearGateTop[i]>= (SowShoulderWidth[i] +0.25)) & (RearGateBottom[i]>= (SowShoulderWidth[i] +0.40)) & (Cratelength[i]>= (SowLength[i] + 0.50)) & (Frontstanchion[i]>= (SowShoulderWidth[i] +0.15))){
				scores[i] <- wSpaceCrate0
			}else{
				scores[i] <- wSpaceCrate1
			}
		}
		cratescores <- scores

		disconnect(Crates)
	}
	
	# Calculate the pen scores, if any penned, assuming that all are individually penned:
	if(nrow(Pens)==0){
		penscores <- numeric(0)
	}else{
		connect(Pens)
		
	    CheckNumeric(Penarea)
	    CheckCategories(Canturn, c('yes', 'no'))
	
	    npens <- length(Penarea)
	    scores <- numeric(npens)
		for(p in 1:npens){
			if((Penarea[p]>= 6) & (Canturn[p]== 'yes')){
				scores[p] <- wSpacePen0
			}else{
				scores[p] <- wSpacePen1
			}
		}
		penscores <- scores

		disconnect(Pens)
	}
	# TODO: it may be needed to add the possibility of group penned farrowing sows but there are none in 2015 data
	
	allscores <- c(cratescores, penscores)
	return(mean(allscores))
}, Mortality = function(Mortality){
	
	CheckPercent(Mortality)
	CheckLength1(Mortality)
	
	# Score is based on % mortality as follows:
	if(Mortality <= vMortThreshold0){
		score <- wMortality0
	}else if(Mortality <= vMortThreshold1){
		score <- wMortality1
	}else if(Mortality <= vMortThreshold2){
		score <- wMortality2
	}else{
		score <- wMortality3
	}
	
	return(score)
}, NoseRing = function(NoseRing_Sows){

	CheckCategories(NoseRing_Sows, c('0','1'))

	w0 <- NumberEqual(NoseRing_Sows, '0') * wNoseRing0
	w1 <- NumberEqual(NoseRing_Sows, '1') * wNoseRing1

	score <- (w0 + w1) / NumberObs(NoseRing_Sows)

	return(score)
}, NursingSows = function(Percent_long_term_crated){
	
	CheckNumeric(Percent_long_term_crated)
	
	w0 <- ((100-Percent_long_term_crated)/100) * wAmmeso0
	w1 <- (Percent_long_term_crated/100)  * wAmmeso1
	score <- w0 + w1
	
	return(score)
  
})
