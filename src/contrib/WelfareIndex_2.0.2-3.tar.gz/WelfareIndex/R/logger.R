logger <- setRefClass('logger',
	fields = list(errorfile='character', warningfile='character', type='character', CHR='character', Observer='character', Date='Date', Measure='character', allerrors='character', allwarnings='character', datasets='numeric', active='logical', opened_at='POSIXct', warning_open='logical', error_open='logical'), 

	methods = list(

	initialize = function(errorfile, warningfile, type){
		"Initialise a logger class with errorfile and warningfile"
		
		.self$errorfile <- errorfile
		.self$warningfile <- warningfile
		.self$type <- type
		.self$allerrors <- character(0)
		.self$allwarnings <- character(0)
		.self$CHR <- ''
		.self$Observer <- ''
		.self$Date <- as.Date('0000-01-01')
		.self$Measure <- ''
		.self$datasets <- 0
		.self$active <- FALSE
		.self$opened_at <- as.POSIXct(Sys.time())
		.self$warning_open <- FALSE
		.self$error_open <- FALSE
		
	},
	
	# Set active dataset for checking:
	SetDataset = function(CHR, Observer, Date, Measure){
		.self$CHR <- CHR
		.self$Observer <- Observer
		.self$Date <- as.Date(Date)
		.self$Measure <- Measure
		.self$allerrors <- character(0)
		.self$allwarnings <- character(0)
		.self$datasets <- .self$datasets + 1
		.self$active <- TRUE
	},
	
	# Deactivate dataset for checking:
	UnsetDataset = function(){
		.self$CHR <- ''
		.self$Observer <- ''
		.self$Date <- as.Date('0000-01-01')
		.self$allerrors <- character(0)
		.self$allwarnings <- character(0)
		.self$active <- FALSE
	},
	
	# Log an error:
	Error = function(text, ...){
		
		if(.self$errorfile!='' && .self$errorfile!='/dev/null' && !.self$error_open){
			# Open a text file (or two if different names for error and warning) and put checking date/time etc there:
			if(.self$errorfile==.self$warningfile){
#				cat('Opening combined error and warning file for', .self$type, 'on', strftime(.self$opened_at), '\n\n', file=.self$errorfile, append=FALSE)
				cat('Opening file on', strftime(.self$opened_at), '\n\n', file=.self$errorfile, append=FALSE)
				.self$warning_open <- TRUE
			}else{
#				cat('Opening error file for', .self$type, 'on', strftime(.self$opened_at), '\n\n', file=.self$errorfile, append=FALSE)
				cat('Opening file on', strftime(.self$opened_at), '\n\n', file=.self$errorfile, append=FALSE)
			}
			.self$error_open <- TRUE
		}
		
		text <- paste(text, ...)
		
		stopifnot(.self$active)
		.self$allerrors <- c(.self$allerrors, text)
		
		logtext <- paste0('Error for measure ', Measure, ' (CHR ', CHR, ', Observer ', Observer, ', Date ', as.character(Date), '):\n\t', text)
		
		if(.self$errorfile!='/dev/null')
			cat(logtext, '\n', file=.self$errorfile, append=TRUE)
		
		invisible(logtext)
	
	},

	# Log a warning:
	Warning = function(text, ...){
		
		if(.self$warningfile!='' && .self$warningfile!='/dev/null' && !.self$warning_open){
			# Open a text file (or two if different names for error and warning) and put checking date/time etc there:
			if(.self$errorfile==.self$warningfile){
#				cat('Opening combined error and warning file for', .self$type, 'on', strftime(.self$opened_at), '\n\n', file=.self$errorfile, append=FALSE)
				cat('Opening file on', strftime(.self$opened_at), '\n\n', file=.self$errorfile, append=FALSE)
				.self$error_open <- TRUE
			}else{
#				cat('Opening warning file for', .self$type, 'on', strftime(.self$opened_at), '\n\n', file=.self$warningfile, append=FALSE)
				cat('Opening file on', strftime(.self$opened_at), '\n\n', file=.self$warningfile, append=FALSE)
			}
			.self$warning_open <- TRUE
		}
		
		text <- paste(text, ...)

		stopifnot(.self$active)
		.self$allwarnings <- c(.self$allwarnings, text)
		
		logtext <- paste0('Warning for measure ', Measure, ' (CHR ', CHR, ', Observer ', Observer, ', Date ', as.character(Date), '):\n\t', text)
		
		if(.self$warningfile!='/dev/null')
			cat(logtext, '\n', file=.self$warningfile, append=TRUE)
		
		invisible(logtext)
	},

	# Retrieve errors:
	RetrieveErrors = function(){
		return(.self$allerrors)
	},

	# Retrieve warnings:
	RetrieveWarnings = function(){
		return(.self$allwarnings)
	},
	
	# Close error and warning files:
	CloseFiles = function(){
		
		# Close the text file(s) and log the time taken from opened_at and .self$datasets:
		if(.self$errorfile!='' && .self$errorfile!='/dev/null' && .self$error_open){
			if(.self$errorfile==.self$warningfile){
#				cat('\nClosing combined error and warning file after checking', .self$datasets, 'datasets in', difftime(Sys.time(), .self$opened_at, units='secs'), 'seconds\n', file=.self$errorfile, append=TRUE)
				cat('\nClosing file after checking', .self$datasets, 'datasets in', difftime(Sys.time(), .self$opened_at, units='secs'), 'seconds\n', file=.self$errorfile, append=TRUE)
				.self$warning_open <- FALSE
			}else{
#				cat('\nClosing error file after checking', .self$datasets, 'datasets in', difftime(Sys.time(), .self$opened_at, units='secs'), 'seconds\n', file=.self$errorfile, append=TRUE)
				cat('\nClosing file after checking', .self$datasets, 'datasets in', difftime(Sys.time(), .self$opened_at, units='secs'), 'seconds\n', file=.self$errorfile, append=TRUE)
			}
			.self$error_open <- FALSE
		}
		if(.self$warningfile!='' && .self$warningfile!='/dev/null' && .self$warning_open){
#			cat('\nClosing warning file after checking', .self$datasets, 'datasets in', difftime(Sys.time(), .self$opened_at, units='secs'), 'seconds\n', file=.self$warningfile, append=TRUE)
			cat('\nClosing file after checking', .self$datasets, 'datasets in', difftime(Sys.time(), .self$opened_at, units='secs'), 'seconds\n', file=.self$warningfile, append=TRUE)
			.self$warning_open <- FALSE
		}

	},
	
	finalize = function(){
		
		CloseFiles()
		
	}
))
