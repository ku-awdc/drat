dfun_Calves <-
list(BodyConditionScore = function(BodyConditionScore){
	
	CheckCategories(BodyConditionScore, c('0','1'))

	w0 <- NumberEqual(BodyConditionScore, '0') * wCalfBodyCond0
	w1 <- NumberEqual(BodyConditionScore, '1') * wCalfBodyCond1

	score <- (w0 + w1) / length(BodyConditionScore)

	return(score)
}, Tethering = function(Group=data.frame(TetheringGroup, NoResourcesAnimals), Individual=data.frame(TetheringIndivid)){
	
	# Note: Tethering does not correspond to the net list

	# Check to see if there are any individual animals and if not then set the values to 0:
	if(nrow(Individual)==0){
		wIndivid0 <- 0
		wIndivid1 <- 0
		individual_animals <- 0
	}else{
		connect(Individual)
	
		CheckCategories(TetheringIndivid, c('0','1'))
		wIndivid0 <- NumberEqual(TetheringIndivid, '0') * wTethering0
		wIndivid1 <- NumberEqual(TetheringIndivid, '1') * wTethering1

		individual_animals <- length(TetheringIndivid)

		disconnect(Individual)
	}
	
	# Check to see if there are any group housed animals and if not then set the values to 0:
	if(nrow(Group)==0){
		wGroup0 <- 0
		wGroup1 <- 0
		group_animals <- 0
	}else{
		connect(Group)

		CheckNumeric(NoResourcesAnimals)
		CheckCategories(TetheringGroup, c('0','1'))
		wGroup0 <- WeightedNumberEqual(TetheringGroup, '0', NoResourcesAnimals) * wTethering0
		wGroup1 <- WeightedNumberEqual(TetheringGroup, '1', NoResourcesAnimals) * wTethering1
	
		group_animals <- sum(NoResourcesAnimals)

		disconnect(Group)
	}
	
	if((individual_animals + group_animals) == 0){
		return("No complete observations for either individual or group housed")
	}

	score <- (wGroup0 + wGroup1 + wIndivid0 + wIndivid1) / (individual_animals + group_animals)
	return(score)
}, AccessToSickPen = function(Individual = data.frame(SuffWaterIndivid), Group = data.frame(AccessToSickPen, NoResourcesAnimals)){

	# Check to see if there are any individual animals and if not then set the values to 0:
	if(nrow(Individual)==0){
		wIndivid0 <- 0
		wIndivid1 <- 0
		individual_animals <- 0
	}else{
		connect(Individual)
		
		CheckCategories(SuffWaterIndivid, c('0','1'))
		# Note: SuffWaterIndivid is a dummy measure, all individually penned animals have access to sick pen
		wIndivid0 <- length(SuffWaterIndivid) * wAccessToSickPen0
		wIndivid1 <- 0
		
		individual_animals <- length(SuffWaterIndivid)

		disconnect(Individual)
	}
	
	# Check to see if there are any group housed animals and if not then set the values to 0:
	if(nrow(Group)==0){
		wGroup0 <- 0
		wGroup1 <- 0
		group_animals <- 0
	}else{
		connect(Group)

		CheckCategories(AccessToSickPen, c('0','1'))
		CheckNumeric(NoResourcesAnimals)
		wGroup0 <- WeightedNumberEqual(AccessToSickPen, '0', NoResourcesAnimals) * wAccessToSickPen0
		wGroup1 <- WeightedNumberEqual(AccessToSickPen, '1', NoResourcesAnimals) * wAccessToSickPen1

		group_animals <- sum(NoResourcesAnimals)

		disconnect(Group)
	}
	
	if((individual_animals + group_animals) == 0){
		return("No complete observations for either individual or group housed")
	}

	score <- (wGroup0 + wGroup1 + wIndivid0 + wIndivid1) / (individual_animals + group_animals)
	return(score)
}, Diarrhea = function(Diarrhea){

	CheckCategories(Diarrhea, c('0','1'))

	w0 <- NumberEqual(Diarrhea, '0') * wDiarrhea0
	w1 <- NumberEqual(Diarrhea, '1') * wDiarrhea1

	score <- (w0 + w1) / length(Diarrhea)
	return(score)
}, LocalAnaestheticsPreDehorning = function(LocalAnestehticsPreDehorning){

	CheckCategories(LocalAnestehticsPreDehorning, c('0','1'))
	CheckLength1(LocalAnestehticsPreDehorning)

	score <- ifelse(LocalAnestehticsPreDehorning=='0', wLocalAnestehticsPreDehorning0, wLocalAnestehticsPreDehorning1)
	return(score)
}, AccessToOtherCalves = function(Group = data.frame(NoResourcesAnimals), Individual = data.frame(AccessToOtherCalves)){
	
	# Check to see if there are any individual animals and if not then set the values to 0:
	if(nrow(Individual)==0){
		wIndivid0 <- 0
		wIndivid1 <- 0
		wIndivid2 <- 0
		individual_animals <- 0
	}else{
		connect(Individual)
		
		CheckCategories(AccessToOtherCalves, c('0','1','2'))
		wIndivid0 <- NumberEqual(AccessToOtherCalves, '0') * wAccessToOtherCalves0
		wIndivid1 <- NumberEqual(AccessToOtherCalves, '1') * wAccessToOtherCalves1
		wIndivid2 <- NumberEqual(AccessToOtherCalves, '2') * wAccessToOtherCalves2

		individual_animals <- length(AccessToOtherCalves)

		disconnect(Individual)
	}
	
	# Check to see if there are any group housed animals and if not then set the values to 0:
	if(nrow(Group)==0){
		wGroup0 <- 0
		wGroup1 <- 0
		wGroup2 <- 0
		group_animals <- 0
	}else{
		connect(Group)

		CheckNumeric(NoResourcesAnimals)
		# Note:  Assumes all group housed animals have access to other calves
		wGroup0 <- sum(NoResourcesAnimals) * wAccessToOtherCalves0
		wGroup1 <- 0
		wGroup2 <- 0

		group_animals <- sum(NoResourcesAnimals)

		disconnect(Group)
	}
	
	if((individual_animals + group_animals) == 0){
		return("No complete observations for either individual or group housed")
	}

	score <- (wGroup0 + wGroup1 + wGroup2 + wIndivid0 + wIndivid1 + wIndivid2) / (individual_animals + group_animals)
	return(score)
}, WaterSuff = function(Individual = data.frame(SuffWaterIndivid), Group = data.frame(SuffWaterGroup, NoResourcesAnimals)){
	
	# Check to see if there are any individual animals and if not then set the values to 0:
	if(nrow(Individual)==0){
		wIndivid0 <- 0
		wIndivid1 <- 0
		individual_animals <- 0
	}else{
		connect(Individual)
	
		CheckCategories(SuffWaterIndivid, c('0','1'))
		wIndivid0 <- NumberEqual(SuffWaterIndivid, '0') * wSuffWaterIndivid0
		wIndivid1 <- NumberEqual(SuffWaterIndivid, '1') * wSuffWaterIndivid1
		individual_animals <- length(SuffWaterIndivid)

		disconnect(Individual)
	}
	
	# Check to see if there are any group housed animals and if not then set the values to 0:
	if(nrow(Group)==0){
		wGroup0 <- 0
		wGroup1 <- 0
		group_animals <- 0
	}else{
		connect(Group)
  
		CheckCategories(SuffWaterGroup, c('0','1'))
		CheckNumeric(NoResourcesAnimals)
		wGroup0 <- WeightedNumberEqual(SuffWaterGroup, '0', NoResourcesAnimals) * wSuffWaterGroup0
		wGroup1 <- WeightedNumberEqual(SuffWaterGroup, '1', NoResourcesAnimals) * wSuffWaterGroup1

		group_animals <- sum(NoResourcesAnimals)

		disconnect(Group)
	}
	
	if((individual_animals + group_animals) == 0){
		return("No complete observations for either individual or group housed")
	}

	score <- (wIndivid0 + wIndivid1 + wGroup0 + wGroup1) / (individual_animals + group_animals)
	return(score)
}, Roughage = function(Individual = data.frame(AccessRoughageTMRCalfmuesliHayIndivid), Group = data.frame(AccessRoughageTMRCalfmuesliHayGroup, NoResourcesAnimals)){
	
	# Check to see if there are any individual animals and if not then set the values to 0:
	if(nrow(Individual)==0){
		wIndivid0 <- 0
		wIndivid1 <- 0
		individual_animals <- 0
	}else{
		connect(Individual)
	
		CheckCategories(AccessRoughageTMRCalfmuesliHayIndivid, c('0','1'))
		wIndivid0 <- NumberEqual(AccessRoughageTMRCalfmuesliHayIndivid, '0') * wCalfRoughage0
		wIndivid1 <- NumberEqual(AccessRoughageTMRCalfmuesliHayIndivid, '1') * wCalfRoughage1
		
		individual_animals <- length(AccessRoughageTMRCalfmuesliHayIndivid)
		
		disconnect(Individual)
	}
	
	# Check to see if there are any group housed animals and if not then set the values to 0:
	if(nrow(Group)==0){
		wGroup0 <- 0
		wGroup1 <- 0
		group_animals <- 0
	}else{
		connect(Group)
  
		CheckCategories(AccessRoughageTMRCalfmuesliHayGroup, c('0','1'))
		CheckNumeric(NoResourcesAnimals)
		wGroup0 <- WeightedNumberEqual(AccessRoughageTMRCalfmuesliHayGroup, '0', NoResourcesAnimals) * wCalfRoughage0
		wGroup1 <- WeightedNumberEqual(AccessRoughageTMRCalfmuesliHayGroup, '1', NoResourcesAnimals) * wCalfRoughage1
		
		group_animals <- sum(NoResourcesAnimals)
		
		disconnect(Group)
	}
	
	if((individual_animals + group_animals) == 0){
		return("No complete observations for either individual or group housed")
	}

	score <- (wIndivid0 + wIndivid1 + wGroup0 + wGroup1) / (individual_animals + group_animals)
	return(score)
}, HamperedResp = function(HamperedResp){

	CheckCategories(HamperedResp, c('0','1'))

	w0 <- NumberEqual(HamperedResp, '0') * wHamperedResp0
	w1 <- NumberEqual(HamperedResp, '1') * wHamperedResp1

	score <- (w0 + w1) / length(HamperedResp)
	return(score)
}, Floorage = function(Group = data.frame(FloorageIndexGroup, NoResourcesAnimals), Individual = data.frame(FloorageIndexIndiv)){

	# Check to see if there are any individual animals and if not then set the values to 0:
	if(nrow(Individual)==0){
		wIndivid0 <- 0
		wIndivid1 <- 0
		wIndivid2 <- 0
		individual_animals <- 0
	}else{
		connect(Individual)
	
		CheckCategories(FloorageIndexIndiv, c('0','1','2'))
		wIndivid0 <- NumberEqual(FloorageIndexIndiv, '0') * wFloorageGroup0
		wIndivid1 <- NumberEqual(FloorageIndexIndiv, '1') * wFloorageGroup1
		wIndivid2 <- NumberEqual(FloorageIndexIndiv, '2') * wFloorageGroup2
	
		individual_animals <- length(FloorageIndexIndiv)

		disconnect(Individual)
	}
	
	# Check to see if there are any group housed animals and if not then set the values to 0:
	if(nrow(Group)==0){
		wGroup0 <- 0
		wGroup1 <- 0
		wGroup2 <- 0
		group_animals <- 0
	}else{
		connect(Group)

		CheckNumeric(NoResourcesAnimals)
		CheckCategories(FloorageIndexGroup, c('0','1','2'))
		wGroup0 <- WeightedNumberEqual(FloorageIndexGroup, '0', NoResourcesAnimals) * wFloorageIndivid0
		wGroup1 <- WeightedNumberEqual(FloorageIndexGroup, '1', NoResourcesAnimals) * wFloorageIndivid1
		wGroup2 <- WeightedNumberEqual(FloorageIndexGroup, '2', NoResourcesAnimals) * wFloorageIndivid2

		group_animals <- sum(NoResourcesAnimals)

		disconnect(Group)
	}
	
	if((individual_animals + group_animals) == 0){
		return("No complete observations for either individual or group housed")
	}

	score <- (wGroup0 + wGroup1 + wGroup2 + wIndivid0 + wIndivid1 + wIndivid2) / (individual_animals + group_animals)
	return(score)
}, AccessToArtificialTeat = function(Group = data.frame(AccessToArtificialTeatGroup, NoResourcesAnimals), Individual = data.frame(AccessToArtificialTeatIndivid)){

	# Check to see if there are any individual animals and if not then set the values to 0:
	if(nrow(Individual)==0){
		wIndivid0 <- 0
		wIndivid1 <- 0
		wIndivid2 <- 0
		individual_animals <- 0
	}else{
		connect(Individual)
	
		CheckCategories(AccessToArtificialTeatIndivid, c('0','1','2'))
		wIndivid0 <- NumberEqual(AccessToArtificialTeatIndivid, '0') * wAccessToArtificialTeat0
		wIndivid1 <- NumberEqual(AccessToArtificialTeatIndivid, '1') * wAccessToArtificialTeat1
		wIndivid2 <- NumberEqual(AccessToArtificialTeatIndivid, '2') * wAccessToArtificialTeat2

		individual_animals <- length(AccessToArtificialTeatIndivid)

		disconnect(Individual)
	}
	
	# Check to see if there are any group housed animals and if not then set the values to 0:
	if(nrow(Group)==0){
		wGroup0 <- 0
		wGroup1 <- 0
		wGroup2 <- 0
		group_animals <- 0
	}else{
		connect(Group)

		CheckCategories(AccessToArtificialTeatGroup, c('0','1','2'))
		CheckNumeric(NoResourcesAnimals)
		wGroup0 <- WeightedNumberEqual(AccessToArtificialTeatGroup, '0', NoResourcesAnimals) * wAccessToArtificialTeat0
		wGroup1 <- WeightedNumberEqual(AccessToArtificialTeatGroup, '1', NoResourcesAnimals) * wAccessToArtificialTeat1
		wGroup2 <- WeightedNumberEqual(AccessToArtificialTeatGroup, '2', NoResourcesAnimals) * wAccessToArtificialTeat2
		
		group_animals <- sum(NoResourcesAnimals)

		disconnect(Group)
	}
	
	if((individual_animals + group_animals) == 0){
		return("No complete observations for either individual or group housed")
	}

	score <- (wGroup0 + wGroup1 + wGroup2 + wIndivid0 + wIndivid1 + wIndivid2) / (individual_animals + group_animals)
	return(score)
}, NSAIDsPostDehorning = function(NSAIDsPostDehorning){

	CheckCategories(NSAIDsPostDehorning, c('0','1'))
	CheckLength1(NSAIDsPostDehorning)

	score <- ifelse(NSAIDsPostDehorning=='0', wNSAIDsPostDehorning0, wNSAIDsPostDehorning1)
	return(score)
}, IntegumentAlterations = function(IntegumentAlterations){

	CheckCategories(IntegumentAlterations, c('0','1','2'))

	w0 <- NumberEqual(IntegumentAlterations, '0') * wIntegumentAlterations0

	w1 <- NumberEqual(IntegumentAlterations, '1') * wIntegumentAlterations1
	w2 <- NumberEqual(IntegumentAlterations, '2') * wIntegumentAlterations2

	score <- (w0 + w1 + w2) / length(IntegumentAlterations)
	return(score)
}, AgeAtDehorning = function(AgeAtDehorning){

	CheckCategories(AgeAtDehorning, c('0','1'))
	CheckLength1(AgeAtDehorning)

	score <- ifelse(AgeAtDehorning=='0', wAgeAtDehorning0, wAgeAtDehorning1)
	return(score)
}, Mortality = function(Mortality){
	
	CheckPercent(Mortality)
	CheckLength1(Mortality)
	
	# Score is based on % mortality as follows:
	if(Mortality <= vMortThreshold0){
		score <- wMortality0
	}else if(Mortality <= vMortThreshold1){
		score <- wMortality1
	}else{
		score <- wMortality2
	}
	
	return(score)
}, Bedding = function(Group = data.frame(BeddingMaterialGroup, NoResourcesAnimals), Individual = data.frame(BeddingMaterialIndivid)){
	
	# Check to see if there are any individual animals and if not then set the values to 0:
	if(nrow(Individual)==0){
		wIndivid0 <- 0
		wIndivid1 <- 0
		wIndivid2 <- 0
		individual_animals <- 0
	}else{
		connect(Individual)
	
		CheckCategories(BeddingMaterialIndivid, c('0','1','2'))
		wIndivid0 <- NumberEqual(BeddingMaterialIndivid, '0') * wBedding0
		wIndivid1 <- NumberEqual(BeddingMaterialIndivid, '1') * wBedding1
		wIndivid2 <- NumberEqual(BeddingMaterialIndivid, '2') * wBedding2
		
		individual_animals <- length(BeddingMaterialIndivid)

		disconnect(Individual)
	}
	
	# Check to see if there are any group housed animals and if not then set the values to 0:
	if(nrow(Group)==0){
		wGroup0 <- 0
		wGroup1 <- 0
		wGroup2 <- 0
		group_animals <- 0
	}else{
		connect(Group)

		CheckCategories(BeddingMaterialGroup, c('0','1','2'))
		CheckNumeric(NoResourcesAnimals)
		wGroup0 <- WeightedNumberEqual(BeddingMaterialGroup, '0', NoResourcesAnimals) * wBedding0
		wGroup1 <- WeightedNumberEqual(BeddingMaterialGroup, '1', NoResourcesAnimals) * wBedding1
		wGroup2 <- WeightedNumberEqual(BeddingMaterialGroup, '2', NoResourcesAnimals) * wBedding2

		group_animals <- sum(NoResourcesAnimals)

		disconnect(Group)
	}
	
	if((individual_animals + group_animals) == 0){
		return("No complete observations for either individual or group housed")
	}

	score <- (wGroup0 + wGroup1 + wGroup2 + wIndivid0 + wIndivid1 + wIndivid2) / (individual_animals + group_animals)
	return(score)
}, AccessToBrush = function(Group = data.frame(AccessToCalfBrushGroup, NoResourcesAnimals), Individual = data.frame(AccessToCalfBrushIndivid)){

	# Check to see if there are any individual animals and if not then set the values to 0:
	if(nrow(Individual)==0){
		wIndivid0 <- 0
		wIndivid1 <- 0
		individual_animals <- 0
	}else{
		connect(Individual)
	
		CheckCategories(AccessToCalfBrushIndivid, c('0','1'))
		wIndivid0 <- NumberEqual(AccessToCalfBrushIndivid, '0') * wAccessToBrush0
		wIndivid1 <- NumberEqual(AccessToCalfBrushIndivid, '1') * wAccessToBrush1

		individual_animals <- length(AccessToCalfBrushIndivid)

		disconnect(Individual)
	}
	
	# Check to see if there are any group housed animals and if not then set the values to 0:
	if(nrow(Group)==0){
		wGroup0 <- 0
		wGroup1 <- 0
		wGroup2 <- 0
		group_animals <- 0
	}else{
		connect(Group)

		CheckNumeric(NoResourcesAnimals)
		CheckCategories(AccessToCalfBrushGroup, c('0','1'))
		wGroup0 <- WeightedNumberEqual(AccessToCalfBrushGroup, '0', NoResourcesAnimals) * wAccessToBrush0
		wGroup1 <- WeightedNumberEqual(AccessToCalfBrushGroup, '1', NoResourcesAnimals) * wAccessToBrush1

		group_animals <- sum(NoResourcesAnimals)

		disconnect(Group)
	}
	
	if((individual_animals + group_animals) == 0){
		return("No complete observations for either individual or group housed")
	}

	score <- (wGroup0 + wGroup1 + wIndivid0 + wIndivid1) / (individual_animals + group_animals)
	return(score)
}, NasalDischarge = function(NasalDischarge){

	CheckCategories(NasalDischarge, c('0','1'))

	w0 <- NumberEqual(NasalDischarge, '0') * wNasalDischarge0
	w1 <- NumberEqual(NasalDischarge, '1') * wNasalDischarge1

	score <- (w0 + w1) / length(NasalDischarge)
	return(score)
}, WaterWeaned = function(Individual = data.frame(WaterAccessNonWeanedIndivid), Group = data.frame(WaterAccessNonWeanedGroup, NoResourcesAnimals)){
	
	# Check to see if there are any individual animals and if not then set the values to 0:
	if(nrow(Individual)==0){
		wIndivid0 <- 0
		wIndivid1 <- 0
		individual_animals <- 0
	}else{
		connect(Individual)
	
		CheckCategories(WaterAccessNonWeanedIndivid, c('0','1'))
		wIndivid0 <- NumberEqual(WaterAccessNonWeanedIndivid, '0') * wWaterAccessNonWeanedIndivid0
		wIndivid1 <- NumberEqual(WaterAccessNonWeanedIndivid, '1') * wWaterAccessNonWeanedIndivid1
		individual_animals <- length(WaterAccessNonWeanedIndivid)

		disconnect(Individual)
	}
	
	# Check to see if there are any group housed animals and if not then set the values to 0:
	if(nrow(Group)==0){
		wGroup0 <- 0
		wGroup1 <- 0
		group_animals <- 0
	}else{
		connect(Group)

		CheckCategories(WaterAccessNonWeanedGroup, c('0','1'))
		CheckNumeric(NoResourcesAnimals)
		wGroup0 <- WeightedNumberEqual(WaterAccessNonWeanedGroup, '0', NoResourcesAnimals) * wWaterAccessNonWeanedGroup0
		wGroup1 <- WeightedNumberEqual(WaterAccessNonWeanedGroup, '1', NoResourcesAnimals) * wWaterAccessNonWeanedGroup1

		group_animals <- sum(NoResourcesAnimals)

		disconnect(Group)
	}
	
	if((individual_animals + group_animals) == 0){
		return("No complete observations for either individual or group housed")
	}

	score <- (wIndivid0 + wIndivid1 + wGroup0 + wGroup1) / (individual_animals + group_animals)
	return(score)
}, Cleanliness = function(Cleanliness){

	CheckCategories(Cleanliness, c('0','1','2'))

	w0 <- NumberEqual(Cleanliness, '0') * wCleanliness0
	w1 <- NumberEqual(Cleanliness, '1') * wCleanliness1
	w2 <- NumberEqual(Cleanliness, '2') * wCleanliness2
	score <- (w0 + w1 + w2) / length(Cleanliness)

	return(score)
}, ValidationCheck = function(TotalAnimals){
	
	CheckLength1(TotalAnimals)
	CheckNumeric(TotalAnimals)

	# Return TotalAnimals:
	return(TotalAnimals)
})
