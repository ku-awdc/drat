dfun_Cows <-
list(ValidationCheck = function(TotalAnimals, NoAnimalsSickCalvingPen){
	
	CheckLength1(TotalAnimals)
	CheckNumeric(TotalAnimals)
	CheckLength1(NoAnimalsSickCalvingPen)
	CheckNumeric(NoAnimalsSickCalvingPen)
	
	if(!is.na(NoAnimalsSickCalvingPen) && TotalAnimals != NoAnimalsSickCalvingPen)
		log$Warning("The recorded TotalAnimals:", TotalAnimals, "is not the same as NoAnimalsSickCalvingPen:", NoAnimalsSickCalvingPen)
	
	# Return TotalAnimals:
	return(TotalAnimals)
}, CleanlinessLowerHind = function(CleanlinessLowerHind){
	
	CheckCategories(CleanlinessLowerHind, c('0','1'))
	
	w0 <- NumberEqual(CleanlinessLowerHind, '0') * wCleanlinessLowerHind0
	w1 <- NumberEqual(CleanlinessLowerHind, '1') * wCleanlinessLowerHind1
	
	score <- (w0 + w1) / length(CleanlinessLowerHind)
	
	return(score)
}, AccessCalvingPen = function(NoCalvingPens, NoAnimalsSickCalvingPen){
	
	# Note: NoAnimalsSickCalvingPen should be the same as TotalAnimals (this is checked by the Validation score):
	# In future it may be better to have this information on the farm sheet with total animals

	CheckNumeric(NoAnimalsSickCalvingPen)
	CheckNumeric(NoCalvingPens)
	
	CheckLength1(NoAnimalsSickCalvingPen)
	CheckLength1(NoCalvingPens)
	
	# If there are no calving pens at all get worst score:
	if(NoCalvingPens == 0){
		return(wCalvingPen2)
	}
	
	# Otherwise look at the ratio of animals to calving pens:
	animals_per_pen <- NoAnimalsSickCalvingPen / NoCalvingPens
	
	# If there are at least 4 pens per 100 cows then get the best score:
	if(animals_per_pen <= 25){
		score <- wCalvingPen0
	}else{
		score <- wCalvingPen1
	}
	
	return(score)
}, CollidingWithEquipment = function(ObservedColliding){
	
	CheckCategories(ObservedColliding, c('0','1','2'))
	
	w0 <- NumberEqual(ObservedColliding, '0') * wObservedColliding0
	w1 <- NumberEqual(ObservedColliding, '1') * wObservedColliding1
	w2 <- NumberEqual(ObservedColliding, '2') * wObservedColliding2
	
	score <- (w0 + w1 + w2) / length(ObservedColliding)
	
	return(score)
}, OvergrownClaws = function(OvergrownClaws){
	
	CheckCategories(OvergrownClaws, c('0','1'))
	
	w0 <- NumberEqual(OvergrownClaws, '0') * wOvergrownClaws0
	w1 <- NumberEqual(OvergrownClaws, '1') * wOvergrownClaws1
	
	score <- (w0 + w1) / length(OvergrownClaws)
	
	return(score)
}, TotalFloorageSickCalving = function(AreaCalvingPens){
	
	CheckCategories(AreaCalvingPens, c('0','1'))
	CheckLength1(AreaCalvingPens)
	
	score <- ifelse(AreaCalvingPens==0, wAreaCalvingPens0, wAreaCalvingPens1)
	
	return(score)
}, CowBrush = function(CowBrush, NoResourceAnimal){
	
	CheckCategories(CowBrush, c('0','1'))
	CheckNumeric(NoResourceAnimal)
	
	scores <- ifelse(CowBrush == '0', wCowBrush0, wCowBrush1)
	
	return( WeightedAverage(scores, NoResourceAnimal) )
}, Stillborn = function(StillBirths){
	
	CheckPercent(StillBirths)
	CheckLength1(StillBirths)

	if(StillBirths <= 5){
		score <- wStillborn0
	}else if(StillBirths <= 10){
		score <- wStillborn1
	}else{
		score <- wStillborn2
	}
	
	return(score)
}, TimeNeededToLieDown = function(TimeNeededToLieDown){
	
	CheckCategories(TimeNeededToLieDown, c('0','1','2'))
	
	w0 <- NumberEqual(TimeNeededToLieDown, '0') * wTimeNeededToLieDown0
	w1 <- NumberEqual(TimeNeededToLieDown, '1') * wTimeNeededToLieDown1
	w2 <- NumberEqual(TimeNeededToLieDown, '2') * wTimeNeededToLieDown2
	
	score <- (w0 + w1 + w2) / length(TimeNeededToLieDown)
	
	return(score)	
}, CleanlinessUdder = function(CleanlinessUdder){
	
	CheckCategories(CleanlinessUdder, c('0','1'))
	
	w0 <- NumberEqual(CleanlinessUdder, '0') * wCleanlinessUdder0
	w1 <- NumberEqual(CleanlinessUdder, '1') * wCleanlinessUdder1
	
	score <- (w0 + w1) / length(CleanlinessUdder)
	
	return(score)
}, Cubicles = function(TotalCubicles, NoResourceAnimal){
	
	CheckNumeric(TotalCubicles)
	CheckNumeric(NoResourceAnimal)
	
	scores <- ifelse(TotalCubicles >= NoResourceAnimal, wTotalCubicles0, wTotalCubicles1)

	return( WeightedAverage(scores, NoResourceAnimal) )
}, FeedBunkSpace = function(FeedBunkSpace, NoResourceAnimal){
	
	CheckCategories(FeedBunkSpace, c('0','1'))
	CheckNumeric(NoResourceAnimal)
	
	# Loop over groups:
	ngroups <- length(NoResourceAnimal)
	scores <- numeric(ngroups)
	
	for(i in 1:ngroups){
		if(FeedBunkSpace[i] == '0'){
			scores[i] <- wFeedBunkSpace0
		}else if(FeedBunkSpace[i] == '1'){
			scores[i] <- wFeedBunkSpace1
		}else{
			stop("Unrecognised category")
		}
	}
	
	# Weight by NoResourceAnimal
	return( WeightedAverage(scores, NoResourceAnimal) )	
}, AvoidanceDistance = function(AvoidanceDistanceAtFeedingTable){
	
	CheckNumeric(AvoidanceDistanceAtFeedingTable)
	
	w0 <- NumberBetween(AvoidanceDistanceAtFeedingTable, -Inf, 0) * wAvoidanceDistanceAtFeedingTable0
	w1 <- NumberBetween(AvoidanceDistanceAtFeedingTable, 0, 50) * wAvoidanceDistanceAtFeedingTable1
	w2 <- NumberBetween(AvoidanceDistanceAtFeedingTable, 50, 100) * wAvoidanceDistanceAtFeedingTable2
	w3 <- NumberBetween(AvoidanceDistanceAtFeedingTable, 100, Inf) * wAvoidanceDistanceAtFeedingTable3
	
	score <- (w0 + w1 + w2 + w3) / length(AvoidanceDistanceAtFeedingTable)
	
	return(score)
}, GettingUpBehaviour = function(GettingUpBehaviour){
	
	CheckCategories(GettingUpBehaviour, c('0','1','2'))
	
	w0 <- NumberEqual(GettingUpBehaviour, '0') * wGettingUpBehaviour0
	w1 <- NumberEqual(GettingUpBehaviour, '1') * wGettingUpBehaviour1
	w2 <- NumberEqual(GettingUpBehaviour, '2') * wGettingUpBehaviour2
	
	score <- (w0 + w1 + w2) / length(GettingUpBehaviour)
	
	return(score)
}, AccessSickPen = function(NoSickPens, NoAnimalsSickCalvingPen){
	
	# Note: NoAnimalsSickCalvingPen should be the same as TotalAnimals (this is checked by the Validation score):
	# In future it may be better to have this information on the farm sheet with total animals

	CheckNumeric(NoAnimalsSickCalvingPen)
	CheckNumeric(NoSickPens)
	
	CheckLength1(NoAnimalsSickCalvingPen)
	CheckLength1(NoSickPens)
	
	# If there are no sick pens at all get worst score:
	if(NoSickPens == 0){
		return(wSickPen2)
	}
	
	# Otherwise look at the ratio of animals to sick pens:
	animals_per_pen <- NoAnimalsSickCalvingPen / NoSickPens
	
	# If there is at least 1 sick per 100 animals then get the best score:
	if(animals_per_pen <= 100){
		score <- wSickPen0
	}else{
		score <- wSickPen1
	}
	
	return(score)
}, Lameness = function(Lameness){
	
	CheckCategories(Lameness, c('0','1','2'))
	
	w0 <- NumberEqual(Lameness, '0') * wLameness0
	w1 <- NumberEqual(Lameness, '1') * wLameness1
	w2 <- NumberEqual(Lameness, '2') * wLameness2
	
	score <- (w0 + w1 + w2) / length(Lameness)
	
	return(score)
}, Tethering = function(Tethering, NoResourceAnimal){
	
	CheckCategories(Tethering, c('0','1'))
	CheckNumeric(NoResourceAnimal)
	
	# This is vectorised but only works when there are 2 scores:
	scores <- ifelse(Tethering=='0', wTethering0, wTethering1)
	
	score <- WeightedAverage(scores, NoResourceAnimal)
	
	return( score )	
}, IntegumentAlterations = function(IntegumentAlterations){
	
	CheckCategories(IntegumentAlterations, c('0','1','2'))
	
	w0 <- NumberEqual(IntegumentAlterations, '0') * wIntegumentAlterations0
	w1 <- NumberEqual(IntegumentAlterations, '1') * wIntegumentAlterations1
	w2 <- NumberEqual(IntegumentAlterations, '2') * wIntegumentAlterations2
	
	score <- (w0 + w1 + w2) / length(IntegumentAlterations)
	
	return(score)	
}, WaterSupply = function(WaterAnimals, TotalNoBowls, TotalTroughLength){
	
	CheckNumeric(WaterAnimals)
	CheckNumeric(TotalNoBowls)
	CheckNumeric(TotalTroughLength)
	
	# Loop through each observation separately:
	ngroups <- length(WaterAnimals)
	scores <- numeric(ngroups)
	
	for(i in 1:ngroups){
		if((WaterAnimals[i] - (TotalNoBowls[i]*10)) * 10 < TotalTroughLength[i]){
			scores[i] <- wWater0
		}else if((WaterAnimals[i] - (TotalNoBowls[i]*10)) * 10 < TotalTroughLength[i]){
			scores[i] <- wWater1
		}else{
			scores[i] <- wWater2
		}
	}
	
	return( WeightedAverage(scores, WaterAnimals) )	
}, TotalFloorage = function(TotalFloorage, NoResourceAnimal){
	
	CheckCategories(TotalFloorage, c('0','1'))
	CheckNumeric(NoResourceAnimal)
	
	# Loop over groups:
	ngroups <- length(NoResourceAnimal)
	scores <- numeric(ngroups)
	
	for(i in 1:ngroups){
		if(TotalFloorage[i] == '0'){
			scores[i] <- wTotalFloorage0
		}else if(TotalFloorage[i] == '1'){
			scores[i] <- wTotalFloorage1
		}else{
			stop("Unrecognised category")
		}
	}
	
	# Weight by NoResourceAnimal
	return( WeightedAverage(scores, NoResourceAnimal) )	
}, CleanlinessHindQuarters = function(CleanlinessHindQuarters){
	
	CheckCategories(CleanlinessHindQuarters, c('0','1'))
	
	w0 <- NumberEqual(CleanlinessHindQuarters, '0') * wCleanlinessHindQuarters0
	w1 <- NumberEqual(CleanlinessHindQuarters, '1') * wCleanlinessHindQuarters1
	
	score <- (w0 + w1) / length(CleanlinessHindQuarters)
	
	return(score)
}, LyingOutsideLyingArea = function(LyingOutsideTotal, LyingOutsideNumber, LyingGroupSize){
	
	CheckNumeric(LyingOutsideTotal)
	CheckNumeric(LyingOutsideNumber)
	CheckNumeric(LyingGroupSize)
	
	# If all LyingOutsideTotal are 0 then the score is missing:
	if(sum(LyingOutsideTotal)==0){
		return("Sum of LyingOutsideTotal is 0")
	} 
	
	# Loop over groups:
	ngroups <- length(LyingOutsideNumber)
	scores <- numeric(ngroups)
	
	for(i in 1:ngroups){
		
		# If LyingOutsideTotal[i] is 0 then the score is ignored for this group:
		if(LyingOutsideTotal[i] == 0){
			scores[i] <- NA
		}else{
				
			# Calculate the proportion lying outside for each group:
			proportion <- LyingOutsideNumber[i] / LyingOutsideTotal[i]
			
			# Assign score based on the proportion:
			if(proportion <= 0){
				scores[i] <- wLyingOutside0
			}else if(proportion <= 0.05){
				scores[i] <- wLyingOutside1
			}else if(proportion <= 0.1){
				scores[i] <- wLyingOutside2
			}else if(proportion <= 1){
				scores[i] <- wLyingOutside3
			}else{
				stop("Lying outside number is greater than total for one or more group")
			}
		}
	}
	
	# Weight by the LyingGroupSize (total animals in the group) for consistency with the way weighting is done between farms:
	return( WeightedAverage(scores, LyingGroupSize) )	
}, BodyConditionScore = function(BodyConditionScore){
	
	CheckCategories(BodyConditionScore, c('0','1','2'))
	
	w0 <- NumberEqual(BodyConditionScore, '0') * wBodyCond0
	w1 <- NumberEqual(BodyConditionScore, '1') * wBodyCond1
	w2 <- NumberEqual(BodyConditionScore, '2') * wBodyCond2
	
	score <- (w0 + w1 + w2) / length(BodyConditionScore)
	
	return(score)
}, BeddingMaterial = function(BeddingSystem, NoResourceAnimal){
	
	CheckCategories(BeddingSystem, c('0','1','2'))
	CheckNumeric(NoResourceAnimal)
	
	# Loop over groups:
	ngroups <- length(NoResourceAnimal)
	scores <- numeric(ngroups)
	
	for(i in 1:ngroups){
		if(BeddingSystem[i] == '0'){
			scores[i] <- wBeddingSystem0
		}else if(BeddingSystem[i] == '1'){
			scores[i] <- wBeddingSystem1
		}else if(BeddingSystem[i] == '2'){
			scores[i] <- wBeddingSystem2
		}else{
			stop("Unrecognised category")
		}
	}
	
	# Weight by NoResourceAnimal
	return( WeightedAverage(scores, NoResourceAnimal) )	
}, CleanWater = function(WaterAnimals, TotalWaterPoints, CleanWaterPoints){
	
	CheckNumeric(WaterAnimals)
	CheckNumeric(TotalWaterPoints)
	CheckNumeric(CleanWaterPoints)
	
	# Calculated as a simple proportion of clean water points:
	ratio <- CleanWaterPoints / TotalWaterPoints
	scores <- ratio * wCleanWaterPoints0 + (1-ratio) * wCleanWaterPoints1
	
	return( WeightedAverage( scores, WaterAnimals ) )	
}, MilkSomaticCellCount = function(MilkSomaticCellCount){
	
	CheckLength1(MilkSomaticCellCount)
	CheckPercent(MilkSomaticCellCount)
	
	# Convert to a ratio (is recorded as % in the data):
	ratio <- MilkSomaticCellCount / 100
	
	score <- (1-ratio) * wMilkSomaticCellCount0 + ratio * wMilkSomaticCellCount1
	
	return(score)
}, Mortality = function(Mortality){
	
	CheckPercent(Mortality)
	CheckLength1(Mortality)
	
	# Score is based on % mortality as follows:
	if(Mortality <= vMortThreshold0){
		score <- wMortality0
	}else if(Mortality <= vMortThreshold1){
		score <- wMortality1
	}else{
		score <- wMortality2
	}
	
	return(score)
})
