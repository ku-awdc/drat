read_data <- function(filename, output, key, excel_names, sep=',', dec='.', ...){
	
	stopifnot(length(filename)==1)
	iscsv <- grepl('.\\.csv$',filename)
	isxl <- grepl('.\\.xlsx$',filename)
	if(!iscsv && !isxl){
		cat('The filename provided was not recognised as a .csv or .xlsx file', endl, file=output, append=TRUE)
		allok <- FALSE
		stop('Data check aborted (file not recognised)', call.=FALSE)
		
	}
	
	if(excel_names){
		key$Sheet <- key$ExcelSheet
		key$Column <- key$ExcelColumn
	}else{
		key$Sheet <- key$DataRelation
		key$Column <- key$DataName
	}
	
	allsheets <- key$Sheet
	names(allsheets) <- key$DataRelation
  allsheets <- allsheets[allsheets!='__external__']
	sheets <- allsheets[!duplicated(allsheets)]
	data <- vector('list', length=length(sheets))
	names(data) <- names(sheets)
	lsheets <- tolower(sheets)
	
	allok <- TRUE
	
	basefile <- gsub('\\.csv$','',filename)
	if(!iscsv){
		if(!file.exists(filename)){
			cat('The file specified does not exist in the current working directory', endl, file=output, append=TRUE)
			allok <- FALSE
			stop('Data check aborted (file does not exist)', call.=FALSE)
		}
		allsheets <- excel_sheets(filename)
		sheetnames <- tolower(gsub(' ', '', allsheets, fixed=TRUE))
		if(any(table(sheetnames)>1)){
			cat(paste0('Duplicated sheet name (after removing capitals and spaces): ', paste(unique(sheetnames[table(sheetnames)>1]), collapse=', ')), endl, file=output, append=TRUE)
			allok <- FALSE
			stop('Data check aborted (duplicated sheet names)', call.=FALSE)
		}
		if(!all(lsheets %in% sheetnames)){
			missing <- sheets[! lsheets %in% sheetnames]
			cat(paste('Missing mandatory sheet(s) (as stipulated by the data key): ', paste(missing, collapse=', ')), endl, file=output, append=TRUE)
			allok <- FALSE
			stop('Data check aborted (missing sheet)', call.=FALSE)
		}
	}
	
	for(i in 1:length(data)){
		
		if(iscsv){
			nfn <- paste0(basefile, '_', sheets[i], '.csv')
			if(!file.exists(nfn)){
				cat(paste0('The required file "', nfn, '" does not exist in the current working directory'), endl, file=output, append=TRUE)
				allok <- FALSE
				next
			}
			td <- checkcsvread(nfn, sep=sep, dec=dec, ...)
		}else{
			snum <- which(sheetnames==lsheets[i])
			stopifnot(length(snum)==1)
			td <- as.data.frame(process_excel(filename, sheet=snum))
		}
		
		td <- sanitise(td, lowerise=TRUE)
		
		cn <- tolower(gsub(' ', '', names(td), fixed=TRUE))
		if(any(table(cn)>1)){
			cat(paste0('Duplicated column name (after removing capitals and spaces): ', paste(unique(names(td)[table(cn)>1]), collapse=', ')), endl, file=output, append=TRUE)
			allok <- FALSE
			next
		}
		
		reqdata <- c('CHR')
		lreqdata <- tolower(reqdata)
		
		if(!all(lreqdata %in% cn)){
			missing <- reqdata[! lreqdata %in% cn]
			cat(paste('Missing mandatory data column(s) in the ', sheets[i], ' sheet: ', paste(missing, collapse=', ')), endl, endl, file=output, append=TRUE)
			allok <- FALSE
			next
		}

		reqdata <- c('CHR', key$Column[key$Sheet==sheets[i] & !key$DataName %in% c('CHR')])
		lreqdata <- tolower(reqdata)
		
		if(!all(lreqdata %in% cn)){
			missing <- reqdata[! lreqdata %in% cn]
			cat(paste('Missing data column(s) in the ', sheets[i], ' sheet (as stipulated by the data key): ', paste(missing, collapse=', ')), endl, endl, file=output, append=TRUE)
			allok <- FALSE
			next
		}
		
		wm <- sapply(lreqdata, function(x) return(which(cn==x)))
		stopifnot(length(wm)==length(reqdata))
		td <- td[,wm]		
		names(td) <- c('CHR', key$DataName[key$Sheet==sheets[i] & !key$DataName %in% c('CHR')])
		data[[i]] <- td
	}
	
	if(!allok){
		stop('Critical errors discovered in the data', call.=FALSE)
	}
			
	return(data)
}

verify_data <- function(data, relation, farms, key, fail_all_missing=FALSE, fail_missing_chr=FALSE, show_warnings=TRUE, warn_missing=TRUE, output=""){
	
	cat('Checking DataRelation ', relation, ':', endl, sep='', file=output, append=TRUE)
	
	date_range_big <- c(as.Date('2000-01-01'), as.Date('2050-12-31'))
	date_range <- c(as.Date('2014-01-01'), as.Date(Sys.time()))
	
	failed <- FALSE
	warnings <- character(0)
	
	# This is a bit of a hack to get the CHR information first - rest of checks in Farm get done later
	if(relation=='Farm'){
		
		reqcols <- c('CHR')
		if(!all(reqcols %in% names(data))){
			missing <- reqcols[!reqcols %in% names(data)]
			cat('	Missing column: ', paste(missing, collapse=', '), ' (in DataRelation Farm)', endl, file=output, append=TRUE)
			failed <- TRUE
			stop('Data check aborted (missing CHR in DataRelation Farm)', call.=FALSE)
		}
		# Check dates:
		#s <- try(alldates <- makedates(data$VisitDate), silent=TRUE)
		#if(inherits(s, 'try-error')){
		#	cat('	', gsub('\n','',as.character(s),fixed=TRUE), ' for column VisitDate in DataRelation Farm', endl, file=output, append=TRUE)
		#	failed <- TRUE
		#	stop('Data check aborted (invalid VisitDate in DataRelation Farm)', call.=FALSE)
		#}

		#if(any(is.na(alldates) | alldates < date_range[1] | alldates > date_range[2])){
		#	os <- is.na(alldates) | alldates < date_range[1] | alldates > date_range[2]
		#	cat('	Observed dates on rows ', paste(paste(which(os), ': ', alldates[os], ' (original text: ', data$VisitDate[os], ')', sep=''), collapse=', '), ' are outside the permissible range of ', as.character(date_range[1]), ' to ', as.character(date_range[2]), ' (in DataRelation Farm)', endl, file=output, append=TRUE, sep='')
		#	failed <- TRUE
		#}
		#data$VisitDate <- alldates
		
		#chrs <- unlist(sapply(data$CHR, sepdash, oneok=TRUE))
		#if(any(as.integer(chrs)!=chrs)){
		#	cat('	One or more CHR provided was not correctly formatted - these should be given as numbers, with multiple CHR within the same farm separated by a dash (-)', endl, file=output, append=TRUE)
		#	failed <- TRUE
		#}
		
		if(failed){
			stop('Critical errors discovered in DataRelation Farm', call.=FALSE)
		}
		
		farms <- data
	}
	

	# Cut down the key to just what is needed:
	key <- key[key$DataRelation==relation & !key$DataName %in% c('CHR'),]
	
	
	# Check required data are available:
	reqcols <- c('CHR', key$DataName)
	if(!all(reqcols %in% names(data))){
		missing <- reqcols[!reqcols %in% names(data)]
		cat('	Missing column: ', paste(missing, collapse=', '), ' (in DataRelation ', relation, ')', endl, file=output, append=TRUE)
		failed <- TRUE
		stop('DataRelation check aborted (missing columns)', call.=FALSE)
	}

	# Then check CHR against valid entries:
	invalid <- ! data$CHR %in% farms$CHR
	if(any(invalid)){
		cat('	Observed CHR of', paste(data$CHR[invalid], collapse=', '), ' (on rows', paste(which(invalid), collapse=', '), ') are not a subset of the valid CHR obtained from the Farm sheet (', paste(unique(farms$CHR), collapse=', '), ') for DataRelation', relation, endl, file=output, append=TRUE)
		failed <- TRUE
	}
	
	# Then check all CHR observations are observed:
	ch_date_required <- farms$CHR
	ch_date_obs <- data$CHR
	if(!all(ch_date_required %in% ch_date_obs)){
		missing <- which(! ch_date_required %in% ch_date_obs )
		if(fail_missing_chr){
			cat('	Required CHR of', paste(ch_date_required[missing], collapse=', '), 'is not present for DataRelation', relation, endl, file=output, append=TRUE)
			failed <- TRUE
		}else{
			warnings <- c(paste('Required CHR of', paste(ch_date_required[missing], collapse=', '), 'is not present for DataRelation', relation), warnings)
			
			# Create a single fake line in this sheet for each missing CHR:
			fakeline <- data[1,,drop=FALSE]					
			fakeline[] <- NA
			fakeline <- do.call(rbind, replicate(length(missing), fakeline, simplify=FALSE))
			stopifnot(nrow(fakeline)==length(missing))
			stopifnot(all(is.na(fakeline)))

			fakeline$CHR <- farms$CHR[missing]
			
			data <- rbind(data, fakeline)
		}
	}
	
	temp <- data
	
	for(i in 1:ncol(data)){
		
		# No need to re-check CHR or data that we don't want to keep:
		if(names(data)[i] %in% c('CHR') || ! names(data)[i] %in% key$DataName){
			next
		}
		
		dataname <- names(data)[i]
		using <- temp[,i,drop=TRUE]
		keyslice <- key[key$DataName == dataname,,drop=FALSE]
		type <- keyslice$Type
		
		# Error/Warning if all missing:
		if(length(using)==0 || all(using %in% na_equiv | is.na(using))){
			if(fail_all_missing){
				cat('	Error:  All observations are missing for DataName', dataname, endl, file=output, append=TRUE)
				failed <- TRUE
			}else{
				# Boot to head of warnings list:
				warnings <- c(paste('All observations are missing for DataName', dataname, '.'), warnings)
				
			}
			next
		}
		
		
			
		if(type=='categorical'){
			
			errmsg <- checkcategories(observed= using, valid= keyslice$CategoriesValid)
			if(errmsg!=''){
				cat('	Categories of', errmsg, 'are not a subset of the valid categories (', paste(getcategories(keyslice$CategoriesValid)[[1]], collapse=' - '), ') for DataName ', keyslice$DataName, 'of DataRelation', keyslice$DataRelation, endl, file=output, append=TRUE)
				failed <- TRUE
				next
			}
			using <- as.character(multifactor(using, levels=sepdash(keyslice$CategoriesValid), simplify2factor=FALSE))
			
		}else if(type%in%c('integer','numeric')){
			
			s <- try(using <- makenumbers(using), silent=TRUE)
			if(inherits(s, 'try-error')){
				cat('	', gsub('\n','',as.character(s),fixed=TRUE), ' for DataName ', keyslice$DataName, 'of DataRelation', keyslice$DataRelation, endl, file=output, append=TRUE)
				failed <- TRUE
				next
			}
			
			# Allow lower and upper limits to come from another column within the same sheet:
			lower <- keyslice$NumMin
			if(any(lower %in% names(temp))){
				s <- try(lower <- makenumbers(temp[[lower]]), silent=TRUE)
				if(inherits(s, 'try-error')){
					# If converting a non-NA to NA:
					cat('	', gsub('\n','',as.character(s),fixed=TRUE), ' for lower limit specified by column ', keyslice$NumMin, ' for DataName ', keyslice$DataName, 'of DataRelation', keyslice$DataRelation, endl, file=output, append=TRUE)
					failed <- TRUE
					next					
				}
				na.allowed <- rep(FALSE, nrow(temp))
				na.allowed[is.na(using)] <- TRUE
				stopifnot(length(na.allowed)==length(using))

				if(any(is.na(lower) & !na.allowed)){
					# If there is a genuine missing just generate a warning:
					warnings <- c(warnings, paste('Missing values (rows ', paste(which(is.na(lower) & !na.allowed), collapse=', '), ') found in the', keyslice$NumMin, 'DataName which is being used as a lower bound for the (non-missing elements of) DataName', keyslice$DataName, 'of DataRelation', keyslice$DataRelation, '. The lower bound was therefore not checked for these rows of this column.'))
				}
			}else{
				s <- try(lower <- makenumbers(lower, giverows=FALSE), silent=TRUE)
				if(inherits(s, 'try-error')){
					cat('	', gsub('\n','',as.character(s),fixed=TRUE), ' - this text does not match any column name, and is given as lower limit of data ', keyslice$column, 'of sheet', keyslice$sheet, '(for DataName ', keyslice$dataname, ')', endl, file=output, append=TRUE)
				}
			}
			upper <- keyslice$NumMax
			if(any(upper %in% names(temp))){
				s <- try(upper <- makenumbers(temp[[upper]]), silent=TRUE)
				if(inherits(s, 'try-error')){
					cat('	', gsub('\n','',as.character(s),fixed=TRUE), ' for upper limit specified by column ', keyslice$NumMax, ' for DataName ', keyslice$DataName, 'of DataRelation', keyslice$DataRelation, endl, file=output, append=TRUE)
					failed <- TRUE
					next					
				}
				na.allowed <- rep(FALSE, nrow(temp))
				na.allowed[is.na(using)] <- TRUE
				stopifnot(length(na.allowed)==length(using))
				
				if(any(is.na(upper) & !na.allowed)){
					# If there is a genuine missing just generate a warning:
					warnings <- c(warnings, paste('Missing values (rows ', paste(which(is.na(upper) & !na.allowed), collapse=', '), ') found in the', keyslice$NumMax, 'column which is being used as a upper bound for the (non-missing elements of) DataName', keyslice$DataName, 'of DataRelation', keyslice$DataRelation, '. The upper bound was therefore not checked for these rows of this column.'))
				}
			}else{
				s <- try(upper <- makenumbers(upper, giverows=FALSE), silent=TRUE)
				if(inherits(s, 'try-error')){
					cat('	', gsub('\n','',as.character(s),fixed=TRUE), ' - this text does not match any column name, and is given as upper limit of data ', keyslice$column, 'of sheet', keyslice$sheet, '(for DataName ', keyslice$dataname, ')', endl, file=output, append=TRUE)
					failed <- TRUE
					next					
				}
			}

			if(any(using < lower | using > upper, na.rm=TRUE)){
				outside <- which(using < lower | using > upper)
				if(length(lower)>1 || length(upper)>1){
					for(o in 1:length(outside)){
						tl <- lower					
						if(length(lower)>1){
							tl <- tl[outside[o]]
						}
						tu <- upper
						if(length(upper)>1){
							tu <- tu[outside[o]]
						}
						cat('	Observation of', paste(using[outside[o]], collapse=', '), '(rows ', outside[o], ') is outside the permissable range (', tl, '-', tu, ') for DataName ', keyslice$DataName, 'of DataRelation', keyslice$DataRelation, endl, file=output, append=TRUE)
						failed <- TRUE
						next
					}
				}else{
					cat('	Observation of', paste(using[outside], collapse=', '), '(rows ', paste(outside, collapse=', '), ') is outside the permissable range (', paste(lower), '-', paste(upper), ') for DataName ', keyslice$DataName, 'of DataRelation', keyslice$DataRelation, endl, file=output, append=TRUE)
					failed <- TRUE
					next
				}
			}
			
			if(keyslice$Type=='integer'){
				notint <- abs(using-round(using)) > 10^-6 & gsub('[[:space:]]','',using)!='' & using!=Inf & using!=-Inf & !is.na(using)
				if(any(notint)){
					cat('	Observation of', paste(using[notint], ' (row ', which(notint), ')', sep='', collapse='; '), 'is not an integer for DataName ', keyslice$DataName, 'of DataRelation', keyslice$DataRelation, endl, file=output, append=TRUE)
					failed <- TRUE
					next
				}
			}
		}else if(keyslice$Type=='group'){
			
			# Nothing to check here?
			using[using==''] <- NA
			
		}else if(keyslice$Type=='date'){
			
			# Just check it can be parsed to a date between 2000 and 2050:
			lower <- date_range_big[1]
			upper <- date_range_big[2]
			
			s <- try(using <- makedates(using), silent=TRUE)
			if(inherits(s, 'try-error')){
				cat('	', gsub('\n','',as.character(s),fixed=TRUE), 'for DataName ', keyslice$DataName, 'of DataRelation', keyslice$DataRelation, endl, file=output, append=TRUE)
				failed <- TRUE
				next
			}else{
			
				if(any(using < lower | using > upper, na.rm=TRUE)){
					outside <- which(using < lower | using > upper)
					cat('	Observation of', paste(using[outside], collapse=', '), 'is outside the permissable range (', paste(lower), '-', paste(upper), ') for DataName ', keyslice$DataName, 'of DataRelation', keyslice$DataRelation, endl, file=output, append=TRUE)
					failed <- TRUE
					next
				}

			}
			
		}else if(keyslice$Type=='time'){
			
			s <- try(using <- maketimes(using), silent=TRUE)
			if(inherits(s, 'try-error')){
				cat('	', gsub('\n','',as.character(s),fixed=TRUE), 'for DataName ', keyslice$DataName, 'of DataRelation', keyslice$DataRelation, endl, file=output, append=TRUE)
				failed <- TRUE
				next
			}
			
		}else{
			stop('Unrecognised format')
			failed <- TRUE
			next
		}
		
		# Check that the data isn't all missing:
		if(all(is.na(using))){
			if(fail_all_missing){
				cat('	All observations of DataName', keyslice$DataName, 'of DataRelation', keyslice$DataRelation, 'are missing', endl, file=output, append=TRUE)
				failed <- TRUE
			}else{
				warnings <- c(paste('All observations of DataName', keyslice$DataName, 'of DataRelation', keyslice$DataRelation, 'are missing'), warnings)
			}
		}
		
		temp[,i] <- using
		
		if(any(is.na(using))){
			if(keyslice$MissingOK!='yes'){
				cat('	Missing observations (rows', paste(which(is.na(using)), collapse=', '), ') are not permitted for DataName ', keyslice$DataName, 'of DataRelation', keyslice$DataRelation, endl, file=output, append=TRUE)
				failed <- TRUE
				next
			}else{
				if(warn_missing) warnings <- c(warnings, paste('Missing observations (rows', paste(which(is.na(using)), collapse=', '), ') were found for DataName ', keyslice$DataName, 'of DataRelation', keyslice$DataRelation))
			}
		}
		
	}
	
	data <- temp
	
	warnout <- paste('	[Warning: ', warnings, ']')
	warnout <- warnout[!grepl('[Warning:   ]',warnout,fixed=TRUE)]
	if(show_warnings){
		if(length(warnout)>0){
			cat(paste(warnout, collapse=endl), endl, file=output, append=TRUE, sep='')
		}else if(!failed){
			cat('	No issues detected', endl, file=output, append=TRUE, sep='')
		}
	}else{
		if(length(warnout)>0){
			cat('	', length(warnout), ' warning', if(length(warnout)>1) 's', ' suppressed', endl, file=output, append=TRUE, sep='')
		}else if(!failed){
			cat('	No issues detected', endl, file=output, append=TRUE, sep='')
		}
	}
	
	if(output!="")
		cat(endl, file=output, append=TRUE, sep='')
	
	if(failed)
		stop('DataRelation check failed (errors detected)', call.=FALSE)
	
	return(data)
		
}

