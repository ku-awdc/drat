na_equiv <- c('ns','NS','Ns','na','NA','Na','n/s','N/S','n/a','N/A','')
date_equiv <- c('visit date', 'visitdate','visit_date','date')
endl <- '\r\n'
min_farms_index <- 20

checkcsvread <- function(filename, sep=',', dec='.', ...){
	
	# TODO: resolve recursive promise
	sep <- ','
	dec <- '.'
	
	rs <- try(df <- read.csv(file=filename, sep=sep, dec=dec, header=TRUE, stringsAsFactors=FALSE, ...))
	if(inherits(rs, 'try-error'))
		stop(paste('The following error was encountered while attempting to read the csv file: ', as.character(rs)))
	
	if(ncol(df)==1)
		stop('The CSV file was read in as a single column - there is probably a mismatch between the column separator specified and that used in the file (e.g. ; vs , which happens frequently when using Excel - it is strongly recommended to use OpenOffice instead)')
	
	if(any(grepl('^X\\.', names(df)))){
		whichblank <- which(grepl('^X\\.', names(df)))
		stop(paste0('Column number(s) ', paste(whichblank, collapse=', '), ' have a blank first row - all columns must have headers (this may have resulted from a failure to properly quote cells containing the separator character, which happens frequently when using Excel - it is strongly recommended to use OpenOffice instead)'))
	}
	
	return(df)
}


process_excel <- function(file, sheet){
	
	# First allow read_excel to try reading the data and guess types:
	suppressWarnings(suppressMessages(firstattempt <- read_excel(file, sheet)))

	if(FALSE){
	guessclass <- sapply(firstattempt, function(x){
		if(inherits(x,c('POSIXct','POSIXlt','POSIXt','Date'), which=FALSE)){
			return('date')
		}else if(is.character(x)){
			return('text')
		}else if(is.numeric(x)){
			# Change text to numeric as well:
			return('text')
		}else{
			return('text')
#				stop(paste('Unrecognised column type from read_excel: ',paste(class(x), collapse=', '), ' - please report this to Matt\n'))
		}
	})
	}
	
	# Then get read_excel to ignore column names (forces everything to character):
	suppressWarnings(suppressMessages(secondattempt <- read_excel(file, sheet, col_names=FALSE)))
	
	# Then over-write the numeric first attempts with character second attempts:
	for(i in which(sapply(firstattempt, is.numeric))){
		firstattempt[[i]] <- secondattempt[[i]][2:nrow(secondattempt)]
	}
	
	return(firstattempt)
	
}

getcategories <- function(obsvalid){
	obsvalid <- strsplit(obsvalid,'-')
	obsvalid <- obsvalid[obsvalid!='']
	return(lapply(obsvalid, tolower))
}
checkcategories <- function(observed, valid){
	stopifnot(length(valid)==1)
	obsvalid <- getcategories(valid)[[1]]
	obsmade <- getcategories(observed)
	
	if(length(obsmade)==0){
		return('')
	}else{
		return(do.call(paste, c(lapply(1:length(obsmade), function(i){
			if(any(!obsmade[[i]] %in% obsvalid)){
				return(paste(paste(obsmade[[i]][!obsmade[[i]]%in%obsvalid], collapse=', '), ' (row ', i+1, '); ', sep=''))
			}else{
				return('')
			}
		}), list(sep='', collapse=''))))
	}
}

sanitise <- function(df, lowerise=TRUE){
	
	stopifnot(inherits(df,'data.frame'))
	
	# First remove NA column entries:
	df <- df[,!is.na(names(df)),drop=FALSE]
	
	# First remove rows and columns of all NA (but only when missing a column heading):
	df <- df[,apply(df,2,function(x) return(!all(is.na(x)))) | gsub('[[:space:]]','',names(df))!='', drop=FALSE]
	df <- df[apply(df,1,function(x) return(!all(is.na(x)))), , drop=FALSE]
	
	if(nrow(df) > 0){
		for(i in 1:ncol(df)){
			if(!inherits(df[[i]], c('POSIXt','Date'))){
				# Now remove spaces:
				df[,i] <- gsub('[[:space:]]','',df[,i])
				if(lowerise){
					# Make everything lowercase:
					df[,i] <- tolower(as.character(df[,i]))
				}
				# Now replace NA equivalents with NA:
				df[df[,i] %in% na_equiv, i] <- NA
			}
		}
	}
	
	# Now sanitise headers:
	if(lowerise){
		newnames <- gsub(' ','',tolower(names(df)))
	}else{
		newnames <- gsub(' ','',names(df))
	}
	if(any(table(newnames)>1)){
		stop(paste('Non-unique column names (after removing spaces and capitals): ', paste(table(newnames)[table(newnames)>1], collapse=', '), sep=''), call.=FALSE)
	}
	# Look for equivalent visit date headers:
	if(sum(newnames %in% date_equiv) > 1){
		stop(paste('Multiple equivalent visit date columns (', paste(newnames[newnames %in% date_equiv], collapse=', '), ') are not allowed', sep=''), call.=FALSE)		}
	newnames[newnames %in% date_equiv] <- ifelse(lowerise, 'visitdate', 'VisitDate')
	
	names(df) <- newnames
	
	return(df)
}

makenumbers <- function(x, giverows=TRUE){
	
	orig <- x
	# commas to decimals:
	x <- gsub(',','.',x,fixed=TRUE)
	# make numeric:
	suppressWarnings(x <- as.numeric(x))
	# any more na?
	newna <- is.na(x) & !is.na(orig)
	
	if(any(newna)){
		stop(paste('Missing value(s) created by converting to numeric', if(giverows) paste(' in row(s) ', paste(which(newna), collapse=', '), sep=''), ': ', paste(orig[newna], collapse=', '), sep=''), call.=FALSE)
	}
	
	return(x)
}

makedates <- function(using, ...){
	
	if(inherits(using,'Date') || any(grepl('POSIX',class(using))))
		return(as.Date(using))
	
	date_s <- try({
	
	orig <- using
	alreadyna <- using=='' | is.na(using)
	
	suppressWarnings(numdates <- !is.na(as.numeric(using)))
	# chardates <- grepl('-',using,fixed=TRUE)) | grepl('/',using,fixed=TRUE)
	
	newdates <- rep(as.Date('2010-01-01'), length(using))
	newdates[] <- NA
	if(any(numdates)){
		suppressWarnings(newdates[numdates] <- as.Date(as.numeric(using[numdates]), origin='1899/12/30'))
	}
	if(any(!numdates) && !all(is.na(orig[!numdates]))){
		suppressWarnings(newdates[!numdates] <- as.Date(using[!numdates], ...))
	}
	
	using <- newdates
	
#	if(any(grepl('-',using,fixed=TRUE)) || any(grepl('/',using,fixed=TRUE))){		
#		suppressWarnings(using <- as.Date(using))
#	}else{
#		suppressWarnings(using <- as.Date(as.numeric(using), origin='1899/12/30'))
#	}
	
	}, silent=TRUE)
	
	if(inherits(date_s, 'try-error')){
		if(grepl('character string is not in a standard unambiguous format', as.character(date_s))){
			stop(paste('One or more of the dates provided in character/string format (', paste(unique(na.omit(orig[!numdates])), collapse=', '), ') are not in the standard ISO format of YYYY-MM-DD.  Either provide the dates as a character/string in a standard format, or use a date format for these cells in Excel.', sep=''), call.=FALSE)
		}

		stop(paste('An unanticipated error occured while processing dates: ', gsub('\n','',as.character(date_s),fixed=TRUE), '(see also notes on dates in instructions.txt file)'), call.=FALSE)
	}
	
	newna <- is.na(using) & !alreadyna
	if(any(newna)){
		stop(paste('Observation of', paste(unique(orig[newna]), collapse=', '), 'is not parsable as a valid date (see notes on dates in instructions.txt file)'), call.=FALSE)
	}

	return(using)
}

maketimes <- function(using, ...){
	
	if(inherits(using,'POSIXt'))
		return(using)
	
	time_s <- try({
		
		alreadyna <- using=='' | is.na(using)
		newtimes <- rep(as.POSIXct('1899-12-30 00:01'), length(using))
		newtimes[] <- NA
		
		numtimes <- suppressWarnings(!is.na(as.numeric(using)))
		if(any(numtimes)){
			newtimes[numtimes] <- as.POSIXct('1899-12-30 00:00') + as.numeric(using[numtimes])*60*60*24
		}
		
		chartimes <- grepl(':',using,fixed=TRUE)
		if(any(chartimes)){
			temp <- as.POSIXct(paste('1899-12-30',using[chartimes]))
			temp[strftime(temp, '%H:%M')=='00:00'] <- NA
			newtimes[chartimes] <- temp
		}
		
		newtimes[alreadyna] <- NA
		if(any(strftime(newtimes, '%H:%M')=='00:00', na.rm=TRUE))
			stop('Parsed one or more times as exactly 00:00 which is probably an error')
		
	})
	
	if(inherits(time_s,'try-error') | all(is.na(newtimes)))
		stop(paste0('One or more of the times provided in character/string format (', paste(using, collapse=', '), ') could not be parsed as a time - make sure they are formatted as e.g. 09:00'))
	
	return(newtimes)
}


checktype <- function(type){
	
	posstypes <- c('Cows', 'Calves', 'SowsAndGilts', 'FarrowingSows', 'Piglets', 'Weaners', 'Custom')
	choice <- pmatch(tolower(type), tolower(posstypes))
	if(is.na(choice))
		stop(paste0('The specified type "', type, '" was not recognised, use one of the following:  ', paste(posstypes, collapse=', ')), call.=FALSE)
	
	type <- posstypes[choice]	
	return(type)
}


checkvariables <- function(variables){
	
	stopifnot(is.data.frame(variables))
	stopifnot(all(c('Variable','Value')%in%names(variables)))
	
	if(nrow(variables)==0){
		return(list())
	}
	
	if(!is.character(variables$Variable) || any(is.na(variables$Variable)) || any(variables$Variable=="") || any(table(variables$Variable)!=1)){
		stop('The Variable column in the weights supplied must be a set of unique characters')
	}
	
	notallowed <- c('+','-','*','/','&','|','%','#','$','@','^',':',';','<','>','"',"'",'!','?',' ')
	present <- vapply(notallowed, function(x) return(grepl(x, variables$Variable, fixed=TRUE)), FUN.VALUE=logical(length(variables$Variable)))
	rows <- which(apply(present,1,any))
	if(length(rows)>0){
		stop(paste('Illegal characters found in Weight Variable(s): ', paste(variables$Variable[rows], collapse=', '), ' - you cannot use any of the following characters:  ', paste(notallowed, collapse=', '), ' (or spaces, including at the end of the text)'), call.=FALSE)
	}
	
	if(!is.numeric(variables$Value) || any(is.na(variables$Value)) || any(variables$Value==Inf) || any(variables$Value < 0)){
		stop('The Value column in the weights supplied must be a set of positive (non-missing) numbers')
	}
	
	localenv <- as.environment(list())
	temp <- lapply(1:nrow(variables), function(i) assign(variables$Variable[i], variables$Value[i], envir=localenv))
	
	return(as.list(localenv))
	
}

checkmeasures <- function(measures){
	if(!inherits(measures, 'data.frame')){
		stop('A data frame must be provided')
	}
	measures <- as.data.frame(measures)
	if(!all(c('Measure','Criteria') %in% names(measures))){
		stop('A data frame including the elements Measure & Criteria must be provided')
	}
	
	if(!'Min' %in% names(measures)){
		measures$Min <- 0
	}
	if(!'Max' %in% names(measures)){
		measures$Max <- 100
	}
	
	measures <- measures[,c('Measure','Criteria','Min','Max')]
	if(any(is.na(measures))){
		stop('Missing values were detected in the measures specified')
	}
	
	if(!any(measures$Measure == 'ValidationCheck')){
		measures <- rbind(measures, data.frame(Measure='ValidationCheck', Criteria='ValidationCheck', Min=1, Max=Inf, stringsAsFactors=FALSE))
	}
	measures$Criteria[measures$Measure=='ValidationCheck'] <- 'ValidationCheck'
	
	notallowed <- c('+','-','*','/','&','|','%','#','$','@','^',':',';','<','>','"',"'",'!','?',' ')

	if(!is.character(measures$Measure) || any(is.na(measures$Measure)) || any(measures$Measure=="")){
		stop('The Measure element must be a character (blank/missing entries are not allowed)')
	}
	measures$Measure <- gsub(' *$', '', measures$Measure)
	present <- vapply(notallowed, function(x) return(grepl(x, measures$Measure, fixed=TRUE)), FUN.VALUE=logical(length(measures$Measure)))
	rows <- which(apply(present,1,any))
	if(length(rows)>0){
		stop(paste('Illegal characters found in Measure(s): ', paste(measures$Measure[rows], collapse=', '), ' - you cannot use any of the following characters:  ', paste(notallowed, collapse=', '), ' (or spaces, including at the end of the text)'), call.=FALSE)
	}
	
	if(!is.character(measures$Criteria) || any(is.na(measures$Criteria)) || any(measures$Criteria=="")){
		stop('The Criteria element must be a character (blank/missing entries are not allowed)')
	}
	measures$Criteria <- gsub(' *$', '', measures$Criteria)
	present <- vapply(notallowed, function(x) return(grepl(x, measures$Criteria, fixed=TRUE)), FUN.VALUE=logical(length(measures$Criteria)))
	rows <- which(apply(present,1,any))
	if(length(rows)>0){
		stop(paste('Illegal characters found in Criteria(s): ', paste(measures$Criteria[rows], collapse=', '), ' - you cannot use any of the following characters:  ', paste(notallowed, collapse=', '), ' (or spaces, including at the end of the text)'), call.=FALSE)
	}
	
	if(!is.numeric(measures$Min) || !is.numeric(measures$Max) || any(measures$Min < 0)){
		stop('The Min and Max elements must be non-negative numeric variables')
	}
	if(any(measures$Min >= measures$Max)){
		stop('One or more of the specified Min is greater than the corresponding Max')
	}
	#if(any(measures$Min == 0)){
		#cat('NOTE: Using Min values of exactly 0 is not recommended as it can mask coding mistakes in functions',endl)
	#}
	
	# Sort alphabeticaly with ValidationCheck first:
	measures <- measures[order(measures$Measure!='ValidationCheck', measures$Criteria, measures$Measure),]
	
	return(measures)
}

getdatanames <- function(i, funs, retdf=FALSE, persistent=FALSE, retrel=FALSE){
	
	allvars <- character(0)
	alldfnames <- character(0)
	
	x <- funs[[i]]
	
	# Permitted classes are '(', 'name', 'call':
	if(!all(vapply(formals(x), class, character(1)) %in% c('(', 'name', 'call'))){
		stop(paste0('One or more arguments for the ', names(funs)[i], ' function are invalid: consult the help file for details of what is possible'))
	}
	if(!all(vapply(formals(x), function(y) return(as.character(y)[1]), character(1)) %in% c('(', '', 'data.frame'))){
		stop(paste0('One or more arguments for the ', names(funs)[i], ' function are invalid: consult the help file for details of what is permitted'))
	}
	
	hasdf <- FALSE
	hasbasic <- FALSE
	hascomplex <- FALSE
	
	stopifnot(! (retdf && persistent))

	relationals <- vector('list', length=0)
	nonrels <- character(0)
	
	for(a in 1:length(formals(x))){

		if(class(formals(x)[[a]])=='(' && as.character(formals(x)[[a]])[1]=='('){
			
			# If persistent then return the name of the variable that will be visible in the function:
			if(persistent){
				allvars <- c(allvars, names(formals(x))[a])
				vars <- names(formals(x))[a]
			}else{
			
				arg2 <- as.character(formals(x)[[a]])[2]
				if(grepl('||',arg2,fixed=TRUE))
					stop(paste0('There was an error processing argument ', a, ' for the ', names(funs)[i], ' function: you cannot use || in the argument - use | instead'))
				if(grepl('&&',arg2,fixed=TRUE))
					stop(paste0('There was an error processing argument ', a, ' for the ', names(funs)[i], ' function: you cannot use && in the argument - use & instead'))

				vars <- gsub('|',' ',gsub('&',' ',gsub('(',' ',gsub(')',' ',arg2,fixed=TRUE),fixed=TRUE),fixed=TRUE),fixed=TRUE)
			
				if(grepl('[[:space:]]', gsub(' ','',vars))){
					stop(paste0('There was an error processing argument ', a, ' for the ', names(funs)[i], ' function: illegal characters detected'))
				}
			
				vars <- strsplit(vars,' ')[[1]]
				allvars <- c(allvars, vars[(!vars%in%c('','<','>','<=','>=')) & is.na(suppressWarnings(as.numeric(vars)))])
			}
			
			nonrels <- c(nonrels, vars[(!vars%in%c('','<','>','<=','>=')) & is.na(suppressWarnings(as.numeric(vars)))])
			
			hascomplex <- TRUE
			
		}else if(class(formals(x)[[a]])=='name' && as.character(formals(x)[[a]])[1]==''){
			
			allvars <- c(allvars, names(formals(x))[a])
			
			nonrels <- c(nonrels, names(formals(x))[a])
			
			hasbasic <- TRUE

		}else if(class(formals(x)[[a]])=='call' && as.character(formals(x)[[a]])[1]=='data.frame'){
			
			vars <- as.character(formals(x)[[a]])[-1]
			alldfnames <- c(alldfnames, names(formals(x))[a])
			allvars <- c(allvars, vars)
			
			relationals <- c(relationals, list(vars))
			
			hasdf <- TRUE
			
		}else{
			stop(paste0('There was an error processing argument ', a, ' for the ', names(funs)[i], ' function'))
		}
	}
	
	if(hasdf && (hasbasic || hascomplex))
		stop(paste0('It is not possible to mix data.frame arguments with other types of argument: use data.frame() for all arguments of the ', names(funs)[i], ' function'))
		
	if(!hasdf)
		relationals <- list(nonrels)
	
	if(retrel){
		return(relationals)
	}else if(retdf){
		return(list(allvars=allvars, alldfvars=alldfnames))
	}else{
		return(allvars)
	}
}

getdataexpressions <- function(i, funs){
	
	x <- funs[[i]]
	
	# Permitted classes are '(', 'name', 'call':
	if(!all(vapply(formals(x), class, character(1)) %in% c('(', 'name', 'call'))){
		stop(paste0('One or more arguments for the ', names(funs)[i], ' function are invalid: consult the help file for details of what is possible'))
	}
	if(!all(vapply(formals(x), function(y) return(as.character(y)[1]), character(1)) %in% c('(', '', 'data.frame'))){
		stop(paste0('One or more arguments for the ', names(funs)[i], ' function are invalid: consult the help file for details of what is permitted'))
	}
	
	allexpr <- character(length(formals(x)))
	for(a in 1:length(formals(x))){
		
		if(class(formals(x)[[a]])=='(' && as.character(formals(x)[[a]])[1]=='('){
			
			allexpr[a] <- (as.character(formals(x)[[a]])[2])
			
		}else if(class(formals(x)[[a]])=='name' && as.character(formals(x)[[a]])[1]==''){
			
			allexpr[a] <- (names(formals(x))[a])

		}else if(class(formals(x)[[a]])=='call' && as.character(formals(x)[[a]])[1]=='data.frame'){
			
			vars <- (as.character(formals(x)[[a]])[-1])
			allexpr[a] <- paste('data.frame(', paste0(vars, ' = ', vars, collapse=', '), ')', sep='')
			
		}else{
			stop(paste0('There was an error processing argument ', a, ' for the ', names(funs)[i], ' function'))
		}
	}

	return(allexpr)
}
