/*
	Copyright (C) 2013 Matthew Denwood <matthewdenwood@mac.com>
	
	This header is based on the pareto distribution in JAGS version 3.3,
	and specifies the Lomax distribution
	
    This file is part of runjags

    runjags is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    runjags is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with runjags  If not, see <http://www.gnu.org/licenses/>.
	
 */

#ifndef DLOMAX_H_
#define DLOMAX_H_

#include <distribution/RScalarDist.h>
namespace jags {
namespace JAGSmodule {

/**
 * <pre>
 * x ~ dlomax(alpha, sigma);
 * f(x|alpha,sigma) = alpha/sigma * (1 + x/sigma)^-(alpha + 1); x >= 0
	= alpha*sigma^alpha / (x + sigma)^(alpha+1)
 * </pre>
 * @short Lomax distribution
 */

class DLomax : public RScalarDist {
 public:
  DLomax();

  double d(double x, PDFType type,
	   std::vector<double const *> const &parameters, bool give_log) const;
  double p(double q, std::vector<double const *> const &parameters, bool lower,
	   bool give_log) const;
  double q(double p, std::vector<double const *> const &parameters, bool lower,
	   bool log_p) const;
  double r(std::vector<double const *> const &parameters, RNG *rng) const;

  bool checkParameterValue(std::vector<double const *> const &parameters) const;
};

}  // namespace JAGSmodule
}  // namespace jags

#endif /* DLOMAX_H_ */
