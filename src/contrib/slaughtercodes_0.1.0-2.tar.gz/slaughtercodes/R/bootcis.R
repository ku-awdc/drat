simulate.re <- function(model, n, new.levels){
  
  nsims <- n
  allres <- names(ranef(model))
  
  if(identical(tolower(new.levels), 'all'))
    new.levels <- allres  
  else if(identical(tolower(new.levels), 'none'))
    new.levels <- character(0)
  
  thedata <- model.frame(model)  
  if(length(new.levels)>0) for(i in 1:length(new.levels)){
    if(!new.levels[i] %in% names(thedata))
      stop(paste('Unrecognised factor: ', new.levels[i]))
  }
  
  # If we don't want any new levels just use simulate:
  if(length(new.levels)==0)
    return(simulate(model, nsims, re.form=NULL))
  # If we want all new levels just use simulate:
  if(all(allres %in% new.levels))
    return(simulate(model, nsims, re.form=NA))
  # But simulate doesn't work for intermediate (ie. use some but not all REs) - predict does though
  
  N <- length(resid(model))
  
  # Use predict to take care of fixed effects:
  newprobs <- matrix(predict(model, re.form=~0), nrow=N, ncol=nsims)
  
  for(i in 1:length(allres)){
    if(class(thedata[[allres[i]]]) != 'factor')
      stop('All random effects must be factors')
  }  

  # Create new levels:
  
#  browser()
  
  fails <- 0
  repeat{
    for(i in 1:length(allres)){
      if(ncol(ranef(model)[[allres[i]]])!=1)
        stop('Random slope models not supported')
      
      if(allres[i] %in% new.levels){
        sd <- as.data.frame(VarCorr(model))$sdcor[i]
        nlevs <- nrow(ranef(model)[[allres[i]]])
        newres <- matrix(rnorm(nlevs*nsims,0,sd), nrow=nlevs, ncol=nsims)
        indices <- as.numeric(thedata[[allres[i]]])
        newprobs <- newprobs + newres[indices,]
      }else{
        estimates <- unlist(ranef(model)[[allres[i]]])[as.numeric(thedata[[allres[i]]])]
        newprobs <- newprobs + estimates
      }  	
    }
    
    response <- as.character(formula(model))[2]
    Total <- apply(thedata[[response]],1,sum)
  
    probs <- inv.logit(newprobs)
    if(! any(is.na(probs))) 
      break
    
    fails <- fails+1
    if(fails > 10)
      stop('Repeated failures in simulate.re')
  }
  
  Positives <- rbinom(N*nsims, Total, probs)
  dim(Positives) <- dim(newprobs)
  Negatives <- Total-Positives
  
  ret <- lapply(1:nsims, function(x){
    return(cbind(Positives[,x], Negatives[,x]))
  })
  names(ret) <- paste('simulation',1:nsims,sep='.')
  return(ret)
  
}

cif <- function(i, call, env, simdata, f){
#	require('lme4')
	env$data$thesimdata <- simdata[[i]]
	rv <- try(f(eval(call, envir=env, enclos=parent.frame())), silent=TRUE)
	return(rv)
}

bootci <- function(model, nsim, f, mc.cores=min(n, detectCores()), new.levels='all', callobjects=list()){
	t <- Sys.time()
	
	env <- new.env()
	assign('data', model.frame(model), envir=env)
	
	if(length(callobjects)>0){
		for(i in 1:length(callobjects)){
			assign(names(callobjects)[i], callobjects[[i]], envir=env)
		}
	}
	
	call <- update(model, formula='thesimdata ~ .', data=data, evaluate=FALSE)

	cis <- replicate(nsim, f(model))
	if(is.null(dim(cis))) dim(cis) <- c(1, nsim)
	cis[] <- NA
	
	nfails <- 0
	startat <- 1
	done <- 0	
	repeat{
		# lme4::simulate seems to be broken ... so use my own function:
		simdata <- simulate.re(model, (nsim-done), new.levels=new.levels)
	
#		suppressWarnings(newboots <- mclapply(1:(nsim-done), cif, mc.cores=mc.cores, mc.preschedule=TRUE, call=call, env=env, simdata=simdata, f=f))
		(newboots <- mclapply(1:(nsim-done), cif, mc.cores=mc.cores, mc.preschedule=TRUE, call=call, env=env, simdata=simdata, f=f))
		newboots <- newboots[sapply(newboots,function(x) return(ifelse(class(x)=='try-error',FALSE,TRUE)))]
		if(length(newboots)==0){
			nfails <- nfails+1
			if(nfails>=3){
				cat('All bootstraps failed 3 times - returning all missing values/n')
				cis[] <- NA
				break
			}			
			cat('All bootstraps failed ... trying again\n')
			next
		}
		done <- (startat-1)+length(newboots)
		cis[,startat:done] <- simplify2array(newboots)
		startat <- done+1
		if(done==nsim) break
	}

	return(t(cis))
	
}

inv.logit <- plogis
logit <- qlogis

