#' @title Fine control of analysis of FVST slaughter codes
#' @name FVSTmodel
#' @aliases FVSTmodel, readFVSTdata, aggregateFVSTdata, FVSTsummary

#' @description
#' Underlying functions to read, aggregate, model and summarise a slaughter code (or combination of slaugher codes) from a single dataset

#' @return
#' readFVSTdata returns a (large) dataframe of individual observations, aggregateFVSTdata returns a smaller dataframe with observations grouped at the specified levels, FVSTmodel returns the model of best fit, and FVSTsummary returns summary statistics obtained from this model (plus bootstrapped confidence intervals if confint=TRUE)

#' @seealso
#' \code{\link{FVSTanalysis}}

#' @examples
#' data('exampleFVST_1')
#' write.csv(exampleFVST_1, file='testdata.csv')
#' alldata <- readFVSTdata('code2', 'testdata.csv', abattoircolumn='abattoir', farmcolumn='farm', datecolumn='date', typecolumn='type')
#' aggregateddata <- aggregateFVSTdata(alldata, 'sow')
#' model <- FVSTmodel(aggregateddata, mc.cores=2)
#' FVSTsummary(model$fit, confint=TRUE)
#' FVSTsummary(model$fit, confint=FALSE)

#' @param code the code (or a character vector of codes) matching columns to be extracted
#' @param filename the name of the csv file holding the data
#' @param abattoircolumn the column of the data indicating the abattoir
#' @param farmcolumn the column of the data indicating the farm
#' @param datecolumn the column of the data indicating the slaughter date
#' @param birthdatecolumn the column of the data indicating the birth date (optional if type is available)
#' @param dateformat the format of the dates in the data - or NA if these are in a standard ISO format
#' @param agecutoff the age in days at which to delineate young vs older animals
#' @param typecolumn the column of the data indicating the animal type (optional if birth date is available)
#' @param dataframe the data as returned by readFSVTdata
#' @param type the animal type to extract
#' @param aggregate the aggregation variables to use
#' @param date.range an optional range of dates to subset the data on
#' @param warn.missing should a note be printed to screen if data are removed for some reason?
#' @param data the data as returned by aggregateFVSTdata
#' @param n the number of initial model runs for model comparison
#' @param mc.cores the number of parallel cores to use
#' @param max the maximum number of model runs for model comparison
#' @param confidence the confidence level for model comparison
#' @param seed an optional RNG state for data simulation
#' @param callobjects a list of objects required to be available for the lme4 function call
#' @param new.levels the new levels to be generated in the simulated data (as opposed to using random effect level coefficients from the real model)
#' @param control a list of arguments to control the lme4 fit
#' @param model a list including the selected model as returned by FVSTmodel
#' @param confint should bootstrapped confidence intervals be produced?
#' @param simulations the number of simulations for bootstrapped confidence intervals

#' @rdname FVSTmodel
#' @export
readFVSTdata <- function(code, filename, abattoircolumn='SLAGTERICHR', farmcolumn='FID', datecolumn='slg_date', dateformat=NA, birthdatecolumn='birth', agecutoff=365*1.5, typecolumn='type'){
	
  farm <- farmcolumn
  abattoir <- abattoircolumn
  date <- datecolumn
  date.format <- dateformat
  birth.date <- birthdatecolumn
  age.cutoff <- agecutoff
  animal.type <- typecolumn
  
  cat('Reading file "', filename, '"...\n', sep='')
  
  # First check the required columns:
  dcheck <- read.csv(filename, nrow=10)
	cols <- dimnames(dcheck)[[2]]
	
	if(!all(c(code) %in% cols)){
	    
		sqlarg <- paste("select ", abattoircolumn, ", ", datecolumn," from thefile", sep="")
		thefile <- file(filename)
	    thedata <- sqldf(sqlarg, stringsAsFactors=FALSE, file.format=list(header=TRUE, colClasses='character', eol='\n'))
	    close(thefile)
		
		if(identical(dateformat, NA)){ 
			slaughter.date <- as.Date(gsub('["\']','',thedata[,date]))  
			if(all(is.na(slaughter.date)))
				stop('All slaughter dates failed coercion - try specifying a dateformat argument')
		}else{
			slaughter.date <- as.Date(gsub('["\']','',thedata[,date]), format=date.format)  
			if(all(is.na(slaughter.date)))
				stop('Incorrect dateformat supplied - all slaughter dates failed coercion')
		}
		if(any(is.na(slaughter.date)))
			cat('NOTE:  ', sum(is.na(slaughter.date)), ' records with missing slaughter dates\n', sep='')
		thedata[,date] <- slaughter.date
		
		abattoir <- sort(unique(thedata[,abattoircolumn]))
		abattoir <- abattoir[!is.na(abattoir) & abattoir!="" & abattoir!=0]
		slprivate$abattoirnames <- abattoir
		slprivate$daterange <- range(thedata[,date], na.rm=TRUE)
		
		stop('One or more of the specified code columns was not found in the data')
	}

	if(!all(c(abattoircolumn, farmcolumn, datecolumn) %in% cols))
		stop('One or more of the specified abattoircolumn, farmcolumn, or datecolumn was not found in the data')
	
	if(! birth.date %in% cols)
		birth.date <- NA
	if(! animal.type %in% cols)
		animal.type <- NA
	if(identical(birth.date, NA) && identical(animal.type, NA))
		stop('Both birth.date and animal.type columns are missing')
	
	if(!identical(animal.type, NA) && !identical(birth.date, NA)){
		cat('NOTE:  A birth.date column was found but ignored - the animal.type column was used instead\n', sep='')
		birth.date <- NA
	}
	
    sqlarg <- paste("select ", farm, ", ", abattoir, ", ", date, ", ", if(!identical(birth.date, NA)) birth.date, if(!identical(birth.date, NA)) ", ", if(!identical(animal.type, NA)) animal.type, if(!identical(animal.type, NA)) ", ", paste(code, collapse=", "), " from thefile", sep="")
  
  thefile <- file(filename)
  thedata <- sqldf(sqlarg, stringsAsFactors=FALSE, file.format=list(header=TRUE, colClasses='character', eol='\n'))
  close(thefile)
  
  # This leaves the file open:
  #read.csv.sql(filename, sql=sqlarg, header=TRUE, colClasses='character', eol="\n")
  
  # If this fails, read just abattoir first to get uniques, then loop through each abattoir - and filter dates then summarise before sticking them all together (just 8 rbinds)
  
  cat('Processing data...\n')
  
	if(identical(dateformat, NA)){ 
		slaughter.date <- as.Date(gsub('["\']','',thedata[,date]))  
		if(all(is.na(slaughter.date)))
			stop('All slaughter dates failed coercion - try specifying a dateformat argument')
	}else{
		slaughter.date <- as.Date(gsub('["\']','',thedata[,date]), format=date.format)  
		if(all(is.na(slaughter.date)))
			stop('Incorrect dateformat supplied - all slaughter dates failed coercion')
	}
	if(any(is.na(slaughter.date)))
		cat('NOTE:  ', sum(is.na(slaughter.date)), ' records with missing slaughter dates\n', sep='')
	thedata[,date] <- slaughter.date
  
	# If we only have birth dates then convert birth dates to animal types:
	if(!identical(birth.date, NA)){
		if(identical(dateformat, NA)){ 
			age.days <- as.Date(gsub('["\']','',thedata[,birth.date]))  
			if(all(is.na(age.days)))
				stop('All birth dates failed coercion - try specifying a dateformat argument')
		}else{
			age.days <- as.Date(gsub('["\']','',thedata[,birth.date]), format=date.format)  
			if(all(is.na(age.days)))
				stop('Incorrect dateformat supplied - all birth dates failed coercion')
		}
		if(any(is.na(age.days)))
			cat('NOTE:  ', sum(is.na(age.days)), ' records with missing birth dates\n', sep='')
		age.days <- as.numeric(difftime(slaughter.date, age.days, units='days'))
		if(any(age.days < 0, na.rm=TRUE))
		cat('NOTE:  ', sum(age.days < 0, na.rm=TRUE), ' records with slaugher date after birth date\n', sep='')
		
		animaltype <- c('young','old')[(age.days >= age.cutoff) + 1]
		thedata[,birth.date] <- animaltype
	}
  
  if(length(code)>1){
    
    names(thedata) <- c('farm', 'abattoir', 'slaughter.date', 'animal.type', paste('code',1:length(code),sep='.'))
    
    for(i in 1:length(code)){
        thedata[,paste('code',i,sep='.')] <- gsub('["\']','',thedata[,paste('code',i,sep='.')])
      if(!(all(na.omit(thedata[,paste('code',i,sep='.')]) %in% c('0','1')))){
        cat('NOTE:  Unrecognised codes found - ensure all entries are 0, 1 or missing (NA)\n')
        thedata[! thedata[,paste('code',i,sep='.')] %in% c('0','1'), paste('code',i,sep='.')] <- NA        
      }
      suppressWarnings(thedata[,paste('code',i,sep='.')] <- as.logical(as.numeric(thedata[,paste('code',i,sep='.')])))
    }

    thedata$code <- apply(thedata[,paste('code',1:length(code),sep='.')],1,any)
    
    thedata <- thedata[,c('farm', 'abattoir', 'slaughter.date', 'animal.type', 'code')]
    
  }else{
    
    names(thedata) <- c('farm', 'abattoir', 'slaughter.date', 'animal.type', 'code')
    thedata$code <- gsub('["\']','',thedata$code)
    if(!(all(na.omit(thedata$code) %in% c('0','1'))))
      cat('NOTE:  Unrecognised codes found - ensure all entries are 0, 1 or missing (NA)\n')
    
    suppressWarnings(thedata$code <- as.logical(as.numeric(thedata$code)))
    thedata$code[! thedata$code %in% c(0,1)] <- NA
  } 
  
  tozap <- which(grepl('\r',thedata[1,]))
  if(length(tozap)>0){
    thedata[,tozap] <- gsub('\r','',thedata[,tozap])
  } 
  
  thedata$farm <- gsub('["\']','',thedata$farm)
  thedata$abattoir <- gsub('["\']','',thedata$abattoir)
  thedata$animal.type <- gsub('["\']','',thedata$animal.type)
  
	if(all(is.na(thedata$code))){
		abattoir <- unique(thedata$abattoir)
		slprivate$abattoirnames <- abattoir[!is.na(abattoir) & abattoir!="" & abattoir!=0]
		slprivate$daterange <- range(thedata$slaughter.date, na.rm=TRUE)
		stop('All codes failed coercion to logical')
	}
	
	if(all(is.na(thedata$farm)))
		stop('All farm identifications were missing')
	if(all(is.na(thedata$abattoir)))
		stop('All abattoir identifications were missing')
	if(all(is.na(thedata$animal.type)))
		stop('All animal.type identifications were missing')
	
  
  cat('Returning ', nrow(thedata), ' records\n', sep='')
    
  return(thedata)
  
}

#' @rdname FVSTmodel
#' @export
aggregateFVSTdata <- function(dataframe, type, aggregate='farm:abattoir', date.range=NA, warn.missing=TRUE){
  	
	cat('Aggregating data...\n')
	
	if(warn.missing){
		dataframe$farm[dataframe$farm==""] <- NA
	    if(any(is.na(dataframe$farm)))
	      cat('NOTE:  ', sum(is.na(dataframe$farm)), ' records with missing/blank farm ID were removed\n', sep='')
	    if(any(dataframe$farm==0, na.rm=TRUE))
	      cat('NOTE:  ', sum(dataframe$farm==0, na.rm=TRUE), ' records with farm ID = 0 were removed\n', sep='')
		dataframe$abattoir[dataframe$abattoir==""] <- NA
	    if(any(is.na(dataframe$abattoir)))
	      cat('NOTE:  ', sum(is.na(dataframe$abattoir)), ' records with missing/blank abattoir ID were removed\n', sep='')
	    if(any(dataframe$abattoir==0, na.rm=TRUE))
	      cat('NOTE:  ', sum(dataframe$abattoir==0, na.rm=TRUE), ' records with abattoir ID = 0 were removed\n', sep='')
	    if(any(is.na(dataframe$code)))
	      cat('NOTE:  ', sum(is.na(dataframe$code)), ' records with missing code were removed\n', sep='')
		dataframe$animal.type[dataframe$animal.type==""] <- NA
	    if(any(is.na(dataframe$animal.type)))
	  	  cat('NOTE:  ', sum(is.na(dataframe$animal.type)), ' records with missing/blank animal type were removed\n', sep='')
  	}
	# Get rid of no visible binding issue:
	farm=abattoir=animal.type=code=slaughter.date <- NA
	
	nstart <- nrow(dataframe)
    dataframe <- dataframe %>%
      filter(!is.na(farm), farm!="", farm!=0, !is.na(abattoir), abattoir!="", abattoir!=0, !is.na(animal.type), animal.type!="", !is.na(code))
  	nend <- nrow(dataframe)
  
	if(min(dataframe$slaughter.date) < as.Date('1900-01-01'))
		stop('The earliest slaughter date appears to be before 1900 - have you remembered to specify dateformat?')
	if(max(dataframe$slaughter.date) > Sys.Date())
		stop('The latest slaughter date appears to be in the future - have you remembered to specify dateformat?')
	if(max(dataframe$slaughter.date)-min(dataframe$slaughter.date) > 365*100)
		stop('The range of slaughter dates appears to cover more than a 100 year period - have you remembered to specify dateformat?')
	
	if(identical(date.range, NA))
		date.range <- range(dataframe$slaughter.date)
	if(length(date.range)!=2 || date.range[1]>date.range[2] || any(date.range < 0))
		stop('The date.range supplied must be 2 dates specifying the range [min, max) of dates to be used - leave missing to use all dates in the data')
	
	aggregate <- gsub('*',':',aggregate, fixed=TRUE)
	options <- c('farm','abattoir','date','farm:abattoir','farm:abattoir:date','abattoir:date','farm:date')
	if(!aggregate %in% options)
		stop('Unrecognised aggregation option - consult the help file for ?aggregateFVSTdata')
	
	dataframe <- dataframe %>%
		filter(slaughter.date >= date.range[1], slaughter.date < date.range[2]) %>%
		filter(animal.type == type)
	
		if(nrow(dataframe)==0)
			stop('No matching slaughter dates and/or animal types found')
	
	if(aggregate=='farm:abattoir'){
		cdf <- dataframe %>%
			group_by(farm, abattoir) %>%
			summarise(N=n(), NP=sum(code))

		cdf$resp <- cbind(cdf$NP, cdf$N-cdf$NP)
		cdf$batch <- factor(1:nrow(cdf))
		cdf$farm <- factor(cdf$farm)
		cdf$abattoir <- factor(cdf$abattoir)
	}else if(aggregate=='farm'){
		cdf <- dataframe %>%
			group_by(farm) %>%
			summarise(N=n(), NP=sum(code))

		cdf$resp <- cbind(cdf$NP, cdf$N-cdf$NP)
		cdf$batch <- factor(1:nrow(cdf))
		cdf$farm <- factor(cdf$farm)
		
	}else if(aggregate=='abattoir'){
		cdf <- dataframe %>%
			group_by(abattoir) %>%
			summarise(N=n(), NP=sum(code))

		cdf$resp <- cbind(cdf$NP, cdf$N-cdf$NP)
		cdf$batch <- factor(1:nrow(cdf))
		cdf$abattoir <- factor(cdf$abattoir)
		
	}else if(aggregate=='date'){
		cdf <- dataframe %>%
			group_by(slaughter.date) %>%
			summarise(N=n(), NP=sum(code))

		cdf$resp <- cbind(cdf$NP, cdf$N-cdf$NP)
		
	}else if(aggregate=='farm:abattoir:date'){
		cdf <- dataframe %>%
			group_by(farm, abattoir, date) %>%
			summarise(N=n(), NP=sum(code))

		cdf$resp <- cbind(cdf$NP, cdf$N-cdf$NP)
		cdf$batch <- factor(1:nrow(cdf))
		cdf$abattoir <- factor(cdf$abattoir)
		cdf$farm <- factor(cdf$farm)
		
	}else if(aggregate=='abattoir:date'){
		cdf <- dataframe %>%
			group_by(abattoir, date) %>%
			summarise(N=n(), NP=sum(code))

		cdf$resp <- cbind(cdf$NP, cdf$N-cdf$NP)
		cdf$batch <- factor(1:nrow(cdf))
		cdf$abattoir <- factor(cdf$abattoir)
		
	}else if(aggregate=='farm:date'){
		cdf <- dataframe %>%
			group_by(farm, date) %>%
			summarise(N=n(), NP=sum(code))

		cdf$resp <- cbind(cdf$NP, cdf$N-cdf$NP)
		cdf$batch <- factor(1:nrow(cdf))
		cdf$farm <- factor(cdf$farm)
		
	}
	
	return(cdf)
	
}

#' @rdname FVSTmodel
#' @export
FVSTmodel <- function(data, n=24, mc.cores=min(2, detectCores()), max=1000, confidence=99, seed=NULL, new.levels='batch', control=glmerControl()){
	
	cat('Obtaining best model fit using ', mc.cores, ' parallel processors...\n', sep='')
	
	if(!is.data.frame(data) || !all(c('resp','batch','farm','abattoir') %in% names(data)))
		stop('Invalid data frame provided - this must match the output of aggregateFVSTdata with abattoir and farm as aggregation variables')
	
	cdf <- data
	formulae <- c('resp ~ (1 | batch)','resp ~ (1 | batch) + (1 | abattoir)','resp ~ (1 | batch) + (1 | farm)','resp ~ (1 | batch) + (1 | farm) + (1 | abattoir)')
	
	# If we have too few observations, skip:
	if(sum(cdf$NP > 0) < 50){
		return(list(model=paste('Too few (', sum(cdf$NP > 0), ') positive batches', sep=''), fit=NULL, fitwarn=NULL, pval=NULL))
	}
	if(all(cdf$NP <= 1)){
		return(list(model=paste('All ', sum(cdf$NP > 0), ' positive batches had zero or one positive animal', sep=''), fit=NULL, fitwarn=NULL, pval=NULL))
	}
	
	ntest <- 1
	atest <- 2
	finaltest <- length(formulae)==atest
	finalfit <- NA
	finalmod <- NA
	
	repeat{
		nullfit <- tryCatchWE(glmer(formulae[ntest], data=cdf, family=binomial, control=control))
		altfit <- tryCatchWE(glmer(formulae[atest], data=cdf, family=binomial, control=control))
	
		if(!is.null(nullfit$error)){
			return(list(model=paste('Error in model ', ntest, sep=''), fit=NULL, fitwarn=NULL, pval=NULL))	
		}	
		if(!is.null(altfit$error)){
			return(list(model=paste('Error in model ', atest, sep=''), fit=NULL, fitwarn=NULL, pval=NULL))	
		}	
	
		temp <- LRbootstrap(nullfit$value, altfit$value, n=n, mc.cores=mc.cores, new.levels=new.levels, max=max, confidence=confidence, seed=seed, callobjects=list(control=control))
		rejdec <- temp$rejectnull
		pval <- temp$pval
	
		if(is.na(rejdec)){
			return(list(model=paste('Error in model ', ntest, ' vs ', atest, ' comparison', sep=''), fit=NULL, fitwarn=NULL, pval=NULL))	
		}
		
#		print('REMOVEME')
#		rejdec <- TRUE
		
		if(rejdec){
			if(length(formulae)==atest){
				finalfit <- altfit
				finalmod <- atest
				break
			}
			ntest <- atest
			atest <- 4
			next
		}else{
			if(length(formulae)==atest || atest==3){
				finalmod <- ntest
				finalfit <- nullfit
				break
			}
			if(atest==2){
				atest <- 3
				next
			}
		}		
	}
	if(identical(finalmod, NA))
		return(list(model='No model chosen for some reason - please submit a bug report to the package maintainer', fit=NULL, fitwarn=NULL, pval=NULL))
	
	return(list(model=formulae[finalmod], fit=finalfit$value, fitwarn=finalfit$warning))
	
}

#' @rdname FVSTmodel
#' @export
FVSTsummary <- function(model, confint=TRUE, mc.cores=detectCores(), simulations=250, new.levels='all', seed=NULL, callobjects=list(control=glmerControl())){
	
	if(class(model)=='list' && names(model)[2]=='fit')
		model <- model$fit
	
	exfun1 <- function(x) return(c(deviance(x),unlist(VarCorr(x))))
	exfun2 <- function(x) return(ranef(x)$abattoir[,1])
	means <- exfun1(model)
	
	colnames <- c('Model', names(VarCorr(model)))
	types <- c('Deviance', rep('Variance', length(names(VarCorr(model)))))

	mt <- paste(as.character(formula(model)), collapse=' ')
	if(grepl('abattoir', mt)){
		colnames <- c(colnames, dimnames(ranef(model)$abattoir)[[1]])
		means <- c(means, exfun2(model))
		types <- c(types, rep('Coefficient', length(dimnames(ranef(model)$abattoir)[[1]])))
	}
	
	lcis=ucis <- NA
	if(confint){
		cis <- bootci(model=model, simulations, exfun1, mc.cores= mc.cores, new.levels='all', callobjects=callobjects)
	
		mt <- paste(as.character(formula(model)), collapse=' ')
		if(grepl('abattoir', mt)){
			cis <- cbind(cis, bootci(model=model, simulations, exfun2, mc.cores= mc.cores, new.levels=new.levels, callobjects=callobjects))
		}
	
		dimnames(cis) <- NULL
		lcis <- apply(cis,2,quantile,prob=0.025, na.rm=TRUE)  # cis guaranteed to be all missing if any persistently failed
		ucis <- apply(cis,2,quantile,prob=0.975, na.rm=TRUE)
	
	}
	
	names(means) <- NULL
	names(lcis) <- NULL
	names(ucis) <- NULL
	
	cis <- data.frame(Parameter=types, Group=colnames, Estimate=means, Lower.95=lcis, Upper.95=ucis)
	return(cis)
	
}



tryCatchWE <- function(expr) 
{ 
    W <- NULL 
    w.handler <- function(w){ # warning handler 
        W <<- w 
        invokeRestart("muffleWarning") 
    } 
	value <- withCallingHandlers(tryCatch(expr, error = function(e) e), warning = w.handler)
	E <- if(any(class(value)=='error')) value else NULL
    return(list(value=value, error=E, warning = W))
} 
