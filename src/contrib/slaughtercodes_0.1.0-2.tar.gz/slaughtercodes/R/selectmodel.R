#' @title Model comparison using bootstrapped likelihood ratios
#' @name LRbootstrap
#' @aliases LRbootstrap

#' @description
#' Model comparison using a bootstrapped likelihood ratio test

#' @return
#' readFVSTdata returns a (large) dataframe of individual observations, aggregateFVSTdata returns a smaller dataframe with observations grouped at the specified levels, FVSTmodel returns the model of best fit, and FVSTsummary returns summary statistics obtained from this model (plus bootstrapped confidence intervals if confint=TRUE)

#' @references
#' Random effect selection in generalised linear models: a practical application to slaughterhouse surveillance data in Denmark. 2015.  Denwood, M., Houe, H., Forkman, B. & Nielsen, S. S. Proceedings of the Society for Veterinary Epidemiology and Preventive Medicine, 26 Mar 2015.  

#' @examples
#' library('lme4')
#' alt <- glmer(cbind(incidence, size - incidence) 
#'        ~ period + (1 | herd), data = cbpp, family = binomial)
#' null <- glmer(cbind(incidence, size - incidence) 
#'        ~ (1 | herd), data = cbpp, family = binomial)
#' LRbootstrap(null, alt, mc.cores=2)

#' @param nullmodel the null fitted model
#' @param altmodel the alternative fitted model
#' @param n the number of bootstrap simulations to use per block
#' @param alpha the desired significance level for model fit comparison
#' @param mc.cores the number of parallel cores to use
#' @param new.levels the new levels to be generated in the simulated data (as opposed to using random effect level coefficients from the real model)
#' @param max the maximum number of bootstrap simulations to use
#' @param confidence the confidence level for the numerical approximation to the p-value
#' @param seed an optional RNG state for data simulation
#' @param callobjects a list of objects required to be available for the lme4 function call

#' @rdname LRbootstrap
#' @export
LRbootstrap <- function(nullmodel, altmodel, n=12, alpha=0.05, mc.cores=min(n, detectCores()), new.levels=character(0), max=1000, confidence=99, seed=NULL, callobjects=list()){

	t <- Sys.time()
	truedev <- deviance(nullmodel) - deviance(altmodel)
	bootdevs <- rep(NA, max)
	
	if(confidence<=0 || confidence>=100) stop('confidence must be >0 and <100')
	confidence <- (confidence/100)
	
	if(is.null(getCall(nullmodel)$data) || is.null(getCall(altmodel)$data))
    stop('Both model calls must use a data frame as data')
	nullenv <- new.env()
	altenv <- new.env()
	assign('data', model.frame(nullmodel), envir=nullenv)
	assign('data', model.frame(altmodel), envir=altenv)
	
	if(length(callobjects)>0){
		for(i in 1:length(callobjects)){
			assign(names(callobjects)[i], callobjects[[i]], envir=nullenv)
			assign(names(callobjects)[i], callobjects[[i]], envir=altenv)
		}
	}
	
	nullcall <- update(nullmodel, formula='thesimdata ~ .', data=data, evaluate=FALSE)
	altcall <- update(altmodel, formula='thesimdata ~ .', data=data, evaluate=FALSE)
	
	# Doesn't work with simulate.merMod as expected:
	#newdata <- model.frame(altmodel)
	# Create new levels:
	#if(length(new.levels)>0) for(i in 1:length(new.levels)){
	#	if(!new.levels[i] %in% names(newdata))
	#		stop(paste('Unrecognised factor: ', new.levels[i]))
		
	#	newdata[,as.character(new.levels[i])] <- paste('newlevel_', as.character(newdata[,as.character(new.levels[i])]), sep='')
	#}
	
  for(i in 1:ceiling(max/n)){
    
    sdt <- Sys.time()
    simdata <- simulate.re(nullmodel, n, new.levels)
    #cat(difftime(Sys.time(), sdt), ' to simulate data\n')
    
    #simdata <- simulate(nullmodel, nsim=n, newdata=newdata, allow.new.levels=TRUE)
		bootdevs[((n*(i-1))+1):(n*i)] <- unlist(mclapply(1:n, bootf, mc.cores=mc.cores, mc.preschedule=TRUE, nullcall=nullcall, altcall=altcall, nullenv=nullenv, altenv=altenv, simdata=simdata))
		if(all(is.na(bootdevs))){
			return(list(rejectnull=NA, truedev=truedev, pval=NA, conf=NA, bootdevs=bootdevs[1:(n*i)], time=difftime(Sys.time(), t, units='secs')))
		}

    # Need two ways of stopping - firstly wilcox.test says we're a long way from the bootdevs, secondly proportion definitely different (probably higher) than 0.05:
	# BUT wilcox test is comparing the median which is wrong - can't do this without some kind of distributional assumption
	# i.e. if looking at ranks we need at least 90 worse (with 0 better) to be sure p<=0.05, although fewer would be needed assuming normality of the bootstraps
	# If the bootstrap overlaps the observed well (like 5 better, 5 worse) we can quickly accept null
#		wilcoxp <- suppressWarnings(wilcox.test(bootdevs,mu=truedev)$p.value)
		
		better <- sum(truedev<bootdevs,na.rm=TRUE)
		worse <- sum(truedev>=bootdevs,na.rm=TRUE)
    # The probability that the probability of observing the observed LR statistic under the null hypothesis is less than 0.05:
		probreject <- pbeta(alpha, better+1, worse+1)
		probfailtoreject <- 1-probreject
#		if(probreject >= confidence || probfailtoreject >= confidence || wilcoxp <= (1-confidence)){
		if(probreject >= confidence || probfailtoreject >= confidence){
			bootdevs <- bootdevs[1:(n*i)]
			break
		}
	}
  
  pval <- better/(better+worse)
	return(list(rejectnull=pval<alpha, truedev=truedev, pval=pval, probreject=probreject, bootdevs=bootdevs, time=difftime(Sys.time(), t, units='secs')))
}

bootf <- function(i, nullcall, altcall, nullenv, altenv, simdata){
  #  require('lme4')
  
  nullenv$data$thesimdata <- simdata[[i]]
  altenv$data$thesimdata <- simdata[[i]]
  
  success <- try({
  nullsim <- eval(nullcall, envir=nullenv, enclos=parent.frame())
  altsim <- eval(altcall, envir=altenv, enclos=parent.frame())
  dd <- deviance(nullsim) - deviance(altsim)
  })
  if(class(success)=='try-error')
    dd <- NA
  
  return(dd)
}

