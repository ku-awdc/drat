#' A package for model comparison via bootstrapping and analysis of FVST data
#'
#' To get started see one of the following vignettes:
#' vignette('fvst', package='slaughtercodes')
#' vignette('comparison', package='slaughtercodes')
#'
#' @docType package
#' @name slaughtercodes
#' @import parallel
#' @import dplyr
#' @import lme4
#' @importFrom sqldf sqldf
#' @importFrom sqldf read.csv.sql
#' @importFrom MASS mvrnorm
NULL

#' An example dataset for FVST analysis
#'
#' This demonstrates the format and minimum information required for FVST analysis functions.  The variables are as follows:
#'
#' \itemize{
#'   \item abattoir The abattoir
#'   \item farm The farm of origin
#'   \item date The date of slaughter
#'   \item type The type of animal (optional if birth date is specified)
#'	 \item birth The birth date of the animal (optional if type is specified)
#'   \item code1 Occurance or absence of a recorded code
#'   \item code2 Occurance or absence of a recorded code
#' }
#'
#' See vignette('fvst') for example of usage
#' @format A data frame in the required format for input to aggregate data
#' @name exampleFVST_1
#' @aliases exampleFVST_1 exampleFVST_2
NULL

#' @title The pig and cow FVST slaughter codes
#' @name pigcodes
#' @aliases pigcodes cowcodes

#' @description
#' A simple function to return the slaughter codes as used in the FVST data that KU have access to

#' @return
#' A list of vectors of codes

#' @seealso
#' \code{\link{FVSTanalysis}}

#' @param individual if TRUE then all codes are returned individually, if FALSE then each element of the list corresponds to one or more related codes as identified by KU as a farm related welfare concern

#' @rdname pigcodes
#' @export
pigcodes <- function(individual=FALSE){
	if(individual){
		return(list("dcode101", "dcode111", "dcode113", "dcode114", "dcode120", "dcode131", "dcode132", "dcode141", "dcode181", "dcode203", "dcode221", "dcode222", "dcode230", "dcode250", "dcode258", "dcode271", "dcode287", "dcode289", "dcode320", "dcode325", "dcode331", "dcode336", "dcode337", "dcode350", "dcode352", "dcode361", "dcode371", "dcode379", "dcode381", "dcode382", "dcode385", "dcode402", "dcode409", "dcode412", "dcode431", "dcode432", "dcode446", "dcode451", "dcode471", "dcode472", "dcode501", "dcode502", "dcode503", "dcode504", "dcode505", "dcode506", "dcode507", "dcode511", "dcode531", "dcode532", "dcode535", "dcode542", "dcode551", "dcode565", "dcode570", "dcode572", "dcode577", "dcode580", "dcode584", "dcode585", "dcode600", "dcode601", "dcode602", "dcode603", "dcode608", "dcode615", "dcode634", "dcode668", "dcode671", "dcode815", "dcode829", "dcode890", "dcode901", "dcode903", "dcode904", "dcode990", "dcode910", "dcode991", "dcode993", "dcode995"))
	}else{
		return(lapply(list(120, 131, 132, 141, 222, 230, 250, 258, 325, 336, 352, 361, 432, 446, 451, 472, 511, 532, 572, 615, 634, 668, 671, c(271,289), c(331,337), c(379,381), c(409,412), c(502,503), c(505,507), c(570,577,580,584,585), c(600,601)), function(x) return(paste('dcode',x,sep=''))))
	}
}
	
#' @rdname pigcodes
#' @export
cowcodes <- function(individual=FALSE){
	if(individual){
		return(list("dcode101", "dcode113", "dcode115", "dcode116", "dcode119", "dcode120", "dcode131", "dcode133", "dcode141", "dcode181", "dcode204", "dcode221", "dcode222", "dcode223", "dcode230", "dcode258", "dcode271", "dcode287", "dcode289", "dcode291", "dcode304", "dcode320", "dcode325", "dcode334", "dcode335", "dcode336", "dcode350", "dcode352", "dcode361", "dcode365", "dcode371", "dcode374", "dcode375", "dcode377", "dcode379", "dcode381", "dcode382", "dcode402", "dcode412", "dcode431", "dcode432", "dcode446", "dcode451", "dcode471", "dcode472", "dcode476", "dcode501", "dcode502", "dcode503", "dcode504", "dcode505", "dcode506", "dcode507", "dcode509", "dcode511", "dcode524", "dcode531", "dcode532", "dcode535", "dcode536", "dcode537", "dcode538", "dcode542", "dcode551", "dcode560", "dcode561", "dcode562", "dcode563", "dcode565", "dcode570", "dcode572", "dcode574", "dcode577", "dcode580", "dcode584", "dcode585", "dcode600", "dcode602", "dcode603", "dcode604", "dcode631", "dcode641", "dcode668", "dcode807", "dcode815", "dcode890", "dcode931", "dcode936", "dcode940", "dcode949", "dcode950", "dcode951", "dcode993", "dcode995"))
	}else{
		return(lapply(list(120, 131, 133, 141, 230, 291, 325, 336, 361, 412, 432, 446, 509, 511, 532, 572, 600, 603, 668, 807, c(271,289), c(222,223,352), c(374,375,377,379,381), c(570,577,580,584,585), c(472,476), c(502,503), c(505,507), c(602,604), c(631,641)), function(x) return(paste('dcode',x,sep=''))))
	}
}



#' @title Analysis of FVST slaughter codes
#' @name FVSTanalysis
#' @export

#' @description
#' A wrapper function to analyse one or more slaughter codes (or combinations of slaugher codes) from a single dataset

#' @return
#' A list with two elements:  a data frame with character strings of summarised results with confidence intervals, and the same dataset but without confidence intervals (with numbers as numerics)

#' @seealso
#' \code{\link{readFVSTdata}}, \code{\link{aggregateFVSTdata}}, \code{\link{FVSTmodel}} and \code{\link{FVSTsummary}} for the underlying functions that provide more options for running the sequence manually

#' @examples
#' # Example 1:
#' data('exampleFVST_1')
#' write.csv(exampleFVST_1, file='testdata.csv')
#' results <- FVSTanalysis(codelist=list('code1', 'code2', c('code1','code2')), animaltype=c('sow', 'pig'), datafilename='testdata.csv', confint=TRUE, mc.cores=2, abattoircolumn='abattoir', farmcolumn='farm', datecolumn='date', typecolumn='type')
#'
#'
#' # Example 2:
#' data('exampleFVST_2')
#' write.csv(exampleFVST_2, file='testdata.csv')
#' results <- FVSTanalysis(codelist=list('code1', 'code2', c('code1','code2')), animaltype=c('calf', 'cow'), datafilename='testdata.csv', model=FALSE, mc.cores=2, abattoircolumn='abattoir', farmcolumn='farm', datecolumn='date', birthdatecolumn='birth')
#' unlink('testdata.csv')
#'
#' # Example 3 - what happens with a missing code3:
#' data('exampleFVST_2')
#' write.csv(exampleFVST_2, file='testdata.csv')
#' results <- FVSTanalysis(codelist=list('code1', c('code1','code3')), animaltype=c('calf', 'cow'), datafilename='testdata.csv', model=FALSE, mc.cores=2, abattoircolumn='abattoir', farmcolumn='farm', datecolumn='date', birthdatecolumn='birth')
#' unlink('testdata.csv')
#' @param codelist a list of codes (or vectors of related codes) to be extracted from the file and analysed
#' @param animaltype a vector of animal types to be analysed from 'cow', 'caf', 'pig', 'sow'
#' @param datafilename the file name for the data
#' @param write.file should a results file be written to disk as the analysis proceeds?
#' @param outputfilename the first part of the name for the file (the date range and ci/noci will be appended automatically)
#' @param model should the model be run?  Otherwise, just summary statistics (number of positive and negative animals etc) will be returned.
#' @param confint should confidence intervals be computed (ignored if model=FALSE)?
#' @param mc.cores the number of parallel cores to use
#' @param ... additional options to be passed to \code{\link{readFVSTdata}}




#' @rdname FVSTanalysis
FVSTanalysis <- function(codelist, animaltype, datafilename, write.file=TRUE, outputfilename='results', model=TRUE, confint=model, mc.cores=detectCores(), ...){
	
	for(i in 1:length(codelist)){
		codes <- codelist[[i]]
		cat('Analysing code "', paste(codes, collapse=''), '" at ', strftime(Sys.time()), '...\n', sep='')
		
		newres <- runfvst(codes=codes, animaltype=animaltype, datafilename=datafilename, model=model, confint=confint, mc.cores=mc.cores, ...)

	    if(i==1){
	      allresm <- newres$noci
	      allresci <- newres$withci
	    }else{
	      allresm <- rbind(allresm, newres$noci)
	      allresci <- rbind(allresci, newres$withci)
	    }
	
		cat('Finished code ', paste(codes, collapse=''), ' at ', strftime(Sys.time()), '\n\n', sep='')
    	year <- allresm[1,'Year']
		
		if(write.file){
			write.csv(allresm, file=paste(outputfilename, '_', year, '_noci.csv', sep=''), row.names=FALSE)

			if(confint)
				write.csv(allresci, file=paste(outputfilename, '_', year, '_withci.csv', sep=''), row.names=FALSE)
		}
	}
	
	if(!confint || !model)
		allresci <- 'No confidence intervals produced when confint=FALSE or model=FALSE'
		
	return(list(withci=allresci, noci=allresm))
	
}

# NOT exported
runfvst <- function(codes, animaltype=c('calf', 'cow'), datafilename='/Users/matthewdenwood/Documents/Research/Projects/Welfare Codes/data/cattle2012_93codes.csv', model=TRUE, confint=TRUE, mc.cores=detectCores(), warn.missing=TRUE, date.range=NA, ...){
	
    success <- try(data <- readFVSTdata(codes, datafilename, ...), silent=TRUE)
	if(class(success)=='try-error'){
		if(!(grepl('specified code columns was not found', as.character(success)) || grepl('All codes failed coercion to logical', as.character(success))) || is.null(slprivate$abattoirnames) || is.null(slprivate$daterange))
			stop(as.character(success))
		
		allabs <- sort(slprivate$abattoirnames)
		date.range <- slprivate$daterange
		if(strftime(date.range[1], format='%Y')==strftime(date.range[2], format='%Y') && (date.range[2]-date.range[1])>=300)
			year <- strftime(date.range[1], format='%Y')
		else
			year <- paste(strftime(date.range[1], format='%Y/%m/%d'), ' - ', strftime(date.range[2], format='%Y/%m/%d'), sep='')
		
		
		for(a in 1:length(animaltype)){
		
			nfarms <- ''
			nabattoirs <- ''
			nnegbatches <- ''
			nposbatches <- ''
			npos <- ''
			nneg <- ''
			nremoved <- ''
			
			farmvarm=abvarm=residvarm <- ''
			farmvarci=abvarci=residvarci <- '--'
			specvarsm <- sapply(allabs, function(x) return(''))
			specvarsci <- sapply(allabs, function(x) return('--'))
			names(specvarsm)=names(specvarsci) <- allabs
			
			if(grepl('specified code columns was not found', as.character(success))){
				comment <- if(length(codes)>1) "One or more of the specified codes was not found in the data" else "The specified code was not found in the data"
			}
			if(grepl('All codes failed coercion to logical', as.character(success))){
				comment <- if(length(codes)>1) "All of the combined codes failed coercion to logical" else "All of the codes failed coercion to logical"
			}
			
			pastedcodes <- paste(codes, collapse='+')
		
			names(specvarsm) <- paste('Ab.', names(specvarsm), sep='')
			names(specvarsci) <- paste('Ab.', names(specvarsci), sep='')
		
			baseinfo <- c(AnimalType=animaltype[a], Code=pastedcodes, Year=year, NFarms=nfarms, NAbattoirs=nabattoirs, PositiveBatches=nposbatches, NegativeBatches=nnegbatches, PositiveAnimals=npos, NegativeAnimals=nneg, RemovedAnimals=nremoved)
		
			toret <- list(noci=c(baseinfo, abattoir=abvarm, farm=farmvarm, residual=residvarm, specvarsm, Comment=comment), withci=c(baseinfo, abattoir=abvarci, farm=farmvarci, residual=residvarci, specvarsci, Comment=comment))
		
			if(a==1){
				allresults <- toret			
			}else{			
				allresults$noci <- rbind(allresults$noci, toret$noci)
				allresults$withci <- rbind(allresults$withci, toret$withci)
			}
		}
		return(allresults)		
	}
	
	
  	if(identical(date.range, NA)){
  		date.range <- range(data$slaughter.date, na.rm=TRUE)
  	}
	date.range <- sort(date.range)
	if(strftime(date.range[1], format='%Y')==strftime(date.range[2], format='%Y') && (date.range[2]-date.range[1])>=300)
		year <- strftime(date.range[1], format='%Y')
	else
		year <- paste(strftime(date.range[1], format='%Y/%m/%d'), ' - ', strftime(date.range[2], format='%Y/%m/%d'), sep='')
	
	# Get rid of no visible binding issue:
	farm=abattoir=animal.type=code <- NA
	
	# Do this before removing otherwise missing codes for some abattoirs only will break rbind
	allabs <- sort(unique(data$abattoir))
	allabs <- allabs[allabs!='' & allabs!=0 & !is.na(allabs)]
	
	if(warn.missing){
		data$farm[data$farm==""] <- NA
	    if(any(is.na(data$farm)))
	      cat('NOTE:  ', sum(is.na(data$farm)), ' records with missing/blank farm ID were removed\n', sep='')
	    if(any(data$farm==0, na.rm=TRUE))
	      cat('NOTE:  ', sum(data$farm==0, na.rm=TRUE), ' records with farm ID = 0 were removed\n', sep='')
		data$abattoir[data$abattoir==""] <- NA
	    if(any(is.na(data$abattoir)))
	      cat('NOTE:  ', sum(is.na(data$abattoir)), ' records with missing/blank abattoir ID were removed\n', sep='')
	    if(any(data$abattoir==0, na.rm=TRUE))
	      cat('NOTE:  ', sum(data$abattoir==0, na.rm=TRUE), ' records with abattoir ID = 0 were removed\n', sep='')
	    if(any(is.na(data$code)))
	      cat('NOTE:  ', sum(is.na(data$code)), ' records with missing code were removed\n', sep='')
		data$animal.type[data$animal.type==""] <- NA
	    if(any(is.na(data$animal.type)))
	  	  cat('NOTE:  ', sum(is.na(data$animal.type)), ' records with missing/blank animal type were removed\n', sep='')
  	}
		
	nstart <- nrow(data)
    data <- data %>%
      filter(!is.na(farm), farm!="", farm!=0, !is.na(abattoir), abattoir!="", abattoir!=0, !is.na(animal.type), animal.type!="", !is.na(code))
  	nremoved <- nstart-nrow(data)
	  	
	for(a in 1:length(animaltype)){
		
		type <- animaltype[a]
		dataantype <- as.character(type)
		if(!dataantype %in% unique(as.character(data$animal.type))){
			if(dataantype%in%c('calf', 'pig'))
				dataantype <- 'young'
			if(dataantype%in%c('cow', 'sow'))
				dataantype <- 'old'
		}
		
		cat('Getting model for animal type "', type, '"...\n', sep='')
		cdf <- aggregateFVSTdata(data, type=dataantype, date.range=date.range, warn.missing=FALSE)
		
		nfarms <- length(levels(cdf$farm))
		nabattoirs <- length(levels(cdf$abattoir))
		nnegbatches <- sum(cdf$NP == 0)
		nposbatches <- sum(cdf$NP > 0)
		stopifnot((nnegbatches+nposbatches)==length(levels(cdf$batch)))
		npos <- sum(cdf$NP)
		nneg <- sum(cdf$N)-npos
		
		
		if(model)
			m <- FVSTmodel(cdf, mc.cores=mc.cores)
		else
			m <- list(model='No model done')
		
		farmvarm=abvarm=residvarm <- ''
		farmvarci=abvarci=residvarci <- '--'
		specvarsm <- sapply(allabs, function(x) return(''))
		specvarsci <- sapply(allabs, function(x) return('--'))
		names(specvarsm)=names(specvarsci) <- allabs
		
		if(!grepl('resp',m$model)){
		  comment <- m$model
		}else{
	      	
			if(confint)
				cat('Getting confidence intervals using ', mc.cores, ' parallel processors...\n', sep='')
			else
				cat('Summarising model...\n')
			
			cis <- FVSTsummary(m, confint=confint, mc.cores=mc.cores)
			digits <- 2
			cis$pasted <- paste(round(cis$Estimate, digits), " (", round(cis$Lower.95, digits), " - ", round(cis$Upper.95, digits), ")", sep="")
			
			if(grepl('abattoir', m$model)){
			  	abvarm <- cis[cis[,'Group']=='abattoir','Estimate']
				abvarci <- cis[cis[,'Group']=='abattoir','pasted']
				fsv <- cis[cis[,'Parameter']=='Coefficient',]
				
        		specvarsm[as.character(fsv$Group)] <- fsv$Estimate
				specvarsci[as.character(fsv$Group)] <- fsv$pasted
        
			}
			if(grepl('farm', m$model)){
			  farmvarm <- cis[cis[,'Group']=='farm','Estimate']
			  farmvarci <- cis[cis[,'Group']=='farm','pasted']
			}
			residvarm <- cis[cis[,'Group']=='batch','Estimate']
			residvarci <- cis[cis[,'Group']=='batch','pasted']
			comment <- ''
			obsdev <- as.numeric(cis[cis[,'Parameter']=='Deviance','Estimate'])
			
			if(confint){
				ldev <- as.numeric(cis[cis[,'Parameter']=='Deviance','Lower.95'])
				udev <- as.numeric(cis[cis[,'Parameter']=='Deviance','Upper.95'])		
				if(obsdev < ldev || obsdev > udev){
					comment <- 'WARNING: suspect model fit (based on bootstrapped deviance)'
				}
			}else{
				comment <- "Note:  model fit assessment was not performed"
			}
		}
		
		pastedcodes <- paste(codes, collapse='+')
		
		names(specvarsm) <- paste('Ab.', names(specvarsm), sep='')
		names(specvarsci) <- paste('Ab.', names(specvarsci), sep='')
		
		baseinfo <- c(AnimalType=animaltype[a], Code=pastedcodes, Year=year, NFarms=nfarms, NAbattoirs=nabattoirs, PositiveBatches=nposbatches, NegativeBatches=nnegbatches, PositiveAnimals=npos, NegativeAnimals=nneg, RemovedAnimals=nremoved)
		
		toret <- list(noci=c(baseinfo, abattoir=abvarm, farm=farmvarm, residual=residvarm, specvarsm, Comment=comment), withci=c(baseinfo, abattoir=abvarci, farm=farmvarci, residual=residvarci, specvarsci, Comment=comment))
		
		if(a==1){
			allresults <- toret			
		}else{			
			allresults$noci <- rbind(allresults$noci, toret$noci)
			allresults$withci <- rbind(allresults$withci, toret$withci)
		}
	}
	
	return(allresults)	
	
}

slprivate <- new.env()
assign("abattoirnames", NULL, envir=slprivate)
assign("daterange", NULL, envir=slprivate)
