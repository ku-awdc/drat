## ------------------------------------------------------------------------
library('slaughtercodes')

data('exampleFVST_1')
write.csv(exampleFVST_1, file='testdata.csv')
head(exampleFVST_1)

## ------------------------------------------------------------------------
results <- FVSTanalysis(codelist=list('code1', c('code1','code2')), animaltype=c('sow', 'pig'), datafilename='testdata.csv', confint=FALSE, mc.cores=2, abattoircolumn='abattoir', farmcolumn='farm', datecolumn='date', typecolumn='type')
results
# Cleanup:
unlink('testdata.csv')
unlink('results_2001_noci.csv')
unlink('results_2001_withci.csv')

## ------------------------------------------------------------------------
library('slaughtercodes')

data('exampleFVST_2')
write.csv(exampleFVST_2, file='testdata.csv')
head(exampleFVST_2)

## ------------------------------------------------------------------------
results <- FVSTanalysis(codelist=list('code1', 'code2'), animaltype=c('cow', 'calf'), datafilename='testdata.csv', model=FALSE, mc.cores=2, abattoircolumn='abattoir', farmcolumn='farm', datecolumn='date', typecolumn='type')
results
# Cleanup:
unlink('testdata.csv')
unlink('results_2001_noci.csv')

## ------------------------------------------------------------------------
citation('slaughtercodes')

## ------------------------------------------------------------------------
sessionInfo()

